'use client';

import s from './startup.module.css';

export default function Startup({ failed = false }: { failed?: boolean }) {
  return <main className={s.screen}>
    <section className={s.card} aria-live="polite">
      <h1>高陞機電維修</h1>
      <p role={failed ? 'alert' : 'status'}>{failed ? '頁面未能載入，請重新整理再試。' : '正在開啟系統…'}</p>
      <a className={s.button} href={failed ? '/?screen=login&switchAccount=1' : ''}>
        {failed ? '返回登入頁' : '重新整理'}
      </a>
    </section>
  </main>;
}
