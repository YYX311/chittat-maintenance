import { getStaff } from "../../../../lib/access";
import { saveCase } from "../../../../lib/case-service";
import { transaction } from "../../../../lib/db";
import { apiError, jsonBody, sameOrigin } from "../../../../lib/http";

export const runtime = "nodejs";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request)) return Response.json({ error: "forbidden" }, { status: 403 });
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    const { id } = await params;
    const body = await jsonBody(request);
    const record = await transaction((client) => saveCase(client, staff, id, body));
    return Response.json(record);
  } catch (error) { return apiError(error); }
}
