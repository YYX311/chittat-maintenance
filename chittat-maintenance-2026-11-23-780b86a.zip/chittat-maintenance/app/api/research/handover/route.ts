import { getStaff } from '../../../../lib/access';
import { requireResearchAdmin } from '../../../../lib/research-service';
import { db } from '../../../../lib/db';
import { apiError,jsonBody,sameOrigin } from '../../../../lib/http';
import { dateRange,themes } from '../../../../lib/handover-coding';
export const runtime='nodejs';
const headers={'Cache-Control':'private, no-store'};
async function authorize(request: Request) {
  const staff=await getStaff(request);
  if (!staff) return Response.json({error:'unauthorized'},{status:401,headers});
  requireResearchAdmin(staff);
}
const period="created_at >= ($1::date::timestamp AT TIME ZONE 'Asia/Hong_Kong') AND created_at < (($2::date + 1)::timestamp AT TIME ZONE 'Asia/Hong_Kong')";
export async function GET(request: Request) {
  try {
    const denied=await authorize(request); if(denied) return denied;
    const q=new URL(request.url).searchParams;
    const dates=dateRange(q.get('from'),q.get('to'));
    const page=Number(q.get('page')||1);
    if(!Number.isSafeInteger(page)||page<1||page>1000000) throw Error('invalid-page');
    const result=await db().query(`WITH scoped AS (
      SELECT id,action,created_at,detail FROM audit_events WHERE ${period} AND action IN ('submit','review','return','confirm')
    ), returns AS (
      SELECT s.*,c.theme FROM scoped s LEFT JOIN research_handover_codes c ON c.event_id=s.id WHERE action='return'
    ) SELECT
      COALESCE((SELECT json_agg(x ORDER BY day,action) FROM (SELECT to_char(created_at AT TIME ZONE 'Asia/Hong_Kong','YYYY-MM-DD') AS day, action,count(*)::int count FROM scoped GROUP BY 1,2)x),'[]') daily,
      COALESCE((SELECT json_agg(x) FROM (SELECT theme,count(*)::int count FROM returns GROUP BY theme)x),'[]') codes,
      COALESCE((SELECT json_agg(x ORDER BY at DESC,id::bigint DESC) FROM (SELECT id::text,created_at AS at,detail->>'field' field,detail->>'reason' reason,theme FROM returns ORDER BY created_at DESC,returns.id DESC LIMIT 15 OFFSET $3)x),'[]') returns`,[...dates,(page-1)*15]);
    return Response.json(result.rows[0],{headers});
  } catch(e){return apiError(e);}
}
export async function POST(request:Request) {
  try {
    if(!sameOrigin(request))throw Error('forbidden');
    const denied=await authorize(request); if(denied)return denied;
    const {id,theme}=await jsonBody(request);
    if(typeof id!=='string'||!/^\d{1,18}$/.test(id)||typeof theme!=='string'||!Object.hasOwn(themes,theme))throw Error('invalid-code');
    const result=await db().query(`INSERT INTO research_handover_codes(event_id,theme) SELECT id,$2 FROM audit_events WHERE id=$1 AND action='return'
      ON CONFLICT(event_id) DO UPDATE SET theme=excluded.theme,updated_at=now() RETURNING event_id`,[id,theme]);
    if(!result.rows.length)throw Error('not-found');
    return Response.json({saved:true},{headers});
  } catch(e){return apiError(e);}
}

