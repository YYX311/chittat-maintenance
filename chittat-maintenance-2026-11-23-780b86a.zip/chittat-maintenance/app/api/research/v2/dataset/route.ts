import { getStaff } from '../../../../../lib/access';
import { db } from '../../../../../lib/db';
import { apiError } from '../../../../../lib/http';
import { loadHandoverDataset } from '../../../../../lib/handover-dataset';
import { requireResearchAdmin } from '../../../../../lib/research-service';

export const runtime = 'nodejs';
const headers = { 'Cache-Control': 'private, no-store' };

export async function GET(request: Request) {
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: 'unauthorized' }, { status: 401, headers });
    requireResearchAdmin(staff);
    const dates = new URL(request.url).searchParams;
    return Response.json(await loadHandoverDataset(db(), dates.get('from') ?? '', dates.get('to') ?? ''), { headers });
  } catch (error) {
    return apiError(error);
  }
}
