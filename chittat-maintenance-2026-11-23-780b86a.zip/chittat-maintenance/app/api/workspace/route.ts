import { getStaff } from "../../../lib/access";
import { listCases } from "../../../lib/case-service";
import { db } from "../../../lib/db";
import { apiError } from "../../../lib/http";
import { listProjects } from "../../../lib/project-service";

export const runtime = "nodejs";

export async function GET(request: Request) {
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    const records = await listCases(db(), staff);
    const projects = staff.role === "worker" ? [] : await listProjects(db());
    return Response.json({ version: 4, records, sheets: [], sampleRows: [], parts: [],
      projects, projectRegistry: projects, counters: { worker: 0, office: 0 } },
    { headers: { "Cache-Control": "no-store" } });
  } catch (error) { return apiError(error); }
}
