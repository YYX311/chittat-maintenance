'use client';

import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react';
import { sessionFetch, sessionToken } from '../../src/session-fetch';
import { signInPhone, signOut } from '../../src/server-api';
import { normalizeLoginPhone } from '../../src/phone';
import { analyze, type ResearchDataset } from '../../lib/research-model';
import { dateRange } from '../../lib/handover-coding';
import { analysisTabs, AttributionView, DataView, DesignView, ExperimentView, PsychView, type Tab } from './studio/views';
import { ResearchReport } from './studio/report';
import Handover from './handover/panel';
import s from './studio.module.css';
import h from './handover/handover.module.css';

const businessSignIn = '/?screen=login&switchAccount=1';
type ResearchTab = Tab | 'handover';
const sections = [
  { id: 'handover', name: '交接觀察' },
  { id: 'design', name: '研究模型' },
  { id: 'data', name: '資料記錄' },
  { id: 'attribution', name: '圖表分析' },
  { id: 'report', name: '報告' },
] as const;

function readTab(): ResearchTab {
  const tab = new URLSearchParams(window.location.search).get('tab');
  return [...sections, ...analysisTabs].some(item => item.id === tab) ? tab as ResearchTab : 'handover';
}

const hongKongDay = (days = 0) => new Date(Date.now() + (8 + 24 * days) * 3600000).toISOString().slice(0, 10);

function Studio({ data, tab, open }: { data: ResearchDataset; tab: Tab; open: (next: ResearchTab) => void }) {
  const a = useMemo(() => analyze(data), [data]);

  return <>
    {analysisTabs.some(view => view.id === tab) && <>
      <header className={s.pageTitle}><h2>圖表分析</h2></header>
      <nav className={s.analysisNav} aria-label="分析圖表">
        {analysisTabs.map(view => <button type="button" key={view.id}
          aria-current={tab === view.id ? 'page' : undefined} onClick={() => open(view.id)}>{view.name}</button>)}
      </nav>
    </>}
    {tab === 'design' && <DesignView a={a} onOpen={open} />}
    {tab === 'attribution' && <AttributionView a={a} />}
    {tab === 'psych' && <PsychView a={a} />}
    {tab === 'experiment' && <ExperimentView a={a} />}
    {tab === 'data' && <DataView a={a} data={data} />}
    {tab === 'report' && <ResearchReport a={a} data={data} />}
  </>;
}

export default function ResearchPanel() {
  const [state, setState] = useState<'loading' | 'login' | 'workspace'>('loading');
  const [tab, setTab] = useState<ResearchTab>('handover');
  const [busy, setBusy] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [from, setFrom] = useState(() => hongKongDay(-29));
  const [to, setTo] = useState(() => hongKongDay());
  const [result, setResult] = useState<{ key: string; data: ResearchDataset; revision: number; loadedAt: number }>();
  const [loadError, setLoadError] = useState('');
  const [retry, setRetry] = useState(0);
  const key = new URLSearchParams({ from, to }).toString();
  const data = result?.key === key ? result.data : undefined;
  const onAnalysis = analysisTabs.some(view => view.id === tab);
  const inStudio = tab !== 'handover';

  const needLogin = useCallback(() => {
    setResult(undefined);
    setLoadError('');
    setState('login');
  }, []);

  useEffect(() => {
    const sync = () => setTab(readTab());
    sync();
    setState(sessionToken() ? 'workspace' : 'login');
    window.addEventListener('popstate', sync);
    return () => window.removeEventListener('popstate', sync);
  }, []);

  useEffect(() => {
    if (state !== 'workspace' || !inStudio) return;
    const controller = new AbortController();
    let pending = false;
    async function load() {
      if (pending) return;
      try { dateRange(from, to); }
      catch { setLoadError('請選擇 1 至 93 日的期間。'); return; }
      pending = true;
      try {
        const response = await sessionFetch('/api/research/v2/dataset?' + key, { signal: AbortSignal.any([controller.signal, AbortSignal.timeout(30000)]) });
        if (controller.signal.aborted) return;
        if (response.status === 401 || response.status === 403) { needLogin(); return; }
        if (!response.ok) throw Error('dataset-unavailable');
        const next: ResearchDataset = await response.json();
        if (!controller.signal.aborted) {
          setResult({ key, data: next, revision: retry, loadedAt: Date.now() });
          setLoadError('');
        }
      } catch {
        if (!controller.signal.aborted) setLoadError('暫時未能讀取業務記錄。');
      }
    }
    if (result?.key !== key || result.revision !== retry || Date.now() - result.loadedAt >= 20000) void load();
    return () => controller.abort();
  }, [state, inStudio, key, from, to, result, retry, needLogin]);

  function open(next: ResearchTab) {
    if (next === tab) return;
    const url = new URL(location.href);
    url.searchParams.set('tab', next);
    history.pushState(null, '', url);
    setTab(next);
    window.scrollTo({ top: 0 });
  }

  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    setBusy(true);
    setLoginError('');
    try {
      await signInPhone(normalizeLoginPhone(String(fields.get('phone'))), String(fields.get('password')));
      setState('workspace');
    } catch {
      setLoginError('帳戶或密碼不正確，或此帳戶沒有研究權限。');
    } finally { setBusy(false); }
  }

  async function logout() {
    try { await signOut(); } finally { needLogin(); }
  }

  if (state !== 'workspace') return <div className={s.gate}><section>
    <span className={s.kicker}>高陞 · 服務單交接</span><h1>研究工作台</h1>
    <div className={s.meta}><a href={businessSignIn}>返回業務系統</a></div>
    {state === 'loading' ? <p role="status">正在讀取研究工作台…</p> :
      <form onSubmit={login} className={s.form}>
        <p className={s.muted}>請使用已授權的研究管理員帳戶登入。</p>
        <label>手機號碼<input name="phone" autoComplete="username" inputMode="tel" required /></label>
        <label>密碼<input name="password" type="password" autoComplete="current-password" required /></label>
        {loginError && <p role="alert" className={s.errorText}>{loginError}</p>}
        <button className={s.primary} disabled={busy}>{busy ? '正在登入…' : '登入'}</button>
      </form>}
  </section></div>;

  return <div className={s.shell}>
    <header className={s.top}>
      <div className={s.brand}><span>高陞 · 服務單交接</span><h1>研究工作台</h1></div>
      <div className={s.meta}><a href={businessSignIn}>返回業務系統</a><button className={s.ghost} onClick={() => void logout()}>退出</button></div>
    </header>
    <nav className={s.tabs} aria-label="研究工作台">
      {sections.map(section => <button key={section.id} type="button"
        aria-current={tab === section.id || (section.id === 'attribution' && onAnalysis) ? 'page' : undefined}
        onClick={() => open(section.id)}>{section.name}</button>)}
    </nav>
    <main className={s.main}>
      <div className={h.filter}>
        <label>由<input type="date" value={from} max={to} onChange={e => { setLoadError(''); setFrom(e.target.value); }} /></label>
        <label>至<input type="date" value={to} min={from} onChange={e => { setLoadError(''); setTo(e.target.value); }} /></label>
        <small>香港時間</small>
        {inStudio && <button className={s.ghost} onClick={() => setRetry(value => value + 1)}>重新整理資料</button>}
      </div>
      <div hidden={inStudio}><Handover active={!inStudio} key={key} from={from} to={to} onLogin={needLogin} /></div>
      {inStudio && <>
        {loadError && <p role="alert">{loadError}</p>}
        {!data && !loadError && <p role="status">正在讀取業務記錄…</p>}
        {data && <Studio data={data} tab={tab} open={open} />}
      </>}
    </main>
  </div>;
}
