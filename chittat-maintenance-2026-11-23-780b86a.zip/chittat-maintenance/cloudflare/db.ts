import { AsyncLocalStorage } from "node:async_hooks";
import { Pool, type PoolClient } from "pg";
import { env } from "cloudflare:workers";

const requestDatabase = new AsyncLocalStorage<{ pool?: Pool }>();
function currentPool() {
  const scope = requestDatabase.getStore();
  if (!scope) throw new Error("database-request-context-required");
  return scope.pool ??= new Pool({
    connectionString: env.HYPERDRIVE.connectionString,
    max: 3,
    connectionTimeoutMillis: 10000,
    idleTimeoutMillis: 1000,
  });
}

// Better Auth holds the adapter globally; sockets must still belong to one request.
const adapter = new Proxy(new Pool(), {
  get(target, property, receiver) {
    if (property === "query" || property === "connect") {
      return (...args: unknown[]) => {
        const pool = currentPool();
        return (pool[property] as Function).apply(pool, args);
      };
    }
    return Reflect.get(target, property, receiver);
  },
});
export function db(): Pool { return adapter; }
export async function withDatabaseRequest<T>(run: () => Promise<T>, waitUntil: (promise: Promise<unknown>) => void) {
  const scope: { pool?: Pool } = {};
  return requestDatabase.run(scope, async () => {
    try { return await run(); }
    finally { if (scope.pool) waitUntil(scope.pool.end()); }
  });
}
export async function transaction<T>(run: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await db().connect();
  try {
    await client.query("BEGIN");
    const result = await run(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally { client.release(); }
}
