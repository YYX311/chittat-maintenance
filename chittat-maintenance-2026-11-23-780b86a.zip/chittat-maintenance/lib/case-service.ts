import { randomUUID } from "node:crypto";
import { makeRecord } from "../src/workspace-model";
import { handoffReason } from "../src/handoff-reasons";
import { studyField } from "../src/field-study-catalog";
import { enrollNewFieldCase } from "./field-study-service";
import type { Staff } from "./access";
import { canSee, editableCopy, formalContent, validateConfirmation, validateWorkerSubmission, type CaseRecord } from "./case-rules";

export type Queryable = {
  query: (sql: string, values?: any[]) => Promise<{ rows: any[] }>;
};

function materialize(row: { data: CaseRecord; row_version: number }): CaseRecord {
  return { ...row.data, serverVersion: row.row_version };
}

export async function listCases(client: Queryable, staff: Staff): Promise<CaseRecord[]> {
  const worker = staff.role === "worker";
  const result = await client.query(`SELECT data, row_version FROM cases
    ${worker ? "WHERE owner_user_id = $1" : ""}
    ORDER BY created_at DESC`, worker ? [staff.userId] : []);
  return result.rows.map(materialize);
}

async function nextNumber(client: Queryable, key: string): Promise<number> {
  const { rows } = await client.query(`INSERT INTO counters(key, value) VALUES ($1, 1)
    ON CONFLICT(key) DO UPDATE SET value = counters.value + 1 RETURNING value`, [key]);
  return Number(rows[0].value);
}

async function audit(client: Queryable, id: string, staff: Staff, action: string, detail: object = {}) {
  await client.query(`INSERT INTO audit_events(case_id, actor_user_id, action, detail, created_at)
    VALUES ($1, $2, $3, $4::jsonb, clock_timestamp())`, [id, staff.userId, action, JSON.stringify(detail)]);
}

async function projectIdFor(client: Queryable, record: CaseRecord): Promise<string | null> {
  if (!record.projectId && !record.projectCode) return null;
  if (!record.projectId || !record.projectCode) throw new Error("invalid-project");
  const { rows } = await client.query(`SELECT id FROM projects WHERE id=$1
    AND (lower(code)=lower($2) OR COALESCE(details->'previousCodes','[]'::jsonb) ? $2)
    AND (active=TRUE OR EXISTS(SELECT 1 FROM cases WHERE cases.id=$3 AND cases.project_id=projects.id))`,
    [record.projectId, record.projectCode, record.id]);
  if (!rows.length) throw new Error("invalid-project");
  return rows[0].id;
}

export async function createCase(client: Queryable, staff: Staff, incoming: Record<string, unknown>): Promise<CaseRecord> {
  if (Object.hasOwn(incoming, "photos")) throw new Error("invalid-photos");
  const source = staff.role === "worker" ? "worker" : "office";
  const id = incoming.clientId ? String(incoming.clientId) : randomUUID();
  if (!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(id)) throw new Error("invalid-client-id");
  // Serialize retrying creates. A lost response must not create a second draft.
  await client.query("SELECT pg_advisory_xact_lock(hashtext($1))", [id]);
  const existing = await client.query("SELECT data,row_version,owner_user_id FROM cases WHERE id=$1", [id]);
  if (existing.rows.length) {
    if (existing.rows[0].owner_user_id !== staff.userId) throw new Error("not-found");
    return materialize(existing.rows[0]);
  }
  const base = makeRecord(source) as CaseRecord;
  base.id = id;
  base.owner = staff.email;
  base.createdById = staff.userId;
  base.createdByName = staff.name;
  base.technician = staff.name;
  base.status = source === "worker" ? "editing" : "draft";
  base.serviceNo = `CT-MNA-${String(await nextNumber(client, "service")).padStart(4, "0")}`;
  base.entryNo = base.serviceNo;
  const record = editableCopy(base, incoming, staff);
  const projectId = await projectIdFor(client, record);
  await client.query(`INSERT INTO cases(id, owner_user_id, source, status, entry_no, project_id, data, service_no)
    VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8)`,
    [id, staff.userId, source, record.status, record.entryNo, projectId, JSON.stringify(record), record.serviceNo]);
  await enrollNewFieldCase(client, staff, id);
  await audit(client, id, staff, "create");
  return { ...record, serverVersion: 0 };
}

async function lockedCase(client: Queryable, staff: Staff, id: string, includeDeleted = false) {
  const { rows } = await client.query(`SELECT data, row_version, owner_user_id FROM cases
    WHERE id = $1 ${includeDeleted ? "" : "AND deleted_at IS NULL"} FOR UPDATE`, [id]);
  if (!rows.length) throw new Error("not-found");
  const record = materialize(rows[0]);
  if (!canSee(staff, record)) throw new Error("not-found");
  return record;
}

async function writeCase(client: Queryable, record: CaseRecord, staff: Staff, action: string, detail: object = {}): Promise<CaseRecord> {
  const projectId = await projectIdFor(client, record);
  const { serverVersion: _version, ...stored } = record;
  const { rows } = await client.query(`UPDATE cases SET data = $2::jsonb, status = $3,
    service_no = $4, quote_ref = $5, quote_revision = $6,
    row_version = row_version + 1, updated_at = now(), deleted_at = $7, project_id = $8
    WHERE id = $1 RETURNING row_version`, [record.id, JSON.stringify(stored), record.status,
    record.serviceNo || null, record.ref || null, Number(record.rev || 0), record.deletedAt || null, projectId]);
  await audit(client, record.id, staff, action, { ...detail, version: rows[0].row_version });
  return { ...record, serverVersion: rows[0].row_version };
}

export async function saveCase(client: Queryable, staff: Staff, id: string, incoming: Record<string, unknown>): Promise<CaseRecord> {
  const current = await lockedCase(client, staff, id);
  if (Number(incoming.serverVersion) !== current.serverVersion) throw new Error("conflict");
  const next = editableCopy(current, incoming, staff);
  if (Object.hasOwn(incoming, "photos") && next.photos.length) {
    const keys = [...new Set(next.photos.map((photo) => photo.assetKey))];
    const { rows } = await client.query("SELECT key FROM assets WHERE case_id=$1 AND key=ANY($2::text[])", [id, keys]);
    if (rows.length !== keys.length) throw new Error("invalid-photo-asset");
  }
  if (JSON.stringify(next) === JSON.stringify(current)) return current;
  next.lastEditedById = staff.userId;
  next.lastEditedByName = staff.name;
  return writeCase(client, next, staff, "save");
}

export type CaseAction = "submit" | "withdraw" | "review" | "return" | "confirm" | "start-revision" | "discard-revision" | "delete-draft" | "restore-draft";

export async function actionCase(client: Queryable, staff: Staff, id: string, action: CaseAction,
  expectedVersion: number, payload: Record<string, unknown> = {}): Promise<CaseRecord> {
  const current = await lockedCase(client, staff, id, action === "restore-draft");
  if (current.serverVersion !== expectedVersion) throw new Error("conflict");
  if (current.deletedAt && action !== "restore-draft") throw new Error("not-found");
  const next = { ...current };
  const worker = staff.role === "worker";
  if (action === "submit") {
    if (!worker || !["editing", "needsInfo"].includes(current.status)) throw new Error("forbidden");
    validateWorkerSubmission(current);
    await client.query(`UPDATE research_cases SET difficulty=$2 WHERE case_id=$1 AND trial_period IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM audit_events WHERE case_id=$1 AND action='submit')`,
      [id,current.items.length>4?"high":current.items.length>1?"medium":"low"]);
    if (!next.serviceNo) next.serviceNo = `CT-MNA-${String(await nextNumber(client, "service")).padStart(4, "0")}`;
    next.status = "submitted";
    next.submittedAt = new Date().toISOString();
    next.feedback = (current.feedback || []).map((item: Record<string, unknown>) => ({ ...item, addressed: true, resolved: true }));
    const serviceSnapshot = { ...next, items: next.items.map((item) => ({ ...item, price: "" })),
      history: [], approvalHistory: [], invoiceHistory: [], serviceDocuments: [], approvedSnapshot: undefined };
    await client.query(`INSERT INTO case_versions(id, case_id, kind, revision, snapshot, created_by)
      VALUES ($1, $2, 'service', $3, $4::jsonb, $5)`, [randomUUID(), id,
      (current.serviceDocuments || []).length, JSON.stringify(serviceSnapshot), staff.userId]);
    next.serviceDocuments = [...(current.serviceDocuments || []), {
      at: next.submittedAt, rev: (current.serviceDocuments || []).length,
      snapshot: serviceSnapshot, assetKey: null,
    }];
  } else if (action === "withdraw") {
    if (!worker || current.status !== "submitted") throw new Error("forbidden");
    next.status = "editing";
  } else if (action === "delete-draft") {
    if (worker ? current.status !== "editing" : current.status !== "draft") throw new Error("forbidden");
    next.deletedAt = new Date().toISOString();
  } else if (action === "restore-draft") {
    if ((worker ? current.status !== "editing" : current.status !== "draft") || !current.deletedAt) throw new Error("forbidden");
    delete next.deletedAt;
  } else if (action === "review") {
    if (worker || current.status !== "submitted") throw new Error("forbidden");
    next.status = "draft";
  } else if (action === "return") {
    if (worker || !["submitted", "draft"].includes(current.status)) throw new Error("forbidden");
    const text = String(payload.text || "").trim();
    if (!text || text.length > 2000) throw new Error("invalid-feedback");
    next.status = "needsInfo";
    next.feedback = [...(current.feedback || []), {
      id: randomUUID(), text, field: String(payload.field || "notes"),
      itemId: payload.itemId || null, at: new Date().toISOString(), addressed: false, resolved: false,
    }];
  } else if (action === "start-revision") {
    if (worker || !["approved", "issued"].includes(current.status)) throw new Error("forbidden");
    next.status = "revision";
  } else if (action === "discard-revision") {
    if (worker || current.status !== "revision" || !current.approvedSnapshot) throw new Error("forbidden");
    const approved = current.approvedSnapshot;
    for (const field of ["date", "address", "tower", "floor", "flat", "customerType", "customer", "contact",
      "occupant", "phone", "contractRef", "brand", "coverage", "coverageNotes", "material", "notes",
      "startedAt", "completedAt", "serviceRemark1", "serviceRemark2", "serviceRemark3", "projectId",
      "projectName", "projectCode", "remark", "remarkTemplate", "paymentTerms", "ledger", "invoiceDate", "invoiceRef", "discountAmount",
      "items", "photos"]) next[field] = approved[field];
    next.status = "approved";
    next.imported = false;
  } else if (action === "confirm") {
    if (worker || !["draft", "revision", "submitted"].includes(current.status)) throw new Error("forbidden");
    await projectIdFor(client, current);
    validateConfirmation(current);
    if (!next.serviceNo) next.serviceNo = `CT-MNA-${String(await nextNumber(client, "service")).padStart(4, "0")}`;
    if (!next.ref) {
      const year = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Hong_Kong" }).slice(2, 4);
      const prefix = `CT-MNA${year}-Q-${next.source === "worker" ? "S-" : ""}`;
      const count = await nextNumber(client, `quotation-${year}-${next.source}`);
      next.ref = prefix + String(count).padStart(3, "0");
      next.invoiceRef = next.ref.replace("-Q-", "-I-");
    }
    const prior = await client.query(`SELECT revision, snapshot FROM case_versions
      WHERE case_id = $1 AND kind = 'confirmation' ORDER BY revision DESC LIMIT 1`, [id]);
    const previous = prior.rows[0];
    const changed = !previous || formalContent(previous.snapshot) !== formalContent(current);
    next.rev = previous ? Number(previous.revision) + (changed ? 1 : 0) : 0;
    next.status = "approved";
    next.approvedAt = new Date().toISOString();
    next.lastConfirmedById = staff.userId;
    next.lastConfirmedByName = staff.name;
    next.approvedSnapshot = { ...next, approvedSnapshot: undefined, history: [], approvalHistory: [] };
    if (changed) {
      await client.query(`INSERT INTO case_versions(id, case_id, kind, revision, snapshot, created_by)
        VALUES ($1, $2, 'confirmation', $3, $4::jsonb, $5)`,
      [randomUUID(), id, next.rev, JSON.stringify(next.approvedSnapshot), staff.userId]);
      next.approvalHistory = [...(current.approvalHistory || []), {
        at: next.approvedAt, rev: next.rev, snapshot: next.approvedSnapshot,
      }];
    }
  } else throw new Error("invalid-action");
  return writeCase(client, next, staff, action,
    action === "return" ? { reason: handoffReason(payload.reason), field: studyField(payload.field) } : {});
}
