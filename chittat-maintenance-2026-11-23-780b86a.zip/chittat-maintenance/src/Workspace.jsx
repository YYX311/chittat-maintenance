import { CaretDown, ClipboardText, MagnifyingGlass, PencilSimple, SignOut, Table, Trash, UserCircle } from "@phosphor-icons/react";
import {handoffReasons} from "./handoff-reasons";
import {documentArchive} from "./document-archive";
import {rememberPhoto} from "./photo-preview-cache";
import {mergeWorkspace} from "./workspace-sync";
import OperationFeedback from "./OperationFeedback";
import DocumentHistory from "./DocumentHistory";
import PrivatePhoto from "./PrivatePhoto";
import { validQuantity, validMoney, quantityInput, moneyInput } from "./numeric-rules";
import PdfPreview from "./PdfPreview";
import RecycleBin from "./RecycleBin";
import PricingPanel from "./PricingPanel";
import CommercialTotals from "./CommercialTotals";
import {formIssues} from "./form-validation";
import {useFieldNavigation} from "./useFieldNavigation";
import ServiceOrder from "./ServiceOrder";
import ProjectPicker from "./ProjectPicker";
import {missingDetails,statusTone,nextServiceNumber,projectRegistry} from "./task-guidance";
import CompactIndex, {compactRow} from "./CompactIndex";
import {INDEX_COLUMNS, REMARK_TEMPLATES, serviceFields, serviceError, assetGroup, safeName, documentPackageName} from "./service-model";
import {getAsset,downloadBlob,chooseSaveTarget,saveBlob,photoBlob,photoArchive} from "./attachments";
import React, { useState, useEffect, useRef } from "react";
import { Converter } from "opencc-js/t2cn";
import {
  SHEETS,
  HEADERS,
  ADDRESSES,
  ITEMS,
  uid,
  makeRecord,
  today,
  readStore,
  setRuntimeStore,
  total,
  itemName,
  completeness,
  toIndexRows,
  normalizeCell,
  parseIndex,
} from "./workspace-model";
import "./workspace.css";
import {
  SummaryView,
  LedgerView,
  ProjectsView,
  SampleGuide,
  downloadOfficeWorkbook,
} from "./OfficeTools";
import {
  extractProjects,
  currentQuotes,
  effectiveQuote,
} from "./office-tools-model";
import { normalizeLoginPhone } from "./phone";
import { cacheDraft, clearDraftCache, mergeDraftCache, readDraftCache } from "./draft-cache";
import { currentAccount, workspace, staffDirectory, signInPhone, signOut, createCase as apiCreateCase, saveCase as apiSaveCase, caseAction, uploadCasePhoto, generateCaseDocument, importIndexWorkbook } from "./server-api";
import { selectedWorkspaceRole, setWorkspaceRole } from "./session-fetch";
import { ResearchProbeLayer, useResearchProbe } from "./research-probe";

const simplified = Converter({ from: "hk", to: "cn" });
const money = (n) =>
  new Intl.NumberFormat("en-HK", { style: "currency", currency: "HKD" }).format(
    Number(n || 0),
  );
const statuses = {
  editing: ["未提交", "Not submitted"],
  submitted: ["待處理", "To process"],
  needsInfo: ["待維修人員確認", "Awaiting worker"],
  draft: ["草稿 · 未完成", "Draft · Incomplete"],
  revision: ["待處理", "To process"],
  approved: ["已確認 · 待生成", "Confirmed · Ready to generate"],
  issued: ["已簽發", "Issued"],
};
const getRoute = () => {
  const q = new URLSearchParams(location.search);
  return {
    screen: ({"office-quotes":"office-inbox","office-archive":"office-index","worker-timeline":"worker-tasks"})[q.get("screen")] || q.get("screen") || "login",
    lang: q.get("lang") || "zh-HK",
    id: q.get("id") || "",
  };
};
function Btn({ children, primary = false, ...props }) {
  return (
    <button className={"ux-btn" + (primary ? " primary" : "")} {...props}>
      {children}
    </button>
  );
}
function HeaderLogo({ compact = false }) {
  const ink = React.useId();
  return (
    <span className={"brand-logo" + (compact ? " compact" : "")}>
      <svg role="img" aria-label="Chit Tat Electrical Engineering Ltd." viewBox="4 80 294 45">
        <defs>
          <filter id={ink} colorInterpolationFilters="sRGB">
            <feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  -0.2126 -0.7152 -0.0722 0 1" />
          </filter>
        </defs>
        <image href="/brand-logo.png" width="300" height="225" filter={`url(#${ink})`} />
        <svg x="4" y="81" width="43" height="43" viewBox="4 81 43 43" overflow="hidden">
          <image href="/brand-logo.png" width="300" height="225" />
        </svg>
      </svg>
    </span>
  );
}
function Input({ label, value, onChange, options, suggestions, suggestionHint, error, onConfirm, confirmed, confirmRequired, type = "text", ...props }) {
  const [expanded,setExpanded]=useState(false);
  const [timePending,setTimePending]=useState(false);
  const errorId=React.useId();
  const suggestionsId=errorId+"-suggestions";
  const toggleRef=useRef(null);
  const closeSuggestions=()=>{setExpanded(false);toggleRef.current?.focus();};
  const calendar = type === "date" || type === "datetime-local";
  const editableCalendar = calendar && !props.readOnly && !props.disabled;
  const confirmCalendar = editableCalendar && (timePending || (confirmRequired && value && !confirmed));
  props={...props,"aria-invalid":!!error,"aria-describedby":error?errorId:undefined};
  return (
    <label className={"ux-field"+(error?" field-invalid":"")} data-feedback-target={props["data-feedback-target"]}>
      <span>{label}</span>
      {suggestions ? (
        <div className="ux-combo-wrap"
          onBlur={e=>{if(expanded&&!e.currentTarget.contains(e.relatedTarget))setExpanded(false);}}
          onKeyDown={e=>{if(expanded&&e.key==="Escape"){e.stopPropagation();closeSuggestions();}}}>
          <div className="ux-combo">
            <input {...props} aria-label={label} value={value??""} disabled={props.disabled} onChange={e=>onChange(e.target.value)} />
            <button type="button" ref={toggleRef} disabled={props.disabled} aria-label={label+" ▾"} aria-expanded={expanded} aria-controls={expanded?suggestionsId:undefined} onClick={()=>setExpanded(!expanded)}>
              <CaretDown size={16} aria-hidden="true" />
            </button>
          </div>
          {expanded&&<div className="ux-suggestions" id={suggestionsId} role="group" aria-label={label}>
            {suggestionHint&&<small>{suggestionHint}</small>}
            {[...new Set(suggestions)].filter(Boolean).map(v=><button type="button" key={v} aria-current={value===v?"true":undefined} onClick={()=>{onChange(v);closeSuggestions();}}>{v}{value===v&&<span aria-hidden="true">✓</span>}</button>)}
          </div>}
        </div>
      ) : options ? (
        <select
          aria-label={label}
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value)}
          {...props}
        >
          {options.map(([v, t]) => (
            <option key={v} value={v}>
              {t}
            </option>
          ))}
        </select>
      ) : type === "textarea" ? (
        <textarea
          aria-label={label}
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value)}
          {...props}
        />
      ) : type === "search" ? (
        <div className="ux-search-control">
          <MagnifyingGlass aria-hidden="true" />
          <input {...props} aria-label={label} type="search" value={value ?? ""} onChange={e=>onChange(e.target.value)} />
        </div>
      ) : calendar ? (
        <span className="calendar-control">
          <input
            aria-label={label}
            type={type}
            value={type === "date" ? value?.slice(0,10) ?? "" : value ?? ""}
            onFocus={() => { if (editableCalendar) setTimePending(true); }}
            onChange={event => onChange(event.target.value)}
            {...props}
          />
          {confirmCalendar && <button type="button" className="ux-btn datetime-confirm" onClick={() => {
            setTimePending(false);
            onConfirm?.();
          }}>
            {type === "date"
              ? (/[A-Za-z]/.test(label) ? "✓ Confirm date" : "✓ 確認日期")
              : (/[A-Za-z]/.test(label) ? "✓ Confirm time" : "✓ 確認時間")}
          </button>}
        </span>
      ) : (
        <input
          aria-label={label}
          type={type}
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value)}
          {...props}
        />
      )}
      {error&&<span id={errorId} className="field-error" role="alert">{error}</span>}
    </label>
  );
}
function Modal({ title, children, close, closeLabel, notice, noticeImportant, confirmation = false }) {
  const ref = useRef();
  useEffect(() => {
    const el = ref.current;
    el.showModal();
    return () => el.close();
  }, []);
  return (
    <dialog
      aria-label={title}
      className={confirmation ? "ux-modal confirm-modal" : "ux-modal"}
      ref={ref}
      onCancel={(event) => { event.preventDefault(); close(); }}
      onClick={(e) => {
        if (e.target === ref.current) close();
      }}
    >
      <header>
        {confirmation && <span className="confirm-icon"><Trash aria-hidden="true" /></span>}
        <h2>{title}</h2>
        {!confirmation && <Btn aria-label={closeLabel} onClick={close}>
          ×
        </Btn>}
      </header>
      {notice && (
        <div className={"ux-message"+(noticeImportant?" important-change":"")} role="alert">
          {notice}
        </div>
      )}
      {children}
    </dialog>
  );
}

export default function Workspace() {
  const [route, setRoute] = useState(getRoute),
    [db, setDb] = useState(() => {
      const d = readStore();
      return { ...d, projects: d.projects || extractProjects(d.sheets || []) };
    }),
    [account, setAccount] = useState(null);
  const serverRecords = useRef(new Map());
  const pendingSaves = useRef(new Map());
  const saveEpochs = useRef(new Map());
  const [authLoading, setAuthLoading] = useState(true);
  const [choosingWorkspace, setChoosingWorkspace] = useState(false);
  const [staffList, setStaffList] = useState([]);
  const [notice, setNoticeText] = useState(""),
    [menu, setMenu] = useState(false),
    [modal, setModal] = useState(""),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState("");
  const [noticeImportant,setNoticeImportant]=useState(false);
  const setNotice=(text,important=false)=>{setNoticeText(text);setNoticeImportant(important||/未能|失敗|不正確|需要確認|請修正|請填寫|請輸入|不能|離線|failed|invalid|could not/i.test(text));};
  const [query, setQuery] = useState(""),
    [source, setSource] = useState("all"),
    [status, setStatus] = useState("pending"),
    [sheet, setSheet] = useState(0),
    [category, setCategory] = useState("all"),
    [editItem, setEditItem] = useState(null),
    [feedbackField, setFeedbackField] = useState("model"),
    [feedbackReason, setFeedbackReason] = useState("unknown"),
    [feedbackText, setFeedbackText] = useState(""),
    [previewRev, setPreviewRev] = useState(null);
  const [uploadPreviews,setUploadPreviews]=useState([]);
  const [upload, setUpload] = useState(null),
    [busy, setBusy] = useState(false),
    [online, setOnline] = useState(navigator.onLine),
    [importResult, setImportResult] = useState(null);
  const [bulkIds, setBulkIds] = useState([]);
  const [officeDirty, setOfficeDirty] = useState(false);
  const [editorTouched, setEditorTouched] = useState(false);
  const [batchQuotes,setBatchQuotes]=useState([]);
  const [officeStep,setOfficeStep]=useState(0);
  const [pricingExpandedId,setPricingExpandedId]=useState("");
  const [projectFilter,setProjectFilter]=useState("");
  const [draftIds,setDraftIds]=useState([]);
  const [removedIds,setRemovedIds]=useState([]);
  const [docType,setDocType]=useState("quotation");
  const [documentResult,setDocumentResult]=useState(null);
  const [feedbackItemId,setFeedbackItemId]=useState("");
  const [feedbackTarget,setFeedbackTarget]=useState(null);
  const [validationAttempted,setValidationAttempted]=useState(false);
  const discountHintId=React.useId();
  useEffect(()=>setValidationAttempted(false),[route.id]);
  useEffect(()=>setPricingExpandedId(""),[route.id]);
  useEffect(()=>{
    if(!feedbackTarget)return;
    let inner;const frame=requestAnimationFrame(()=>{inner=requestAnimationFrame(()=>{
      const selector='[data-feedback-target="'+feedbackTarget.field+'"]';
      const el=document.querySelector('dialog[open] '+selector)||document.querySelector(selector);
      if(el){el.classList.add("field-attention");el.scrollIntoView({block:"start",behavior:"smooth"});(el.querySelector('input,textarea,button')||el).focus({preventScroll:true});}
    });});
    return ()=>{cancelAnimationFrame(frame);cancelAnimationFrame(inner);document.querySelectorAll(".field-attention").forEach(el=>el.classList.remove("field-attention"))};
  },[feedbackTarget,route.screen,modal,officeStep]);
  const t = (hk, en) =>
    route.lang === "en" ? en : route.lang === "zh-CN" ? simplified(hk) : hk;
  const sLabel = (s) => t(...(statuses[s] || [s, s]));
  const displayItem = (i) =>
    i.description || t(ITEMS[i.preset]?.[1] || "", ITEMS[i.preset]?.[2] || "");
  const role = account?.role || "worker";
  const worker = role === "worker";
  const hideWorkerNav=useFieldNavigation(worker,route.screen,route.id);
  const home = worker ? "worker-tasks" : "office-inbox";
  const record = db.records.find((r) => r.id === route.id);
  const editAllowed = record && !record.deletedAt && (worker
    ? ["editing","needsInfo"].includes(record.status)
    : ["submitted","needsInfo","draft","revision"].includes(record.status));
  const fieldStudy=useResearchProbe(account,record,route.screen,officeStep,editAllowed);
  const submitRef=useRef(null);
  const issues=formIssues(record,worker,projectRegistry(db));
  const activeIssues=validationAttempted?issues:[];
  const discountIssue=activeIssues.find(issue=>issue.field==="discountAmount");
  const ownRecords = db.records.filter(
    (r) => !r.deletedAt && r.source === "worker" && r.owner === account?.email,
  );
  const workerSteps = [
    ["worker-basic", "基本資料", "Basic details"],
    ["worker-work", "工作內容", "Work items"],
    ["worker-photo", "相片與描述", "Photos and notes"],
    ["worker-review", "確認提交", "Review and submit"],
  ];
  const workerStepIndex = workerSteps.findIndex(([s]) => s === route.screen);
  const workerNeedsInfo = ownRecords.filter(r => r.status === "needsInfo");
  const workerDrafts = ownRecords.filter(r => r.status === "editing");
  const officeQueuePriority = { submitted: 0, revision: 1, draft: 2, needsInfo: 3 };
  const officeQueue = db.records
    .filter(r => !r.deletedAt && !(r.source === "worker" && r.status === "editing") && !["approved","issued"].includes(r.status))
    .map((r, n) => [r, n])
    .sort((a, b) => ((officeQueuePriority[a[0].status] ?? 9) - (officeQueuePriority[b[0].status] ?? 9)) || a[1] - b[1])
    .map(([r]) => r);
  const officeCounts = {
    submitted: officeQueue.filter(r => r.status === "submitted").length,
    revision: officeQueue.filter(r => r.status === "revision").length,
    draft: officeQueue.filter(r => r.status === "draft").length,
    needsInfo: officeQueue.filter(r => r.status === "needsInfo").length,
  };
  const nextOfficeTask = record && officeQueue.find(r => r.id !== record.id && ["submitted","revision","draft"].includes(r.status));
  const deletedDrafts = db.records.filter(r => r.deletedAt && (worker ? r.source === "worker" && r.owner === account?.email : r.status === "draft"));
  const editorScreens = ["worker-basic","worker-work","worker-photo","worker-review","office-quote","office-case"];
  const canLeave = () =>
    !officeDirty ||
    window.confirm(
      t(
        "有未儲存的項目或發票修改，確定放棄並離開？",
        "Discard unsaved project or invoice changes and leave?",
      ),
    );
  const go = (screen, id = "", force = false) => {
    screen=({"office-quotes":"office-inbox","office-archive":"office-index","worker-timeline":"worker-tasks"})[screen]||screen;
    if (!force && !canLeave()) return;
    const leavingDraft = record && (editorTouched || (!record.localOnly && [record.customer,record.address,record.notes,record.items?.length].some(Boolean))) && ["editing","draft","needsInfo","revision"].includes(record.status) && editorScreens.includes(route.screen) && (!editorScreens.includes(screen) || (id && id !== record.id));
    if (!force && leavingDraft && !window.confirm(t("內容尚未確認。是否儲存到草稿並離開？未確認報價不會進入 INDEX；取消可繼續填寫。","Content is not confirmed. Save as draft and leave? Unconfirmed quotes stay out of INDEX. Cancel to keep editing."))) return;
    setFeedbackTarget(null);
    if (!editorScreens.includes(screen) || id !== record?.id) setEditorTouched(false);
    if (record?.localOnly && !editorTouched && (!editorScreens.includes(screen) || id !== record.id)) {
      const next = {...readStore(), records: readStore().records.filter(r => r.id !== record.id)};
      setRuntimeStore(next); setDb(next); clearDraftCache(account, record.id);
    }
    setOfficeDirty(false);
    setOfficeStep(0);
    setRoute((r) => ({ ...r, screen, id }));
    setMenu(false);
    setModal("");
    setNotice("");
    setQuery(""); setSource("all"); setStatus(screen==="office-inbox"?"pending":"all"); setBulkIds([]); setProjectFilter("");
    setPreviewRev(null);
    window.scrollTo({ top: 0 });
  };
  const acceptWorkspace = (next, canonical = next) => {
    setRuntimeStore(next);
    serverRecords.current = new Map(canonical.records.filter(r=>!r.localOnly).map((r) => [r.id, r]));
    setDb(next);
  };
  const acceptRecord = (item) => {
    if(serverRecords.current.get(item.id)?.serverVersion>item.serverVersion)return;
    serverRecords.current.set(item.id, item);
    setDb((current) => {
      const next = { ...current, records: current.records.some(r=>r.id===item.id)?current.records.map((r) => r.id === item.id ? item : r):[...current.records,item] };
      setRuntimeStore(next);
      return next;
    });
  };
  const refreshWorkspace = async () => acceptWorkspace(await workspace());
  const queueSave = (item, draftAccount = account) => {
    const epoch = (saveEpochs.current.get(item.id) || 0) + 1;
    saveEpochs.current.set(item.id, epoch);
    const previous = pendingSaves.current.get(item.id) || Promise.resolve();
    const pending = previous.then(async () => {
      if (saveEpochs.current.get(item.id) !== epoch) return serverRecords.current.get(item.id) || null;
      await new Promise(resolve => setTimeout(resolve, 250));
      if (saveEpochs.current.get(item.id) !== epoch) return serverRecords.current.get(item.id) || null;
      const version = serverRecords.current.get(item.id)?.serverVersion;
      const {photos, ...creation} = item;
      const saved = version == null && item.localOnly
        ? await apiCreateCase({...creation, clientId: item.id})
        : await apiSaveCase({ ...item, serverVersion: version });
      serverRecords.current.set(item.id, saved);
      if (saveEpochs.current.get(item.id) === epoch) { clearDraftCache(draftAccount, item.id); acceptRecord(saved); }
      else { const latest=readStore().records.find(r=>r.id===item.id); if(latest){const draft={...latest,localOnly:false,serverVersion:saved.serverVersion};cacheDraft(draftAccount,draft,saved.serverVersion);const state={...readStore(),records:readStore().records.map(r=>r.id===item.id?draft:r)};setRuntimeStore(state);setDb(state);} }
      return saved;
    }).catch(async (error) => {
      if (!error?.status || error.status >= 500) {
        setNotice(t("目前離線或連線不穩，修改已保存在本機草稿；恢復連線後會自動同步。", "You appear offline or the connection is unstable. Changes are saved in a local draft and will sync when connection returns."),true);
      } else if (error.status === 409) {
        setNotice(t("此任務有其他人同時修改。你的輸入仍保存在本機草稿，請核對最新資料後再儲存。", "This record changed elsewhere. The latest version was reloaded."),true);
        // Keep this editor intact; do not silently replace a conflicting draft.
      } else {
        setNotice(t("未能儲存，輸入已保留。請重試；如登入已過期，請重新登入。", "Could not save. Your input is retained. Retry, or sign in again if your session expired."),true);
      }
      return null;
    });
    pendingSaves.current.set(item.id, pending);
    return pending;
  };
  const runAction = async (item, action, payload) => {
    let pending = pendingSaves.current.get(item.id);
    while(pending) {
      await pending;
      const newest=pendingSaves.current.get(item.id);
      if(newest===pending)break;
      pending=newest;
    }
    if (pending && await pending === null) {
      const latest = readStore().records.find(r => r.id === item.id);
      if (!latest || await queueSave(latest) === null) throw new Error("save-failed");
    }
    if (item.localOnly && !serverRecords.current.get(item.id)?.serverVersion && !pending) await queueSave(item);
    const current = serverRecords.current.get(item.id);
    if (!current) throw new Error("not-found");
    const completed=["submit","return","confirm"].includes(action);
    if(completed)fieldStudy.finishTime();
    const changed = await caseAction(current, action, payload);
    if(completed){fieldStudy.ask(item.id, action, changed.serverVersion);void fieldStudy.flush();}
    clearDraftCache(account,item.id);
    acceptRecord(changed);
    return changed;
  };
  function openWorkspace(staff, data, goHome = false) {
    const merged = mergeDraftCache(data, staff);
    acceptWorkspace(merged.workspace, data);
    setAccount(staff);
    setChoosingWorkspace(false);
    merged.recovered.forEach(item => queueMicrotask(() => queueSave(item, staff)));
    if (goHome || ["login", "forgot-password", "reset-sent", "mfa"].includes(getRoute().screen)) {
      go(staff.role === "worker" ? "worker-tasks" : "office-inbox", "", true);
    }
  }
  useEffect(() => {
    if (getRoute().screen === "login" && new URLSearchParams(location.search).get("switchAccount") === "1") {
      setAuthLoading(false);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const staff = await currentAccount();
        if (cancelled) return;
        if (staff.canResearch && getRoute().screen === "login") return;
        if (staff.canWork && !selectedWorkspaceRole()) {
          setChoosingWorkspace(true);
          return;
        }
        const data = await workspace();
        if (cancelled) return;
        openWorkspace(staff, data);
      } catch (error) {
        if (!cancelled) {
          if (error.status === 401) { setAccount(null); go("login", "", true); }
          else setNotice(t("暫時無法連接伺服器，請重新整理。", "Cannot reach the server. Please refresh."));
        }
      } finally { if (!cancelled) setAuthLoading(false); }
    })();
    return () => { cancelled = true; };
  }, []);
  useEffect(() => {
    if (route.screen !== "users" || !account?.canManage) return;
    staffDirectory().then(setStaffList).catch(() => setNotice(t("未能載入員工清單。", "Could not load staff directory.")));
  }, [route.screen, account?.canManage]);
  useEffect(()=>{
    if(!account)return;
    let cancelled=false,fetching=false;
    const refresh=async()=>{
      if(fetching || document.visibilityState!=="visible")return;
      fetching=true;
      try{const requestedVersions=new Map([...serverRecords.current].map(([id,r])=>[id,r.serverVersion]));const next=await workspace();if(!cancelled){
        const merged=mergeWorkspace(next,serverRecords.current,readStore(),new Set(readDraftCache(account).map(entry=>entry.record.id)),requestedVersions);
        setRuntimeStore(merged);setDb(merged);
      }}catch{}finally{fetching=false;}
    };
    const timer=setInterval(refresh,5000);
    window.addEventListener("focus",refresh);
    document.addEventListener("visibilitychange",refresh);
    return ()=>{cancelled=true;clearInterval(timer);window.removeEventListener("focus",refresh);document.removeEventListener("visibilitychange",refresh);};
  },[account?.id,route.screen]);
  const jumpFeedback = (r,f) => {
    if(f.missing)setValidationAttempted(true);

    const screen=f.screen||{date:"worker-basic",customer:"worker-basic",phone:"worker-basic",address:"worker-basic",items:"worker-work",model:"worker-work",qty:"worker-work",photo:"worker-photo",notes:"worker-photo",startedAt:"worker-photo",completedAt:"worker-photo"}[f.field]||"worker-task-detail";
    go(screen,r.id);
    setFeedbackTarget({id:f.id,field:f.field,text:f.missing?t(f.text,f.en):f.text});
    setNotice(t("需要確認：","Please check: ")+(f.missing?t(f.text,f.en):f.text));
    if(["model","qty"].includes(f.field)){
      const item=r.items.find(i=>i.id===f.itemId)||(r.items.length===1?r.items[0]:null);
      if(item&&["needsInfo","editing"].includes(r.status)){setEditItem({...item});setModal("item");}
      else setNotice(t("請選擇需要修改的工作項目。問題：","Choose the work item to correct. Question: ")+f.text);
    }
  };
  const focusIssue = (issue,quiet=false) => {
    if(!quiet)setValidationAttempted(true);
    if(worker){go(["worker-basic","worker-work","worker-photo"][issue.step]||"worker-review",record.id);}
    else setOfficeStep(issue.step);
    if(!worker&&issue.field.startsWith("price-"))setPricingExpandedId(issue.itemId||issue.field.slice(6));
    setFeedbackTarget({field:issue.field,text:t(issue.hk,issue.en)});
    if(!quiet)setNotice(["project","discountAmount"].includes(issue.field)?"":t(issue.hk,issue.en));
    if(["qty","model","brand"].includes(issue.field)&&issue.itemId){const item=record.items.find(i=>i.id===issue.itemId);if(item){setEditItem({...item});setModal("item")}}
  };
  const nextWorker = (step,screen) => {
    const issue=issues.find(e=>e.step<=step);if(issue){fieldStudy.track("validation_error",issue.field);focusIssue(issue);return;}go(screen,record.id);
  };
  const moveOffice = step => {
    if(step>officeStep){const issue=issues.find(e=>e.step<step);if(issue){fieldStudy.track("validation_error",issue.field);focusIssue(issue);return;}}
    setFeedbackTarget(null);setOfficeStep(step);
    requestAnimationFrame(()=>document.querySelector(".service-steps")?.scrollIntoView({block:"start",behavior:window.matchMedia("(prefers-reduced-motion: reduce)").matches?"instant":"smooth"}));
  };
  const feedbackLink = (r,f) => {
    const addressed=!f.missing&&!f.resolved&&f.addressed;
    return <button key={f.id} className={"ux-feedback ux-feedback-link "+(addressed?"feedback-addressed":"important-feedback")} onClick={()=>addressed?go("worker-review",r.id):jumpFeedback(r,f)}><b>{addressed?t("已修改：","Updated: "):""}{feedbackLabel(f.field,t)}</b><p>{f.missing?t(f.text,f.en):f.text}</p><span>{addressed?t("前往重新提交","Go to resubmit"):t("前往查看／修改","Go to details / correct")} →</span></button>;
  };
  const commit = (next) => {
    const previous = readStore();
    const original = new Map(previous.records.map((r) => [r.id, r]));
    const changed = next.records.filter((r) => original.has(r.id) && JSON.stringify(r) !== JSON.stringify(original.get(r.id)));
    if (next.records.some((r) => !original.has(r.id))) {
      setNotice(t("請使用建立任務入口。", "Use Create task to add a record."));
      return false;
    }
    setRuntimeStore(next);
    setDb(next);
    changed.forEach(item=>queueSave(item));
    return true;
  };
  const update = (patch) => {
    if (!record) return;
    const latest = readStore();
    setEditorTouched(true);
    const currentRecord=latest.records.find(r=>r.id===record.id)||record;
    const addressedFeedbackIds=(currentRecord.feedback||[])
      .filter(f=>!f.resolved && (f.addressed || feedbackTarget?.id===f.id ||
        (worker && Object.hasOwn(patch,f.field) && patch[f.field]!==currentRecord[f.field])))
      .map(f=>f.id);
    const changedRecord = { ...currentRecord, ...patch,
      feedback:(currentRecord.feedback||[]).map(f=>addressedFeedbackIds.includes(f.id)?{...f,addressed:true}:f),
      addressedFeedbackIds, technician:record.technician, lastEditedById:account.id,lastEditedByName:account.name };
    if(feedbackTarget?.id)setFeedbackTarget(null);
    const remainingIssues=formIssues(changedRecord,worker,db.projects||[]);
    if(!remainingIssues.length || (feedbackTarget?.field&&!remainingIssues.some(issue=>issue.field===feedbackTarget.field)))setNotice("");
    cacheDraft(account, changedRecord, serverRecords.current.get(record.id)?.serverVersion);
    return commit({
      ...latest,
      records: latest.records.map((r) =>
        r.id === record.id ? changedRecord : r,
      ),
    });
  };
  const editRecord = async r => {
    try {
      if (["approved", "issued"].includes(r.status)) await runAction(r, "start-revision");
      go(r.source === "worker" && ["submitted", "needsInfo"].includes(r.status) ? "office-case" : "office-quote", r.id);
    } catch { setNotice(t("狀態已改變，請重新開啟任務。", "Status changed. Reopen the task."),true); }
  };
  const open = (r) => { if(["approved","issued"].includes(r.status)){go("office-confirmed",r.id);return;} if (route.screen === "office-index" || route.screen === "office-archive") { go("office-confirmed",r.id); return; }
    go(
      r.source === "worker" && ["submitted", "needsInfo"].includes(r.status)
        ? "office-case"
        : "office-quote",
      r.id,
    ); };
  const create = () => {
    const r = {...makeRecord(worker ? "worker" : "office"), owner:account.email,
      technician:account.name, createdById:account.id, localOnly:true};
    const next = {...readStore(), records:[r,...readStore().records]};
    setRuntimeStore(next); setDb(next);
    go(worker ? "worker-basic" : "office-quote", r.id);
  };
  const logout = async () => {
    if (!canLeave()) return;
    if(editorTouched && !window.confirm(t("儲存草稿並退出登入？","Save draft and sign out?")))return;
    await Promise.all(pendingSaves.current.values());
    await signOut();
    setAccount(null);
    acceptWorkspace({ version: 4, records: [], projects: [], sheets: [], sampleRows: [], parts: [], counters: { worker: 0, office: 0 } });
    setEmail("");
    setPassword("");
    go("login", "", true);
  };
  useEffect(() => {
    document.documentElement.lang = route.lang;
    const q = new URLSearchParams(location.search);
    q.set("screen",route.screen);q.set("lang",route.lang);q.delete("id");
    if (account) q.set("role", account.role);
    if (route.screen !== "login") q.delete("switchAccount");
    if (route.id) q.set("id", route.id);
    history.replaceState(null, "", "?" + q);
  }, [route, account]);
  useEffect(() => {
    const warn = (e) => {
      if (officeDirty || editorTouched) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [officeDirty,editorTouched]);
  useEffect(() => {
    const f = () => setRoute(getRoute());
    const net = () => {
      setOnline(navigator.onLine);
      if (navigator.onLine && account) {
        for (const entry of readDraftCache(account)) {
          const item=readStore().records.find(r=>r.id===entry.record.id);
          if(item) queueSave(item);
        }
      }
    };
    window.addEventListener("popstate", f);
    window.addEventListener("online", net);
    window.addEventListener("offline", net);
    return () => {
      window.removeEventListener("popstate", f);
      window.removeEventListener("online", net);
      window.removeEventListener("offline", net);
    };
  }, [account]);
  useEffect(() => {
    setNotice("");
  }, [modal]);
  useEffect(() => {
    const close = (e) => {
      if (
        e.type === "keydown"
          ? e.key === "Escape"
          : !e.target.closest(".ux-account-menu")
      )
        setMenu(false);
    };
    document.addEventListener("click", close);
    document.addEventListener("keydown", close);
    return () => {
      document.removeEventListener("click", close);
      document.removeEventListener("keydown", close);
    };
  }, []);
  const langControl = (
    <select
      aria-label={t("語言", "Language")}
      className="ux-lang"
      value={route.lang}
      onChange={(e) => setRoute({ ...route, lang: e.target.value })}
    >
      <option value="zh-HK">繁體中文</option>
      <option value="zh-CN">简体中文</option>
      <option value="en">English</option>
    </select>
  );
  const banner = (
    <div className="ux-demo">
      {t(
        "公司內部系統・僅限已授權員工使用。",
        "Company system · Authorized staff only.",
      )}
    </div>
  );
  const toast = notice ? (
    <div className={"ux-message"+(noticeImportant?" important-change":"")} role="status">
      {notice}
      <button aria-label={t("關閉", "Dismiss")} onClick={() => setNotice("")}>
        ×
      </button>
    </div>
  ) : null;
  const signIn = async (e) => {
    e.preventDefault();
    if (!online) {
      setNotice(
        t(
          "目前未有網絡連線，請保留輸入並於連線後重試。",
          "You are offline. Your input is retained. Reconnect and retry.",
        ),
      );
      return;
    }
    setBusy(true);
    try {
      setNotice("");
      await signInPhone(normalizeLoginPhone(email), password);
      setPassword("");
      const staff = await currentAccount();
      if (staff.canResearch && getRoute().screen === "login") { window.location.assign("/research"); return; }
      if (staff.canWork) {
        setChoosingWorkspace(true);
        return;
      }
      openWorkspace(staff, await workspace(), true);
    } catch {
      setNotice(t("帳戶或密碼不正確，或帳戶未獲授權。", "Invalid credentials or this account is not authorized."));
    } finally { setBusy(false); }
  };
  async function chooseWorkspace(role) {
    if (busy) return;
    setBusy(true);
    setNotice("");
    setWorkspaceRole(role);
    try {
      const [staff, data] = await Promise.all([currentAccount(), workspace()]);
      openWorkspace(staff, data, true);
    } catch {
      setWorkspaceRole(null);
      setNotice(t("暫時無法開啟工作台，請重試。", "Could not open the workspace. Please try again."));
    } finally {
      setBusy(false);
    }
  }
  async function cancelWorkspaceChoice() {
    if (busy) return;
    try { await signOut(); } catch {}
    finally {
      setChoosingWorkspace(false);
      setNotice("");
      go("login", "", true);
    }
  }
  if (authLoading) return <div className="ux ux-auth" role="status"><OperationFeedback busy t={t}/>{t("正在載入…", "Loading…")}</div>;
  if (!account || ["login", "forgot-password"].includes(route.screen))
    return (
      <div className="ux ux-auth"><OperationFeedback busy={busy} message={notice} important={!!notice&&noticeImportant} t={t}/>
        <header>
          <div className="brand-lockup"><HeaderLogo /><b>{t("維修業務系統", "Maintenance Operations")}</b></div>
          {langControl}
        </header>
        {banner}
        <main className="ux-login">
          <section className="ux-login-intro">
            <small>CHIT TAT</small>
            <h1>
              {t(
                "同一入口，連接現場與維修部。",
                "One sign-in. Connected field and office work.",
              )}
            </h1>
            <p>
              {t(
                "手機方便現場填報；電腦提供熟悉的表格工作台。畫面按尺寸排列，功能按帳戶權限提供。",
                "Mobile forms for site work. A familiar table workspace on desktop. Layout follows screen size; access follows the account.",
              )}
            </p>
            <div className="ux-login-stages">
              {t("① 維修人員：現場填寫服務單", "① Field staff: complete the service order on site")}
              <br />
              {t("② 維修部：覆核及修正服務單，在 INDEX 處理報價及發票", "② Maintenance dept: review and correct service orders, then handle quotations and invoices in INDEX")}
            </div>
          </section>
          <section className="ux-login-card">
            <h2>
              {route.screen === "forgot-password" ? t("重設密碼", "Reset password") : t("登入", "Sign in")}
            </h2>
            {route.screen === "forgot-password" ? (
              <div>
                <p>
                  {t(
                    "請聯絡公司管理員核實身分並重設密碼。",
                    "Contact the company administrator to verify your identity and reset your password.",
                  )}
                </p>
                <Btn type="button" onClick={() => go("login")}>
                  {t("返回登入", "Back to sign in")}
                </Btn>
              </div>
            ) : (
              <form onSubmit={signIn}>
                <Input
                  label={t("公司已登記的手機號碼", "Company-registered mobile number")}
                  type="tel"
                  inputMode="tel"
                  required
                  value={email}
                  onChange={setEmail}
                  autoComplete="username"
                />
                <Input
                  label={t("密碼", "Password")}
                  type="password"
                  required
                  value={password}
                  onChange={setPassword}
                  autoComplete="current-password"
                />
                <Btn
                  type="button"
                  className="ux-link"
                  onClick={() => go("forgot-password")}
                >
                  {t("忘記密碼？", "Forgot password?")}
                </Btn>
                <Btn primary disabled={busy}>{busy ? t("正在登入…", "Signing in…") : t("登入", "Sign in")}</Btn>
                <p>{t("僅公司已授權帳戶可登入。", "Only company-authorized accounts may sign in.")}</p>
              </form>
            )}
            {toast}
          </section>
        </main>
        {choosingWorkspace && <Modal title={t("選擇工作台", "Choose workspace")}
          close={cancelWorkspaceChoice} closeLabel={t("取消登入", "Cancel sign-in")} notice={notice}
          noticeImportant={noticeImportant}>
          <div className="ux-actions">
            <button type="button" disabled={busy} className="ux-btn workspace-choice" onClick={() => void chooseWorkspace("worker")}><b>{t("維修人員", "Maintenance personnel")}</b><small>{t("現場填報、補交維修部要求", "Field reports and corrections")}</small></button>
            <button type="button" disabled={busy} className="ux-btn workspace-choice" onClick={() => void chooseWorkspace("office")}><b>{t("維修部", "Office")}</b><small>{t("覆核修正服務單；辦公室在 INDEX 出報價及發票", "Review service orders; office issues quotes and invoices in INDEX")}</small></button>
          </div>
        </Modal>}
      </div>
    );
  const denied =
    (route.screen === "users" && !account.canManage) ||
    (route.screen.startsWith("office-") && worker) ||
    (route.screen.startsWith("worker-") && !worker) ||
    (record?.deletedAt) ||
    (record &&
      worker &&
      (record.source !== "worker" || record.owner !== account.email));
  const visible = db.records.filter(
    (r) =>
      !r.deletedAt && (!projectFilter || r.address===projectFilter) &&
      (source === "all" || r.source === source) &&
      (status === "all" ||
        (status === "pending"
          ? ["submitted", "draft", "revision", "needsInfo"].includes(r.status)
          : r.status === status)) &&
      [
        r.ref, r.entryNo, r.projectCode, r.contractRef,r.phone,r.contact,r.notes,r.remark,...(r.ledger||[]).flat(),
        r.date,r.tower,r.floor,r.flat,total(r),...r.items.map(i=>i.model||""),
        r.address,
        r.customer,
        r.projectName,
        r.brand,
        ...r.items.map(i=>i.brand||""),
        r.technician,
        ...r.items.map((i) => displayItem(i)),
      ]
        .join(" ")
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  const field = (key, hk, en, extra = {}) => (
    <Input
      key={key}
      data-feedback-target={key}
      error={activeIssues.find(e=>e.field===key)?t(activeIssues.find(e=>e.field===key).hk,activeIssues.find(e=>e.field===key).en):undefined}
      label={t(hk, en)}
      value={record?.[key]}
      onConfirm={worker&&["startedAt","completedAt"].includes(key)?()=>update({timeConfirmed:{...record.timeConfirmed,[key]:true}}):undefined}
      confirmRequired={worker&&["startedAt","completedAt"].includes(key)}
      confirmed={record?.timeConfirmed?.[key]}
      onChange={(v) => {if(key!=="chargeAmount"||moneyInput(v))update({[key]:v,...(worker&&["startedAt","completedAt"].includes(key)?{timeConfirmed:{...record.timeConfirmed,[key]:false}}:{})});}}
      disabled={!editAllowed}
      {...extra}
    />
  );
  const createFromProject = async (p, refs) => {
    try {
      const r = await apiCreateCase({
      projectId: p.id,
      projectCode: p.code,
      projectName: p.name,
      address: p.property,
      brand: p.brand,
      contractRef: p.contractRef,
      coverage: p.coverage,
      coverageNotes: p.coverageNotes,
      remark: p.itemTerms,
      items: refs.map((i) => ({
        id: uid(),
        preset: 14,
        description: i.description,
        qty: 1,
        model: "",
        brand: p.brand,
        price: i.price,
        reference: i.remark,
      })),
      });
      const latest = readStore();
      acceptWorkspace({ ...latest, records: [r, ...latest.records] });
      go("office-quote", r.id);
    } catch { setNotice(t("未能建立任務，請重試。", "Could not create task. Please retry.")); }
  };
  const validateReady = r => Boolean(r.customer.trim() && r.address.trim() && r.items.length && r.items.every(i=>validQuantity(i.qty) && i.price!=="" && Number.isFinite(Number(i.price)) && Number(i.price)>=0) && (!r.chargeAmount || /^\d+(?:\.\d{1,2})?$/.test(String(r.chargeAmount))) && !r.feedback.some(f=>!f.resolved));
  const showActionError = error => {
    const messages = {
      401: ["登入已過期，資料已保留；請重新登入。","Session expired. Your input is retained. Sign in again."],
      403: ["任務狀態或登入帳戶已改變，請返回任務查看最新狀態。","Task status or account changed. Reopen Tasks."],
      409: ["另一位同事已更新此任務。請返回任務重新開啟，再核對提交；本機草稿已保留。","Another colleague updated this task. Reopen it and review before submitting; your local draft is retained."],
    };
    const message=messages[error.status]||["暫時未能提交，輸入已保留。請檢查欄位及連線後重試。","Submission failed. Input is retained. Check fields and connection, then retry."];
    setNotice(t(...message),true);
    if(error.missingFields?.length){fieldStudy.track("validation_error",error.missingFields[0]);const issue=issues.find(i=>error.missingFields.includes(i.field));if(issue)focusIssue(issue);}
  };
  const approve = async () => {
    if(busy)return;
    if(issues.length){fieldStudy.track("validation_error",issues[0].field);focusIssue(issues[0]);return;}
    if(!record.projectCode?.trim()){setOfficeStep(0);setNotice(t("請先選擇地盤，或新增公司自訂的 Project Code。","Select a project or add its company-defined Project Code first."));return;}
    if(record.completedAt && record.startedAt && record.completedAt.slice(0,10)<record.startedAt.slice(0,10)){setOfficeStep(3);setNotice(t("完工時間不能早於開工時間。","Completion cannot be before commencement."));return;}
    if(!validateReady(record)){setOfficeStep(!record.customer.trim()||!record.address.trim()?0:record.feedback.some(f=>!f.resolved)?4:1);setNotice(t("請完成客戶、地址、有效數量及價錢，並解決所有標註。","Complete customer, address, quantities and prices, and resolve all requests."));return;}
    setBusy(true);
    try {
      await runAction(record, "confirm");
      const remaining=officeQueue.filter(r=>r.id!==record.id&&["submitted","revision"].includes(r.status)).length;
      go("office-inbox", "", true); setStatus("pending"); setNotice(t("已確認，INDEX 已更新。可在 INDEX 生成文件。","Confirmed. INDEX updated. Generate documents from INDEX.")+(remaining?t(` 尚有 ${remaining} 宗待覆核／修改中。`,` ${remaining} more to review or in revision.`):t(" 待覆核隊列已清空。"," The review queue is clear.")));
    } catch (error) { showActionError(error); } finally {setBusy(false);}
  };
  const prepareQuotes = (rows,type="quotation") => {
    const eligible=rows.filter(r=>["approved","issued"].includes(r.status)&&!r.pendingRevision);
    if(!eligible.length)return;
    setBatchQuotes(eligible);setDocType(type);setDocumentResult(null);generateDocuments(eligible,type);
  };
  const generateDocuments = async (chosenRecords = batchQuotes, chosenType = docType) => {
    if(busy)return;setNotice("");setBusy(true);
    try {
      const suggested=chosenType==="both"?documentPackageName(chosenRecords):chosenRecords.length===1?safeName((chosenType==="invoice"?chosenRecords[0].invoiceRef:chosenRecords[0].ref)+"_Rev"+chosenRecords[0].rev)+".pdf":chosenType+"_"+today()+".zip";

      const target=await chooseSaveTarget(suggested);
      const files=[];
      for(const chosen of chosenRecords){
        for(const type of (chosenType==="both"?["confirmed-service","quotation","invoice"]:[chosenType])){
          const result=await generateCaseDocument(chosen.id,type,chosen.rev);
          acceptRecord(result.record);
          const blob=await getAsset(result.assetKey);
          const folder=chosenType==="both"?safeName(chosen.ref)+"_Rev"+chosen.rev+"/":"";
          files.push({name:folder+safeName((type==="confirmed-service"?(chosen.serviceNo||chosen.ref)+"_服務單":type==="invoice"?chosen.invoiceRef:chosen.ref)+"_Rev"+chosen.rev)+".pdf",blob});
        }
      }
      let blob,name;
      if(files.length===1){({blob,name}=files[0]);}
      else {blob=await documentArchive(files);name=chosenType==="both"?documentPackageName(chosenRecords):chosenType+"_"+today()+".zip";}
      name=suggested;if(!blob.size)throw Error("Empty package");setDocumentResult({blob,name});
      await saveBlob(blob,name,target);
      setNotice(target?t("文件已儲存成功。","Files saved successfully."):t("文件已交給瀏覽器下載，請查看下載清單。","Download started. Check your browser downloads."));
    }catch(error){if(error.name==="AbortError")return;setNotice(error.message==="invalid-quotation-remarks-too-long"?t("報價備註超出一頁可容納的範圍，請精簡備註後重試。","Quotation remarks exceed one page. Shorten them and retry."):t("未能生成或儲存文件，資料仍然保留，請重試。","Could not generate or save documents. Your data is retained. Please retry."),true);}
    finally{setBusy(false);}
  };
  const addPhotos = async (files) => {
    const selected=Array.from(files||[]);
    if(!selected.length||busy)return;
    const latest=readStore().records.find(r=>r.id===record.id)||record;
    if(latest.photos.length+selected.length>20){setNotice(t("每個任務最多 20 張。","Up to 20 photos per task."),true);return;}
    const previews=selected.map(file=>({url:URL.createObjectURL(file),name:file.name,caseId:record.id}));
    setUploadPreviews(previews);setBusy(true);setNotice("");
    try{
      if(record.localOnly&&!await queueSave(latest))throw new Error("save-failed");
      for(const file of selected){
        const asset=await uploadCasePhoto(record.id,file);
        rememberPhoto(asset.key,file);
        const current=readStore().records.find(r=>r.id===record.id)||latest;
        update({photos:[...current.photos,{id:uid(),assetKey:asset.key,name:file.name,url:asset.url,caption:""}]});
        if(!await pendingSaves.current.get(record.id))throw new Error("save-failed");
      }
      setNotice(t("相片已儲存。","Photos saved."));
    }catch{setNotice(t("相片未能全部儲存，請重試。已成功儲存的相片會保留。","Some photos could not be saved. Retry; saved photos are retained."),true);}
    finally{setUploadPreviews([]);previews.forEach(p=>URL.revokeObjectURL(p.url));setBusy(false);}
  };
  const exportCompact = async(rows,year) => {
    setBusy(true);
    try{const {default:ExcelJS}=await import("exceljs");const wb=new ExcelJS.Workbook();const ws=wb.addWorksheet("INDEX_"+(year||today().slice(0,4)));ws.addRow(INDEX_COLUMNS);
    rows.forEach((r,n)=>ws.addRow(compactRow(r,n,route.lang)));ws.views=[{state:"frozen",ySplit:1}];ws.autoFilter="A1:L"+Math.max(1,rows.length+1);ws.columns.forEach((c,i)=>{c.width=[8,15,26,9,10,10,10,28,45,18,28,24][i]});ws.getColumn(10).numFmt='#,##0.00';
    downloadBlob(new Blob([await wb.xlsx.writeBuffer()],{type:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}),"INDEX_"+(year||"ALL")+"_"+today()+".xlsx");
    setNotice(t("已匯出 12 欄 INDEX。","The 12-column INDEX has been exported."));
    }catch{setNotice(t("未能匯出，請重試。","Export failed. Please retry."));}finally{setBusy(false);}
  };
  const bulkReview = async () => {
    let count = 0;
    for (const r of db.records.filter(r => bulkIds.includes(r.id) && r.status === "submitted")) {
      try { await runAction(r, "review"); count++; } catch {}
    }
    setNotice(
        t("已完成覆核：", "Reviewed: ") +
          count +
          t(
            "；其餘選取記錄未符合條件，保持不變。",
            "; other selected records did not meet the requirements and remain unchanged.",
          ),
      );
    setBulkIds([]);
  };
  const basics = record && <div>

    <h3>{t("01 日期及工作地點","01 Date and site")}</h3><p>{t("除標示補充／如有的資料外，所有欄位均須填寫。不適用的座數、樓層、單位或型號請填「不適用」。","Complete every field except optional supplements. Enter N/A for inapplicable tower, floor, flat or model.")}</p>
    <div className="ux-fields">
      {field("date","日期","Date",{type:"date"})}
      {worker&&field("address","地址／屋苑","Address / Property",{suggestions:[...ADDRESSES,...(db.projects||[]).map(p=>p.property)]})}
    {!worker&&<ProjectPicker onSelected={()=>{setFeedbackTarget(null);setNotice("")}} db={db} record={record} update={update} commit={commit} t={t} disabled={!editAllowed} error={activeIssues.find(e=>e.field==="project")?t(activeIssues.find(e=>e.field==="project").hk,activeIssues.find(e=>e.field==="project").en):""}>{field("address","地址／屋苑","Address / Property",{suggestions:[...ADDRESSES,...(db.projects||[]).filter(p=>p.active!==false).map(p=>p.property)]})}</ProjectPicker>}
      {field("tower","座數","Tower")}{field("floor","樓層","Floor")}{field("flat","單位","Flat")}
    </div>
    <h3>{t("02 客戶及負責人","02 Customer and person in charge")}</h3>
    <div className="ux-fields">
      {field("customerType","客戶類型","Customer type",{options:[["property",t("物業","Property management")],["owner",t("業主","Owner")]]})}
      {field("customer","客戶名稱","Customer name")}{field("contact","聯絡人","Contact person")}
      {field("occupant","住戶資料","Occupant details")}{field("phone","客戶聯絡電話","Customer phone",{type:"tel"})}
      {field("technician","填報負責人（帳戶綁定）","Report owner (account-bound)",{disabled:true})}
    </div>
    {!worker && <details><summary>{t("合約及項目補充資料（有需要才填）","Contract and project details (optional)")}</summary><div className="ux-fields">
      {field("projectName","地盤名稱（由所選地盤帶入）","Project name (from selected project)",{disabled:true})}
      {field("contractRef","合約／報價參考","Contract / quote reference")}
      {field("brand","預設空調品牌（項目可另選）","Default AC brand (overridable per item)",{suggestions:["Daikin","Mitsubishi Electric","Panasonic","Hitachi","Carrier","Toshiba","LG","Samsung"]})}
      {field("coverage","保養狀態","Maintenance coverage",{options:[["unknown",t("未指定","Unspecified")],["contract",t("有合約／保養","Under contract")],["none",t("無保養","No maintenance")],["expired",t("合約已完","Expired")]]})}
      {field("coverageNotes","保養及服務條件","Maintenance and service notes")}
    </div></details>}
  </div>;
  const saveItem = () => {
    if (
      !editItem ||
      !validQuantity(editItem.qty) ||
      !editItem.model?.trim() || !(editItem.brand||record.brand)?.trim() ||
      (!worker && editItem.price !== "" &&
        !validMoney(editItem.price)) ||
      (editItem.preset === 14 && !editItem.description.trim())
    ) {
      setFeedbackTarget({field:!editItem?.model?.trim()?"model":!(editItem?.brand||record.brand)?.trim()?"brand":!validQuantity(editItem?.qty)?"qty":editItem?.preset===14&&!editItem.description.trim()?"description":"price",text:t("請修正此欄位後儲存。","Correct this field before saving.")});
      setNotice(
        t(
          "請填寫有效數量、非負價錢，以及「其他」項目的說明。",
          "Enter a valid quantity, non-negative price, and a description for Other.",
        ),
      );
      return;
    }
    const safeItem=worker?{...editItem,price:record.items.find(i=>i.id===editItem.id)?.price??""}:{...editItem,priceConfirmed:editItem.price!==""&&editItem.price!=null,priceDraft:undefined};
    const items = record.items.some((i) => i.id === editItem.id)
      ? record.items.map((i) => (i.id === editItem.id ? safeItem : i))
      : [...record.items, safeItem];
    if (update({ items, ...(!worker?{priceDrafts:Object.fromEntries(Object.entries(record.priceDrafts||{}).filter(([id])=>id!==editItem.id))}:{}) })) {
      setModal("");
      go(worker ? "worker-work" : route.screen, record.id);
      if(!worker)setOfficeStep(1);
      setNotice(
        t(
          "項目已儲存。可繼續新增或進行下一步。",
          "Item saved. Add another item or continue.",
        ),
      );
    }
  };
  const itemsPanel = record && (
    <>
      <div className="ux-section-title">
        <h2>{worker?t("工作內容","Work items"):t("工作項目","Work items")}</h2>
        {editAllowed && (
          <Btn
            onClick={() => {
              setCategory("all");
              setModal("picker");
            }}
          >
            ＋ {t("新增一行", "Add row")}
          </Btn>
        )}
      </div>
      <div className={"ux-work-items"+(activeIssues.some(e=>e.field==="items")?" field-invalid":"")} data-feedback-target="items" tabIndex="-1">{activeIssues.filter(e=>e.field==="items").map((e,n)=><p role="alert" className="field-error" key={n}>{t(e.hk,e.en)}</p>)}
        {record.items.map((i, n) => (
          <div key={i.id} className="work-item-accordion"><button
            aria-expanded={!worker ? pricingExpandedId===i.id : undefined}
            disabled={worker&&!editAllowed}
            className="ux-work-item"
            key={i.id}
            onClick={() => {
              if (worker) {
                setEditItem({ ...i });
                setModal("item");
              } else {
                setPricingExpandedId(current => current === i.id ? "" : i.id);
              }
            }}
          >
            <span className="work-item-number">{String(n + 1).padStart(2, "0")}</span>
            <span className="work-item-copy">
              <b>{displayItem(i)}</b>
              <small>
                {t("數量", "Quantity")}: {i.qty} · {t("型號", "Model")}:{" "}
                {i.model || "—"} · {t('品牌','Brand')}: {i.brand||record.brand||'—'}
              </small>
            </span>
            {!worker&&<span className="work-item-price">
              {i.price===""||i.price==null?t("待定價","To price"):<><small>{t("單價","Unit price")}</small><strong>{money(i.price)}</strong></>}
            </span>}
            <span className="work-item-disclosure">{worker ? (editAllowed ? t("編輯", "Edit") : t("檢視", "View")) : pricingExpandedId===i.id ? t("收起定價", "Hide pricing") : t("查看定價", "View pricing")} {worker?"›":<CaretDown aria-hidden="true"/>}</span>
          </button>
        {!worker&&pricingExpandedId===i.id&&<PricingPanel
          record={record}
          update={update}
          t={t}
          editAllowed={editAllowed}
          displayItem={displayItem}
          money={money}
          issues={activeIssues}
          expandedId={pricingExpandedId}
          onEdit={i=>{setEditItem({...i});setModal("item")}}
          onRemove={i=>{
            if(window.confirm(t("確定刪除此工作項目？","Delete this work item?"))){
              setPricingExpandedId("");
              update({items:record.items.filter(item=>item.id!==i.id),priceDrafts:Object.fromEntries(Object.entries(record.priceDrafts||{}).filter(([id])=>id!==i.id))});
            }
          }}
        />}
          </div>
        ))}
      </div>
      {!record.items.length && (
        <p className="ux-empty">
          {t(
            "尚未新增項目。按「新增一行」選擇項目並填寫詳情。",
            "No items yet. Select Add row, choose an item and complete its details.",
          )}
        </p>
      )}
      {!worker && <section className="ux-discount" aria-label={t("優惠金額","Less discount")}>
        <div>
          <label className="ux-field ux-discount-field" data-feedback-target="discountAmount">
            <span>{t("優惠金額","Less discount")}</span>
            <div className="ux-discount-input">
              <span aria-hidden="true">HK$</span>
              <input aria-label="Less discount HK$" type="text" inputMode="decimal" disabled={!editAllowed}
                aria-invalid={!!discountIssue} aria-describedby={discountHintId}
                value={record.discountAmount ?? "0"}
                onChange={e=>{if(moneyInput(e.target.value))update({discountAmount:e.target.value});}} />
            </div>
          </label>
          {discountIssue
            ? <p id={discountHintId} className="field-error" role="alert">{t(discountIssue.hk,discountIssue.en)}</p>
            : <p id={discountHintId}>{t("沒有優惠填 0。折扣從整單扣減，原單價不變。", "Enter 0 for no discount. The discount applies to the order total; unit prices stay the same.")}</p>}
        </div>
        <CommercialTotals record={record} money={money}/>
      </section>}
    </>
  );
  const searchbar = (
    <div className="ux-filters">
      <Input
        type="search"
        label={t(
          "搜尋編號、地址或客戶",
          "Search reference, address or customer",
        )}
        value={query}
        onChange={v=>{setQuery(v);setBulkIds([])}}
      />
      {<Input
        label={t("來源", "Source")}
        value={source}
        onChange={v=>{setSource(v);setBulkIds([])}}
        options={[
          ["all", t("全部來源", "All sources")],
          ["worker", t("維修人員", "Maintenance personnel")],
          ["office", t("維修部", "Office")],
        ]}
      />}
      <Input
        label={t("狀態", "Status")}
        value={status}
        onChange={v=>{setStatus(v);setBulkIds([])}}
        options={[
          ["all", t("全部狀態", "All statuses")],
          ["pending", t("全部待處理", "All to process")],
          ["submitted", t("待覆核（維修人員提交）", "To review (worker submissions)")],
          ["revision", t("修改中（已確認後重開）", "In revision")],
          ["draft",t("草稿 · 未完成","Draft · Incomplete")],
          ["needsInfo", t("待維修人員確認", "Awaiting worker")],
        ]}
      />
      <Btn
        onClick={() => {
          setQuery("");
          setSource("all");
          setStatus("pending");
          setProjectFilter("");
        }}
      >
        {t("清除篩選", "Clear filters")}
      </Btn>
    </div>
  );
  const recordTable = (rows) => {
    const eligibleIds = rows.filter(record => record.status === "draft").map(record => record.id);
    const selectedIds = eligibleIds.filter(id => draftIds.includes(id));
    const allSelected = eligibleIds.length > 0 && eligibleIds.length === selectedIds.length;

    return <>
      <div className="ux-actions task-bulk-actions">
        <Btn disabled={!eligibleIds.length} onClick={() => setDraftIds(allSelected ? [] : eligibleIds)}>
          {allSelected ? t("取消全選", "Deselect all") : t("全選可刪除任務", "Select all deletable tasks")}
        </Btn>
        <Btn className="ux-btn danger-text" disabled={!selectedIds.length} onClick={() => {
          setDraftIds(selectedIds);
          setModal("delete-drafts");
        }}>
          {t("刪除所選任務", "Delete selected tasks")} ({selectedIds.length})
        </Btn>
      </div>
      <div className="ux-grid-scroll">
      <table className="ux-grid">
        <thead>
          <tr>
            <th>{t("選取","Select")}</th>{[
              t("記錄／報價編號", "Record / Quote reference"),
              t("來源", "Source"),
              t("地址／屋苑", "Property"),
              t("客戶", "Customer"),
              t("工作內容", "Work items"),
              t("狀態", "Status"),
              t("跟進", "Action"),
            ].map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, n) => (
            <tr key={r.id}><td>{r.status==="draft"&&<input type="checkbox" aria-label={t("選取任務 ","Select task ")+(r.customer||r.entryNo||r.id)} checked={draftIds.includes(r.id)} onChange={e=>setDraftIds(e.target.checked?[...draftIds,r.id]:draftIds.filter(id=>id!==r.id))}/>}</td>
              <td>
                <button className="ux-link" onClick={() => open(r)}>
                  {r.serviceNo || r.entryNo || t("尚未編號","Not numbered")}
                </button>
              </td>
              <td>
                <span className={"source-tag source-"+r.source}>
                  {r.source === "worker"
                    ? t("維修人員", "Maintenance personnel")
                    : t("維修部", "Office")}
                </span>
              </td>
              <td>{r.address || "—"}</td>
              <td>{r.customer || "—"}</td>
              <td>{r.items.map((i) => displayItem(i)).join("; ") || "—"}</td>
              <td>
                <span className={"ux-status state-"+statusTone(r)}>{sLabel(r.status)}{r.rev>0?" · Rev "+r.rev:""}</span>
                {r.history.length>0 && <small> · {r.rev ? "Rev "+r.rev : t("原版","Original")} · {r.history.length} {t("個已生成版本","generated versions")}</small>}
              </td>
              <td>
                <div className="ux-actions"><Btn onClick={() => open(r)}>
                  {["approved","issued"].includes(r.status) ? t("查看已確認資料","View confirmed details") : ["submitted", "needsInfo"].includes(r.status)
                    ? t("覆核資料", "Review details")
                    : t("開啟報價", "Open quote")}
                </Btn>{["approved","issued"].includes(r.status)&&<Btn onClick={()=>go("office-index")}>{t("查看 INDEX","View INDEX")}</Btn>}{r.status==="draft"&&<Btn className="ux-btn danger-text" onClick={()=>{setDraftIds([r.id]);setModal("delete-drafts")}}>{t("刪除","Delete")}</Btn>}</div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {!rows.length && (
        <p className="ux-empty">
          {t("沒有符合條件的記錄。", "No matching records.")}
        </p>
      )}
      </div>
    </>;
  };
  async function loadWorkbook(file) {
    if (!file) return;
    setUpload(null);
    setImportResult(null);
    if (!/\.xlsx$/i.test(file.name) || file.size > 10 * 1024 * 1024) {
      setNotice(
        t(
          "請選擇不超過 10 MB 的 .xlsx 檔案。舊 .xls 請先於 Excel 另存為 .xlsx。",
          "Choose an .xlsx file up to 10 MB. Save legacy .xls as .xlsx in Excel first.",
        ),
      );
      return;
    }
    setBusy(true);
    try {
      const { default: ExcelJS } = await import("exceljs");
      const wb = new ExcelJS.Workbook();
      await wb.xlsx.load(await file.arrayBuffer());
      if (
        wb.worksheets.some((s) => s.rowCount > 10000 || s.columnCount > 100)
      ) {
        throw Error("limit");
      }
      const sheets = wb.worksheets.map((s) => ({
        name: s.name,
        rows: Array.from({ length: s.rowCount }, (_, r) =>
          Array.from({ length: s.columnCount }, (_, c) =>
            normalizeCell(s.getCell(r + 1, c + 1).value),
          ),
        ),
      }));
      const idx = sheets.find((s) => /^INDEX_\d{4}$/.test(s.name));
      if (!idx) {
        setNotice(
          t(
            "找不到 INDEX_年份 分頁。請選擇含首 12 欄的 INDEX 格式。",
            "No INDEX_year worksheet found. Select an INDEX workbook with the first 12 columns.",
          ),
        );
        return;
      }
      setUpload({
        name: file.name,
        file,
        sheets: [{...idx,rows:idx.rows.map(r=>r.slice(0,12))}],
        projects: [],
        ...parseIndex(idx, db.records),
      });
    } catch {
      setNotice(
        t(
          "未能讀取檔案。請檢查是否已加密、損壞或超過 10,000 行／100 欄。",
          "Could not read the file. Check for encryption, damage, or more than 10,000 rows / 100 columns.",
        ),
      );
    } finally {
      setBusy(false);
    }
  }
  async function exportWorkbook() {
    setBusy(true);
    try {
      await downloadOfficeWorkbook(db, route.lang);
      setNotice(
        t(
          "已匯出總表、明細、即時彙總及項目參考。Excel 巨集與原樞紐分析物件不包含在內。",
          "Register, details, live totals and project references exported. Macros and original pivot objects are not included.",
        ),
      );
    } catch {
      setNotice(t("匯出失敗，請重試。", "Export failed. Please retry."));
    } finally {
      setBusy(false);
    }
  }
  const confirmImport = async () => {
    if (
      !upload ||
      upload.errors.length ||
      (!upload.records.length && !upload.projects.length)
    )
      return;
    setBusy(true);
    try {
      const result = await importIndexWorkbook(upload.file);
      await refreshWorkspace();
      setImportResult({
        count: result.count,
        rows: result.rowCount,
        skipped: result.duplicates,
      });
      setUpload(null);
    } catch { setNotice(t("匯入失敗，資料未變更。請檢查檔案或聯絡管理員。", "Import failed; no data was changed. Check the file or contact an administrator.")); }
    finally { setBusy(false); }
  };
  const submitWorker = async (checked=false) => {
    if(busy)return;
    if(issues.length){fieldStudy.track("validation_error",issues[0].field);focusIssue(issues[0]);return;}
    if (!online) {
      setNotice(
        t(
          "未連線，無法提交；恢復連線後請重新開啟任務並重試。",
          "Offline. Reconnect, reopen the task, and try submitting again.",
        ),
      );
      return;
    }
    if (
      !record.customer.trim() ||
      !record.address.trim() ||
      !record.items.length
    ) {
      setNotice(
        t(
          "請先填寫客戶、地址及至少一個工作項目。",
          "Enter a customer, address and at least one work item.",
        ),
      );
      return;
    }
    const problem=serviceError(record);
    if(problem){go(problem[0]==="phone"?"worker-basic":"worker-photo",record.id);setNotice(t(problem[1],problem[2]));return;}
    if(!checked)return fieldStudy.gate(record,()=>submitRef.current(true));
    setBusy(true);
    try{
      await runAction(record, "submit");
      go("worker-success", record.id, true);
    }catch(error){showActionError(error);}
    finally{setBusy(false);}
  };
  submitRef.current=submitWorker;

  const sendFeedback = async () => {
    if (!feedbackText.trim()) {
      setNotice(
        t(
          "請填寫具體需要確認的內容。",
          "Describe exactly what needs confirmation.",
        ),
      );
      return;
    }
    try {
      await runAction(record, "return", {
        field: feedbackField,
        reason: feedbackReason,
        itemId: ["model", "qty"].includes(feedbackField) ? (feedbackItemId || (record.items.length === 1 ? record.items[0].id : null)) : null,
        text: feedbackText,
      });
      setFeedbackText("");
      setFeedbackReason("unknown");
      go("office-inbox", "", true);
      setNotice(
        t(
          "已標註並退回此維修人員的記錄。任務會顯示於「待維修人員回覆」，補交後回到「待覆核」。",
          "The request has been returned to the maintenance employee. It appears under Awaiting worker and returns to To review after resubmission.",
        ),
      );
    } catch { setNotice(t("退回失敗，請重新載入後重試。", "Return failed. Reload and retry.")); }
  };
  const issue = async () => {
    try {
      await runAction(record, "confirm");
        setModal("");
        setNotice(
          t(
            "報價已確認，已保留內容快照。",
            "Quotation confirmed. A content snapshot has been retained.",
          ),
        );
    } catch {
      setModal("");
      setNotice(
        t(
          "請先填寫客戶、地址、工作項目、有效數量及所有價錢。",
          "Complete the customer, address, work items, valid quantities and all prices first.",
        ),
      );
    }
  };
  let content;
  if (denied)
    content = (
      <>
        <h1>{t("沒有存取權限", "Access denied")}</h1>
        <p>
          {t(
            "此帳戶不能開啟其他崗位或其他維修人員的記錄。",
            "This account cannot open another role or maintenance personnel’s records.",
          )}
        </p>
        <Btn onClick={() => go(home)}>
          {t("返回工作台", "Back to workspace")}
        </Btn>
      </>
    );
  else if (route.screen === "office-inbox") content=<>
    <div className="ux-heading"><div><small>{t("維修部工作台","OFFICE WORKSPACE")}</small><h1>{t("任務","Tasks")}</h1><p>{t("維修人員提交及維修部自建，在同一處處理。覆核、填寫或修改後，確認並更新 INDEX。","Handle worker submissions and office-created tasks together. Review, complete or edit details, then confirm and update INDEX.")}</p></div><div className="ux-actions"><Btn onClick={()=>{setUpload(null);setImportResult(null);go("office-import")}}>↓ {t("匯入 Excel","Import Excel")}</Btn><Btn primary onClick={create}>＋ {t("建立任務","Create task")}</Btn></div></div>
    <div className="office-queue" role="group" aria-label={t("工作隊列","Work queues")}>
      {[
        ["submitted","待覆核","To review","維修人員已提交，請先處理","Submitted by workers — handle first"],
        ["revision","修改中","In revision","已確認後重開，需重新確認","Reopened after confirmation — reconfirm"],
        ["draft","草稿","Drafts","維修部自建，尚未填妥","Office-created, incomplete"],
        ["needsInfo","待維修人員回覆","Awaiting worker","已退回，等待補交","Returned, awaiting resubmission"],
      ].map(([key,h,e,dh,de])=><button type="button" key={key} className={"queue-card workspace-sheen queue-"+key+(status===key?" active":"")} aria-pressed={status===key} onClick={()=>{setStatus(status===key?"pending":key);setSource("all");setBulkIds([]);setDraftIds([]);}}>
        <strong>{officeCounts[key]}</strong><b>{t(h,e)}</b><small>{t(dh,de)}</small>
      </button>)}
    </div>
    {searchbar}
    <p role="status">{t("按優先次序排列：待覆核 → 修改中 → 草稿 → 待維修人員回覆。確認後會自動移至 INDEX。","Sorted by priority: To review → In revision → Drafts → Awaiting worker. Confirmed work moves to INDEX automatically.")}</p>
    {recordTable(officeQueue.filter(r=>visible.includes(r)))}
    <RecycleBin records={deletedDrafts} t={t} lang={route.lang} onChanged={refreshWorkspace}/>
    <p>{t("維修人員資料：可自行修正便直接修改；需要現場確認才標註並退回。維修部自建：填妥後直接確認。已確認任務可查看歷史，再開啟修改；來源和報價編號保持不變。","Maintenance personnel details: correct minor issues directly; return marked questions only when site verification is needed. Office tasks: complete and confirm directly. For confirmed tasks, view history and start an edit; the source and quote reference stay unchanged.")}</p>
  </>;
  else if (route.screen === "office-index")
    content=<CompactIndex records={db.records} t={t} lang={route.lang} open={async q=>{let current=readStore().records.find(r=>r.id===q.id);if(!current){setBusy(true);try{current=(await workspace()).records.find(r=>r.id===q.id);if(current)acceptRecord(current);}catch{setNotice(t("未能載入資料，請重試。","Could not load the record. Please retry."),true);return;}finally{setBusy(false);}}if(current&&!current.deletedAt)open(current);else setNotice(t("此記錄已移除，請重新選取。","This record was removed. Please select another."),true);}} generate={prepareQuotes} exportExcel={exportCompact} busy={busy}/>;
  else if (route.screen === "office-confirmed" && record) content=<><div className="ux-actions"><Btn onClick={()=>go("office-index")}>{t("返回 INDEX","Back to INDEX")}</Btn></div><h1>{record.ref} · {t("已確認內容（唯讀）","Confirmed details (read only)")}</h1><section className="document-center" aria-label={t("報價及發票下載","Quotation and invoice downloads")}><h2>{t("生成報價及發票","Generate quotation and invoice")}</h2><p>{t("使用同一份已確認資料及版本。可同時預覽報價單及發票，並一次下載有時間編號的壓縮檔。","Use the same confirmed details and revision. Preview both documents together and download one time-stamped ZIP package.")}</p><div className="ux-actions"><Btn primary disabled={!["approved","issued"].includes(record.status)} onClick={()=>prepareQuotes([record],"both")}>{t("生成服務單、報價單＆發票","Generate quotation & invoice")}</Btn></div><small>{t("修改中的任務須先確認；重複下載不新增版本。","Confirm pending edits first. Repeat downloads do not add revisions.")}</small></section><p>{record.address} · {record.source==="worker"?t("維修人員","Maintenance personnel"):t("維修部","Office")} · {sLabel(record.status)}</p><div className="ux-actions"><Btn onClick={()=>editRecord(record)}>{t("修改此任務","Edit this task")}</Btn></div><details className="ux-panel"><summary>{t("全部已確認資料及相片（唯讀）","All confirmed details and photos (read only)")}</summary><dl>{[["projectName","項目名稱","Project name"],["contractRef","合約參考","Contract reference"],["address","屋苑","Property"],["tower","座數","Tower"],["floor","樓層","Floor"],["flat","單位","Flat"],["customer","客戶","Customer"],["contact","聯絡人","Contact"],["phone","電話","Phone"],["occupant","住戶","Occupant"],["technician","負責人","Technician"],["brand","預設品牌","Default brand"],["coverageNotes","服務條件","Service notes"],["notes","現場描述","Site description"],["remark","報價備註","Quote remarks"]].map(([k,h,e])=><React.Fragment key={k}><dt>{t(h,e)}</dt><dd>{effectiveQuote(record)[k]||"—"}</dd></React.Fragment>)}</dl><PhotoList record={effectiveQuote(record)} t={t}/></details><DocumentHistory record={record} t={t}/></>;
  else if (route.screen === "office-import")
    content = (
      <>
        <div className="ux-heading">
          <div>
            <h1>{t("匯入 Excel", "Import Excel")}</h1>
            <p>
              {t(
                "選擇檔案 → 核對預覽 → 確認匯入 → 查看 INDEX",
                "Select file → Review preview → Confirm import → Open INDEX",
              )}
            </p>
          </div>
          <Btn onClick={() => go("office-inbox")}>
            {t("返回任務", "Back to tasks")}
          </Btn>
        </div>
        <section className="ux-panel">
          <label className="ux-upload">
            ↓ {t("選擇 .xlsx 檔案", "Choose .xlsx file")}
            <input
              type="file"
              accept=".xlsx"
              disabled={busy}
              onChange={(e) => { const file=e.target.files[0]; e.target.value=""; loadWorkbook(file); }}
            />
          </label>
          <p>
            {t(
               "先在此瀏覽器預覽；確認後上載首 12 欄 INDEX 到公司伺服器。不執行巨集或重算 Excel 公式。",
               "Preview the workbook, then import the 12-column INDEX into the company system after confirmation. Macros are not run and formulas are not recalculated.",
            )}
          </p>
          {busy && (
            <p role="status">
              {t("正在讀取及核對欄位…", "Reading and validating columns…")}
            </p>
          )}
          {upload && (
            <>
              <h2>{upload.name}</h2>
              <p>
                {t("分頁", "Worksheets")}:{" "}
                {upload.sheets.map((s) => s.name).join(" · ")}
              </p>
              <p>
                {t("可新增案件", "New records")}: {upload.records.length} ·{" "}
                {t("新增項目參考", "New project references")}:{" "}
                {upload.projects.length} ·{" "}
                {t("重複行（略過）", "Duplicate rows (skip)")}:{" "}
                {upload.duplicates} · {t("錯誤", "Errors")}:{" "}
                {upload.errors.length}
              </p>
              {!upload.errors.length && !upload.records.length && !upload.projects.length && <div className="ux-panel" role="status"><h3>{upload.duplicates ? t("資料已存在，毋須重複匯入","Records already exist — no import needed") : t("沒有可匯入的資料","No records available to import")}</h3><p>{upload.duplicates ? t("檔案已成功讀取，但所有報價編號均已存在。為免重複計算及覆蓋修改，系統不會再次新增。請到 INDEX 查看；如需修改，開啟已有報價後選擇「修改此任務」。","The file was read successfully, but all quotation references already exist. Nothing is added or overwritten, preventing duplicate totals. View INDEX; to amend a quotation, open it and choose Edit this task.") : t("請檢查 INDEX_2026 是否包含報價編號及資料行。","Check that INDEX_2026 contains quotation references and data rows.")}</p>{upload.duplicates > 0 && <Btn primary onClick={()=>{setQuery("");setSource("all");setStatus("all");setProjectFilter("");setSheet(0);go("office-index")}}>{t("查看已有資料（INDEX）","View existing records (INDEX)")}</Btn>}</div>}
              {upload.errors.length > 0 && (
                <div role="alert">
                  <p>
                    {t(
                      "尚未匯入。請修正以下欄位或金額後重試。",
                      "Nothing imported. Correct these columns or amounts and retry.",
                    )}
                  </p>
                  <ul>
                    {upload.errors.slice(0, 20).map((e, i) => (
                      <li key={i}>{e}</li>
                    ))}
                  </ul>
                </div>
              )}
              <div className="ux-grid-scroll">
                <table className="ux-grid">
                  <thead>
                    <tr>
                      <th>QUO ref. no.</th>
                      <th>Location</th>
                      <th>CUS.</th>
                      <th>QUO. Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {upload.records.slice(0, 8).map((r) => (
                      <tr key={r.id}>
                        <td>{r.ref}</td>
                        <td>{r.address}</td>
                        <td>{r.customer}</td>
                        <td>{money(total(r))}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p>
                {t(
                  "預覽首八宗案件。同一報價的分期發票行會保留；已存在的報價不會被覆蓋。",
                  "Preview of the first eight records. Instalment invoice rows are retained; existing quotations are not overwritten.",
                )}
              </p>
              <Btn
                primary
                disabled={
                  !!upload.errors.length ||
                  (!upload.records.length && !upload.projects.length)
                }
                onClick={confirmImport}
              >
                {t("確認匯入", "Confirm import")}
              </Btn>
            </>
          )}
          {importResult && (
            <div role="status">
              <h2>{t("匯入完成", "Import complete")}</h2>
              <p>
                {t("已新增案件", "Records added")}: {importResult.count} ·{" "}
                {t("略過重複行", "Duplicate rows skipped")}:{" "}
                {importResult.skipped}
              </p>
              <Btn
                primary
                onClick={() => {
                  setQuery("");
                  setSource("all");
                  setStatus("all");
                  setSheet(0);
                  go("office-index");
                }}
              >
                {t("查看 INDEX 總表", "Open INDEX register")}
              </Btn>
            </div>
          )}
        </section>
      </>
    );
  else if (
    [
      "office-case",
      "office-quote",
      "office-new",
      "office-pdf",
      "office-versions",
      "office-issue",
      "office-send",
    ].includes(route.screen)
  )
    content = !record ? (
      <>
        <h1>{t("請先選擇記錄", "Select a record first")}</h1>
        <Btn onClick={() => go("office-inbox")}>
          {t("返回任務", "Back to tasks")}
        </Btn>
      </>
    ) : (
      <>
        <div className="ux-heading">
          <div>
            <small>
              {record.source === "worker"
                ? t("維修人員來源", "Maintenance personnel submission")
                : t("維修部建立", "Created in office")}{" "}
              · {sLabel(record.status)}
            </small>
            <h1>
              {route.screen === "office-case"
                ? t("覆核提交資料", "Review submission")
                : record.ref || t("任務報價", "Task quotation")}
              {record.rev > 0 && ` / Rev ${record.rev}`}
            </h1>
            <p>
              {t(
                "欄位及項目修改會自動儲存至公司系統。",
                "Field and item changes save automatically to the company system.",
              )}
            </p>
          </div>
          <div className="ux-actions">
            <Btn onClick={() => go(["approved","issued"].includes(record.status) ? "office-index" : "office-inbox")}>
              {t("返回任務列表", "Back to task list")}
            </Btn>
            {nextOfficeTask && <Btn onClick={() => open(nextOfficeTask)}>
              {t("下一宗待處理", "Next task")} →
            </Btn>}
          </div>
        </div>
        {record.source === "worker" && (
          <div className="ux-progress">
            <b>
              {t("維修人員資料完整度", "Maintenance personnel detail completeness")}:{" "}
              {completeness(record).percent}%
            </b>
            <progress value={completeness(record).percent} max="100" />
            <div className="missing-fields">{issues.map((issue,n)=><button type="button" className="missing-tag" key={issue.field+n} onClick={()=>focusIssue(issue)}>⚠ {t(issue.hk,issue.en)}</button>)}</div>
            <small>
              {t(
                "只作覆核提示；價錢由維修部決定。",
                "Review guidance only; the office sets prices.",
              )}
            </small>
          </div>
        )}
        {record.status === "issued" && (
          <div className="ux-callout">
            {t(
              "已簽發版本唯讀。正式內容需要修改時，修改已簽發報價；原版本不會被覆蓋。",
              "Issued versions are read-only. Create a revision to change formal content; the previous version remains intact.",
            )}{" "}
            <Btn
              onClick={() => editRecord(record)}
            >
              {t("修改已簽發報價", "Modify issued quote")} · Rev{" "}
              {record.rev + 1}
            </Btn>
          </div>
        )}
        {record.status === "revision" && (
          <div className="ux-callout important-change" role="alert">
            {t(
              "目前正在修改；重新確認後才返回 INDEX。金額彙總暫時保留上次已確認金額，不重複加總版本。",
              "Editing in progress. Reconfirm to return to INDEX. Financial summaries retain the last confirmed amount without adding historical versions.",
            )}
            <Btn
              onClick={async () => {
                try { await runAction(record, "discard-revision"); go("office-confirmed", record.id); }
                catch { setNotice(t("未能取消修改，請重新載入。", "Could not discard changes. Reload and retry."),true); }
              }}
            >
              {t("取消本次修改", "Discard pending changes")}
            </Btn>
          </div>
        )}
        <p className="ux-callout">{t("可點選步驟直接跳轉，或使用上一步／下一步。資料自動儲存；確認後只更新 INDEX，報價單及發票在 INDEX 生成。","Tap a step to jump, or use Previous / Next. Details save automatically; confirmation updates INDEX only — quotations and invoices are generated from INDEX.")}</p>
        <ol className="service-steps" aria-label={t("填寫進度","Entry progress")}>{[t("客戶及物業","Customer and property"),t("工作項目及定價","Work items and pricing"),t("相片及現場描述","Photos and site notes"),t("服務資料及報價備註","Service details and quote remarks"),t("核對及確認","Review and confirm")].map((name,i)=><li key={i} className={officeStep===i?"step-current":i<officeStep?"step-visited":""} aria-current={officeStep===i?"step":undefined}><button type="button" className="step-jump" disabled={busy||officeStep===i} onClick={()=>moveOffice(i)}><span>{i+1}</span> {name}{officeStep===i?<small>{t("正在填寫","Current step")}</small>:<small>{i<officeStep?t("已填寫 · 返回修改","Done · Go back"):t("前往","Go")}</small>}</button></li>)}</ol>

        <div className="ux-edit-layout">
          <div>
            <section className="ux-panel" hidden={officeStep!==0}>
              <h2>{t("客戶及地點", "Customer and location")}</h2>
              {basics}
            </section>
            <section className="ux-panel" hidden={officeStep!==1}>{itemsPanel}</section>
            <section className="ux-panel" hidden={officeStep!==2}>
              <h2>
                {t("現場資料及報價備註", "Site details and quotation remarks")}
              </h2>
              {field("notes", "現場描述（內部）", "Site notes (internal)", {
                type: "textarea",
              })}
              {editAllowed && <label className="ux-upload">{t("從電腦上載相片","Upload photos from computer")}<input aria-label="Office photo upload" type="file" accept="image/jpeg,image/png,image/webp" multiple disabled={busy} onChange={e=>{addPhotos(e.target.files);e.target.value=""}}/></label>}
              <AttachmentDownloads record={record} t={t}/>

              <div className="ux-photos">{uploadPreviews.filter(p=>p.caseId===record.id).map(p=><figure key={p.url}><img src={p.url} alt={p.name}/><figcaption>{t("正在儲存相片…","Saving photo…")}</figcaption></figure>)}</div><PhotoList record={record} t={t} caption={editAllowed?(id,caption)=>update({photos:record.photos.map(p=>p.id===id?{...p,caption}:p)}):null} remove={editAllowed?id=>update({photos:record.photos.filter(p=>p.id!==id)}):null}/>
            </section>
          </div>
          <section className="ux-panel" hidden={officeStep!==3}>
            <h2>{t("服務資料及報價備註","Service details and quote remarks")}</h2>
            <div className="ux-fields">{serviceFields.map(([key,h,e,type])=>field(key,h,e,{type,
              ...(key==="completedAt" && record.source==="worker" && record.serviceDocuments?.at(-1)?.snapshot?.completedAt
                ? {value:record.serviceDocuments.at(-1).snapshot.completedAt,readOnly:true} : {})}))}
            {field("chargeAmount","工程收費 HK$（如適用）","Service charge HK$ (if applicable)",{type:"text",inputMode:"decimal",pattern:"\\d*(?:\\.\\d{0,2})?",placeholder:"0.00"})}</div>
            <RemarkPicker record={record} update={update} t={t} disabled={!editAllowed}/>
            {field("paymentTerms","付款條件（補充）","Payment terms (optional)",{type:"textarea"})}
          </section>
          <aside className="ux-panel ux-check" data-feedback-target="feedback" tabIndex="-1" hidden={officeStep!==4}>
            <h2>{t("核對後提交", "Review before confirming")}</h2><dl className="ux-confirm-summary"><dt>{t("客戶","Customer")}</dt><dd>{record.customer||t("未填寫","Missing")}</dd><dt>{t("工作地點","Work location")}</dt><dd>{[record.address,record.tower,record.floor,record.flat].filter(Boolean).join(" · ")||t("未填寫","Missing")}</dd><dt>{t("工作項目","Work items")}</dt><dd>{record.items.map(i=>displayItem(i)+" × "+i.qty).join("; ")||t("未填寫","Missing")}</dd><dt>{t("報價總額","Quote total")}</dt><dd>{money(total(record))}</dd><dt>{t("現場相片","Site photos")}</dt><dd>{record.photos.length}</dd></dl>
            {["submitted", "needsInfo"].includes(record.status) ? (
              <>
                <p>
                  {t(
                    "細節可直接修改。只有必須由維修人員確認的現場資訊才退回。",
                    "Edit minor details directly. Return only site information that requires the maintenance personnel’s confirmation.",
                  )}
                </p>
                <Btn onClick={() => {setFeedbackReason("unknown");setModal("feedback");}}>
                  {t("標註並請維修人員確認", "Mark and ask worker to confirm")}
                </Btn>
                {record.feedback.some((f) => !f.resolved) && (
                  <p>
                    {t(
                      "仍有未確認的標註；維修人員補交後才可完成覆核。",
                      "Unresolved requests remain. Finish review after the maintenance employee responds.",
                    )}
                  </p>
                )}
              </>
            ) : (
              <>
                <Btn
                  onClick={() => {
                    setPreviewRev(null);
                    setModal("preview");
                  }}
                >
                  {t("預覽報價單", "Preview quotation")}
                </Btn>
                <Btn
                  disabled={!record.history.length}
                  onClick={() => setModal("history")}
                >
                  {t("已簽發修改記錄", "Issued change history")} (
                  {record.history.length})
                </Btn>
              </>
            )}
            <h3>{t("確認標註", "Clarification requests")}</h3>
            {record.feedback.length ? (
              record.feedback.map((f) => (
                <div className={"ux-feedback"+(!f.resolved?" important-feedback":"")} key={f.id}>
                  <b>{feedbackLabel(f.field, t)}</b>
                  <p>{f.text}</p>
                  <small>
                    {f.resolved
                      ? t("已補交", "Resubmitted")
                      : t("待維修人員確認", "Awaiting worker")}
                  </small>
                </div>
              ))
            ) : (
              <p>{t("沒有待確認事項。", "No clarification requests.")}</p>
            )}
          </aside>
        </div>
        <div className="ux-actions office-step-actions"><Btn disabled={officeStep===0||busy} onClick={()=>moveOffice(officeStep-1)}>{t("上一步","Previous step")}</Btn>{officeStep<4?<Btn primary disabled={busy} onClick={()=>moveOffice(officeStep+1)}>{t("下一步","Next step")}</Btn>:record.status!=="issued"&&<Btn primary disabled={busy||record.feedback.some(f=>!f.resolved)} onClick={approve}>{t("確認並更新 INDEX","Confirm and update INDEX")}</Btn>}<span role="status">{t("步驟","Step")} {officeStep+1} / 5</span><Btn disabled={!(record.approvalHistory?.length||record.history.length)} onClick={()=>setModal("approval-history")}>{t("確認歷史溯源","Confirmation history")}</Btn></div>
      </>
    );
  else if (
    [
      "worker-tasks",
      "worker-drafts",
      "worker-timeline",
      "worker-offline",
    ].includes(route.screen)
  ) {
    const isDraftPage=["worker-drafts","worker-offline"].includes(route.screen);
    const rows = ownRecords.filter(r=>isDraftPage?r.status==="editing":!["editing","issued"].includes(r.status)).sort((a,b)=>{
      if(isDraftPage)return 0;
      return (a.status==="needsInfo"?0:1)-(b.status==="needsInfo"?0:1);
    });
    const taskCard = (r) => (
      <article className="ux-task-wrap workspace-sheen" key={r.id} aria-label={r.address||t("現場記錄","Site report")}>{isDraftPage&&<label className="draft-select"><input type="checkbox" checked={draftIds.includes(r.id)} onChange={e=>setDraftIds(e.target.checked?[...draftIds,r.id]:draftIds.filter(id=>id!==r.id))}/>{t("選取草稿","Select draft")}</label>}<button
        className={"ux-note-card"+(r.status==="needsInfo"?" needs-info-card":"")}
        onClick={() => go("worker-task-detail", r.id)}
      >
        <span className={"ux-status state-"+statusTone(r)}>{t("審核進度","Review status")}: {sLabel(r.status)}{r.rev>0?" · Rev "+r.rev:""}</span>
        <h2>{r.address || t("新增現場記錄", "New site report")}</h2>
        <p>{r.customer || t("客戶待填寫", "Customer not entered")}</p><small>{r.serviceNo||t("尚未提交","Not submitted")}{r.date?" · "+r.date:""}</small>
        <progress value={completeness(r).percent} max="100" />
        <small>
          {t("資料完成度","Details completed")}: {completeness(r).percent}%
        </small>
        <strong>{r.status==="needsInfo"?t("查看並修改","Review and correct"):isDraftPage?t("繼續填寫","Continue"):t("查看進度","View progress")} →</strong>
      </button>{r.feedback.some(f=>!f.resolved)&&<section className="task-feedback-zone" aria-label={t("此任務需要修改","Corrections for this task")}><h3>{t("維修部要求確認","Office requests")}</h3>{r.feedback.filter(f=>!f.resolved).map(f=>feedbackLink(r,f))}</section>}</article>
    );
    const groups = isDraftPage
      ? [["drafts", null, null, rows]]
      : [
          ["needs", "需要你修改後重新提交", "Correct and resubmit", rows.filter(r=>r.status==="needsInfo")],
          ["waiting", "已提交 · 等待維修部處理", "Submitted · Awaiting office", rows.filter(r=>!["needsInfo","approved"].includes(r.status))],
          ["done", "維修部已確認", "Confirmed by office", rows.filter(r=>r.status==="approved")],
        ].filter(g=>g[3].length);
    content = (
      <>
        <div className="ux-heading">
          <div>
            <small>{t("現場助手", "FIELD ASSISTANT")}</small>
            <h1>
              {isDraftPage ? t("我的草稿", "My drafts") : t("我的任務", "My tasks")}
            </h1>
            <p>
              {isDraftPage
                ? t("未提交的現場記錄。繼續填寫完成後提交給維修部。", "Unsubmitted site reports. Continue, then submit to the office.")
                : t("先處理需要修改的任務；已提交的任務可在此查看進度。", "Handle corrections first; track submitted tasks here.")}
            </p>
          </div>
          <Btn primary onClick={create}>
            ＋ {t("新增現場記錄", "New site report")}
          </Btn>
        </div>
        {!isDraftPage && workerNeedsInfo.length > 0 && (
          <div className="ux-callout important-change worker-attention" role="status">
            <b>{t(`有 ${workerNeedsInfo.length} 宗任務需要你修改`, `${workerNeedsInfo.length} task(s) need your correction`)}</b>
            <span>{t("點擊下方紅色標註可直接跳到需要修改的欄位。", "Tap a highlighted request below to jump to the field.")}</span>
          </div>
        )}
        {!isDraftPage && workerDrafts.length > 0 && (
          <button type="button" className="ux-callout worker-draft-hint" onClick={() => go("worker-drafts")}>
            {t(`你有 ${workerDrafts.length} 份未提交草稿`, `You have ${workerDrafts.length} unsubmitted draft(s)`)} · <b>{t("前往草稿繼續填寫", "Continue in Drafts")} →</b>
          </button>
        )}
        {isDraftPage&&rows.length>0&&<div className="ux-actions task-bulk-actions"><Btn disabled={!rows.length} onClick={()=>setDraftIds(rows.every(r=>draftIds.includes(r.id))?[]:rows.map(r=>r.id))}>{rows.length&&rows.every(r=>draftIds.includes(r.id))?t("取消全選","Deselect all"):t("全選草稿","Select all drafts")}</Btn><Btn className="ux-btn danger-text" disabled={!draftIds.length} onClick={()=>setModal("delete-drafts")}>{t("刪除所選草稿","Delete selected drafts")} ({draftIds.length})</Btn></div>}
        {groups.map(([key,h,e,list])=><section key={key} className="worker-task-group" aria-label={h?t(h,e):undefined}>
          {h&&<h2 className="worker-group-title">{t(h,e)} <span>{list.length}</span></h2>}
          <div className="ux-task-grid">{list.map(taskCard)}</div>
        </section>)}
        {!rows.length && (
          <div className="ux-empty">
            <p>{isDraftPage ? t("沒有未提交的草稿。", "No unsubmitted drafts.") : t("目前沒有已提交的任務。完成現場工作後，按「新增現場記錄」開始填報。", "No submitted tasks yet. After site work, choose New site report to start.")}</p>
          </div>
        )}
        {isDraftPage&&<RecycleBin records={deletedDrafts} t={t} lang={route.lang} onChanged={refreshWorkspace}/>}
      </>
    );
  } else if (
    [
      "worker-task-detail",
      "worker-basic",
      "worker-work",
      "worker-photo",
      "worker-review",
      "worker-needs-info",
      "worker-success",
    ].includes(route.screen)
  ) {
    content = !record ? (
      <>
        <p>{t("請先選擇任務。", "Select a task first.")}</p>
        <Btn onClick={() => go(home)}>{t("返回任務", "Back to tasks")}</Btn>
      </>
    ) : route.screen === "worker-success" ? (
      <section className="ux-panel">
        <h1>{t("已提交至維修部", "Submitted to the maintenance office")}</h1>
        <p>
          {t(
            "維修部可在系統中覆核。請在任務頁查看最新狀態及退回提示。",
            "The office can review this task in the system. Check Tasks for its latest status or return requests.",
          )}
        </p>
        <AttachmentDownloads record={record} t={t}/>
        <div className="ux-actions">
          <Btn primary onClick={() => go("worker-timeline")}>
            {t("返回任務查看狀態", "Back to tasks and status")}
          </Btn>
          <Btn onClick={create}>
            ＋ {t("新增下一份現場記錄", "Start next site report")}
          </Btn>
        </div>
      </section>
    ) : (
      <>
        <Btn
          onClick={() =>
            go(
              route.screen === "worker-task-detail"
                ? "worker-tasks"
                : "worker-task-detail",
              route.screen === "worker-task-detail" ? "" : record.id,
            )
          }
        >
          ← {t("返回", "Back")}
        </Btn>
        <h1>{record.address || t("現場記錄", "Site report")}</h1>
        {workerStepIndex >= 0 && (
          <ol className="service-steps worker-steps" aria-label={t("填報進度", "Report progress")}>
            {workerSteps.map(([s, h, e], i) => (
              <li key={s} className={i === workerStepIndex ? "step-current" : i < workerStepIndex ? "step-visited" : ""} aria-current={i === workerStepIndex ? "step" : undefined}>
                <button type="button" className="step-jump" disabled={busy || i === workerStepIndex}
                  onClick={() => i > workerStepIndex && ["editing","needsInfo"].includes(record.status) ? nextWorker(i - 1, s) : go(s, record.id)}>
                  <span>{i + 1}</span> {t(h, e)}
                </button>
              </li>
            ))}
          </ol>
        )}
        {["worker-task-detail","worker-needs-info"].includes(route.screen)&&["editing","needsInfo"].includes(record.status)&&missingDetails(record).length>0&&<section className="ux-missing"><h2>{t("尚待填寫（點擊前往）","Missing details (tap to complete)")}</h2>{missingDetails(record).map(f=>feedbackLink(record,f))}</section>}
        {record.status==="editing"&&<div className="ux-actions"><Btn onClick={()=>go("worker-drafts","",true)}>{t("儲存並返回草稿","Save and return to drafts")}</Btn><Btn onClick={()=>{setDraftIds([record.id]);setModal("delete-drafts")}}>{t("刪除此草稿","Delete this draft")}</Btn></div>}
        {record.status==="submitted"&&<Btn onClick={()=>setModal("withdraw-submission")}>{t("撤回至草稿","Withdraw to drafts")}</Btn>}
        <div><b>{t("資料完成度","Details completed")}: {completeness(record).percent}%</b><progress value={completeness(record).percent} max="100"/><span className={"ux-status state-"+statusTone(record)}>{t("審核進度","Review status")}: {sLabel(record.status)}</span></div>
        {route.screen!=="worker-review" && record.feedback
          .filter((f) => !f.resolved)
          .filter((f) => ["worker-task-detail","worker-needs-info"].includes(route.screen)||f.addressed)
          .map((f) => (
            feedbackLink(record,f)
          ))}
        {route.screen === "worker-task-detail" ||
        route.screen === "worker-needs-info" ? (
          <>
            <p>
              {t(
                "點選步驟卡查看或修改；請填妥前面的必填資料後繼續。",
                "Open a step to view or edit. Complete the preceding required fields before continuing.",
              )}
            </p>
            <div className="ux-step-cards">
              {workerSteps.map(([s, h, e], i) => (
                <button key={s} onClick={() => ["editing","needsInfo"].includes(record.status)&&i>0?nextWorker(i-1,s):go(s,record.id)}>
                  <b>0{i + 1}</b>
                  <span>
                    {t(h, e)}
                    <small>
                      {i === 3
                        ? t(
                            "檢查所有資料後提交",
                            "Check all details before submitting",
                          )
                        : completeness(record).flags[i]
                          ? t("已填寫，可查看", "Filled in · View")
                          : t("尚未完成", "Incomplete")}
                    </small>
                  </span>
                  <span>›</span>
                </button>
              ))}
            </div>
          </>
        ) : route.screen === "worker-basic" ? (
          <section className="ux-panel">
            <h2>01 {t("基本資料", "Basic details")}</h2>
            {basics}
            <Btn primary onClick={() => nextWorker(0,"worker-work")}>
              {t("下一步：工作內容", "Next: Work items")}
            </Btn>
          </section>
        ) : route.screen === "worker-work" ? (
          <section className="ux-panel">
            {itemsPanel}
            <div className="ux-actions worker-step-actions">
              <Btn onClick={() => go("worker-basic", record.id)}>← {t("上一步：基本資料", "Back: Basic details")}</Btn>
              <Btn primary onClick={() => nextWorker(1,"worker-photo")}>
                {t("下一步：相片及描述", "Next: Photos and notes")}
              </Btn>
            </div>
          </section>
        ) : route.screen === "worker-photo" ? (
          <section className="ux-panel">
            <h2 tabIndex="-1" data-feedback-target="photo">03 {t("相片及描述", "Photos and notes")}</h2>
            {editAllowed && <><div className="ux-actions">{[true,false].map(camera=><label className="ux-upload" key={String(camera)}>{camera?t("拍攝相片","Take photo"):t("從相簿選取","Choose from gallery")}<input aria-label={camera?"Take photo":"Choose from gallery"} type="file" accept="image/jpeg,image/png,image/webp" capture={camera?"environment":undefined} multiple={!camera} disabled={busy} onChange={e=>{addPhotos(e.target.files);e.target.value=""}}/></label>)}</div><p role="status">{busy?t("正在保留原相片及建立預覽…","Saving originals and creating previews…"):t("最多 20 張。點擊相片放大查看；提交時按工程及編號自動整理成相片組，保留原檔。","Up to 20 photos. Tap to inspect. Submission groups original files by project and reference.")}</p></>}

            <div className="ux-photos">{uploadPreviews.filter(p=>p.caseId===record.id).map(p=><figure key={p.url}><img src={p.url} alt={p.name}/><figcaption>{t("正在儲存相片…","Saving photo…")}</figcaption></figure>)}</div>
            <PhotoList
              record={record}
              t={t}
              caption={editAllowed ? (id,caption)=>update({photos:record.photos.map(p=>p.id===id?{...p,caption}:p)}) : null}
              remove={
                editAllowed
                  ? (id) =>
                      update({
                        photos: record.photos.filter((p) => p.id !== id),
                      })
                  : null
              }
            />
            {field("notes", "現場描述", "Site description", {
              type: "textarea",
            })}
            <h3>{t("工程／維修服務資料","Project / service details")}</h3>
            <div className="ux-fields">{serviceFields.map(([key,h,e,type])=>field(key,h,e,{type}))}</div>
            {(!record.timeConfirmed?.startedAt||!record.timeConfirmed?.completedAt)&&<p className="field-error" role="status">{t("請先確認開工及完工時間，才可進入下一步。","Confirm commencement and completion times before continuing.")}</p>}
            <div className="ux-actions worker-step-actions">
              <Btn onClick={() => go("worker-work", record.id)}>← {t("上一步：工作內容", "Back: Work items")}</Btn>
              <Btn primary disabled={busy||(editAllowed&&(!record.timeConfirmed?.startedAt||!record.timeConfirmed?.completedAt))} onClick={() => editAllowed ? nextWorker(2,"worker-review") : go("worker-review", record.id)}>
                {t("下一步：確認提交", "Next: Review and submit")}
              </Btn>
            </div>
          </section>
        ) : (
          <section className="ux-panel">
            <h2>04 {t("確認提交", "Review and submit")}</h2>
            <PdfPreview record={record} kind="service" t={t}/>
            <p>{t("提交後會儲存服務單資料與相片；維修部確認後，在 INDEX 一併生成服務單、報價單及發票，供授權維修部查看。客戶簽收欄保持空白，不代表已驗收。","Submission saves the service details and photos. After office confirmation, INDEX generates the service order, quotation and invoice together. An empty customer-signature field does not mean acceptance.")}</p>
            <AttachmentDownloads record={record} t={t}/>
            {editAllowed ? (
              <div className="ux-actions worker-step-actions">
                <Btn onClick={() => go("worker-photo", record.id)}>← {t("上一步：相片及描述", "Back: Photos and notes")}</Btn>
                <Btn primary disabled={busy} onClick={()=>submitWorker()}>
                  {busy?t("正在儲存並提交…","Saving and submitting…"):record.status==="needsInfo"?t("確認修改並重新提交","Confirm corrections and resubmit"):t("確認服務單並提交", "Confirm service order and submit")}
                </Btn>
              </div>
            ) : (
              <p>
                {t(
                  "已提交的資料暫時唯讀；如有問題，維修部會標註需要確認的部分。",
                  "Submitted details are read-only. The office will mark any information requiring confirmation.",
                )}
              </p>
            )}
          </section>
        )}
      </>
    );
  } else if (["worker-notifications", "notifications"].includes(route.screen))
    content = (
      <>
        <h1>{t("我的通知", "My notifications")}</h1>
        <p>
          {t(
            "只顯示此帳戶可處理的資料。",
            "Only information within this account’s scope is shown.",
          )}
        </p>
        {(worker
          ? ownRecords
          : db.records.filter((r) => r.status === "submitted")
        ).map((r) => (
          <article className="ux-notification" key={r.id}><Btn onClick={() => (worker ? go("worker-task-detail", r.id) : open(r))}>{t("開啟任務","Open task")}</Btn>
            <b>{r.address || t("現場記錄", "Site record")}</b>
            <span>{sLabel(r.status)}</span>
            {r.feedback
              .filter((f) => !f.resolved)
              .map((f) => (
                worker ? feedbackLink(r,f) : <p key={f.id}>{feedbackLabel(f.field,t)}: {f.text}</p>
              ))}
          </article>
        ))}
      </>
    );
  else if (["worker-profile", "account", "users"].includes(route.screen))
    content = (
      <section className="ux-panel">
        <h1>
          {route.screen === "users"
            ? t("用戶管理", "User management")
            : t("我的帳戶", "My account")}
        </h1>
        {route.screen === "users" && account.canManage ? (
          <>
            <p>
              {t(
                "員工帳戶由公司管理員預先授權；此頁顯示目前登記狀態。",
                "Staff accounts are preauthorized by a company administrator. This page shows their current registration status.",
              )}
            </p>
            {staffList.map((a) => (
              <p key={a.staff_code}>
                {a.name} · {a.phone} · {a.staff_code} ·{" "}
                {a.role === "worker"
                  ? t("維修人員", "Maintenance personnel")
                  : a.role === "manager" ? t("管理員", "Manager") : t("維修部", "Office")}
                {a.active ? "" : " · " + t("已停用", "Inactive")}
              </p>
            ))}
          </>
        ) : (
          <>
            <h2 className="account-name">{account.name}</h2>
            <p>{account.phone}</p>
            <p>
              {worker
                ? t(
                    "只限自己的任務、草稿及通知。",
                    "Own tasks, drafts and notifications only.",
                  )
                : t(
                    "維修部收件覆核、報價及 INDEX。",
                    "Office submission review, quotations and INDEX.",
                  )}
            </p>
          </>
        )}
        <Btn onClick={logout}>{t("登出／切換帳戶", "Sign out / switch account")}</Btn>
      </section>
    );
  else
    content = (
      <>
        <h1>{t("請選擇工作項目", "Choose a workspace")}</h1>
        <Btn primary onClick={() => go(home)}>
          {t("返回工作台", "Back to workspace")}
        </Btn>
      </>
    );
  const navigation = worker
    ? [
        ["worker-tasks", "任務", "Tasks", ClipboardText, workerNeedsInfo.length],
        ["worker-drafts", "草稿", "Drafts", PencilSimple, workerDrafts.length],
        ["worker-profile", "我的", "Me", UserCircle],
      ]
    : [
        ["office-inbox", "服務單覆核", "Order review", ClipboardText, officeCounts.submitted + officeCounts.revision],
        ["office-index", "INDEX 報價發票", "INDEX · Quotes", Table],
      ];
  const nav = (
    <nav
      className={worker ? "ux-worker-nav"+(hideWorkerNav?" is-typing":"") : "ux-office-nav"}
      inert={worker&&hideWorkerNav?true:undefined}
      aria-hidden={worker&&hideWorkerNav?true:undefined}
      aria-label={t("主要導覽", "Main navigation")}
    >
      {navigation.map(([s, h, e, Icon, count]) => (
        <button
          key={s}
          className={
            route.screen === s ||
            (s === "worker-tasks" && ["worker-task-detail","worker-needs-info","worker-success"].includes(route.screen) && record?.status !== "editing") ||
            (s === "worker-drafts" && (workerStepIndex >= 0 || route.screen === "worker-task-detail") && record?.status === "editing") ||
            (s === "office-inbox" && ["office-quote","office-case","office-import"].includes(route.screen)) || (s === "office-index" && route.screen === "office-confirmed")
              ? "active"
              : ""
          }
          aria-current={route.screen === s ? "page" : undefined}
          onClick={() => go(s)}
        >
          <Icon className="workspace-nav-icon" aria-hidden="true" />
          <span>{t(h, e)}</span>
          {count > 0 && <span className="nav-badge" aria-label={t(`${count} 項待處理`, `${count} to handle`)}>{count}</span>}
        </button>
      ))}
      {!worker&&<button className="office-logout" onClick={logout}><SignOut className="workspace-nav-icon" aria-hidden="true" /><span>{t("登出帳戶","Sign out")}</span></button>}
    </nav>
  );
  const deleteSelectedDrafts = async () => {
    if (busy) return;
    setBusy(true);
    const selected = db.records.filter(r => draftIds.includes(r.id) && ["editing", "draft"].includes(r.status) && !r.deletedAt);
    let moved = 0;
    try {
      for (const item of selected) {
        try { await runAction(item, "delete-draft"); clearDraftCache(account, item.id); moved += 1; }
        catch { /* keep failed items visible so the user can retry */ }
      }
      setDraftIds([]);
      setModal("");
      go(worker ? "worker-drafts" : "office-inbox", "", true);
      setNotice(t(`已移至回收站：${moved} 項。`, `Moved ${moved} draft(s) to the recycle bin.`), moved < selected.length);
    } finally { setBusy(false); }
  };
  return (
    <div className={"ux " + (worker ? "ux-worker" : "ux-office")}>
      <OperationFeedback busy={busy} message={notice} important={!!notice&&noticeImportant} t={t}/>
      <header className="ux-top">
        <button className="ux-brand" onClick={() => go(home)}>
          <HeaderLogo compact />
          <b>
            {worker
              ? t("現場助手", "Field Assistant")
              : t("維修業務系統", "Maintenance Operations")}
          </b>
        </button>
        <div className="ux-top-actions">
          {langControl}
          <div className="ux-account-menu">
            <button
              className="ux-avatar"
              aria-label={t("帳戶選單", "Account menu")}
              aria-expanded={menu}
              onClick={() => setMenu(!menu)}
            >
              {account.name[0]}
            </button>
            {menu && (
              <div className="ux-menu">
                <strong className="account-menu-name">{account.name}</strong>
                <small>{account.phone} · {account.id}</small>
                <button
                  onClick={() => go(worker ? "worker-profile" : "account")}
                >
                  {t("我的帳戶", "My account")}
                </button>
                {account.canManage && (
                  <button onClick={() => go("users")}>
                    {t("用戶管理", "User management")}
                  </button>
                )}
                <button onClick={logout}>{t("登出／切換帳戶", "Sign out / switch account")}</button>
              </div>
            )}
          </div>
        </div>
      </header>
      {banner}
      {!online && (
        <div className="ux-callout" role="status">
          {t(
            "目前離線；修改已保存在本機草稿，恢復連線後會自動同步。",
            "Offline: changes are saved locally and will sync after reconnecting.",
          )}
        </div>
      )}
      <div className="ux-body">
        {!worker && nav}
        <main className="ux-main">
          {toast}
          <ResearchProbeLayer probe={fieldStudy} t={t} onFocus={issue=>focusIssue(issue,true)}/>
          {content}
        </main>
      </div>
      {worker && nav}

      {modal === "picker" && record && (
        <Modal
          notice={notice} noticeImportant={noticeImportant}
          title={t("選擇工作項目", "Choose work item")}
          close={() => setModal("")}
          closeLabel={t("關閉", "Close")}
        >
          <div className="ux-chips">
            {[
              ["all", "全部", "All"],
              ["inspect", "檢查", "Inspect"],
              ["replace", "更換", "Replace"],
              ["purchase", "購買", "Purchase"],
              ["clean", "清洗", "Clean"],
              ["other", "其他", "Other"],
            ].map(([v, h, e]) => (
              <button
                className={category === v ? "active" : ""}
                key={v}
                onClick={() => setCategory(v)}
              >
                {t(h, e)}
              </button>
            ))}
          </div>
          <div className="ux-picker">
            {ITEMS.map(
              ([cat, h, e], i) =>
                (category === "all" || cat === category) && (
                  <button
                    key={i}
                    onClick={() => {
                      setEditItem({
                        id: uid(),
                        preset: i,
                        qty: 1,
                        model: "",
                        price: "",
                        description: "",
                      });
                      setModal("item");
                    }}
                  >
                    {t(h, e)} <span>＋</span>
                  </button>
                ),
            )}
          </div>
        </Modal>
      )}
      {modal === "item" && editItem && record && (
        <Modal
          notice={notice} noticeImportant={noticeImportant}
          title={t("工作項目詳情", "Work item details")}
          close={() => setModal("")}
          closeLabel={t("關閉", "Close")}
        >
          <h3>{t(ITEMS[editItem.preset][1], ITEMS[editItem.preset][2])}</h3>
          {feedbackTarget&&<p className="ux-feedback" role="status">{t("維修部問題：","Office question: ")}{feedbackTarget.text}</p>}
          <Input
            data-feedback-target="brand" error={feedbackTarget?.field==="brand"?feedbackTarget.text:undefined}
            label={t("空調品牌", "AC brand")}
            suggestions={["Daikin","Mitsubishi Electric","Panasonic","Hitachi","Carrier","Toshiba","LG","Samsung"]}
            value={editItem.brand || record.brand || ""}
            onChange={(v) => setEditItem({ ...editItem, brand: v })}
          />
          <Input
            data-feedback-target="qty"
            error={feedbackTarget?.field==="qty"?feedbackTarget.text:undefined}
            label={t("數量", "Quantity")}
            type="text"
            inputMode="numeric"
            value={editItem.qty}
            onChange={(v) => {if(quantityInput(v))setEditItem({ ...editItem, qty: v });}}
          />
          <Input
            data-feedback-target="model" error={feedbackTarget?.field==="model"?feedbackTarget.text:undefined}
            label={t("型號（按銘牌填寫）", "Model (check equipment label)")}
            suggestionHint={t("僅列出已有型號；請核對銘牌，不適用時手動輸入。","Previously entered models only. Check the equipment label or enter manually.")}
            suggestions={db.records.flatMap(r=>r.items).filter(i=>i.model && (!editItem.brand||i.brand===editItem.brand)).map(i=>i.model)}
            value={editItem.model}
            onChange={(v) => setEditItem({ ...editItem, model: v })}
          />
          {!worker && <Input
            data-feedback-target="price" error={feedbackTarget?.field==="price"?feedbackTarget.text:undefined}
            label={
              worker
                ? t("參考價錢（可留空）", "Reference price (optional)")
                : t("單價 HKD", "Unit price HKD")
            }
            type="text"
            inputMode="decimal"
            value={editItem.price}
            onChange={(v) => {if(moneyInput(v))setEditItem({ ...editItem, price: v });}}
          />}
          {editItem.preset===14 && <Input
            data-feedback-target="description" error={feedbackTarget?.field==="description"?feedbackTarget.text:undefined}
            label={t(
              "項目說明（「其他」必填）",
              "Item description (required for Other)",
            )}
            type="textarea"
            value={editItem.description}
            onChange={(v) => setEditItem({ ...editItem, description: v })}
          />}
          <div className="ux-actions">
            <Btn primary onClick={saveItem}>
              {t("儲存並返回工作內容", "Save and return to work items")}
            </Btn>
            {record.items.some((i) => i.id === editItem.id) && (
              <Btn
                onClick={() => {
                  update({
                    items: record.items.filter((i) => i.id !== editItem.id),
                  });
                  setModal("");
                }}
              >
                {t("移除此項目", "Remove item")}
              </Btn>
            )}
          </div>
        </Modal>
      )}
      {modal === "delete-drafts" && (
        <Modal confirmation title={t("確認移至回收站？", "Move selected drafts to the recycle bin?")}
          close={() => { if (!busy) setModal(""); }}>
          <p>{t(`已選取 ${draftIds.length} 份草稿，移動後可在回收站復原。`, `Selected drafts: ${draftIds.length}. You can restore them from the recycle bin.`)}</p>
          <div className="ux-actions confirm-actions">
            <Btn autoFocus disabled={busy} onClick={() => setModal("")}>{t("保留草稿", "Keep drafts")}</Btn>
            <Btn className="ux-btn danger-action" disabled={busy} onClick={deleteSelectedDrafts}>
              {busy ? t("處理中…", "Working…") : t("確認移至回收站", "Move to recycle bin")}
            </Btn>
          </div>
        </Modal>
      )}
      {modal==="withdraw-submission"&&<Modal title={t("撤回提交？","Withdraw submission?")} close={()=>setModal("")} closeLabel={t("取消","Cancel")}><p>{t("只可撤回尚未完成覆核的提交；資料會保留於草稿，修改後須重新提交。","Only submissions not yet reviewed can be withdrawn. Details remain in Drafts and must be resubmitted after editing.")}</p><Btn primary onClick={async()=>{try{await runAction(record,"withdraw");go("worker-drafts")}catch{setNotice(t("狀態已改變，請重新查看任務。","Status changed. Reopen the task."))}}}>{t("確認撤回","Confirm withdrawal")}</Btn></Modal>}
      {modal === "feedback" && (
        <Modal
          notice={notice} noticeImportant={noticeImportant}
          title={t("請維修人員確認", "Ask worker to confirm")}
          close={() => setModal("")}
          closeLabel={t("關閉", "Close")}
        >
          <Input
            label={t("需要確認的位置", "Field requiring confirmation")}
            value={feedbackField}
            onChange={v=>{setFeedbackField(v);setFeedbackItemId("")}}
            options={["address", "model", "qty", "photo", "notes"].map((f) => [
              f,
              feedbackLabel(f, t),
            ])}
          />
          <Input label={t("主要退回原因（選填）", "Main return reason (optional)")} value={feedbackReason} onChange={setFeedbackReason}
            options={handoffReasons.map(([code,hk,en])=>[code,t(hk,en)])} />
          {["model","qty"].includes(feedbackField)&&record.items.length>1&&<Input label={t("對應工作項目","Related work item")} value={feedbackItemId} onChange={setFeedbackItemId} options={[["",t("整體工作內容／未指定","All work items / unspecified")],...record.items.map((i,n)=>[i.id,(n+1)+". "+displayItem(i)+" · "+(i.model||"—")])]} />}
          <Input
            label={t(
              "具體問題及所需資料",
              "Specific question and required information",
            )}
            type="textarea"
            value={feedbackText}
            onChange={setFeedbackText}
          />
          <p>
            {t(
              "維修人員會看到此標註；原有資料及維修部修改會保留。",
              "The worker will see this request. Existing details and office edits are retained.",
            )}
          </p>
          <Btn primary onClick={sendFeedback}>
            {t("發送確認要求", "Send confirmation request")}
          </Btn>
        </Modal>
      )}
      {modal === "issue" && (
        <Modal
          notice={notice} noticeImportant={noticeImportant}
          title={t("簽發報價", "Issue quotation")}
          close={() => setModal("")}
          closeLabel={t("關閉", "Close")}
        >
          <p>
            {t(
              "簽發後會凍結目前內容。再次修改須修改已簽發報價，不會每次儲存便新增 Rev。",
              "Issuing freezes the current content. Later changes require a revision; ordinary draft saves do not create Rev numbers.",
            )}
          </p>
          <p>{money(total(record))}</p>
          <Btn primary onClick={issue}>
            {t("確認簽發", "Confirm issue")}
          </Btn>
        </Modal>
      )}
      {modal==="approval-history" && record && <Modal title={t("確認歷史溯源","Confirmation history")} close={()=>setModal("")} closeLabel={t("關閉","Close")}><p>{t("同一編號，只有內容改動後再次確認才增加版本；歷史價錢不相加。","Same reference. Reconfirmation adds a version only when content changes; historical prices are not summed.")}</p>{(record.approvalHistory||record.history).map((h,i)=><Btn key={i} onClick={()=>{setPreviewRev(h.snapshot);setModal("preview")}}>{record.ref} / Rev {h.rev} · {money(total(h.snapshot))} · {new Date(h.at).toLocaleString(route.lang)}</Btn>)}</Modal>}
      {modal === "history" && record && (
        <Modal
          notice={notice} noticeImportant={noticeImportant}
          title={t("已簽發版本", "Issued versions")}
          close={() => setModal("")}
          closeLabel={t("關閉", "Close")}
        >
          {record.history.map((h, i) => (
            <button
              className="ux-notification"
              key={i}
              onClick={() => {
                setPreviewRev(h.snapshot);
                setModal("preview");
              }}
            >
              <b>
                {record.ref} / {h.rev ? `Rev ${h.rev}` : t("原版", "Original")}
              </b>
              <span>{new Date(h.at).toLocaleString(route.lang)}</span>
              <span>{money(total(h.snapshot))} ›</span>
            </button>
          ))}
        </Modal>
      )}
      {modal === "preview" && record && (
        <Modal
          notice={notice} noticeImportant={noticeImportant}
          title={t("報價單預覽", "Quotation preview")}
          close={() => setModal("")}
          closeLabel={t("關閉", "Close")}
        >
          <p>{t("僅供核對內容；請在 02 INDEX 選取報價後生成正式列印版本。","Preview only. Generate the formal print version from 02 INDEX.")}</p>
          <QuotePreview record={previewRev || record} t={t} lang={route.lang} />
        </Modal>
      )}
    </div>
  );
}
function feedbackLabel(f, t) {
  return t(
    ...({
      date:["日期","Date"], customer:["客戶名稱","Customer name"], phone:["聯絡電話","Phone"], items:["工作項目","Work items"], startedAt:["開工時間","Commencement"], completedAt:["完工時間","Completion"],
      address: ["地址／單位", "Address / Unit"],
      model: ["工作項目型號", "Work item model"],
      qty: ["數量", "Quantity"],
      photo: ["現場相片", "Site photos"],
      notes: ["現場描述", "Site notes"],
    }[f] || [f, f]),
  );
}
function PhotoList({record,t,remove,caption}) {
 const [view,setView]=useState(null),[error,setError]=useState("");
 useEffect(()=>()=>{if(view?.url?.startsWith("blob:"))URL.revokeObjectURL(view.url)},[view]);
 const show=async p=>{try{const blob=await photoBlob(p);setView({...p,url:URL.createObjectURL(blob)});setError("");}catch{setError(t("原相片未能讀取，請重新加入。","Original photo unavailable. Add it again."));}};
 const discard=p=>{if(window.confirm(t("確定移除此相片？提交前可重新上載。","Remove this photo? You can upload it again before submission."))){remove(p.id);setView(null);}};
 return <><div className="ux-photos">{record.photos.map(p=><figure key={p.id}><button className="photo-open" aria-label={t("查看相片 ","View photo ")+p.name} onClick={()=>show(p)}><PrivatePhoto photo={p}/></button><figcaption>{p.name}</figcaption>{caption?<Input label={t("相片說明（補充）","Photo caption (optional)")} value={p.caption||""} onChange={v=>caption(p.id,v)} type="textarea"/>:<p>{p.caption}</p>}{remove&&<Btn onClick={()=>discard(p)}>{t("移除相片","Remove photo")}</Btn>}</figure>)}</div>{!record.photos.length&&<p>{t("尚未附加相片。","No photos attached.")}</p>}{error&&<p role="alert">{error}</p>}{view&&<Modal title={t("查看相片","View photo")} close={()=>setView(null)} closeLabel={t("關閉","Close")}><img className="photo-full" src={view.url} alt={view.name}/><p>{view.caption}</p>{remove&&<Btn onClick={()=>discard(view)}>{t("移除此相片","Remove this photo")}</Btn>}</Modal>}</>;
}
function RemarkPicker({record,update,t,disabled}) {
 return <div><Input label={t("報價備註範本","Quotation remark template")} value={record.remarkTemplate||""} disabled={disabled} options={[["",t("選擇範本","Choose template")],...REMARK_TEMPLATES.map(v=>[v.id,t(v.name,v.en)]),["other",t("其他／自行編輯","Other / write your own")]]} onChange={v=>{
 const value=REMARK_TEMPLATES.find(x=>x.id===v);
 if(value && record.remark && !window.confirm(t("套用範本將取代目前報價備註，是否繼續？","Replace the current quotation remarks with this template?")))return;
 update({remarkTemplate:v,...(value?{remark:value.text}:{})});
 }}/><p>{t("範本沿用公司提供文字，請核對適用品牌、保養及額外收費，可在下方調整。","Templates retain the supplied company wording. Check brands, warranty and extras; edit below as needed.")}</p><Input label={t("報價備註（補充，列印於報價單）","Quotation remarks (optional, printed on quotation)")} type="textarea" disabled={disabled} value={record.remark} onChange={v=>update({remark:v})}/></div>;
}
function AttachmentDownloads({record:r,t}) {
  const [error,setError]=useState(""),[busy,setBusy]=useState(false),[show,setShow]=useState(false),[ready,setReady]=useState(null);
  const docs=r.serviceDocuments||[];
  const dl=async(name,kind,revision)=>{
    setBusy(true);setError("");
    try {
      const target=await chooseSaveTarget(name);
      const actual=(await generateCaseDocument(r.id,kind,revision)).assetKey;
      const blob=await getAsset(actual);await saveBlob(blob,name,target);
      setReady({blob,name});
    } catch(error) { if(error.name==="AbortError")return;setError(t("未能下載附件，請檢查權限及網絡後重試。","Could not download the attachment. Check access and connection, then retry.")); }
    finally { setBusy(false); }
  };
  const zipPhotos=async(snapshot)=>{
    setBusy(true);setError("");
    try { downloadBlob(await photoArchive(snapshot,assetGroup(snapshot)),(assetGroup(snapshot)||"Photos")+".zip"); }
    catch { setError(t("相片組下載失敗，請重試。","Photo group download failed. Retry.")); }
    finally { setBusy(false); }
  };
  return <section className="attachment-group"><OperationFeedback busy={busy} message={error||(ready?t("文件已完成儲存／交由瀏覽器下載。","File saved / handed to browser downloads."):"")} important={!!error} t={t}/><h3>{t("服務單及相片組","Service order and photo group")}</h3><p>{r.photoGroup||assetGroup(r)} · {r.photos.length} {t("張相片","photos")}</p>
  {docs.length?<><Btn disabled={busy} onClick={()=>dl(safeName(r.serviceNo)+"_服務單.pdf","service",docs.at(-1).rev)}>{t("下載服務單 PDF","Download service order PDF")}</Btn>{docs.at(-1).snapshot.photos.length>0&&<Btn disabled={busy} onClick={()=>zipPhotos(docs.at(-1).snapshot)}>{t("下載相片組 ZIP","Download photo group ZIP")}</Btn>}<Btn onClick={()=>setShow(!show)}>{t("查看已提交服務單","View submitted service order")}</Btn>{show&&<PdfPreview record={r} kind="service" revision={docs.at(-1).rev} t={t}/>}
  {docs.length>1&&<details><summary>{t("歷次提交附件","Previous submission attachments")} ({docs.length})</summary>{docs.map((d,n)=><Btn key={n} onClick={()=>dl(safeName(r.serviceNo)+"_"+n+".pdf","service",d.rev)}>{t("提交","Submission")} {n+1}</Btn>)}</details>}</>:<p>{t("首次提交時自動建立；維修部自建任務毋須服務單附件。","Created on first field submission. Office-created tasks do not require a service-order attachment.")}</p>}
  {(r.invoiceHistory||[]).length>0&&<details><summary>{t("已生成發票","Generated invoices")} ({r.invoiceHistory.length})</summary>{r.invoiceHistory.map((h,n)=><Btn key={n} onClick={()=>dl(safeName(r.invoiceRef)+"_Rev"+h.rev+".pdf","invoice",h.rev)}>{r.invoiceRef} / Rev {h.rev} · {t("對應報價版本","Quote revision")} {h.quoteRev}</Btn>)}</details>}
 {ready&&<div className="ux-callout"><p>{t("文件已準備完成。","File ready.")}</p><Btn disabled={busy} primary onClick={async()=>{setBusy(true);try{await saveBlob(ready.blob,ready.name,await chooseSaveTarget(ready.name));setReady(null);}catch(e){if(e.name!=="AbortError")setError(t("儲存失敗，請重試。","Save failed. Retry."),true);}finally{setBusy(false);}}}>{t("選擇位置並儲存","Choose location and save")}</Btn></div>}{error&&<p role="alert">{error}</p>}</section>;
}
function IndexSheet({
  sheet,
  db,
  rows,
  t,
  lang,
  open,
  commit,
  onCreate,
  onDirty,
}) {
  if (sheet === 1) return <SampleGuide db={db} t={t} />;
  if (sheet === 2)
    return <LedgerView db={db} commit={commit} t={t} onDirty={onDirty} />;
  if (sheet === 3)
    return (
      <ProjectsView
        db={db}
        commit={commit}
        t={t}
        onCreate={onCreate}
        onDirty={onDirty}
      />
    );
  if (sheet === 4) return <SummaryView db={db} t={t} open={open} />;
  if (sheet === 0) {
    const data = currentQuotes(rows).flatMap(({ record: r, quote }, n) =>
      toIndexRows({ ...quote, ledger: r.ledger }, lang, n + 1).map((v) => ({
        r,
        v,
      })),
    );
    return (
      <>
        <p className="ux-sheet-note">
          {t(
            "A–AA：案件欄位；AB–AG：原檔摘要／日期區，並非逐行必填。只顯示已確認內容；未確認或待修改內容請返回任務。",
            "A–AA: record fields. AB–AG: original summary/date area, not per-record inputs. Confirmed details only; pending work remains in Inbox.",
          )}{" "}
          {data.length} {t("行", "rows")}
        </p>
        <div
          className="ux-grid-scroll ux-index"
          tabIndex="0"
          aria-label={t("INDEX 全部三十三欄", "All 33 INDEX columns")}
        >
          <table className="ux-grid">
            <thead>
              <tr>
                {HEADERS.map((h, i) => (
                  <th key={i}>
                    <small>
                      {i < 26
                        ? String.fromCharCode(65 + i)
                        : "A" + String.fromCharCode(65 + i - 26)}
                    </small>
                    {i === 32
                      ? today()
                      : i === 30
                        ? "—"
                        : h === "負責人"
                          ? t(h, "Person in charge")
                          : h === "舊QUO / INV."
                            ? t(h, "Previous QUO / INV.")
                            : h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map(({ r, v }, n) => (
                <tr key={r.id + "-" + n}>
                  {v.map((c, i) => (
                    <td key={i}>
                      {i === 2 ? (
                        <button className="ux-link" onClick={() => open(r)}>
                          {c}
                        </button>
                      ) : (
                        String(c ?? "")
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
          {!data.length && (
            <p className="ux-empty">
              {t(
                "沒有符合條件的已確認內容。",
                "No matching confirmed details.",
              )}
            </p>
          )}
        </div>
      </>
    );
  }
  return null;
}
function LegacyQuotePreview({ record: r, t, lang, type="quotation" }) {
  const invoice=type==="invoice";
  return (
    <article className="ux-print">
      <header>
        <span className="brand-logo print"><img src="/brand-logo.png" alt="Chit Tat Electrical Engineering Ltd." /></span>
      </header>
      <div className="ux-quote-meta">
        <div>
          <p>To: {r.customer}</p>
          <p>Attn.: {r.contact || "—"}</p>
          <p>
            Project:{" "}
            {[r.address, r.tower, r.floor, r.flat].filter(Boolean).join(" ")}
          </p>
        </div>
        <div>
          <p>
            {invoice?"Invoice No.: ":"QUO Ref. No.: "}{(invoice?(r.invoiceRef||r.ref?.replace("-Q-","-I-")):r.ref) || t("草稿，尚未編號", "Draft — unassigned")}
            {(invoice?r.invoiceRev:r.rev)>0 && ` / Rev ${invoice?r.invoiceRev:r.rev}`}
          </p>
          <p>{invoice?"QUO No.: "+r.ref+" / Rev "+(r.rev||0):"From: "+(r.lastConfirmedByName||t("維修部","Maintenance office"))}</p>
          {invoice&&<p>Project Code.: {r.projectCode||"—"}</p>}
          <p>Date: {invoice?(r.invoiceDate||today()):r.date}</p>
        </div>
      </div>
      <h2 className="ux-quotation">{invoice?"INVOICE 發票":"Quotation 報價單"}</h2>
      <table>
        <thead>
          <tr>
            {["Item", "Description", "Quantity", "Unit Price", "Amount"].map(
              (h) => (
                <th key={h}>{h}</th>
              ),
            )}
          </tr>
        </thead>
        <tbody>
          {r.items.map((i, n) => (
            <tr key={i.id}>
              <td>{n + 1}</td>
              <td>
                {itemName(i, lang)}
                <br />
                {i.model} · {i.brand||r.brand||'—'}
              </td>
              <td>{i.qty} no.</td>
              <td>{money(i.price)}</td>
              <td>{money(Number(i.qty) * Number(i.price))}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <CommercialTotals record={r} money={money}/>
      {!invoice&&<><h3>Remark</h3>
      <p className="ux-prewrap">
        {r.remark ||
          t(
            "報價有效期為發出日期起三十天。其他正式條款須由公司確認。",
            "Quotation valid for 30 days from issue. Other formal terms require company confirmation.",
          )}
      </p>
      </>}
      <h3>{t("付款方式", "Payment details")}</h3>
      <p>{r.paymentTerms}</p>
      <p>
        {t(
          "付款資料按公司設定顯示於正式 PDF。",
          "Payment details appear in the formal PDF when configured by the company.",
        )}
      </p>
      <div className="ux-signatures">
        <p>
          For and on behalf of
          <br />
          CHIT TAT ELECTRICAL ENG. LTD.
          <br />
          <br />
          ________________________
        </p>
        {!invoice&&<p>
          Confirmed and Accepted by
          <br />
          <br />
          <br />
          ________________________
          <br />
          Authorized Signature
        </p>}
      </div>
    </article>
  );
}

function QuotePreview({record,t,type="quotation"}) {return <PdfPreview record={record} kind={type} revision={record.ref ? record.rev||0 : undefined} t={t}/>;}
