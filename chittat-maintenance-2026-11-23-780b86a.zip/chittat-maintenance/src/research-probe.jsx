// 研究埋點 v2（維修人員／維修部前端）。事件名稱與 lib/research-events.ts 一致。
// 原則：只記錄操作類型、欄位代號、計時與自評分數；不記錄輸入文字、相片、定位或按鍵。
// 任何研究請求失敗都不會阻擋業務操作。
import React, { useCallback, useEffect, useRef, useState } from "react";
import { sessionFetch, sessionToken } from "./session-fetch";
import { uid } from "./workspace-model";
import { fieldStudyFields, fieldStudyScreens, studyField } from "./field-study-catalog";
import { assistantSuggestions, readFieldQueue, updateFieldQueue } from "./field-study";
import "./field-study.css";

const SCHEMA = "workflow-fatigue-v2";
const api = "/api/research/v2/probe";
const queueKey = (user, study) => `ct-research-v2-events:${user}:${study}`;
const seqKey = (user, day) => `ct-research-v2-seq:${user}:${day}`;
const today = () => new Date().toLocaleDateString("en-CA");
const legacyNames = { validation_error: "form.validation_block" };
const effortScale = [[1, "極少"], [5, "中等"], [9, "極多"]];
const fatigueScale = [[1, "精神飽滿"], [4, "有點累"], [7, "筋疲力盡"]];

async function request(path, body) {
  const response = await sessionFetch(api, body ? {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: path, ...body }),
    keepalive: path === "events", signal: AbortSignal.timeout(5000),
  } : { signal: AbortSignal.timeout(5000) });
  if (!response.ok) throw Object.assign(Error("research-unavailable"), { status: response.status });
  return response.status === 204 ? null : response.json();
}

function readSeq(user) {
  try { return Number(localStorage.getItem(seqKey(user, today()))) || 0; } catch { return 0; }
}

/**
 * 回傳與舊 fieldStudy 相容的介面：config, track, finishTime, ask, flush，
 * 並新增 gate（微隨機核對卡）、check、prompt、answer。
 */
export function useResearchProbe(account, record, screen, officeStep, editable) {
  const user = account?.id;
  const role = account?.role === "worker" ? "worker" : "office";
  const caseId = record?.localOnly ? null : record?.id;
  const [config, setConfig] = useState(null);
  const [check, setCheck] = useState(null);
  const [prompt, setPrompt] = useState(null);
  const decided = useRef(new Map());
  const flushing = useRef(false);
  const active = config?.user === user && config?.joined ? config : null;
  const key = active?.studyId ? queueKey(user, active.studyId) : null;
  const step = editable && Object.hasOwn(fieldStudyScreens, screen) ? screen
    : editable && ["office-case", "office-quote"].includes(screen) ? `office-${officeStep}` : null;

  const refresh = useCallback(async () => {
    if (!user || !sessionToken()) return;
    try { setConfig({ ...await request("config"), user }); } catch { /* 研究未啟用或離線 */ }
  }, [user]);
  useEffect(() => { setConfig(null); if (user) void refresh(); }, [user, refresh]);

  const emit = useCallback((name, extra = {}) => {
    if (!key || !(extra.caseId ?? caseId)) return;
    const event = { id: uid(), schema: SCHEMA, name, role, caseId: extra.caseId ?? caseId, at: Date.now(), ...extra };
    if (event.field != null) event.field = studyField(event.field);
    updateFieldQueue(localStorage, key, [event]);
  }, [key, role, caseId]);

  const flush = useCallback(async () => {
    if (!key || !navigator.onLine || flushing.current || !sessionToken()) return;
    flushing.current = true;
    try {
      const batch = readFieldQueue(localStorage, key).slice(0, 40);
      if (!batch.length) return;
      try { await request("events", { studyId: active.studyId, events: batch }); }
      catch (error) { if (![400, 403, 404].includes(error.status)) return; }
      updateFieldQueue(localStorage, key, [], batch.map(e => e.id));
    } finally { flushing.current = false; }
  }, [key, active?.studyId]);
  const commitRef = useRef(null);
  useEffect(() => {
    if (!key) return;
    void flush();
    const timer = setInterval(flush, 12000);
    const pagehide = () => { commitRef.current?.(); void flush(); };
    window.addEventListener("online", flush);
    window.addEventListener("pagehide", pagehide);
    return () => { clearInterval(timer); window.removeEventListener("online", flush); window.removeEventListener("pagehide", pagehide); };
  }, [key, flush]);

  // L2：步驟有效時間（只計前台、30 秒內有操作）、欄位重填、斷線。
  useEffect(() => {
    if (!key || !step || !caseId) return;
    let last = performance.now(), lastActivity = last, ms = 0, visible = document.visibilityState === "visible";
    const cleared = new WeakSet();
    const tick = () => { const now = performance.now(); if (visible) ms += Math.max(0, Math.min(now, lastActivity + 30000) - last); last = now; };
    const activity = () => { tick(); lastActivity = last; };
    const commit = () => { tick(); if (ms >= 1000) emit("form.step_leave", { step, activeMs: Math.min(600000, Math.round(ms)) }); ms = 0; };
    commitRef.current = commit;
    const visibility = () => { tick(); visible = document.visibilityState === "visible"; if (visible) lastActivity = last; };
    const input = e => {
      if (!e.target.closest?.(".ux-main,dialog[open]")) return;
      activity();
      if (!e.target.matches?.("input:not([type=file]):not([type=password]),textarea")) return;
      const field = e.target.closest("[data-feedback-target]")?.dataset.feedbackTarget;
      if (!field) return;
      if (!e.target.value.trim()) cleared.add(e.target);
      else if (cleared.has(e.target)) { cleared.delete(e.target); emit("form.field_refill", { step, field }); }
    };
    const offline = () => emit("net.offline", { step });
    document.addEventListener("visibilitychange", visibility);
    document.addEventListener("input", input, true);
    document.addEventListener("click", activity, true);
    window.addEventListener("offline", offline);
    return () => {
      commit(); commitRef.current = null;
      document.removeEventListener("visibilitychange", visibility);
      document.removeEventListener("input", input, true);
      document.removeEventListener("click", activity, true);
      window.removeEventListener("offline", offline);
    };
  }, [key, step, caseId, emit]);

  const track = useCallback((kind, field) => {
    const name = legacyNames[kind];
    if (name && step) emit(name, { step, field });
  }, [emit, step]);

  // T：提交前核對卡。只在「有可核對內容」的提交節點分派（決策點）。
  const gate = useCallback((current, proceed) => {
    const phase = active?.phase;
    if (!active || role !== "worker" || !current || !["mrt", "adaptive"].includes(phase)) return proceed();
    const flags = (assistantSuggestions(current, true, [], active.hints || []).items || []).filter(i => i.kind === "check");
    if (!flags.length) return proceed();
    const point = `${current.id}:${current.updatedAt || current.serverVersion || ""}`;
    const seq = Math.max(readSeq(user), Number(active.taskSeqToday) || 0) + 1;
    const late = seq >= (active.lateTaskThreshold || 4);
    let arm = decided.current.get(point);
    if (!arm) {
      const p = Number(active.checkProbability ?? 0.5);
      arm = phase === "adaptive" ? (late ? "check" : "control") : Math.random() < p ? "check" : "control";
      decided.current.set(point, arm);
      emit("check.assigned", { caseId: current.id, arm, flags: flags.length, late, taskSeq: seq, randomized: phase === "mrt", p });
      if (arm === "check") {
        emit("check.shown", { caseId: current.id, flags: flags.length });
        setCheck({ caseId: current.id, flags, proceed });
        return;
      }
    }
    return proceed();
  }, [active, role, user, emit]);

  const ask = useCallback((id, action, version) => {
    if (role === "worker" && action === "submit") {
      try { localStorage.setItem(seqKey(user, today()), String(readSeq(user) + 1)); } catch {}
    }
    if (!active || !Number.isInteger(version) || action === "return") return;
    const rate = Number(active.surveyRate ?? 0.4);
    if (Math.random() < rate) {
      emit("survey.shown", { caseId: id, version });
      setPrompt({ caseId: id, action, version });
    }
  }, [active, role, user, emit]);

  const answer = useCallback((values) => {
    if (!prompt) return;
    if (values) {
      emit("survey.effort", { caseId: prompt.caseId, value: values.effort, version: prompt.version });
      emit("survey.fatigue", { caseId: prompt.caseId, value: values.fatigue, version: prompt.version });
    } else emit("survey.skipped", { caseId: prompt.caseId, version: prompt.version });
    setPrompt(null);
    void flush();
  }, [prompt, emit, flush]);

  return {
    config: config?.user === user ? config : null, joined: Boolean(active), track, flush, gate, ask, answer, prompt,
    check, emit, finishTime: () => commitRef.current?.(), closeCheck: () => setCheck(null),
  };
}

function Scale({ name, label, max, anchors, value, onChange }) {
  return <fieldset className="probe-scale">
    <legend>{label}</legend>
    <div role="radiogroup" aria-label={label}>{Array.from({ length: max }, (_, i) => i + 1).map(n =>
      <button key={n} type="button" role="radio" aria-checked={value === n} className={value === n ? "is-on" : ""} onClick={() => onChange(name, n)}>{n}</button>)}</div>
    <p className="probe-anchors">{anchors.map(([n, text]) => <span key={n} style={{ left: `${((n - 1) / (max - 1)) * 100}%` }}>{text}</span>)}</p>
  </fieldset>;
}

export function ResearchProbeLayer({ probe, t, onFocus }) {
  const { config, check, prompt, answer, emit, closeCheck } = probe;
  const [values, setValues] = useState({});
  const checkRef = useRef(null);
  useEffect(() => { setValues({}); }, [prompt?.caseId, prompt?.version]);
  useEffect(() => {
    if (!check) return;
    checkRef.current?.scrollIntoView({ block: "start", behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth" });
    checkRef.current?.querySelector(".probe-primary")?.focus({ preventScroll: true });
  }, [check]);
  if (!config?.studyId) return null;
  const pick = (name, n) => setValues(v => ({ ...v, [name]: n }));
  return <>
    {check && <section ref={checkRef} className="field-study-card field-study-hints probe-check" role="dialog" aria-labelledby="probe-check-title">
      <div><h2 id="probe-check-title">{t("提交前核對", "Check before submitting")}</h2>
        <span>{t(`以下 ${check.flags.length} 項較常被維修部修正，請花幾秒確認。`, `${check.flags.length} items are often corrected. Take a few seconds to check.`)}</span></div>
      <ul>{check.flags.map(issue => <li key={issue.field}><span>{t(issue.hk, issue.en)}</span>
        <button type="button" onClick={() => { emit("check.go_field", { caseId: check.caseId, field: issue.field }); closeCheck(); onFocus(issue); }}>
          {t("前往", "Go to")} <span className="field-study-sr">{fieldStudyFields[studyField(issue.field)]}</span><span aria-hidden="true"> →</span></button></li>)}</ul>
      <div className="probe-actions">
        <button type="button" className="probe-primary" onClick={() => { emit("check.confirmed", { caseId: check.caseId }); const go = check.proceed; closeCheck(); go(); }}>{t("已核對，提交", "Checked, submit")}</button>
      </div>
    </section>}
    {prompt && <section className="field-study-card probe-survey" aria-label={t("兩條問題 · 約 10 秒", "Two questions")}>
      <h2>{t("兩條問題 · 約 10 秒", "Two quick questions")}</h2>
      <Scale name="effort" max={9} value={values.effort} onChange={pick} anchors={effortScale}
        label={t(prompt.action === "confirm" ? "覆核這張服務單用了多少腦力？" : "完成這張服務單用了多少腦力？", "How much mental effort did this take?")} />
      <Scale name="fatigue" max={7} value={values.fatigue} onChange={pick} anchors={fatigueScale}
        label={t("你現在有多累？", "How tired are you right now?")} />
      <div className="probe-actions">
        <button type="button" className="probe-primary" disabled={!values.effort || !values.fatigue} onClick={() => answer(values)}>{t("送出", "Send")}</button>
        <button type="button" onClick={() => answer(null)}>{t("略過", "Skip")}</button>
      </div>
      <p className="probe-note">{t("只作群體研究，不用於個人考核。", "Used for group research only, never for individual appraisal.")}</p>
    </section>}
  </>;
}
