import { sessionFetch, setSessionToken, setWorkspaceRole } from "./session-fetch";

async function request(path, method = "GET", body, signal) {
  const response = await sessionFetch(path, {
    method, credentials: "same-origin", cache: "no-store",
    headers: body === undefined ? undefined : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
    ...(signal ? { signal } : {}),
  });
  let payload;
  try { payload = await response.json(); } catch { payload = null; }
  if (!response.ok) {
    const error = new Error(payload?.error || "service-unavailable");
    error.status = response.status;
    error.missingFields = payload?.missingFields || [];
    throw error;
  }
  return payload;
}

async function readWithRetry(path) {
  const signal = AbortSignal.timeout(12000);
  for (let attempt = 0; ; attempt++) {
    signal.throwIfAborted();
    try { return await request(path, "GET", undefined, signal); }
    catch (error) {
      if (signal.aborted || ![502, 503, 504].includes(error.status) || attempt >= 2) throw error;
      await new Promise(resolve => setTimeout(resolve, 250 * (attempt + 1)));
    }
  }
}
export async function currentAccount() { return readWithRetry("/api/me"); }
export async function workspace() { return readWithRetry("/api/workspace"); }
export async function staffDirectory() { return readWithRetry("/api/staff"); }
export async function signInPhone(phoneNumber, password) {
  const response = await fetch("/api/auth/sign-in/phone-number", { method:"POST", credentials:"omit",
    headers:{"Content-Type":"application/json"}, signal:AbortSignal.timeout(30000),
    body:JSON.stringify({phoneNumber,password,rememberMe:true}) });
  const token=response.headers.get("set-auth-token");
  if(!response.ok || !token)throw new Error("invalid-credentials");
  setWorkspaceRole(null);
  setSessionToken(token);
  return response.json();
}
export async function signOut() {
  try { await request("/api/auth/sign-out", "POST", {}); }
  finally {
    setSessionToken(null);
    setWorkspaceRole(null);
  }
}
export async function createCase(data) { return request("/api/cases", "POST", data); }
export async function createProject(data) { return request("/api/projects", "POST", data); }
export async function updateProject(data) { return request("/api/projects", "PATCH", data); }
export async function deleteProject(data) { return request("/api/projects", "DELETE", data); }
export async function importIndexWorkbook(file) {
  const form = new FormData();
  form.set("file", file);
  const response = await sessionFetch("/api/imports/index", { method: "POST", body: form });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "import-failed");
  return payload;
}
export async function saveCase(record) { return request(`/api/cases/${encodeURIComponent(record.id)}`, "PATCH", record); }
export async function uploadCasePhoto(caseId, file) {
  const form = new FormData();
  form.set("file", file);
  const response = await sessionFetch(`/api/cases/${encodeURIComponent(caseId)}/assets`, {
    method: "POST", credentials: "same-origin", body: form,
  });
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "upload-failed");
  return payload;
}
export async function generateCaseDocument(caseId, kind, revision) {
  return request(`/api/cases/${encodeURIComponent(caseId)}/documents`, "POST", { kind, revision });
}
export async function caseAction(record, action, payload = {}) {
  return request(`/api/cases/${encodeURIComponent(record.id)}/actions`, "POST", {
    action, serverVersion: record.serverVersion, payload,
  });
}

export async function updateTrash(action, records) { return request(`/api/trash/${action}`, "POST", {items: records.map(r=>({id:r.id,serverVersion:r.serverVersion}))}); }
