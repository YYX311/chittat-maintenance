import assert from 'node:assert/strict';
import { test } from 'node:test';
import { PGlite } from '@electric-sql/pglite';
import { loadHandoverDataset } from '../lib/handover-dataset.ts';
import { analyze, toCsv } from '../lib/research-model.ts';

test('live dataset follows Hong Kong dates, preserves rounds and leaves missing measures blank', async () => {
  const db = new PGlite();
  try {
    await db.exec(`
      CREATE TABLE audit_events(id bigint GENERATED ALWAYS AS IDENTITY, case_id text, actor_user_id text,
        action text, detail jsonb DEFAULT '{}', created_at timestamptz);
      CREATE TABLE case_versions(case_id text, kind text, revision int, snapshot jsonb,
        created_by text, created_at timestamptz);
      CREATE TABLE research_probe_events(id text, case_id text, actor_user_id text, role text, name text,
        at timestamptz, step text, active_ms int, rating int, case_version int);
      INSERT INTO audit_events(case_id,actor_user_id,action,created_at,detail) VALUES
        ('case-rework','worker-private','submit','2026-11-17 15:55Z','{}'),
        ('case-rework','office-private','return','2026-11-17 16:05Z','{"reason":"location","field":"address"}'),
        ('case-rework','worker-private','submit','2026-11-17 16:20Z','{"version":4}'),
        ('case-rework','office-private','review','2026-11-17 16:30Z','{}'),
        ('case-rework','office-private','confirm','2026-11-17 16:40Z','{}'),
        ('case-rework','office-private','confirm','2026-11-17 17:20Z','{}'),
        ('case-return','worker-private','submit','2026-11-17 17:00Z','{}'),
        ('case-return','office-private','return','2026-11-17 17:15Z','{"reason":"photos","field":"photo"}'),
        ('case-pending','worker-private','submit','2026-11-18 15:55Z','{}'),
        ('case-pending','office-private','confirm','2026-11-18 16:00Z','{}'),
        ('case-withdraw','worker-private','submit','2026-11-18 14:10Z','{}'),
        ('case-withdraw','worker-private','withdraw','2026-11-18 14:15Z','{}'),
        ('case-pass','worker-private','submit','2026-11-18 14:20Z','{}'),
        ('case-pass','office-private','confirm','2026-11-18 14:30Z','{}');
      INSERT INTO case_versions VALUES
        ('case-rework','service',1,'{"address":"private original","items":[{}],"submittedAt":"2026-11-17T16:19:59Z"}','worker-private','2026-11-17 16:19:59Z'),
        ('case-rework','confirmation',0,'{"address":"private correction","approvedAt":"2026-11-17T16:39:59Z"}','office-private','2026-11-17 16:39:59Z');
      INSERT INTO research_probe_events VALUES
        ('outside-round','case-rework','worker-private','worker','form.step_leave','2026-11-17 15:45Z','worker-basic',60000,null,null),
        ('fill','case-rework','worker-private','worker','form.step_leave','2026-11-17 16:10Z','worker-basic',60000,null,null),
        ('block','case-rework','worker-private','worker','form.validation_block','2026-11-17 16:12Z','worker-basic',null,null,null),
        ('prompt','case-rework','worker-private','worker','survey.shown','2026-11-17 16:20:01Z',null,null,null,4),
        ('effort','case-rework','worker-private','worker','survey.effort','2026-11-17 16:21Z',null,null,6,4),
        ('fatigue','case-rework','worker-private','worker','survey.fatigue','2026-11-17 16:21Z',null,null,4,4),
        ('review','case-rework','office-private','office','form.step_leave','2026-11-17 16:35Z','office-0',120000,null,null);
    `);
    const data = await loadHandoverDataset(db, '2026-11-18', '2026-11-18');
    const analysis = analyze(data);
    assert.equal(data.episodes.length, 5);
    assert.deepEqual(data.episodes.map(e => [e.round, e.returned, e.taskSeqToday]),
      [[2, false, 1], [1, true, 2], [1, null, 3], [1, false, 4], [1, null, 5]]);
    assert.deepEqual(data.episodes[0].correctedFields, ['address']);
    assert.equal(data.episodes[0].cycleMin, 20);
    assert.equal(data.episodes[0].reviewWaitMin, 10);
    assert.equal(data.episodes[0].fillActiveMin, 1);
    assert.equal(data.episodes[0].reviewActiveMin, 2);
    assert.equal(data.episodes[0].validationBlocks, 1);
    assert.equal(data.episodes[0].itemCount, 1);
    assert.equal(data.episodes[0].effort, 6);
    assert.equal(data.episodes[0].fatigue, 4);
    assert.equal(data.episodes[1].fillActiveMin, null);
    assert.equal(analysis.kpi.fpy, 0.5);
    assert.equal(analysis.kpi.firstDecided, 2);
    assert.equal(analysis.kpi.corrected, 1);
    assert.equal(analysis.kpi.cycle, 15);
    assert.equal(analysis.models.m1, null);
    assert.equal(analysis.kpi.surveyResponse, 1);
    assert.ok(!toCsv(analysis.rows).includes('NaN'));
    assert.doesNotMatch(JSON.stringify(data), /private|case-rework/);
  } finally {
    await db.close();
  }
});
