# 注意事项

- 每次改动完成后，都必须创建一个对应的 Git commit，以便后续追踪和回滚。
- 每次改动后，都必须编写或更新相关测试，并在交付给用户前，确保所有测试和验证全部通过。

## 前端样式基准

- 用户于 2026-09-14 指定：「梳理机电维修系统需求」对话中最新发布的 Cloudflare 网站（https://chittat-maintenance-demo.pages.dev/?screen=login&lang=zh-HK）为最终前端样式与交互基准。技术迁移和后端开发须保持该版本的界面；以线上效果核对本地源码，不能直接采用旧截图或旧交付包。
- 已核对的基准包括维修部「任務／INDEX」导航、12 个业务栏位的 INDEX、维修人员手机端任务卡片及「任務／草稿／我的」底部导航。旧 v10 文档中的 33 列布局不能覆盖最新线上基准；详见 TECH_STACK_PROPOSAL.md。

<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->
