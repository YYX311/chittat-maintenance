# 免費雲端測試部署

驗證日期：2026-09-22。

2026-09-23 提交與登入修正：每個分頁在 sessionStorage 保存獨立的簽名 session token，API、私人圖片、PDF 預覽及下載均使用此 token，前端不回退至其他分頁的 Cookie。重新整理保留登入；新分頁需獨立登入。更新前開著的頁面需重新整理及登入一次。

連續輸入合併儲存，請求有 30 秒超時，草稿在登入後也會恢復同步。工人提交只建立資料快照，不等待 PDF；INDEX 的合併下載包含以同一確認版本產生的服務單、報價單及發票，服務單標記工人／辦公室來源。新增遷移 `005_confirmed_service.sql`，原始提交快照仍保留。

此修正通過 57 項自動化測試及 15 個瀏覽器流程（完整測試及針對新增／更新用例的重跑），並完成雲端 API、同步和三類私人 PDF 驗收。雲端原有使用者草稿保留。

測試入口：https://chittat-maintenance-test.yjsyyx00.workers.dev/

此部署使用原有 Cloudflare 帳戶中的新 Worker，舊 `chittat-maintenance-demo.pages.dev` 設計演示站保留。沒有啟用 R2、綁卡或升級付費方案。

## 架構與資料

- Cloudflare Workers + vinext/Vite 執行現有 App Router 頁面及 API；本地 Next.js 開發指令仍然保留。vinext 為 beta，此版本用於雲端驗收，不能視為大規模正式上線已驗收。
- Supabase Free PostgreSQL（Singapore）保存員工、工作單與版本。Hyperdrive 關閉查詢快取，驗證來源 TLS 憑證。
- Supabase 私人 S3 相容儲存桶 `maintenance-private` 保存附件與 PDF；下載經伺服器檢查員工權限。沒有開放公開桶或 Data API。
- Worker 的資料庫連線池按請求建立與關閉，避免跨請求重用 sockets；Better Auth 使用相同請求範圍的代理。
- PDF 字體透過 Cloudflare 靜態資產 binding 載入。PDFKit 的 browser build 使用內嵌 ICC 資料，建置時修正其非絕對 module URL 註冊鍵。
- 公司地址、電話、付款資料目前明確標為 `TEST ONLY - pending company confirmation`。正式單據前必須換成經確認資料。
- 初始僅保留兩個測試角色帳戶，沒有示範任務。登入號碼：維修員 `91234567`，維修部 `92345678`；密碼另行提供，不寫入 Git。

## 部署與驗證

```powershell
npm ci
npm test
npm run typecheck
npm run typecheck:cloudflare
npm run build:vinext
npx wrangler deploy --config dist/server/wrangler.json --dry-run
npx wrangler deploy --config dist/server/wrangler.json
```

不要用 `vinext build` 取代 `vite build`：本專案需執行 Cloudflare Vite plugin、資料庫與 PDF 資產轉接。

部署密鑰透過 `wrangler secret bulk` 設定； `.env.cloud-test`、`tmp/`、`.dev.vars*` 都已忽略。必需變數包括 `.env.example` 的正式環境欄位，以及 S3 endpoint/access key/secret key。不要提交密鑰或將它們放進 `vars`。資料庫密碼改動時，同步更新 Hyperdrive 來源憑證及本地遷移設定。

遷移仍使用 `scripts/migrate.mjs`；本機連線 Supabase 時以 `NODE_EXTRA_CA_CERTS` 載入官方 Supabase CA，保持 `sslmode=verify-full`。禁止關閉 TLS 憑證驗證。

雲端驗收腳本需要 `CLOUD_TEST_URL`、`CLOUD_TEST_PASSWORD`，可選 `CLOUD_WORKER_PHONE`、`CLOUD_OFFICE_PHONE`。執行 `npm run test:cloud` 會建立標記為 Cloud acceptance 的測試資料，並在忽略的 `tmp/cloud-smoke-<run>.json` 記錄精確 ID，測試完只清除此 run 的資料，不清空整個資料庫。

已驗證：三個並行登入 session 不互相登出、兩端同時建立、提交與同步、退回修改及重新提交、確認進入 INDEX、三類 PDF 真實下載及解析、匿名下載拒絕。另有 55 項既有自動化測試。這些是功能驗收，不是大量使用者壓力測試。

## 免費額度與限制

Supabase Free 提供 500 MB 資料庫、1 GB 檔案儲存、5 GB egress，閒置一週會暫停，沒有免費自動備份。Cloudflare Workers Free 有每日請求及 CPU 額度；PDF 和密碼驗證會消耗較多 CPU。本次小量驗收通過不代表高負載可用性保證。用量接近限制時先評估，沒有使用者授權不能升級。

官方資料：[Supabase pricing](https://supabase.com/pricing)、[Workers limits](https://developers.cloudflare.com/workers/platform/limits/)。

正式投入使用前需確認公司單據資料、獨立員工帳戶、備份恢復、容量與壓力驗收。不要將測試密碼作為正式員工共用密碼。


## 2026-09-23 交互與同步修正

- 用獨立的伺服器版本表合併背景同步；舊查詢不得蓋過已保存回應，其他人的真實衝突仍保留檢查。本機未同步內容不會被背景查詢取代。
- INDEX 以登入 session、篩選及分頁作快取鍵，重新開啟先顯示上次表格再核對；退回工人的任務仍留在維修部待處理清單。
- 使用者操作顯示中央等待與結果提示；自動保存及背景輪詢不反覆彈窗。直接生成按鈕先開儲存選擇器，再生成、寫入及關閉檔案；不支援選擇器的瀏覽器使用正常下載，不宣稱已寫入硬碟。
- INDEX 詳情只保留頂部返回入口，歷史版本按確認版本展開三份 PDF。已有文件的預覽直接讀私有存檔。
- Project Code 可新增、更改選用和復用，不替換任務的原工作地點。改用新代碼不追溯修改已確認版本。
- 主要聯絡、位置、設備、描述及起訖時間必填（不適用的文字欄填「不適用」）；補充備註、材料、合約和相片說明可留空。服務時間資料變更也納入確認版本比較。
- 報價備註優先擴展同頁區域，保留至少 7pt 字體；過長而無法放入一頁時回傳可理解的錯誤，禁止截斷或另開備註頁。
- 遷移 006 保留已有服務編號，為未編號草稿分配同一全域 CT-MNA-xxxx 序號。建立新任務時即分配；刪除不回收編號。正式報價及發票編號不變。

本次驗證使用隔離資料庫、兩端瀏覽器工作流、原生儲存介面模擬（確認呼叫次序及實際字節寫入）、PDF 頁數與排版檢查。真實作業系統檔案對話框由瀏覽器控制。

## 2026-09-23 後續六項修正

- INDEX 在同一登入及相同已確認版本下保留分頁快取，不因草稿變更重新請求；列表以分頁 API 為準，不被尚未完成的工作區輪詢裁掉。下載選取採最新可用版本，已刪除記錄不納入。
- 移除切頁提示；正常操作結果用白色，錯誤和重要警告用紅色。生成、儲存、上傳仍顯示等待狀態。
- 已儲存 Project Code 在原項目 ID 更新，以原代碼作並發檢查；保留旧代碼別名讓既有任務可繼續編輯，已確認文件不追溯改寫。代碼與原工作地點放在同一區域。
- 相片選取後立即以本機預覽顯示，上傳並保存任務關聯後才提示成功；私有縮圖失敗可重試。
- 維修人員需逐一確認開工與完工時間才可下一步，修改時間後重新確認；服務端同步驗證。

相機流程以 Playwright 檔案輸入模擬驗證第一張照片立即顯示及重新載入保留；未使用實體手機相機驗收。

## Project Code 清單操作

維修部先填工作地點，再在同一區域輸入並儲存 Project Code。已儲存代碼在下拉清單中；選取後可直接改寫原代碼並再次儲存。輸入期間不改動任務已保存的關聯，儲存成功才套用。清單中的選定代碼可在確認後單獨移除，移除後不再供新任務選用。資料庫保留停用代碼及其 ID，舊任務、歷史版本與已生成文件不被刪除；舊任務若要再次確認，需選用有效代碼。
