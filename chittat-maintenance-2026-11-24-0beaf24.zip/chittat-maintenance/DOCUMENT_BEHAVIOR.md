# Commercial document reference

`assets/commercial-template.json` records the column widths, row heights, labels and horizontal rules from the user-supplied Desktop/报价单和发票.xls (QUO and INVOICE worksheets). Customer details, references, dates, item values and sample preparer names were removed; runtime snapshots supply them. The company payment and signature wording is retained from the supplied template.

Both browser previews and downloads call the same PDF renderer. Long work descriptions continue on additional pages; oversized remarks/payment terms use continuation sheets. Rendering uses the static embedded Noto Sans HK face to avoid the previously reported variable-font extraction error. Its glyph shapes differ from the spreadsheet's Ming/Times fonts, so pixel-identical font appearance is not claimed.

Downloads are prepared and validated before offering **Choose location and save**. The subsequent user click opens the native save picker where supported; other browsers use their configured download location. This prevents a generation failure from creating an empty selected file.

Multi-user validation currently covers four independent sessions, concurrent case creation/submission, unique numbering, shared office visibility, optimistic conflict rejection and independent logout. The local PGlite development database is not a production load benchmark. Production requires PostgreSQL, an appropriately sized connection pool, and load testing with the expected staff count. Same-origin tabs share browser cookies; localhost (office) and 127.0.0.1 (worker) remain separate for local dual-role testing.

Local PGlite requires DATABASE_POOL_MAX=1 because its socket multiplexer does not isolate unnamed prepared statements between connections. Requests queue on that connection without sharing login sessions. PostgreSQL uses DATABASE_POOL_MAX=10 by default; do not use the development emulator to measure production concurrency.
