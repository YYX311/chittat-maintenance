# 高陞機電維修系統

面向維修人員及維修部的响应式 Web 系统。首版覆盖现场提交、维修部覆核与退回、12 栏 INDEX、报价及发票版本，以及受权限保护的照片和正式 PDF。

## 本地运行

需要 Node.js 24 和 PostgreSQL 16 或以上版本。

```powershell
Copy-Item .env.example .env.local
npm ci
$env:DATABASE_URL = "postgres://maintenance:password@localhost:5432/maintenance"
npm run db:migrate
npm run dev
```

在 `.env.local` 中生成一个至少 32 字符的 `BETTER_AUTH_SECRET`。本地开发默认将私人附件写入 `.data/assets`；生产环境必须使用 S3 兼容的私人对象存储。

## 建立员工账号

系统不开放自行注册。管理员在部署环境中运行以下命令预先开通员工；命令会以隐藏输入方式读取密码。

```powershell
npm run staff:provision -- --phone +85291234567 --name "維修員" --staff-code W001 --role worker
npm run staff:provision -- --phone +85292345678 --name "維修部" --staff-code O001 --role office
```

角色可用 `worker`、`office` 或 `manager`。维修人员只能访问自己创建的任务；维修部可覆核、定价和签发；经理另外可查看员工清单。

## 同时验收两个角色

同一浏览器的普通窗口会共享登录 Cookie，所以两个普通标签页不能保持不同身份。需要同时查看维修人员与维修部的信息流转时，用一个普通窗口和一个无痕／InPrivate 窗口打开同一个地址：

- 普通窗口：<http://localhost:3000>，登录维修部账号
- 无痕／InPrivate 窗口：<http://localhost:3000>，登录维修人员账号

两个窗口拥有独立的 Cookie，可以同时刷新并观察任务提交、覆核、退回和重提。正式使用时，每名员工在自己的设备或浏览器中登录。

## 验证

```powershell
npm test
npm run typecheck
npm run build
npm audit
```

生产配置、容器启动、备份恢复及验收步骤见 [DEPLOYMENT.md](./DEPLOYMENT.md)。技术决策与首版边界见 [TECH_STACK_PROPOSAL.md](./TECH_STACK_PROPOSAL.md)。
