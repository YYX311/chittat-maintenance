"use client";

import { useEffect } from "react";

const previewKey = "ct-local-appearance";

export default function AppearancePreview() {
  useEffect(() => {
    if (!["localhost", "127.0.0.1"].includes(window.location.hostname)) return;
    const requested = new URLSearchParams(window.location.search).get("appearance");
    let blue = requested === "blue";
    try {
      if (requested === "blue" || requested === "white") {
        window.sessionStorage.setItem(previewKey, requested);
      } else {
        blue = window.sessionStorage.getItem(previewKey) === "blue";
      }
    } catch {
      // The preview link also works when browser storage is unavailable.
    }
    if (blue) document.documentElement.dataset.workspaceAppearance = "blue";
    else delete document.documentElement.dataset.workspaceAppearance;
  }, []);
  return null;
}
