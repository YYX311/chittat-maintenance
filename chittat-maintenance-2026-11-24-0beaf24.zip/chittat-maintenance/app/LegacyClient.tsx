"use client";

import dynamic from "next/dynamic";
import Startup from "./Startup";

const Workspace = dynamic(() => import("../src/Workspace"), {
  ssr: false,
  loading: () => <Startup />,
});

export default function LegacyClient() {
  return <Workspace />;
}
