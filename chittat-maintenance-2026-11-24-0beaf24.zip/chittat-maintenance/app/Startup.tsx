'use client';

import { useEffect, useState } from 'react';
import s from './startup.module.css';

export default function Startup({ failed = false }: { failed?: boolean }) {
  const [stalled, setStalled] = useState(false);

  useEffect(() => {
    if (failed) return;
    const timer = window.setTimeout(() => setStalled(true), 10000);
    return () => window.clearTimeout(timer);
  }, [failed]);

  const isAlert = failed || stalled;
  return <main className={s.screen}>
    <section className={s.card} aria-live="polite">
      <h1>高陞機電維修</h1>
      <p role={isAlert ? 'alert' : 'status'}>
        {failed
          ? '頁面未能載入，請重新整理再試。'
          : stalled
            ? '系統載入時間較長，網絡可能繁忙，請按「重新整理」再試。'
            : '正在開啟系統…'}
      </p>
      {failed ? (
        <a className={s.button} href="/?screen=login&switchAccount=1">返回登入頁</a>
      ) : (
        <button type="button" className={s.button} onClick={() => window.location.reload()}>
          重新整理
        </button>
      )}
    </section>
  </main>;
}
