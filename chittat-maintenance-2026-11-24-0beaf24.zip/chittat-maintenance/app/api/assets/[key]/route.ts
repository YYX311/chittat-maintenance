import { getStaff } from "../../../../lib/access";
import { readAsset } from "../../../../lib/asset-service";
import { db } from "../../../../lib/db";
import { apiError } from "../../../../lib/http";
import { configuredObjectStore } from "../../../../lib/object-storage";

export const runtime = "nodejs";

export async function GET(request: Request, { params }: { params: Promise<{ key: string }> }) {
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    const { key } = await params;
    const { asset, bytes } = await readAsset(db(), configuredObjectStore(), staff, key);
    const body = new Uint8Array(new ArrayBuffer(bytes.length));
    body.set(bytes);
    return new Response(body.buffer, { headers: {
      "Content-Type": asset.content_type,
      "Content-Length": String(asset.byte_size),
      "Content-Disposition": "inline",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    } });
  } catch (error) { return apiError(error); }
}
