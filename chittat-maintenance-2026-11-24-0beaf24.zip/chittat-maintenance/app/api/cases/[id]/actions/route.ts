import { getStaff } from "../../../../../lib/access";
import { actionCase, type CaseAction } from "../../../../../lib/case-service";
import { transaction } from "../../../../../lib/db";
import { apiError, jsonBody, sameOrigin } from "../../../../../lib/http";

export const runtime = "nodejs";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request)) return Response.json({ error: "forbidden" }, { status: 403 });
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    const { id } = await params;
    const body = await jsonBody(request);
    const record = await transaction((client) => actionCase(client, staff, id,
      body.action as CaseAction, Number(body.serverVersion), body.payload || {}));
    return Response.json(record);
  } catch (error) { return apiError(error); }
}
