import { getStaff } from "../../../../../lib/access";
import { saveImage } from "../../../../../lib/asset-service";
import { db } from "../../../../../lib/db";
import { apiError, sameOrigin } from "../../../../../lib/http";
import { configuredObjectStore } from "../../../../../lib/object-storage";

export const runtime = "nodejs";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request)) return Response.json({ error: "forbidden" }, { status: 403 });
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    if (Number(request.headers.get("content-length")) > 21 * 1024 * 1024) throw new Error("invalid-image");
    const file = (await request.formData()).get("file");
    if (!(file instanceof File)) throw new Error("invalid-image");
    const { id } = await params;
    const asset = await saveImage(db(), configuredObjectStore(), staff, id, new Uint8Array(await file.arrayBuffer()), file.type);
    return Response.json({ key: asset.key, url: `/api/assets/${asset.key}` }, { status: 201 });
  } catch (error) { return apiError(error); }
}
