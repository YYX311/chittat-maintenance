import { getStaff } from "../../../../../lib/access";
import { transaction } from "../../../../../lib/db";
import { generateCaseDocument } from "../../../../../lib/document-service";
import { apiError, jsonBody, sameOrigin } from "../../../../../lib/http";
import { configuredObjectStore } from "../../../../../lib/object-storage";
import type { DocumentKind } from "../../../../../lib/pdf-document";

export const runtime = "nodejs";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!sameOrigin(request)) return Response.json({ error: "forbidden" }, { status: 403 });
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    const { id } = await params;
    const body = await jsonBody(request);
    const document = await transaction(client => generateCaseDocument(client, configuredObjectStore(), staff, id,
      body.kind as DocumentKind, body.revision === undefined ? undefined : Number(body.revision)));
    return Response.json(document);
  } catch (error) { return apiError(error); }
}
