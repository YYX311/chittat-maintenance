import { getStaff } from "../../../../../lib/access";
import { db } from "../../../../../lib/db";
import { apiError } from "../../../../../lib/http";
import { canSee } from "../../../../../lib/case-rules";
import { renderDocument, type DocumentKind } from "../../../../../lib/pdf-document";
import {readAsset} from "../../../../../lib/asset-service";
import {configuredObjectStore} from "../../../../../lib/object-storage";
export const runtime="nodejs";
export async function GET(request:Request,{params}:{params:Promise<{id:string}>}) {
 try {
  const staff=await getStaff(request);
  if(!staff)return Response.json({error:"unauthorized"},{status:401});
  const {id}=await params,q=new URL(request.url).searchParams,kind=q.get("kind") as DocumentKind;
  if(!["service","quotation","invoice","confirmed-service"].includes(kind))throw new Error("invalid-document-kind");
  const {rows}=await db().query("SELECT data FROM cases WHERE id=$1 AND deleted_at IS NULL",[id]);
  const record=rows[0]?.data;
  if(!record||!canSee(staff,record))throw new Error("not-found");
  if(kind!=="service"&&staff.role==="worker")throw new Error("forbidden");
  let snapshot=record;
  if(q.has("revision")){
   const revision=Number(q.get("revision"));
   if(!Number.isInteger(revision)||revision<0)throw new Error("invalid-revision");
   const issued=await db().query("SELECT asset_key FROM case_versions WHERE case_id=$1 AND kind=$2 AND revision=$3",[id,kind,revision]);
   if(issued.rows[0]?.asset_key){
    const {bytes}=await readAsset(db(),configuredObjectStore(),staff,issued.rows[0].asset_key);
    return new Response(new Uint8Array(bytes),{headers:{"Content-Type":"application/pdf","Content-Disposition":"inline","Cache-Control":"private, no-store"}});
   }
   const source=await db().query("SELECT snapshot FROM case_versions WHERE case_id=$1 AND kind=$2 AND revision=$3",[id,kind==="service"?"service":"confirmation",revision]);
   if(!source.rows.length)throw new Error("not-found");
   snapshot=source.rows[0].snapshot;
  }
  const bytes=await renderDocument(snapshot,kind);
  return new Response(new Uint8Array(bytes),{headers:{"Content-Type":"application/pdf","Content-Disposition":"inline","Cache-Control":"private, no-store"}});
 }catch(error){return apiError(error);}
}
