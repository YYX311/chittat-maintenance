import { getStaff } from "../../../lib/access";
import { createCase } from "../../../lib/case-service";
import { transaction } from "../../../lib/db";
import { apiError, jsonBody, sameOrigin } from "../../../lib/http";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "forbidden" }, { status: 403 });
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    const body = await jsonBody(request);
    const record = await transaction((client) => createCase(client, staff, body));
    return Response.json(record, { status: 201 });
  } catch (error) { return apiError(error); }
}
