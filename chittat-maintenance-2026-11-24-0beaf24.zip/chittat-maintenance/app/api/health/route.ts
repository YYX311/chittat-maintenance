import { db } from "../../../lib/db";
import { productionConfigurationErrors } from "../../../lib/environment";

export const runtime = "nodejs";

export async function GET() {
  if (productionConfigurationErrors().length) {
    return Response.json({ status: "misconfigured" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
  try {
    await db().query("SELECT 1");
    return Response.json({ status: "ok" }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ status: "unavailable" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
