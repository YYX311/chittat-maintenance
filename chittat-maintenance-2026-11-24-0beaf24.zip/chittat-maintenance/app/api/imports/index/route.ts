import { getStaff } from "../../../../lib/access";
import { transaction } from "../../../../lib/db";
import { apiError, sameOrigin } from "../../../../lib/http";
import { importIndex } from "../../../../lib/index-import";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "forbidden" }, { status: 403 });
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    if (Number(request.headers.get("content-length")) > 11 * 1024 * 1024) throw new Error("invalid-workbook");
    const file = (await request.formData()).get("file");
    if (!(file instanceof File) || !/\.xlsx$/i.test(file.name)) throw new Error("invalid-workbook");
    const bytes = new Uint8Array(await file.arrayBuffer());
    const result = await transaction(client => importIndex(client, staff, bytes));
    return Response.json(result);
  } catch (error) { return apiError(error); }
}
