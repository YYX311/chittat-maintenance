import { getStaff } from "../../../lib/access";
import { db } from "../../../lib/db";
import { apiError } from "../../../lib/http";
import { listIndex } from "../../../lib/index-service";
export const runtime="nodejs";
export async function GET(request:Request) {
 try {
  const staff=await getStaff(request);
  if(!staff)return Response.json({error:"unauthorized"},{status:401});
  return Response.json(await listIndex(db(),staff,new URL(request.url).searchParams),{headers:{"Cache-Control":"no-store"}});
 }catch(error){return apiError(error);}
}
