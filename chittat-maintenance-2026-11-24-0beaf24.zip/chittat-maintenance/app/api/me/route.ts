import { getStaff } from "../../../lib/access";
import { requireResearchAdmin } from "../../../lib/research-service";

export const runtime = "nodejs";

export async function GET(request: Request) {
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    let canResearch = false;
    try { requireResearchAdmin(staff); canResearch = true; } catch {}
    return Response.json({
      id: staff.staffCode,
      phone: staff.phone,
      email: staff.email,
      name: staff.name,
      role: staff.role === "worker" ? "worker" : "office",
      canWork: staff.canWork,
      canManage: staff.role === "manager",
      canResearch,
    }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "service-unavailable" }, { status: 503 });
  }
}
