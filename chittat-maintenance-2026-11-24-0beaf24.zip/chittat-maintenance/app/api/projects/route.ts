import { getStaff } from "../../../lib/access";
import { db } from "../../../lib/db";
import { apiError, jsonBody, sameOrigin } from "../../../lib/http";
import { createProject, deleteProject, updateProject } from "../../../lib/project-service";

export const runtime = "nodejs";
export async function DELETE(request: Request) {
 if(!sameOrigin(request))return Response.json({error:"forbidden"},{status:403});
 try {
  const staff=await getStaff(request);
  if(!staff)return Response.json({error:"unauthorized"},{status:401});
  return Response.json(await deleteProject(db(),staff,await jsonBody(request)));
 }catch(error){return apiError(error);}
}
export async function PATCH(request: Request) {
 if(!sameOrigin(request))return Response.json({error:"forbidden"},{status:403});
 try {
  const staff=await getStaff(request);
  if(!staff)return Response.json({error:"unauthorized"},{status:401});
  return Response.json(await updateProject(db(),staff,await jsonBody(request)));
 }catch(error){return apiError(error);}
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: "forbidden" }, { status: 403 });
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    return Response.json(await createProject(db(), staff, await jsonBody(request)), { status: 201 });
  } catch (error) { return apiError(error); }
}
