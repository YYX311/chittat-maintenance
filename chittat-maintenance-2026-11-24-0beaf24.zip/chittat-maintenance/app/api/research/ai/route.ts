import { getStaff } from '../../../../lib/access';
import { db,transaction } from '../../../../lib/db';
import { jsonBody,sameOrigin } from '../../../../lib/http';
import { requireResearchAdmin } from '../../../../lib/research-service';
import { reserveResearchAi,finishResearchAi,validateAiResult,researchModel,dailyLimit } from '../../../../lib/research-ai';
import { researchAiAvailable,invokeResearchAi } from '../../../../lib/research-provider';
export const runtime='nodejs';
const headers={'Cache-Control':'private, no-store'};
export async function GET(request:Request){
  try {
  const staff=await getStaff(request);
  if(!staff)return Response.json({error:'unauthorized'},{status:401,headers});
  try{requireResearchAdmin(staff);}catch{return Response.json({error:'forbidden'},{status:403,headers});}
  const row=(await db().query("SELECT attempts FROM research_ai_usage WHERE day=(now() AT TIME ZONE 'UTC')::date")).rows[0];
  return Response.json({available:researchAiAvailable(),model:researchModel,dailyLimit,attempts:row?.attempts||0},{headers});
  } catch { return Response.json({error:'service-unavailable'},{status:503,headers}); }
}
export async function POST(request:Request){
  if(!sameOrigin(request))return Response.json({error:'forbidden'},{status:403,headers});
  let reservation:Awaited<ReturnType<typeof reserveResearchAi>>|undefined,id='';
  try{
    const staff=await getStaff(request);
    if(!staff)return Response.json({error:'unauthorized'},{status:401,headers});
    requireResearchAdmin(staff);
    if(!researchAiAvailable())throw new Error('ai-not-configured');
    const body=await jsonBody(request);
    if(typeof body.observationId!=='string'||body.observationId.length>100)throw new Error('invalid-observation');
    id=body.observationId;
    reservation=await transaction(client=>reserveResearchAi(client,staff,id,body.deidentifiedConfirmed));
    if('cached' in reservation)return Response.json({result:reservation.cached,cached:true},{headers});
    const result=validateAiResult(await invokeResearchAi(reservation.evidence!),reservation.evidence!);
    await finishResearchAi(db(),id,reservation.attempt!,result);
    return Response.json({result,cached:false},{headers});
  }catch(error){
    const raw=error instanceof Error?error.message:'';
    const known=['forbidden','not-found','invalid-observation','invalid-ai-consent','invalid-study-not-collecting','ai-not-configured','ai-running','ai-daily-limit','ai-invalid-result','ai-timeout'];
    const code=known.includes(raw)?raw:'ai-unavailable';
    if(reservation&&'attempt' in reservation&&reservation.attempt){
      try{await finishResearchAi(db(),id,reservation.attempt,null,code);}catch{console.error('Research AI failure could not be persisted');}
    }
    return Response.json({error:code},{status:code==='forbidden'?403:code==='ai-daily-limit'?429:code==='ai-running'?409:code.startsWith('invalid')?400:503,headers});
  }
}
