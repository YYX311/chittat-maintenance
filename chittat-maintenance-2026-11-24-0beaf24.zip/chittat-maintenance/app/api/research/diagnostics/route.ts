import {getStaff} from '../../../../lib/access';
import {db,transaction} from '../../../../lib/db';
import {sameOrigin,jsonBody,apiError} from '../../../../lib/http';
import {requireResearchAdmin} from '../../../../lib/research-service';
import {maintenanceOverview,reserveDiagnosticAi,finishDiagnosticAi} from '../../../../lib/maintenance-service';
import {researchAiAvailable,invokeResearchAi} from '../../../../lib/research-provider';
import {validateAiResult} from '../../../../lib/research-ai';
import {isManagementModel,managementPrompt,validateManagementReport} from '../../../../lib/management-analysis';
import {fieldRange} from '../../../../lib/research-field';
const headers={'Cache-Control':'private, no-store','X-Robots-Tag':'noindex, nofollow'};
export const runtime='nodejs';
export async function GET(request:Request){try{const staff=await getStaff(request);if(!staff)return Response.json({error:'unauthorized'},{status:401,headers});
  return Response.json(await maintenanceOverview(db(),staff,new URL(request.url).searchParams.get('study')||''),{headers});
}catch(e){return apiError(e);}}
export async function POST(request:Request){
  if(!sameOrigin(request))return Response.json({error:'forbidden'},{status:403,headers});
  let run:Awaited<ReturnType<typeof reserveDiagnosticAi>>|undefined;
  try {const staff=await getStaff(request);if(!staff)return Response.json({error:'unauthorized'},{status:401,headers});requireResearchAdmin(staff);
    const body=await jsonBody(request);if(typeof body.studyId!=='string'||body.studyId.length>100)throw new Error('invalid-study');
    if(body.signalKey!==undefined&&(typeof body.signalKey!=='string'||!['server_error','network','conflict','rejected','slow','returns'].includes(body.signalKey)))throw new Error('invalid-signal');
    if(body.managementModel!==undefined&&(!isManagementModel(body.managementModel)||body.signalKey!==undefined))throw new Error('invalid-management-model');
    const scope=body.fieldScope;
    if(scope!==undefined&&(!scope||typeof scope.from!=='string'||typeof scope.to!=='string'||body.signalKey!==undefined||body.managementModel!==undefined))throw Error('invalid-field-range');
    const range=scope?fieldRange(scope.from,scope.to):undefined;
    if(!researchAiAvailable())throw new Error('ai-not-configured');
    run=await transaction(db=>reserveDiagnosticAi(db,staff,body.studyId,body.signalKey,body.managementModel,range));
    if('cached' in run)return Response.json({result:run.cached,evidence:run.evidence,cached:true},{headers});
    const report=Boolean(range||body.managementModel);
    const raw=await invokeResearchAi(run.evidence,report?managementPrompt:undefined);
    const result=report?validateManagementReport(raw,run.factIds||[]):validateAiResult(raw,run.evidence);
    await finishDiagnosticAi(db(),run.id!,run.attempt!,result);return Response.json({result,evidence:run.evidence,cached:false},{headers});
  }catch(e){if(run&&'id' in run)try{await finishDiagnosticAi(db(),run.id!,run.attempt!,null);}catch{}
    const message=e instanceof Error?e.message:'';
    const known=['ai-not-configured','ai-daily-limit','ai-running','ai-timeout','ai-invalid-result','ai-unavailable','ai-provider-quota'];
    if(known.includes(message))return Response.json({error:message},{status:message==='ai-daily-limit'?429:503,headers});
    return apiError(e);
  }
}
