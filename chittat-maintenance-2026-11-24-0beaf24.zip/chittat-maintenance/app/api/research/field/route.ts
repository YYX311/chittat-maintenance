import { getStaff } from "../../../../lib/access";
import { db, transaction } from "../../../../lib/db";
import { apiError, jsonBody, sameOrigin } from "../../../../lib/http";
import { fieldStudyConfig, fieldStudyMutation } from "../../../../lib/field-study-service";

export const runtime = "nodejs";
const headers = { "Cache-Control":"private, no-store" };

export async function GET(request: Request) {
  try {
    const staff=await getStaff(request);
    if (!staff) return Response.json({error:"unauthorized"},{status:401,headers});
    const caseId=new URL(request.url).searchParams.get("case");
    return Response.json(await fieldStudyConfig(db(),staff,caseId),{headers});
  } catch (error) { return apiError(error); }
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({error:"forbidden"},{status:403,headers});
  try {
    const staff=await getStaff(request);
    if (!staff) return Response.json({error:"unauthorized"},{status:401,headers});
    const body=await jsonBody(request);
    return Response.json(await transaction(client=>fieldStudyMutation(client,staff,body)),{headers});
  } catch (error) { return apiError(error); }
}
