import {getStaff} from '../../../../lib/access';
import {db,transaction} from '../../../../lib/db';
import {requireResearchAdmin} from '../../../../lib/research-service';
import {apiError,jsonBody,sameOrigin} from '../../../../lib/http';
import {fieldRange,fieldCsv} from '../../../../lib/research-field';
import {loadRecovery,saveRecovery} from '../../../../lib/recovery-service';
import {readRecoveryDocument} from '../../../../lib/recovery-document';
export const runtime='nodejs';
const headers={'Cache-Control':'private, no-store'};
export async function GET(request:Request){try{
  const staff=await getStaff(request);if(!staff)return Response.json({error:'unauthorized'},{status:401,headers});
  requireResearchAdmin(staff);const q=new URL(request.url).searchParams;
  if (q.get('view') === 'interface') {
    const html = await readRecoveryDocument();
    const head = '<head><meta name="recovery-mode" content="system">' +
      '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; form-action \'none\'; base-uri \'none\'">';
    return new Response(html.replace('<head>', head), {
      headers: {...headers, 'Content-Type':'text/html; charset=utf-8'},
    });
  }
  const range=fieldRange(q.get('from')??undefined,q.get('to')??undefined);
  const role=q.get('role')||'worker';if(!['worker','office'].includes(role))throw Error('invalid-recovery-role');
  const data=await loadRecovery(db(),q.get('study')||'',range.start,range.end,role);
  if(q.has('csv')){
    if(data.partial)throw Error('invalid-export-window');
    return new Response(fieldCsv(['episode','participant','role','variant','at','focused','resolved','submitted','left','offline','seconds','activeSeconds','frustration','skipped'],data.episodes),
      {headers:{...headers,'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="phone-recovery-${range.from}-${range.to}.csv"`}});
  }
  const enabled=(await db().query("SELECT enabled FROM research_recovery_settings WHERE study_id=$1",[q.get("study")||""])).rows[0]?.enabled===true;
  return Response.json({...data,enabled},{headers});
}catch(error){return apiError(error);}}
export async function POST(request:Request){try{
  if(!sameOrigin(request))throw Error('forbidden');
  const staff=await getStaff(request);if(!staff)return Response.json({error:'unauthorized'},{status:401,headers});
  const body=await jsonBody(request);
  if(body.action==='configure'){
    requireResearchAdmin(staff);
    if(typeof body.studyId!=='string'||typeof body.enabled!=='boolean')throw Error('invalid-recovery-setting');
    const result=await db().query(`INSERT INTO research_recovery_settings(study_id,enabled,updated_by)
      SELECT id,$2,$3 FROM research_studies WHERE id=$1 AND status='collecting'
      ON CONFLICT(study_id) DO UPDATE SET enabled=$2,updated_by=$3,updated_at=now() RETURNING study_id`,[body.studyId,body.enabled,staff.userId]);
    if(!result.rows.length)throw Error('invalid-study-not-collecting');
    return Response.json({ok:true},{headers});
  }
  return Response.json(await transaction(client=>saveRecovery(client,staff,body)),{headers});
}catch(error){return apiError(error);}}
