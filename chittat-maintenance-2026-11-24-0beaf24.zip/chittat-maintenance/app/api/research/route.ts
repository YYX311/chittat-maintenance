import { getStaff } from '../../../lib/access';
import { db, transaction } from '../../../lib/db';
import { apiError, jsonBody, sameOrigin } from '../../../lib/http';
import { requireResearchAdmin, researchOverview, researchDetail, researchMutation, researchExport,researchRuntimeExport } from '../../../lib/research-service';
import {loadResearchHandoffs} from "../../../lib/research-handoffs";
import {fieldCsv,fieldRange,loadFieldReport} from "../../../lib/research-field";
import {summarizeContext} from "../../../lib/human-factors";
import {contextRows} from '../../../lib/human-factors-service';
import {fieldExports,type FieldExport} from '../../../lib/field-export-catalog';
import {fieldAssistantSnapshot} from '../../../lib/field-assistant';
import {researchAiAvailable} from '../../../lib/research-provider';
import {researchModelLabel} from '../../../lib/research-ai';
export const runtime='nodejs';
const headers={ 'Cache-Control':'private, no-store', 'X-Robots-Tag':'noindex, nofollow' };
export async function GET(request: Request) {
  try {
    const staff=await getStaff(request);
    if(!staff) return Response.json({error:'unauthorized'},{status:401,headers});
    requireResearchAdmin(staff);
    const q=new URL(request.url).searchParams;
    if(q.has('field')) {
      const studyId=q.get('study')||'';
      const exists=await db().query('SELECT id FROM research_studies WHERE id=$1',[studyId]);
      if(!exists.rows.length) throw Error('not-found');
      const data=await loadFieldReport(db(),studyId,fieldRange(q.get('from')??undefined,q.get('to')??undefined));
      const preview=q.has('preview');
      const kind=q.get(preview?'preview':'csv');
      if(kind!==null) {
        if(!Object.hasOwn(fieldExports,kind)) throw Error('invalid-export');
        const tables={
          cases: {partial:data.handoffs.truncated,
            rows:data.handoffs.rows.map(row=>({...row,returns:row.reasons.length,reasons:row.reasons.join('|')}))},
          events:{partial:data.truncated,rows:data.events},
          tasks:{partial:data.trial.partial,rows:data.trial.rows},
          workload:{partial:data.trial.workloadPartial,rows:data.trial.workload},
          context:{partial:data.context.partial,
            rows:data.context.rows.map(row=>({...row,factors:row.factors.join('|')}))},
        };
        const table=tables[kind as FieldExport];
        const columns=fieldExports[kind as FieldExport].columns.map(([key])=>key);
        if(table.partial) throw Error('invalid-export-window');
        if(preview)return Response.json({total:table.rows.length,rows:table.rows.slice(0,5).map(row=>
          Object.fromEntries(columns.map(key=>[key,(row as Record<string,unknown>)[key]??null])))},{headers});
        return new Response(fieldCsv(columns,table.rows),{headers:{...headers,'Content-Type':'text/csv; charset=utf-8',
          'Content-Disposition':`attachment; filename="research-${kind}-${data.from}-${data.to}.csv"`}});
      }
      const {events: _events,context,trial,...report}=data;
      const workloadSummary=["baseline","improved"].map(label=>{
        const rows=trial.workload.filter(row=>row.role==="worker"&&row.period.startsWith(label==="baseline"?"A":"B"));
        return {label,n:rows.length,mean:rows.length?rows.reduce((total,row)=>total+row.raw_tlx,0)/rows.length:null};
      });
      return Response.json({...report,workloadSummary:trial.workloadPartial?null:workloadSummary,trial:{enabled:trial.enabled,roster:trial.roster,partial:trial.partial,tasks:trial.rows.length},
        contextSummary:summarizeContext(context.rows,context.partial),
        assistant:{...fieldAssistantSnapshot(data),available:researchAiAvailable(),model:researchModelLabel}}, {headers});
    }
    if(q.get('export')) {
      const studyId=q.get('study')||'';
      const [improvements,rows,runtime]=await Promise.all([db().query('SELECT id,metric,applied_on::text AS applied_on,created_at FROM research_improvements WHERE study_id=$1 ORDER BY created_at,id',[studyId]),researchExport(db(),staff,studyId),researchRuntimeExport(db(),staff,studyId)]);
      const [context,handoffs]=await Promise.all([contextRows(db(),studyId),loadResearchHandoffs(db(),studyId)]);
      return Response.json({schemaVersion:4,handoffs:{...handoffs,rows:handoffs.rows.map(({id,...row})=>row)},improvements:improvements.rows,rows,runtime,context:{...context,rows:context.rows.map(({research_case_id,...row})=>row)}},{headers:{...headers,'Content-Disposition':'attachment; filename="research-observations.json"'}});
    }
    if(q.get('id')) return Response.json(await researchDetail(db(),staff,q.get('id')!),{headers});
    return Response.json(await researchOverview(db(),staff,q.get('study'),Number(q.get('page')||1)),{headers});
  } catch(error) { const response=apiError(error); Object.entries(headers).forEach(([k,v])=>response.headers.set(k,v)); return response; }
}
export async function POST(request: Request) {
  if(!sameOrigin(request)) return Response.json({error:'forbidden'},{status:403,headers});
  try {
    const staff=await getStaff(request);
    if(!staff) return Response.json({error:'unauthorized'},{status:401,headers});
    requireResearchAdmin(staff);
    const body=await jsonBody(request);
    return Response.json(await transaction(client=>researchMutation(client,staff,body)),{headers});
  } catch(error) { const response=apiError(error); Object.entries(headers).forEach(([k,v])=>response.headers.set(k,v)); return response; }
}
