import {getStaff} from '../../../../lib/access';
import {transaction} from '../../../../lib/db';
import {jsonBody,sameOrigin,apiError} from '../../../../lib/http';
import {storeRuntime} from '../../../../lib/runtime-observation';
export const runtime='nodejs';
export async function POST(request:Request){
  if(!sameOrigin(request))return Response.json({error:'forbidden'},{status:403});
  try {const staff=await getStaff(request);if(!staff)return Response.json({error:'unauthorized'},{status:401});
    const body=await jsonBody(request);return Response.json(await transaction(db=>storeRuntime(db,staff,body)),{headers:{'Cache-Control':'no-store'}});
  }catch(error){return apiError(error);}
}
