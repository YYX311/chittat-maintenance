import { getStaff } from '../../../../../lib/access';
import { db } from '../../../../../lib/db';
import { apiError } from '../../../../../lib/http';
import { loadHandoverDataset } from '../../../../../lib/handover-dataset';
import { requireResearchAdmin } from '../../../../../lib/research-service';

export const runtime = 'nodejs';
const headers = { 'Cache-Control': 'private, no-store' };

export async function GET(request: Request) {
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: 'unauthorized' }, { status: 401, headers });
    requireResearchAdmin(staff);
    const params = new URL(request.url).searchParams;
    const excludeTest = params.get('excludeTest') === '1';
    return Response.json(await loadHandoverDataset(db(), params.get('from') ?? '', params.get('to') ?? '', { excludeTest }), { headers });
  } catch (error) {
    return apiError(error);
  }
}
