import { getStaff } from '../../../../../lib/access';
import { db, transaction } from '../../../../../lib/db';
import { apiError, jsonBody, sameOrigin } from '../../../../../lib/http';
import { mutateProbe, probeConfig } from '../../../../../lib/research-probe';

export const runtime = 'nodejs';
const headers = { 'Cache-Control': 'private, no-store' };
const unauthorized = () => Response.json({ error: 'unauthorized' }, { status: 401, headers });

export async function GET(request: Request) {
  try {
    const staff = await getStaff(request);
    if (!staff) return unauthorized();
    return Response.json(await probeConfig(db(), staff), { headers });
  } catch (error) { return apiError(error); }
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return Response.json({ error: 'forbidden' }, { status: 403, headers });
  try {
    const staff = await getStaff(request);
    if (!staff) return unauthorized();
    const body = await jsonBody(request);
    return Response.json(await transaction(client => mutateProbe(client, staff, body)), { headers });
  } catch (error) { return apiError(error); }
}
