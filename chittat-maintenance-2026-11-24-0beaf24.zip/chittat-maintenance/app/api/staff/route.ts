import { getStaff, listStaff } from "../../../lib/access";
import { apiError } from "../../../lib/http";
import { db } from "../../../lib/db";

export const runtime = "nodejs";

export async function GET(request: Request) {
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    return Response.json(await listStaff(db(), staff), { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) { return apiError(error); }
}
