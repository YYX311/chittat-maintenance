import { getStaff } from "../../../../lib/access";
import { db, transaction } from "../../../../lib/db";
import { apiError, jsonBody, sameOrigin } from "../../../../lib/http";
import { updateTrash } from "../../../../lib/trash-service";
import { drainObjectDeletions } from "../../../../lib/object-storage";
export const runtime="nodejs";
export async function POST(request:Request,{params}:{params:Promise<{action:string}>}) {
  if(!sameOrigin(request)) return Response.json({error:"forbidden"},{status:403});
  try {
    const staff=await getStaff(request);
    if(!staff) return Response.json({error:"unauthorized"},{status:401});
    const {action}=await params, body=await jsonBody(request);
    const result=await transaction(client=>updateTrash(client,staff,body.items,action));
    // The durable queue survives storage outages; the next request retries cleanup.
    await drainObjectDeletions(db()).catch(()=>{});
    return Response.json(result);
  }catch(error){return apiError(error);}
}
