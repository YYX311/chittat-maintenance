import { getStaff } from "../../../lib/access";
import { listCases, workspaceFingerprint } from "../../../lib/case-service";
import { db } from "../../../lib/db";
import { apiError } from "../../../lib/http";
import { listProjects } from "../../../lib/project-service";

export const runtime = "nodejs";

export async function GET(request: Request) {
  try {
    const staff = await getStaff(request);
    if (!staff) return Response.json({ error: "unauthorized" }, { status: 401 });
    const client = db();
    const etag = await workspaceFingerprint(client, staff);
    if (request.headers.get("if-none-match") === etag) {
      return new Response(null, { status: 304, headers: { ETag: etag, "Cache-Control": "private, no-cache" } });
    }
    const url = new URL(request.url);
    const full = url.searchParams.get("full") === "1";
    const records = await listCases(client, staff, { compact: !full });
    const projects = staff.role === "worker" ? [] : await listProjects(client);
    return Response.json({ version: 4, records, sheets: [], sampleRows: [], parts: [],
      projects, projectRegistry: projects, counters: { worker: 0, office: 0 } },
    { headers: { ETag: etag, "Cache-Control": "private, no-cache" } });
  } catch (error) { return apiError(error); }
}
