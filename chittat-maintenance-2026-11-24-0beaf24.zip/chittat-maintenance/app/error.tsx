'use client';

import Startup from './Startup';

export default function ErrorPage() {
  return <Startup failed />;
}
