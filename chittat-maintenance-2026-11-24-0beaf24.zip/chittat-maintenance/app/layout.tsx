import type { Metadata } from "next";
import AppearancePreview from "./AppearancePreview";
import "../src/styles.css";

export const metadata: Metadata = {
  title: "高陞集团机电维修",
  description: "机电维修现场填报及维修部工作台",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-HK" suppressHydrationWarning>
      <body suppressHydrationWarning>
        <AppearancePreview />
        {children}
      </body>
    </html>
  );
}
