import LegacyClient from "./LegacyClient";

export default function Page() {
  return <LegacyClient />;
}
