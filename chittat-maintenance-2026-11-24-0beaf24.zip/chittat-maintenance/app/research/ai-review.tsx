'use client';
import { useState } from 'react';
import { sessionFetch } from '../../src/session-fetch';
type Factor={cause:string;quote:string;explanation:string};
export type Result=Factor|{factors:Factor[];uncertainties:string[]};
export type Review={id:string;observation_id:string;verdict:string;correction:string;created_at:string};
const causes:Record<string,string>={missing_information:'資料缺漏',changed_requirement:'要求變更',technical_failure:'技術故障',other:'其他',unknown:'證據不足'};
export default function AiReview({id,initial,model,promptVersion,reviews=[],onReview,readOnly=false}:{id:string;initial?:Result|null;model?:string;promptVersion?:string;reviews?:Review[];onReview?:(body:Record<string,unknown>)=>Promise<void>;readOnly?:boolean}){
  const [reviewBusy,setReviewBusy]=useState(false),[reviewError,setReviewError]=useState('');
  const [result,setResult]=useState(initial),[busy,setBusy]=useState(false),[error,setError]=useState('');
  async function analyze(){
    if(!window.confirm('確認此觀察依據已去除姓名、電話、住址，並獲准交由 Cloudflare AI 分析？只傳送此段依據文字，不傳人工分類、客戶資料或照片。'))return;
    setBusy(true);setError('');
    try{
      const response=await sessionFetch('/api/research/ai',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({observationId:id,deidentifiedConfirmed:true})});
      const data=await response.json();
      if(!response.ok)throw new Error(data.error);
      setResult(data.result);
    }catch(e){const code=(e as Error).message;setError(({ 'ai-not-configured':'此環境尚未啟用 AI。請使用已完成配置的雲端版本。','ai-daily-limit':'今日研究 AI 已達 100 次上限，香港時間明早 08:00 重設。','ai-running':'此份證據正在分析，請稍後重新開啟案件。','ai-timeout':'AI 等待超時，可稍後重試；失敗請求也計入限額。','ai-invalid-result':'模型輸出未通過格式或引文核查，未採用此判斷。','forbidden':'此帳號沒有研究權限。','unauthorized':'登入已過期，請重新登入。'} as Record<string,string>)[code]||'AI 暫時不可用或供應商額度已用完。資料仍已保存，可稍後重試。');}
    finally{setBusy(false);}
  }
  const factors=result?('factors' in result?result.factors:[result]):[];
  return <div className="research-ai">
    <p><small>只分析已脫敏的觀察文字。</small></p>
    <button type="button" disabled={busy||readOnly} onClick={analyze}>{busy?'AI 正在分析…':result?'重新讀取已保存的 AI 結果':'用 Qwen3 分析此份證據'}</button>
    {error&&<p role="alert">{error}</p>}
    {result&&<div><h4>可能因素 · {reviews.length?'已有人工核查':'待人工核查'}</h4>
      {factors.map((f,i)=><article key={i}><strong>{i+1}. {causes[f.cause]||f.cause}</strong><blockquote>{f.quote||'證據不足，沒有可引用內容。'}</blockquote><p>{f.explanation}</p></article>)}
      {'uncertainties' in result&&!!result.uncertainties.length&&<><h4>仍需核實</h4><ul>{result.uncertainties.map((u,i)=><li key={i}>{u}</li>)}</ul></>}
      <p><small>模型：{model||'Qwen'} · 提示版本：{promptVersion||'rework-factors-v2'} · 待人工核實</small></p>
      {onReview&&!readOnly&&<form onSubmit={async e=>{e.preventDefault();const data=new FormData(e.currentTarget);setReviewBusy(true);setReviewError('');try{await onReview({action:'review-ai',observationId:id,verdict:data.get('verdict'),correction:data.get('correction')});}catch{setReviewError('核查未能儲存，請重試。');}finally{setReviewBusy(false);}}}>
        <h4>人工核查</h4><label>核查判斷<select name="verdict"><option value="agree">認可</option><option value="partial">部分認可</option><option value="disagree">不認可</option></select></label>
        <label>核查理由與修正<textarea name="correction" required minLength={5} maxLength={2000} placeholder="說明哪個因素有依據、哪個不成立，以及還缺哪些證據。"/></label>
        <button disabled={reviewBusy}>{reviewBusy?'儲存中…':'儲存人工核查'}</button>{reviewError&&<p role="alert">{reviewError}</p>}
      </form>}
      {reviews.map(r=><blockquote key={r.id}><strong>{{agree:'認可',partial:'部分認可',disagree:'不認可'}[r.verdict]||r.verdict}</strong> · {new Date(r.created_at).toLocaleString('zh-HK')}<p>{r.correction}</p></blockquote>)}
    </div>}
  </div>;
}
