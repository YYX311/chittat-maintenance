'use client';
import {useState} from 'react';
import {contextFactors,contextStages,contextBrief,type ContextSummary,type ContextFactor} from '../../lib/human-factors';
import s from './research.module.css';

type Props={data:ContextSummary;readOnly:boolean;busy:boolean;onSave:(body:Record<string,unknown>)=>Promise<boolean>};
export default function ContextPanel({data,readOnly,busy,onSave}:Props){
  const [adding,setAdding]=useState(false),[source,setSource]=useState('observed'),[selected,setSelected]=useState<ContextFactor[]>([]),[focus,setFocus]=useState<ContextFactor|null>(null),[notice,setNotice]=useState('');
  const ranked=data.counts.filter(f=>f.count>0).sort((a,b)=>b.count-a.count);
  const chosen=data.counts.find(f=>f.id===focus);
  function toggle(id:ContextFactor){setSelected(old=>id==='unknown'?['unknown']:old.includes(id)?old.filter(v=>v!==id):[...old.filter(v=>v!=='unknown'),id]);}
  function download(){if(!focus)return;const url=URL.createObjectURL(new Blob([contextBrief(data,focus)],{type:'text/markdown;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=`workflow-${focus}-proposal.md`;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);setNotice('建議已交給瀏覽器下載；尚未實施任何改動。');}
  return <section className={s.card} aria-label="現場因素核查">
    <div className={s.header}><div><h2>{adding?'記錄當時情況':'操作不順，先看當時情況'}</h2><p className={s.muted}>人工核對情境，避免把網絡、打斷或負擔誤判為能力問題。</p></div>{!adding&&!readOnly&&<button onClick={()=>{setAdding(true);setFocus(null);setNotice('');}}>新增情境核查</button>}</div>
    {notice&&<p role="status" className={s.notice}>{notice}</p>}
    {adding?<form onSubmit={async e=>{e.preventDefault();const v=Object.fromEntries(new FormData(e.currentTarget));const saved=await onSave({action:'context-review',entryNo:v.entryNo,role:v.role,stage:v.stage,source,factors:selected,load:source==='self_report'&&v.load!==''?Number(v.load):null,safety:v.safety,contextPermission:v.permission==='on',consentReference:v.consentReference});if(saved){setAdding(false);setSelected([]);}}}>
      <div className={s.grid}>
        <label>已加入研究的案件編號<input name="entryNo" required maxLength={80} placeholder="CT-MNA-0001"/></label>
        <label>哪一端<select name="role"><option value="worker">維修師傅端</option><option value="office">辦公室端</option></select></label>
        <label>發生在哪一步<select name="stage">{contextStages.map(v=><option key={v.id} value={v.id}>{v.label}</option>)}</select></label>
        <label>資料來源<select aria-label="資料來源" name="source" value={source} onChange={e=>{setSource(e.target.value);setSelected([]);}}><option value="observed">研究者現場觀察</option><option value="self_report">當事人自願回報（管理員代錄）</option></select></label>
      </div>
      <fieldset className={s.contextChoices}><legend>當時有哪些情況？可多選</legend>{contextFactors.filter(f=>source==='self_report'||!['fatigue','time_pressure'].includes(f.id)).map(f=><label className={s.check} key={f.id}><input type="checkbox" checked={selected.includes(f.id)} onChange={()=>toggle(f.id)}/>{f.label}</label>)}</fieldset>
      <div className={s.grid}>
        {source==='self_report'&&<label>本人覺得填寫有多費力？（選填）<select aria-label="本人覺得填寫有多費力？（選填）" name="load" defaultValue=""><option value="">未詢問／不回答</option><option value="1">1 · 很輕鬆</option><option value="2">2 · 較輕鬆</option><option value="3">3 · 一般</option><option value="4">4 · 較費力</option><option value="5">5 · 很費力</option></select><small>自訂單題負擔回報，不是疲勞診斷或 NASA-TLX。</small></label>}
        <label>是否有人提出安全方面需要跟進？<select name="safety"><option value="not_asked">未詢問／不清楚</option><option value="reported">有提出，需要現場負責人跟進</option><option value="none_reported">已詢問，本次未提出</option></select></label>
        <label>情境資料同意記錄編號<input name="consentReference" required maxLength={200} placeholder="填寫已取得的同意記錄編號"/></label>
      </div>
      <label className={s.check}><input name="permission" type="checkbox" required/>已取得此類情境資料的研究同意；已說明管理員可查看、彙總可供 AI 分析，並可拒絕回報。</label>
      <p className={s.muted}>這裡不會自動通知現場負責人；即時安全問題須沿用現場通報程序。</p>
      <button disabled={busy||!selected.length}>保存情境核查</button><button type="button" className={s.secondary} disabled={busy} onClick={()=>setAdding(false)}>取消</button>
    </form>:<>
      <div className={s.contextMetrics}><div><strong>{data.cases}</strong><span>宗有情境資料</span></div><div><strong>{data.reported}</strong><span>組本人回報</span></div><div><strong>{data.observed}</strong><span>組現場觀察</span></div></div>
      {data.followup>0&&<p className={s.error}>有 {data.followup} 組最新記錄提出安全跟進。請聯絡現場負責人；這不是即時警報或風險評分。</p>}
      {data.partial&&<p className={s.notice}>只分析最近部分核查，數量不完整。</p>}
      {chosen?<article className={s.contextAction}><button className={s.secondary} onClick={()=>setFocus(null)}>返回因素分布</button><h3>{chosen.label}</h3><p>人工記錄 {chosen.count} 組；尚未證明是問題原因。</p><button onClick={download}>下載試行建議</button></article>:ranked.length?<>
        <h3>有哪些因素被記錄？</h3><div className={s.factorBars}>{ranked.map(f=><button key={f.id} className={s.factorBar} onClick={()=>setFocus(f.id)}><span><b>{f.label}</b><small>{f.group} · {f.count} / {data.total} 組</small></span><span className={s.barTrack} aria-hidden="true"><i style={{width:`${f.count/data.total*100}%`}}/></span><span className={s.muted}>查看核查資料 →</span></button>)}</div><p className={s.muted}>同一案件、角色、步驟只取最新核查；因素可重疊，不代表原因或人數。</p>
      </>:<div className={s.contextEmpty}><h3>尚未核查現場因素</h3><p>系統記錄能指出哪一步卡住，當時原因需要人員補充。</p><p className={s.muted}>不用猜原因；不清楚時選「尚未查明」。</p></div>}
    </>}
  </section>;
}
