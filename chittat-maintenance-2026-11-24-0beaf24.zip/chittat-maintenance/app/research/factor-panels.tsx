'use client';
import {useState} from 'react';
import styles from './research.module.css';
type Process={submissions:number;returns:number;elapsedMinutes:number|null;startId:string|null;endId:string|null;returnIds:string[];truncated:boolean};
type Observation={worker_minutes:string|null;office_minutes:string|null;quality_errors?:number|null;measurement_method?:string};
export function ProcessPanel({process,difficulty,observation}:{process:Process;difficulty:string;observation?:Observation}){
  return <section className={styles.evidencePanel} aria-label="案件多因素證據">
    <h3>案件指標</h3>
    <div className={styles.factorGrid}>
      <article><span className={styles.source}>系統記錄 · 納入後</span><h4>提交與退回</h4><strong>{process.submissions} 次提交 · {process.returns} 次退回</strong>{process.returnIds.map((id,i)=><a key={id} href={`#event-${id}`}>查看第 {i+1} 次退回 ↗ </a>)}</article>
      <article><span className={styles.source}>系統計算 · 經過時間</span><h4>首次提交至首次確認</h4><strong>{process.elapsedMinutes===null?'尚無完整起止事件':`${process.elapsedMinutes.toFixed(1)} 分鐘`}</strong><p>經過時間，不是人工時間。</p>{process.elapsedMinutes!==null&&<><a href={`#event-${process.startId}`}>起點 ↗</a>　<a href={`#event-${process.endId}`}>終點 ↗</a></>}</article>
      <article><span className={styles.source}>人工測量 · 最新觀察</span><h4>雙方人工時間</h4><strong>{observation?.worker_minutes!=null&&observation?.office_minutes!=null?`${(Number(observation.worker_minutes)+Number(observation.office_minutes)).toFixed(1)} 分鐘`:'尚未完整測量'}</strong><p>{observation?.measurement_method==='observed'?'觀察計時':observation?.measurement_method==='self_report'?'人員回報':'未記錄測量方式'}。</p></article>
      <article><span className={styles.source}>人工評定 · 案件背景</span><h4>難度與資料品質</h4><strong>難度：{{low:'低',medium:'中',high:'高'}[difficulty]||difficulty}</strong><p>獨立覆核錯漏：{observation?.quality_errors??'尚未評分'}。</p></article>
    </div>
  </section>;
}
export type Improvement={id:string;change_text:string;rationale:string;metric:string;applied_on:string};
export function Improvements({items,readOnly,busy,onSave}:{items:Improvement[];readOnly:boolean;busy:boolean;onSave:(body:Record<string,unknown>)=>Promise<void>}){
  const [editing,setEditing]=useState(false),[startCount,setStartCount]=useState(0);
  const adding=editing&&startCount===items.length;
  return <section className={styles.card} id="improvements"><div className={styles.header}><h2>{adding?'新增改進記錄':'改進記錄'}</h2>{!adding&&!readOnly&&<button disabled={busy} onClick={()=>{setStartCount(items.length);setEditing(true);}}>新增改進記錄</button>}</div>
    {adding?<form onSubmit={e=>{e.preventDefault();const values=Object.fromEntries(new FormData(e.currentTarget));void onSave({action:'improvement',...values});}}>
      <label>改進內容<textarea name="changeText" minLength={5} maxLength={1000} required placeholder="例：提交前核對設備型號。"/></label>
      <label>依據與預期效果<textarea name="rationale" minLength={5} maxLength={2000} required placeholder="例：型號缺漏造成補填；希望減少退回。"/></label>
      <div className={styles.grid}><label>實施日期<input name="appliedOn" type="date" required/></label><label>主要觀察指標<select name="metric"><option value="time">人工時間</option><option value="errors">資料錯漏數</option><option value="returns">退回次數</option></select></label></div>
      <button disabled={busy}>儲存改進記錄</button><button type="button" onClick={()=>setEditing(false)}>取消</button>
    </form>:!items.length?<p className={styles.muted}>尚未記錄改進。</p>:items.map(item=><article className={styles.change} key={item.id}><small>{item.applied_on.slice(0,10)} · {{time:'人工時間',errors:'資料錯漏',returns:'退回次數'}[item.metric]}</small><h3>{item.change_text}</h3><p>{item.rationale}</p></article>)}
  </section>;
}
export type Breakdown={phase:string;difficulty:string;measurement_method:string|null;cases:number;measured:number;timed:number;mean_minutes:string|null;mean_errors:string|null;quality_measured:number};
