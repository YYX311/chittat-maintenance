'use client';

import {useState} from 'react';
import type {FieldReport} from './field-study-dashboard';
import type {ManagementReport} from '../../lib/management-analysis';
import {sessionFetch} from '../../src/session-fetch';
import s from './research.module.css';
import layout from './field-study-dashboard.module.css';

export default function FieldAssistant({data,studyId,readOnly,loading,onRefresh}:{
  data:FieldReport;studyId:string;readOnly:boolean;loading:boolean;onRefresh:()=>void;
}){
  const snapshot=data.assistant;
  const [result,setResult]=useState<ManagementReport|null>(null);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');
  const issues=[
    ...data.usage.backlog.slice(0,3).map((row,i)=>({id:`signal_${i+1}`,
      next:row.action==='offline'||row.action==='slow_network'?'檢查斷線時草稿是否保留、重新連線後上傳能否繼續，並清楚顯示結果。':
        row.action==='rage_click'?'核查按鈕第一次點擊後是否即時顯示處理中，避免使用者反覆點擊。':
        row.action==='field_clear'?'查看欄位名稱、預設值及範例是否容易誤解；先用幾宗同類案件試填。':'在對應欄位旁加上必填條件和填寫範例。',
      verify:'改版前後用同類案件比較此訊號涉及的案件比例，並同時核對首次退回率。'})),
    ...data.handoffs.reasons.slice(0,2).map(row=>({id:`return_${row.code}`,next:`抽查「${row.label}」退回案件的時間線，確認首次提交有何資訊需要補上，再試行一項核對提示。`,
      verify:'比較同類案件中這項退回原因佔已覆核案件的比例。'})),
  ].flatMap(issue=>{const fact=snapshot.facts.find(f=>f.id===issue.id);return fact?[{...issue,fact}]:[];});
  const [selected,setSelected]=useState('');
  const issue=issues.find(item=>item.id===selected)??issues[0];
  const suggestion=issue?{finding:`${issue.fact.label}：${issue.fact.value}。需核查實際操作後再判斷原因。`,
    action:issue.next,verification:issue.verify,factIds:[issue.id]}:null;
  const status=readOnly?'此研究已停止收集。':snapshot.partial?'此期間記錄超出分析上限，請縮短日期範圍。':
    !snapshot.ready?'此期間尚未收到操作記錄。':!snapshot.available?'此環境尚未啟用 Qwen。下方仍可查看、切換和下載按記錄整理的改善建議。':'可先核查下列問題，再讓 Qwen 整理本期整體建議。';

  async function generate(){
    setBusy(true);setError('');
    try{
      const response=await sessionFetch('/api/research/diagnostics',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({studyId,fieldScope:{from:data.from,to:data.to}})});
      const body=await response.json();
      if(!response.ok)throw Error(body.error);
      if(body.evidence!==snapshot.evidence){setResult(null);onRefresh();setError('期間數據已更新，請核對後重新生成。');return;}
      setResult(body.result);
    }catch(error){
      const code=(error as Error).message;
      setError(code==='ai-daily-limit'||code==='ai-provider-quota'?'目前 AI 額度已用完。':
        code==='ai-running'?'同一份資料正在分析，請稍後再查看。':'暫時未能生成分析，請稍後再試。');
    }finally{setBusy(false);}
  }

  function download(report:ManagementReport,ai=true){
    const references=snapshot.facts.filter(fact=>report.factIds.includes(fact.id));
    const content=[`# ${ai?'AI':'規則'}改善建議 · ${data.from} 至 ${data.to}`,ai?`模型：${snapshot.model}`:'來源：預設核查規則，需人工驗證。',
      report.finding,`建議試行：${report.action}`,`如何驗證：${report.verification}`,
      "## 依據",...references.map(f=>`- ${f.label}：${f.value}`)].join('\n\n');
    const url=URL.createObjectURL(new Blob([content],{type:'text/markdown;charset=utf-8'}));
    const link=document.createElement('a');link.href=url;link.download=`workflow-${ai?'ai':'check'}-${data.from}-${data.to}.md`;
    link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
  }

  return <section className={s.card} aria-label="AI 改善助手">
    <h3>按記錄核查問題</h3>
    <p>{status}</p>
    {snapshot.ready&&suggestion&&issue?<div className={layout.assistantGrid}>
      <div role="group" aria-label="選擇要核查的問題" className={layout.issueList}>{issues.map(item=>
        <button key={item.id} className={s.secondary} aria-pressed={item.id===issue.id} onClick={()=>setSelected(item.id)}>
          <strong>{item.fact.label}</strong><span>{item.fact.value}</span></button>)}</div>
      <article className={layout.pointDetail} aria-label="規則改善建議">
        <h3>先核查這項操作</h3><p>{suggestion.finding}</p>
        <h4>可以怎樣改</h4><p>{suggestion.action}</p><h4>怎樣驗證</h4><p>{suggestion.verification}</p>
        <button className={s.secondary} onClick={()=>download(suggestion,false)}>下載核查建議</button>
      </article>
    </div>:snapshot.ready&&<p className={s.muted}>已收到 {data.usage.cases} 宗案件的操作，目前未見需要優先核查的摩擦或退回訊號。</p>}
    {snapshot.available&&snapshot.ready&&!readOnly&&
      <button disabled={busy||loading} onClick={generate}>{busy?'正在整理…':`用 ${snapshot.model} 生成改善建議`}</button>}
    {error&&<p className={s.error} role="alert">{error}</p>}
    {result&&<article aria-label="AI 改善建議">
      <h3>建議試行</h3><p>{result.action}</p>
      <h3>為甚麼值得試</h3><p>{result.finding}</p>
      <p><strong>如何驗證：</strong>{result.verification}</p>
      <p className={s.muted}>依據：{snapshot.facts.filter(f=>result.factIds.includes(f.id)).map(f=>`${f.label} ${f.value}`).join(' · ')}</p>
      <button className={s.secondary} onClick={()=>download(result)}>下載 AI 改善建議</button>
    </article>}
  </section>;
}
