'use client';

import {useEffect,useState} from 'react';
import {fieldExports,type FieldExport} from '../../lib/field-export-catalog';
import {sessionFetch} from '../../src/session-fetch';
import styles from './research.module.css';
import s from './field-study-dashboard.module.css';

type Preview = {total:number;rows:Record<string,string|number|boolean|null>[]};

export default function FieldExportPanel({query,from,to,onJson,busy}:{
  query:string;from:string;to:string;onJson:()=>void;busy:boolean;
}){
  const [kind,setKind]=useState<FieldExport>('tasks');
  const [all,setAll]=useState(false);
  const [retry,setRetry]=useState(0);
  const [downloadError,setDownloadError]=useState('');
  const [downloading,setDownloading]=useState(false);
  const [result,setResult]=useState<{key:string;data?:Preview;error?:string}>();
  const key=`${query}:${kind}:${retry}`;
  const {title,measures,columns,primary}=fieldExports[kind];
  const visible=columns.filter(([id])=>all||(primary as readonly string[]).includes(id));
  const data=result?.key===key?result.data:undefined;
  const error=result?.key===key?result.error:undefined;
  useEffect(()=>{
    const controller=new AbortController();
    sessionFetch(`/api/research?${query}&preview=${kind}`,{signal:AbortSignal.any([controller.signal,AbortSignal.timeout(30000)])})
      .then(async response=>{
        if(!response.ok)throw Error(response.status===400?'無法預覽。請縮短日期範圍。':'未能讀取資料表。');
        const data:Preview=await response.json();
        if(!controller.signal.aborted)setResult({key,data});
      }).catch(e=>{if(!controller.signal.aborted)setResult({key,error:e.message});});
    return ()=>controller.abort();
  },[query,kind,key]);

  async function download(){
    setDownloading(true);setDownloadError('');
    try{
      const response=await sessionFetch(`/api/research?${query}&csv=${kind}`);
      if(!response.ok)throw Error('下載未完成。請更新預覽或縮短日期範圍。');
      const url=URL.createObjectURL(await response.blob());
      const link=document.createElement('a');link.href=url;link.download=`research-${kind}-${from}-${to}.csv`;
      link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
    }catch(e){setDownloadError((e as Error).message);}
    finally{setDownloading(false);}
  }
  return <section className={s.card} aria-label="研究資料下載">
    <h2>預覽及下載資料表</h2>
    <label className={s.exportPicker}>選擇資料表<select value={kind} onChange={e=>{setKind(e.target.value as FieldExport);setAll(false);setDownloadError('');}}>
      {Object.entries(fieldExports).map(([id,table])=><option key={id} value={id}>{table.title}</option>)}
    </select></label>
    <p>{measures}</p>
    <p className={styles.muted}>{from} 至 {to} · {data?`共 ${data.total} 列，預覽前 ${data.rows.length} 列`:'按目前日期範圍'}</p>
    {error?<p role="alert">{error} <button onClick={()=>setRetry(n=>n+1)}>重試</button></p>:!data?<p role="status">正在讀取資料表…</p>:null}
    <div className={`${s.table} ${s.exportTable}`} tabIndex={0} role="region" aria-label={`${title}預覽`}>
      <table><thead><tr>{visible.map(([id,label])=><th scope="col" key={id}>{label}<small>{id}</small></th>)}</tr></thead>
        <tbody>{data?.rows.length?data.rows.map((row,i)=><tr key={i}>{visible.map(([id])=><td key={id}>
          {row[id]===null||row[id]===''?'—':id==='alias'&&String(row[id]).length>14?<abbr title={String(row[id])}>{String(row[id]).slice(0,14)}…</abbr>:String(row[id])}
        </td>)}</tr>):<tr><td colSpan={visible.length}>{data?'這段日期尚無記錄，CSV 仍會保留欄位名稱。':'目前顯示欄位。'}</td></tr>}</tbody></table>
    </div>
    <div className={styles.inlineActions}>
      <button disabled={!data||busy||downloading} onClick={download}>{downloading?'下載中…':`下載${title} CSV`}</button>
      <button className={styles.secondary} aria-pressed={all} onClick={()=>setAll(v=>!v)}>{all?'只看主要欄位':'查看全部欄位'}</button>
    </div>
    <p className={styles.muted}>CSV 包含所有欄位。空白表示缺資料；0 是實際記錄的數值。</p>
    {all&&<dl className={s.dictionary}>{columns.map(([id,label,meaning])=><div key={id}><dt><code>{id}</code> · {label}</dt>{meaning&&<dd>{meaning}</dd>}</div>)}</dl>}
    {downloadError&&<p role="alert" className={styles.error}>{downloadError}</p>}
    <p className={s.exportExtras}><a href="/field-study-analysis.R" download>下載 R 分析腳本</a>
      <button className={styles.secondary} disabled={busy} onClick={onJson}>匯出研究資料</button></p>
  </section>;
}
