'use client';

import { useEffect, useRef, useState, type FormEvent } from "react";
import { sessionFetch } from "../../src/session-fetch";
import type { loadFieldReport } from "../../lib/research-field";
import type { ContextSummary } from "../../lib/human-factors";
import type { fieldAssistantSnapshot } from "../../lib/field-assistant";
import { fieldEventLabels, fieldStudyFields, fieldStudyScreens, participantProfile } from "../../src/field-study-catalog";
import styles from "./research.module.css";
import s from "./field-study-dashboard.module.css";
import FieldExportPanel from "./field-export-panel";

type ReportData = Awaited<ReturnType<typeof loadFieldReport>>;
export type FieldReport = Omit<ReportData, "events" | "context" | "trial"> & {
  contextSummary: ContextSummary;
  trial: Pick<ReportData["trial"],"enabled"|"roster"|"partial"> & {tasks:number};
  assistant: ReturnType<typeof fieldAssistantSnapshot> & {available:boolean;model:string};
  workloadSummary: {label:string;n:number;mean:number|null}[]|null;
};
type Scope = { from: string; to: string };
const analysisSections = [
  { id:"context", label:"心理橋樑", path:"01 · X → M", question:"哪些操作卡住？員工怎樣回報？" },
  { id:"handoff", label:"多因素分析", path:"02 · M → Y", question:"提示開關、填單耗時與退回率有何差異？" },
  { id:"report", label:"改進建議", path:"03 · Y → 改版", question:"先改哪一步？怎樣驗證？" },
] as const;
export type AnalysisEntry = typeof analysisSections[number]["id"];

const hkToday = () => new Date(Date.now() + 8 * 3600000).toISOString().slice(0, 10);
const recent = (days: number): Scope => {
  const to = hkToday();
  return { from: new Date(Date.parse(to) - (days - 1) * 86400000).toISOString().slice(0, 10), to };
};
const roleLabel = { worker: "維修員", office: "維修部" };
const actionLabels: Record<string, string> = {
  ...fieldEventLabels,
  submit:"提交／補交", withdraw:"撤回提交", review:"開始覆核", return:"退回補充", confirm:"確認",
  save:"儲存資料", assets:"相片處理", documents:"生成文件", reopen:"重開編輯",
};
const outcomeLabels: Record<string,string> = {
  network:"連線失敗", conflict:"版本衝突", rejected:"未通過", server_error:"服務錯誤",
};
const minutes = (value: number | null) => value == null ? "—" : value < 1 ? "< 1 分鐘" : `${value.toFixed(1)} 分鐘`;
const activityTime = (value:number|null) => value===null ? "—" : value<1 ? `${Math.round(value*60)} 秒` : minutes(value);
const screenLabels: Record<string,string> = fieldStudyScreens;
const fieldLabels: Record<string,string> = fieldStudyFields;
function profileLabel(values:Record<string,string>,value:string|null) { return value ? values[value] : "待收集"; }

export function useFieldReport(studyId: string, revision: unknown, live = false) {
  const [scope, setScope] = useState(() => recent(28));
  const liveDay=useRef(hkToday());
  const [reload, setReload] = useState(0);
  const key = `${studyId}:${scope.from}:${scope.to}`;
  const [result, setResult] = useState<{ key: string; report?: FieldReport; error?: string; updatedAt?:number }>();
  const [busy, setBusy] = useState(false);
  const query = new URLSearchParams({ field: "1", study: studyId, ...scope }).toString();
  useEffect(()=>{
    if(!live||!studyId||busy)return;
    function refreshLive(){
      if(document.visibilityState!=="visible")return;
      const previous=liveDay.current,today=hkToday();
      liveDay.current=today;
      if(previous!==today)setScope(current=>current.to===previous?recent((Date.parse(current.to)-Date.parse(current.from))/86400000+1):current);
      setReload(value=>value+1);
    }
    const timer=setTimeout(refreshLive,20000);
    function visible(){refreshLive();}
    document.addEventListener("visibilitychange",visible);
    return ()=>{clearTimeout(timer);document.removeEventListener("visibilitychange",visible);};
  },[live,studyId,busy,reload]);
  useEffect(() => {
    if (!studyId) return;
    let current = true;
    setBusy(true);
    sessionFetch(`/api/research?${query}`).then(async response => {
      if (!response.ok) throw Error(response.status === 400 ? "請選擇有效日期，區間最多 93 天。" : "未能讀取研究數據。");
      const report = await response.json() as FieldReport;
      if (current) setResult({ key, report, updatedAt:Date.now() });
    }).catch(error => {
      if (current) setResult(previous=>({ key,report:previous?.key===key?previous.report:undefined,updatedAt:previous?.key===key?previous.updatedAt:undefined,
        error: error.message || "未能讀取研究數據。" }));
    }).finally(() => { if (current) setBusy(false); });
    return () => { current = false; };
  }, [studyId, key, query, revision, reload]);
  return {
    scope, setScope, report: result?.key === key ? result.report : undefined,
    error: result?.key === key ? result.error : undefined,
    busy, updatedAt:result?.key===key?result.updatedAt:undefined, refresh: () => setReload(n => n + 1), query,
  };
}

export function FieldScope({ scope, onChange, busy, onRefresh }: {
  scope: Scope; onChange: (next: Scope) => void; busy: boolean; onRefresh: () => void;
}) {
  function apply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    onChange({ from: String(form.get("from")), to: String(form.get("to")) });
  }
  return <section className={s.scope} aria-label="研究日期範圍">
    <form className={s.range} key={scope.from + scope.to} onSubmit={apply}>
      <label>開始日期<input type="date" name="from" required defaultValue={scope.from}/></label>
      <label>結束日期<input type="date" name="to" required defaultValue={scope.to}/></label>
      <button type="submit" disabled={busy}>套用日期</button>
    </form>
    <div className={s.shortcuts}>
      {[7,14,28].map(days => <button className={styles.secondary} type="button" key={days} onClick={()=>onChange(recent(days))}>近 {days} 天</button>)}
      <button className={styles.secondary} disabled={busy} type="button" onClick={onRefresh}>更新</button>
    </div>
  </section>;
}

export function FieldUsage({ data,updatedAt,onSetup }: { data: FieldReport;updatedAt?:number;onSetup:()=>void }) {
  const { usage, truncated } = data;
  const [showValues, setShowValues] = useState(false);
  const peak = Math.max(1, ...usage.daily.flatMap(d => [d.submitted, d.confirmed]));
  const cards = [
    ["已納入案件", data.enrolled, "研究全期"],
    ["有記錄的參與者", usage.participants, `${data.trial.roster.filter(p=>p.status==="joined").length} 人同意參與`],
    ["提交及補交", usage.submitted, "包括同一案件多次提交"],
    ["維修部確認", usage.confirmed, "伺服器成功確認"],
    ["提示後點擊前往", usage.assistant.exposed?`${usage.assistant.accepted} / ${usage.assistant.exposed}`:"—", "按看到提示的案件計算"],
    ["連線失敗記錄", usage.networkIssues, "瀏覽器已送達的紀錄"],
  ];
  if (truncated) return <p role="status" className={styles.notice}>此期間事件超過分析上限。請縮短日期範圍。</p>;
  return <>
    <div className={s.liveStatus}><span>{updatedAt?`最近更新 ${new Date(updatedAt).toLocaleTimeString("zh-HK",{timeZone:"Asia/Hong_Kong",hour12:false})} · 香港時間`:"等待更新"} · 頁面開啟時約每 20 秒更新</span>
      {!data.trial.enabled&&<button className={styles.secondary} onClick={onSetup}>設定自動記錄</button>}</div>
    <section className={s.kpis} aria-label="使用概覽">{cards.map(([label,value,detail]) => <article key={label}>
      <span>{label}</span><strong>{value}</strong><small>{detail}</small>
    </article>)}</section>
    <section className={s.card} aria-label="維修交接流程">
      <h2>維修交接流程</h2>
      <ol className={s.workflowSteps}>{[
        ["維修員","提交","submit"],["維修部","開始覆核","review"],["兩端交接","退回補充","return"],["維修部","確認","confirm"],
      ].map(([role,name,id])=><li key={id}><div><small>{role}</small><strong>{name}</strong><span>{usage.milestones[id]??0} 宗</span></div></li>)}</ol>
      <p className={styles.muted}>各步按日期內有該動作的案件計數，同一宗可出現在多步。退回是可重複的支線，不是必經步驟。</p>
    </section>
    <div className={s.overviewGrid}>
      <section className={s.card} aria-label="每日提交及確認">
        <h2>每日完成情況</h2>
        <p className={s.legend}><span>提交／補交</span><span>確認</span></p>
        {usage.submitted + usage.confirmed ? <>
          <div className={s.chart} aria-hidden="true">
            {usage.daily.map(d => <div className={s.day} key={d.date} title={`${d.date} · 提交 ${d.submitted} 次 · 確認 ${d.confirmed} 次`}>
              <i style={{height:`${d.submitted/peak*100}%`}}/><i style={{height:`${d.confirmed/peak*100}%`}}/>
            </div>)}
          </div>
          <div className={s.axis}><span>{data.from}</span><span>{data.to}</span></div>
          <button className={styles.secondary} aria-expanded={showValues} onClick={()=>setShowValues(!showValues)}>{showValues ? "收起每日數值" : "查看每日數值"}</button>
          {showValues && <div className={s.table}><table><thead><tr><th>日期</th><th>提交</th><th>確認</th></tr></thead>
            <tbody>{usage.daily.map(d=><tr key={d.date}><td>{d.date}</td><td>{d.submitted}</td><td>{d.confirmed}</td></tr>)}</tbody></table></div>}
        </> : <p className={styles.muted}>所選日期內尚無提交或確認。</p>}
      </section>
      <section className={s.card} aria-label="近期操作記錄">
        <h2>近期操作記錄</h2>
        {!usage.recent.length ? <p className={styles.muted}>此期間尚無操作記錄。</p> :
          <ul className={s.activity}>{usage.recent.map((e,i)=><li key={e.at+":"+i}>
            <time dateTime={e.at}>{new Date(e.at).toLocaleString("zh-HK",{timeZone:"Asia/Hong_Kong",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"})}</time>
            <span>{roleLabel[e.role]} · {e.participant}</span><strong>{actionLabels[e.action] || e.action}</strong>
            {outcomeLabels[e.outcome] && <small>{outcomeLabels[e.outcome]}</small>}
          </li>)}</ul>}
      </section>
    </div>
    <section className={s.card} aria-label="研究參與者">
      <h2>研究參與者</h2>
      {data.trial.roster.length ? <div className={s.table}><table><thead><tr><th>參與者</th><th>角色</th><th>參與狀態</th><th>背景資料</th><th>有記錄天數</th><th>案件數</th></tr></thead>
        <tbody>{data.trial.roster.map(person=>{
          const activity=usage.people.find(row=>row.participant===person.participant);
          return <tr key={person.participant}><td>{person.participant}</td><td>{roleLabel[person.role]}</td>
            <td>{person.status==="joined"?"已同意":person.status==="left"?"已停止":"未參與"}</td>
            <td>{[profileLabel(participantProfile.tenure,person.tenure),profileLabel(participantProfile.specialty,person.specialty),
              person.licensed==null?"待收集":person.licensed?"持牌":"未持牌",profileLabel(participantProfile.work_area,person.work_area)].join(" · ")}</td>
            <td>{activity?.days??0}</td><td>{activity?.cases??0}</td></tr>;
        })}</tbody></table></div> : <p className={styles.muted}>尚無參與記錄。</p>}
    </section>
  </>;
}

export function AnalysisNavigation({ selected, onOpen }: {
  selected: AnalysisEntry;
  onOpen: (entry: AnalysisEntry) => void;
}) {
  return <section className={`${s.card} ${s.evidenceChain}`} aria-labelledby="research-chain-title">
      <h2 id="research-chain-title">一條論證鏈看懂整個研究</h2>
      <p>表單摩擦與弱網（X） → 本人回報的心累（M） → 耗時與退回（Y）</p>
      <nav aria-label="分析頁面"><ol className={s.chainFlow}>
        {analysisSections.map(section=><li key={section.id}><button type="button"
          aria-label={section.label} aria-describedby={`chain-${section.id}`} aria-controls="research-analysis-view"
          aria-pressed={selected===section.id} onClick={()=>onOpen(section.id)}>
          <span className={s.chainPath}>{section.path}</span><strong>{section.label}</strong>
          <span id={`chain-${section.id}`}>{section.question}</span>
        </button></li>)}
      </ol></nav>
  </section>;
}

export function BurdenComparison({ data }: { data: FieldReport }) {
  const partial = data.contextSummary.partial || data.handoffs.truncated;
  const hasPulse=data.trialSummary.paths.some(row=>row.pulse>0)||data.trialSummary.strain.some(row=>row.pulse>0);
  if(data.trial.tasks>0) return <section className={s.card} aria-label="心理橋樑比較">
    <h2>心理橋樑</h2>
    <p>使用維修員提交後、首次覆核結果之前的回報。</p>
    {data.trial.partial?<p>資料超出上限，請縮短日期範圍。</p>:hasPulse?<div className={s.overviewGrid}>
      <div className={s.analysisChart}><h3>摩擦與回報的心累分數</h3>
        {data.trialSummary.paths.map(row=><EvidenceBar key={row.label} label={row.label} value={row.strain} max={7}
          detail={row.strain===null?"—":`${row.strain.toFixed(1)} / 7 分 · ${row.pulse} 宗`}/>)}</div>
      <div className={s.analysisChart}><h3>心累分數與首次退回</h3>
        {data.trialSummary.strain.map(row=><EvidenceBar key={row.label} label={row.label} value={row.decided?row.returned/row.decided:null} max={1}
          detail={row.decided?`${row.returned} / ${row.decided} 宗 · ${minutes(row.minutes)}畫面活動`:"尚無覆核結果"}/>)}</div>
    </div>:<p className={styles.muted}>等待符合時序的本人回報。</p>}
    {!partial&&!data.trial.partial&&hasPulse&&<section className={s.analysisChart} aria-label="心累與填單時間"><h3>不同心累分數的填單時間</h3>
      {data.trialSummary.strain.map((row,i)=><EvidenceBar key={row.label} label={row.label} value={row.minutes}
        max={Math.max(1,...data.trialSummary.strain.map(r=>r.minutes??0))} accent={i===1}
        detail={row.timed?`${activityTime(row.minutes)} · ${row.timed} 宗`:"尚無完整計時"}/>)}</section>}
    <p className={styles.muted}>分組結果供探索。時序與案件難度仍須在研究分析時核對。</p>
  </section>;
  return <section className={s.card} aria-label="心理橋樑比較">
    <h2>心理橋樑</h2>
    <p>比較維修員回報的填寫費力程度與同一案件的交接結果。</p>
    {partial ? <p role="status">部分記錄超出分析上限，請縮短日期範圍。</p> :
      data.burden.some(b => b.n > 0) ? <div className={s.table}><table><thead><tr><th>本人回報</th><th>配對案件</th><th>首次退回</th><th>交接中位歷時</th></tr></thead>
        <tbody>{data.burden.map(b => <tr key={b.band}><th scope="row">{b.band === "low" ? "1–3 分" : "4–5 分"}</th>
          <td>{b.n} 宗</td><td>{b.decided ? `${b.returned} / ${b.decided} 宗` : "—"}</td>
          <td>{minutes(b.medianMinutes)}{b.timed ? `（${b.timed} 宗）` : ""}</td></tr>)}</tbody></table></div> :
        <p className={styles.muted}>等待本人回報與交接案件配對。</p>}
    <p className={styles.muted}>每宗取一筆最近的填寫或提交回報。分組供探索，交接歷時包含等候。</p>
  </section>;
}

function EvidenceBar({label,value,max,detail,accent=false}:{label:string;value:number|null;max:number;detail:string;accent?:boolean}) {
  return <div className={s.evidenceBar} data-accent={accent}><strong>{label}</strong><span>{detail}</span>
    {value!==null&&<div aria-hidden="true"><i style={{width:`${Math.max(0,Math.min(1,value/(max||1)))*100}%`}}/></div>}</div>;
}
type ComparisonRow=FieldReport["trialSummary"]["comparisons"][number];
const returnRate=(row:ComparisonRow)=>row.decided?row.returned/row.decided:null;
const returnText=(row:ComparisonRow)=>row.decided?`${(row.returned/row.decided*100).toFixed(1)}% · ${row.returned} / ${row.decided} 宗`:"尚無覆核結果";
const condition=(label:string)=>label==="baseline"?"A · 原流程":"B · 提示可用";
const reported=(score:number|null,n:number,max:number)=>score===null?"尚無回報":`${score.toFixed(1)} / ${max} · ${n} 份`;

function ContextComparison({data}:{data:FieldReport}){
  const {usual,context,ratings,unknownDemand}=data.trialSummary;
  return <div className={s.overviewGrid}>
    <section className={s.analysisChart} aria-label="防錯提示在甚麼情境有用">
      <h3>提示在哪些情境可能有用？</h3>
      <p className={styles.muted}>情境線索：傍晚提交、連線或慢請求訊號、較複雜案件。</p>
      {([["一般情境 · 首次退回率",usual],["有情境線索 · 首次退回率",context]] as const).map(([label,rows])=><div key={label}>
        <h4>{label}</h4>{rows.map(row=><EvidenceBar key={row.label} label={condition(row.label)} value={returnRate(row)} max={1} detail={returnText(row)} accent={row.label==="improved"}/>)}</div>)}
      <h4>有情境線索 · 本人回報心累</h4>
      {context.map(row=><EvidenceBar key={row.label} label={condition(row.label)} value={row.strain} max={7} detail={reported(row.strain,row.pulse,7)} accent={row.label==="improved"}/>)}
      <p className={styles.muted}>{unknownDemand>0?`${unknownDemand} 宗資料不足以分組。 `:""}分組比較供探索。</p>
    </section>
    <section className={s.analysisChart} aria-label="員工自評對照">
      <h3>員工怎樣回報？</h3>
      <h4>單後順手程度 · 1–7</h4>
      {ratings.map(row=><EvidenceBar key={row.label} label={condition(row.label)} value={row.ease} max={7} detail={reported(row.ease,row.easeN,7)} accent={row.label==="improved"}/>)}
      <h4>期末工作負荷 · NASA-TLX 六項平均</h4>
      {data.workloadSummary?data.workloadSummary.map(row=><EvidenceBar key={row.label} label={condition(row.label)} value={row.mean} max={100} detail={reported(row.mean,row.n,100)} accent={row.label==="improved"}/>):<p>請縮短日期範圍。</p>}
      <p className={styles.muted}>單後順手分是單題自評。期末量表為 0–100 分，六項不加權。</p>
    </section>
  </div>;
}

export function TrialComparison({data}:{data:FieldReport}) {
  if(data.trial.partial)return <p role="status">試行資料超出上限，請縮短日期範圍。</p>;
  if(!data.trialSummary.comparisons.some(row=>row.n))return <section className={s.card} aria-label="四期試行比較"><h2>四期試行比較</h2>
    <p className={styles.muted}>這段日期尚無可比較的試行提交。日常記錄仍會出現在總覽與資料表。</p></section>;
  const rows=data.trialSummary.comparisons;
  const maxMinutes=Math.max(1,...rows.map(row=>row.minutes??0));
  return <section className={s.card} aria-label="四期試行比較">
    <h2>四期試行比較</h2>
    <p className={styles.muted}>依案件建立時的期別分組。A 沿用原流程；B 提供防錯提示。</p>
    <div className={s.overviewGrid}>
      <section className={s.analysisChart} aria-label="各期平均畫面活動"><h3>平均畫面活動時間</h3>
        {rows.map(row=><EvidenceBar key={row.label} label={row.label} value={row.minutes} max={maxMinutes}
          accent={row.label.startsWith("B")} detail={row.timed?`${activityTime(row.minutes)} · ${row.timed} 宗`:"尚無完整計時"}/>)}
      </section>
      <section className={s.analysisChart} aria-label="各期首次退回率"><h3>首次退回率</h3>
        {rows.map(row=><EvidenceBar key={row.label} label={row.label} value={row.decided?row.returned/row.decided:null} max={1}
          accent={row.label.startsWith("B")} detail={row.decided?`${(row.returned/row.decided*100).toFixed(1)}% · ${row.returned} / ${row.decided} 宗`:"尚無覆核結果"}/>)}
      </section>
    </div>
    <details className={s.sourceDetails}><summary>查看四期明細</summary>
    <div className={s.table}><table><thead><tr><th>期別</th><th>提交</th><th>平均畫面活動</th><th>首次退回</th><th>看到提示</th></tr></thead>
      <tbody>{rows.map(row=><tr key={row.label}><th scope="row">{row.label}</th><td>{row.n}</td>
        <td>{activityTime(row.minutes)}{row.timed?`（${row.timed} 宗）`:""}</td><td>{row.decided?`${row.returned} / ${row.decided}`:"—"}</td><td>{row.exposed}</td></tr>)}</tbody></table></div></details>
    <ContextComparison data={data}/>
    <p className={styles.muted}>這是分組比較，不能直接解讀成提示造成的改善。</p>
  </section>;
}

export function RegressionGuide({data}:{data:FieldReport}){
  const {complete,people,conditions}=data.trialSummary.modelCoverage;
  return <section className={s.card} aria-label="回歸圖與資料準備"><h2>回歸圖：考慮其他因素後，差異還在嗎？</h2>
    <p>用點顯示模型估計、橫線顯示 95% 區間。係數以 0 為參考；首次退回的勝算比以 1 為參考。</p>
    <ul className={s.modelList}>
      <li><strong>填單時間</strong><span>同時考慮難度、時段與同一人反覆填單。</span></li>
      <li><strong>心累與首次退回</strong><span>只用早於首次覆核的本人回報。</span></li>
      <li><strong>提示何時較有用</strong><span>探索提示與情境線索的交互作用。</span></li>
    </ul>
    {data.trial.partial?<p>目前資料不完整，請縮短日期範圍。</p>:<>
      <ul className={s.coverage}><li><strong>{complete}</strong> 宗有畫面計時</li><li><strong>{people}</strong> 位有計時的參與者</li><li><strong>{conditions} / 2</strong> 種有計時的條件</li></ul>
      <p className={styles.muted}>{complete<20||people<3||conditions<2?"目前連耗時模型的基本資料門檻也未達到。":"已達耗時模型的基本資料門檻，仍須由腳本檢查模型能否估計。"} 從研究設定下載「案件成效」CSV 和 R 腳本，可在本機產生回歸圖。首次退回及交互作用另有樣本檢查。</p>
    </>}
  </section>;
}

const returnSuggestions: Record<string, string> = {
  photos:"在提交前顯示已上傳的相片張數，並提供重試入口。",
  equipment:"在設備資料旁加入範例，讓維修員在原欄位核對。",
  description:"將工作說明拆成已檢查項目與現場發現。",
  time:"提交前集中展示開工及完工時間供核對。",
  location:"在覆核頁並排顯示原工作地點與補充資料。",
  changed_request:"在交接時標示要求變更及更新時間。",
  other:"抽查對應案件，整理可重現的問題。",
  unknown:"回看對應案件，核對退回原因後再選擇改動。",
};

export function ImprovementEvidence({ data, busy, onOpenCase }: { data: FieldReport; busy:boolean; onOpenCase: (id:string) => void }) {
  const groups:Record<string,string>={validation_error:"常被攔截的欄位",field_clear:"常被清空的欄位",connection:"常見連線訊號的畫面"};
  return <section className={s.card} aria-label="改進建議證據">
    <h2>改進建議</h2>
    <h3>先核查哪裏？</h3>
    <p className={styles.muted}>各圖按涉及的案件數排序；同一宗可以出現多次操作。</p>
    {data.truncated?<p>請縮短日期範圍後查看。</p>:<div className={s.frictionGrid}>
      {data.usage.frictionGroups.map(({kind,rows})=><section className={s.analysisChart} key={kind} aria-label={groups[kind]}>
        <h4>{groups[kind]}</h4>
        {rows.length?rows.map(row=><EvidenceBar key={`${row.role}:${row.action}:${row.target}`}
          label={`${roleLabel[row.role]} · ${fieldLabels[row.target]||screenLabels[row.target]}${kind==="connection"?` · ${actionLabels[row.action]}`:""}`}
          value={row.cases} max={rows[0].cases} detail={`${row.cases} 宗 · ${row.count} 次`}/>):<p className={styles.muted}>尚無這類記錄。</p>}
      </section>)}
    </div>}
    <div className={s.overviewGrid}>
    <div className={s.analysisChart}>
    <h3>覆核退回原因</h3>
    {data.handoffs.truncated ? <p>請縮短日期範圍後查看。</p> :
      data.handoffs.reasons.length ? <ol className={s.findings}>{data.handoffs.reasons.slice(0,4).map(reason=>{
        const matches=data.handoffs.rows.filter(row=>row.reasons.includes(reason.code));
        return <li key={reason.code}>
        <div><strong>{reason.label}</strong><span>{reason.count} 次退回</span></div><p>{returnSuggestions[reason.code]}</p>
        {matches.length>0&&<details className={s.sourceDetails} name="return-reason">
          <summary>查看{reason.label}案件（{matches.length} 宗）</summary>
          {matches.slice(-5).reverse().map(row=><button className={styles.secondary} key={row.id} disabled={busy}
            onClick={()=>onOpenCase(row.id)}>查看案件 {row.alias.slice(0,10)}</button>)}
          {matches.length>5&&<p className={styles.muted}>顯示最近 5 宗。</p>}
        </details>}
      </li>;})}</ol> : <p className={styles.muted}>此期間尚無可整理的退回原因。</p>}
    </div>
    <div className={s.analysisChart}><h3>畫面活動分布</h3>
      <p className={styles.muted}>時間是各畫面已記錄的活動總和，受案件量影響。</p>
      {data.truncated?<p>請縮短日期範圍後查看。</p>:data.usage.surfaces.length?
      data.usage.surfaces.slice(0,5).map(row=><EvidenceBar key={row.surface} label={screenLabels[row.surface]}
        value={row.duration} max={data.usage.surfaces[0].duration} detail={`${activityTime(row.duration/60000)} · ${row.cases} 宗`}/>):<p className={styles.muted}>尚無計時。</p>}
    </div></div>
  </section>;
}

export function FieldSettings({ view, data, query, scope, busy, readOnly, onSave, onJson }: {
  view:"points"|"exports"|"trial"; data: FieldReport | undefined; query: string; scope:Scope; busy: boolean; readOnly: boolean;
  onSave: (body: Record<string, unknown>) => void; onJson: () => void;
}) {
  function plan(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    onSave({action:"trial-plan", startsOn:form.get("start"), weeks:Number(form.get("weeks"))});
  }
  return <>
    {view==="points"&&data && !data.trial.enabled&&!readOnly&&<section className={s.card} aria-label="自動操作記錄">
      <h2>設定自動記錄</h2>
      <p>只需完成一次公司許可設定。員工可在自己的帳戶同意參與，此後新案件會自動納入。</p>
      <form onSubmit={event=>{
        event.preventDefault();const fields=new FormData(event.currentTarget);
        onSave({action:"auto-collection",consentReference:fields.get("reference"),permissionConfirmed:fields.has("permission")});
      }}>
        <label>公司研究許可記錄編號<input name="reference" required maxLength={200}/></label>
        <label className={styles.check}><input type="checkbox" name="permission" required/>已完成公司許可及所需研究審查。</label>
        <button disabled={busy}>啟用自動記錄</button>
      </form>
    </section>}
    {view==="exports"&&<FieldExportPanel key={query} query={query} {...scope} busy={busy} onJson={onJson}/>}
    {view==="trial"&&<section className={s.card} aria-label="實驗排程">
      <h2>防錯提示試行 <small className={styles.muted}>選用</small></h2>
      <p>只有比較提示效果時才需排程。A 沿用原表單，B 加上防錯提示。日常記錄不受排程限制。</p>
      {data&&!data.trial.enabled&&<p className={styles.muted}>要讓新案件自動分入試行期，請先在「工作流埋點」設定自動記錄。</p>}
      {data && !readOnly && (data.periods.length === 0 || data.periods[0].from > hkToday()) &&
        <form className={s.range} onSubmit={plan} key={data.periods[0]?.from + ":" + data.periods[0]?.to}>
          <label>第一期開始日<input type="date" name="start" defaultValue={data.periods[0]?.from || hkToday()} min={hkToday()} required/></label>
          <label>每期長度<select name="weeks" defaultValue={data.periods.length
            ? (Date.parse(data.periods[0].to) - Date.parse(data.periods[0].from) + 86400000) / 604800000
            : 1}>{[1,2,3,4].map(week=><option value={week} key={week}>{week} 週</option>)}</select></label>
          <button disabled={busy}>儲存四期排程</button>
        </form>}
      {data?.periods.length ? <div className={s.table}><table><thead><tr><th>期別</th><th>防錯提示</th><th>開始</th><th>結束</th></tr></thead>
        <tbody>{data.periods.map(period=><tr key={period.label}><th scope="row">{period.label}</th><td>{period.phase==="baseline"?"關閉":"開啟"}</td><td>{period.from}</td><td>{period.to}</td></tr>)}</tbody></table></div> :
        <p className={styles.muted}>尚未儲存排程。</p>}
    </section>}
  </>;
}
