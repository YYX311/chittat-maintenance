'use client';

import { useState } from "react";
import type { summarizeHandoffs } from "../../lib/research-handoffs";
import { handoffReasons } from "../../src/handoff-reasons";
import styles from "./research.module.css";
import layout from "./handoff-panel.module.css";

type Summary = ReturnType<typeof summarizeHandoffs>;
const statusLabels = {
  submitted: "待維修部覆核",
  needsInfo: "待維修員補交",
  confirmed: "已確認",
  withdrawn: "已撤回",
};
const reasonLabels = Object.fromEntries(handoffReasons.map(([id, label]) => [id, label]));

export default function HandoffPanel({ data, busy, onOpen }: {
  data: Summary;
  busy: boolean;
  onOpen: (id: string) => void;
}) {
  const [difficulty, setDifficulty] = useState("all");
  const groups = data.groups.filter(group => group.difficulty === difficulty);
  const visibleRows = data.rows.filter(row => difficulty === "all" || row.difficulty === difficulty);
  const strata = data.groups.filter(group => group.difficulty !== "all" && group.submitted > 0 && (difficulty === "all" || group.difficulty === difficulty));

  return <section className={styles.card} aria-label="現場交接分析">
    <h2>交接與覆核結果</h2><p className={styles.muted}>這裡包含日常案件；基線組可包含試行排程以外的記錄。</p>
    {data.truncated ? <p role="status">交接事件超過本次分析上限。請以較小的研究範圍重新分析。</p> :
      !data.rows.length ? <div className={layout.empty}>
        <h3>等待第一宗維修員提交</h3>
        <p>獲准收集的案件提交後，這裡會顯示交接進度。</p>
      </div> : <>
        <label className={layout.filter}>案件難度<select value={difficulty} onChange={event => setDifficulty(event.target.value)}>
          <option value="all">全部難度</option><option value="low">低</option>
          <option value="medium">中</option><option value="high">高</option>
        </select></label>
        <div className={layout.phases}>
          {groups.map(group => <article className={layout.phase} key={group.phase}>
            <h3>{group.phase === "baseline" ? "基線期" : "改進期"}</h3>
            <p className={layout.metric}>{group.decided ? `${group.firstPass} / ${group.decided}` : "尚無覆核結果"}</p>
            <p>一次通過 · {group.submitted} 宗曾提交</p>
            {group.decided > 0 && <div className={layout.track} aria-hidden="true">
              <span style={{ width: `${group.firstPass / group.decided * 100}%` }} />
            </div>}
            <dl className={layout.counts}>
              <div><dt>待覆核</dt><dd>{group.waitingReview}</dd></div>
              <div><dt>待補交</dt><dd>{group.waitingWorker}</dd></div>
              <div><dt>已確認</dt><dd>{group.confirmed}</dd></div>
              <div><dt>已撤回</dt><dd>{group.withdrawn}</dd></div>
            </dl>
            <p className={styles.muted}>交接中位歷時 {group.medianMinutes === null ? "尚無資料" : `${group.medianMinutes < 1 ? "少於 1" : Math.round(group.medianMinutes)} 分鐘（${group.confirmed} 宗）`}</p>
          </article>)}
        </div>
        <p className={styles.muted}>一次通過以已有首次覆核決定的案件為分母。交接歷時由首次提交至首次確認，含等候時間。階段差異供描述性比較。</p>
        {strata.length > 0 && <>
          <h3>按階段及案件難度比較</h3>
          <div className={layout.table}><table><thead><tr><th>階段</th><th>難度</th><th>提交案件</th><th>一次通過</th><th>交接中位歷時</th></tr></thead>
            <tbody>{strata.map(group => <tr key={group.phase+group.difficulty}>
              <td>{group.phase === "baseline" ? "基線期" : "改進期"}</td>
              <td>{{low:"低",medium:"中",high:"高"}[group.difficulty]}</td>
              <td>{group.submitted}</td><td>{group.decided ? `${group.firstPass} / ${group.decided}` : "—"}</td>
              <td>{group.medianMinutes === null ? "—" : `${group.medianMinutes < 1 ? "< 1" : group.medianMinutes.toFixed(1)} 分鐘`}</td>
            </tr>)}</tbody></table></div>
        </>}
        {visibleRows.length > 0 && <>
          <h3>案件證據</h3>
          <ul className={layout.cases}>{visibleRows.slice(-8).reverse().map(row => <li key={row.alias}>
            <div><strong title={row.alias}>{row.alias.slice(0,10)}</strong><span>{statusLabels[row.state]} · 提交 {row.submissions} 次 · 退回 {row.reasons.length} 次</span>
              {row.reasons.length > 0 && <span>{row.reasons.map(reason => reasonLabels[reason]).join("、")}</span>}</div>
            <button className={styles.secondary} disabled={busy} onClick={() => onOpen(row.id)}>查看證據</button>
          </li>)}</ul>
        </>}
      </>}
  </section>;
}
