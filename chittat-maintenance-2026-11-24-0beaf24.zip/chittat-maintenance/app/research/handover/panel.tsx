'use client';
import { useEffect,useState } from 'react';
import { sessionFetch } from '../../../src/session-fetch';
import { actions,themes,type Action,type HandoverData } from '../../../lib/handover-coding';
import { handoffReasons } from '../../../src/handoff-reasons';
import { fieldNames } from '../../../lib/research-events';
import s from '../studio.module.css';
import h from './handover.module.css';

export default function Handover({ active, onLogin, from, to, excludeTest = false }: { active: boolean; onLogin: () => void; from: string; to: string; excludeTest?: boolean }) {
  const [page, setPage] = useState(1);
  const [tab,setTab]=useState<'timeline'|'themes'>('timeline'),[revision,refresh]=useState(0);
  const [result,setResult]=useState<{key:string;data:HandoverData}>();
  const [error,setError]=useState(''),[saving,setSaving]=useState(false);
  const [pending,setPending]=useState<{id:string;theme:string}|null>(null);
  const key=new URLSearchParams({from,to,page:String(page),...(excludeTest?{excludeTest:'1'}:{})}).toString();
  useEffect(()=>{
    if (!active) return;
    let current=true, loading=false;
    async function load(){ if(loading)return; loading=true;
      try{
        const r=await sessionFetch('/api/research/handover?'+key);
        if(!current)return;
        if(r.status===401||r.status===403){onLogin();return;}
        if(!r.ok)throw Error(r.status===400?'請選擇 1 至 93 日的期間。':'讀取失敗，請重試。');
        const data=await r.json();
        if(current){setResult({key,data});setError('');}
      }catch(e){if(!current)return; if((e as {status?:number})?.status===401){onLogin();return;} setError(e instanceof Error && e.message.startsWith('請選擇')?e.message:'連線失敗，請重試。');} finally {loading=false;}
    }
    void load();
    const timer=setInterval(()=>{if(document.visibilityState==='visible')void load();},20000);
    return ()=>{current=false;clearInterval(timer);};
  },[active,key,revision,onLogin]);
  const data=result?.key===key?result.data:undefined;
  const totals=Object.keys(actions).map(action=>({action:action as Action,n:data?.daily.filter(r=>r.action===action).reduce((n,r)=>n+r.count,0)??0}));
  const count=data?.codes.reduce((n,c)=>n+c.count,0)??0;
  async function code(id:string,theme:string){
    setSaving(true); setPending({id,theme}); setError('');
    try{
      const r=await sessionFetch('/api/research/handover',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,theme})});
      if(r.status===401||r.status===403){onLogin();return;} if(!r.ok)throw Error();
      setResult(prev=>prev?{...prev,data:{...prev.data,returns:prev.data.returns.map(row=>row.id===id?{...row,theme:theme as keyof typeof themes}:row)}}:prev); refresh(n=>n+1);
    }catch{setError('標記尚未儲存，請重試。');}finally{setSaving(false);setPending(null);}
  }
  return <>
    <nav className={s.analysisNav} aria-label="交接研究"><button aria-current={tab==='timeline'?'page':undefined} onClick={()=>setTab('timeline')}>交接趨勢</button><button aria-current={tab==='themes'?'page':undefined} onClick={()=>setTab('themes')}>退回原因</button></nav>
    {error&&<p role="alert">{error} <button onClick={()=>refresh(n=>n+1)}>重試</button></p>}
    {!data&&!error&&<p role="status">正在讀取交接記錄…</p>}
    {data&&(tab==='timeline'?<section className={h.panel}><h2>期間交接量</h2><p>按成功操作次數統計，補交會再次計入提交。</p><div className={h.metrics}>{totals.map(t=><div key={t.action}>{actions[t.action]}<strong>{t.n}</strong><meter aria-label={actions[t.action]} min={0} max={Math.max(1,...totals.map(v=>v.n))} value={t.n}/></div>)}</div><h3>每日交接</h3>{data.daily.length?<table><thead><tr><th>有活動的日期</th>{totals.map(t=><th key={t.action}>{actions[t.action]}</th>)}</tr></thead><tbody>{Array.from(new Set(data.daily.map(r=>r.day))).reverse().map(date=><tr key={date}><th>{date}</th>{totals.map(t=><td key={t.action}>{data.daily.find(r=>r.day===date&&r.action===t.action)?.count??0}</td>)}</tr>)}</tbody></table>:<p>這段期間沒有交接記錄。</p>}</section>:
    <section className={h.panel}><h2>退回時需要解決甚麼？</h2><p>每次退回可選一個主題。有訪談或交接證據時才分類，無法判斷可選「證據不足」。</p><div className={h.metrics}>{[...Object.entries(themes),['','待分類']].map(([k,label])=><div key={k}>{label}<strong>{data.codes.find(c=>(c.theme??'')===k)?.count??0}</strong></div>)}</div>
    {data.returns.map(row=><label className={h.row} key={row.id}><span><strong>{handoffReasons.find(r=>r[0]===row.reason)?.[1]||'未標示原因'}</strong> · {fieldNames[row.field||'']||'其他欄位'}<small>{new Date(row.at).toLocaleString('zh-HK',{timeZone:'Asia/Hong_Kong'})} · 記錄 {row.id}</small></span><select aria-label={'記錄 '+row.id+' 主題'} disabled={saving} value={pending?.id===row.id?pending.theme:row.theme??''} onChange={e=>void code(row.id,e.target.value)}><option value="" disabled>選擇主題</option>{Object.entries(themes).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></label>)}
    {!count&&<p>這段期間沒有退回記錄。</p>}{count>15&&<div><button disabled={page===1} onClick={()=>setPage(page-1)}>上一頁</button> {page} / {Math.ceil(count/15)} <button disabled={page*15>=count} onClick={()=>setPage(page+1)}>下一頁</button></div>}</section>)}
    </>;
}
