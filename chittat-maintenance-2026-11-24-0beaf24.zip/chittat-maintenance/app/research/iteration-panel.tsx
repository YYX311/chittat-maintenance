import type { Diagnostics } from '../../lib/research-diagnostic-types';
import styles from './research.module.css';

export default function IterationPanel({data,busy,onOpen}:{data:Diagnostics;busy:boolean;onOpen:(id:string)=>void}) {
  return <section className={styles.card} aria-label="迭代診斷">
    <h2>待核查 · {data.total} 宗</h2>
    {data.total>data.items.length&&<p className={styles.muted}>顯示前 {data.items.length} 宗</p>}
    <div className={styles.table}><table><thead><tr><th>案件代號</th><th>待核查事項</th><th>操作</th></tr></thead><tbody>{data.items.map(item=><tr key={item.id}><td>{item.alias}</td><td>{item.rule}</td><td><button disabled={busy} onClick={()=>onOpen(item.id)}>核查證據</button></td></tr>)}</tbody></table></div>
  </section>;
}
