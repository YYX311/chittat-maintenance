'use client';
import {useEffect,useRef,useState} from 'react';
import {sessionFetch} from '../../src/session-fetch';
import {diagnosticEvidence,maintenanceBrief,type MaintenanceAnalysis} from '../../lib/maintenance-analysis';
import {prioritizeSignals,recommendedSignal,signalScope,emptyGuidance,plainIssue} from '../../lib/maintenance-presentation';
import type {Result} from './ai-review';
import ManagementReport from './management-report';
import s from './maintenance-console.module.css';
const labels:Record<string,string>={submit:'提交',return:'退回補充',confirm:'確認',save:'儲存',assets:'上傳',documents:'生成文件',reopen:'重新修改',worker:'維修人員',office:'維修部',manager:'管理人員',business:'業務事件',missing_information:'資料缺漏',changed_requirement:'要求變更',technical_failure:'技術現象',other:'其他因素',unknown:'證據不足'};
const errorText:Record<string,string>={'ai-not-configured':'此環境未啟用 AI，仍可使用規則診斷與維護說明。','ai-daily-limit':'今日免費分析上限已用完，請稍後再試。','ai-running':'已有分析正在進行，請稍後重試。','ai-invalid-result':'AI 結果未通過引文核查，未採用。','invalid-no-evidence':'目前沒有可分析的問題訊號。','invalid-study-not-collecting':'此實驗尚未收集或已封存。','unauthorized':'登入已過期，請重新登入。','forbidden':'此帳號沒有研究權限。'};
export default function MaintenanceConsole({studyId,readOnly,view,onManage}:{studyId:string;readOnly:boolean;view:'overview'|'report';onManage:()=>void}) {
  const [data,setData]=useState<MaintenanceAnalysis|null>(null),[selected,setSelected]=useState<string|null>(null),[loading,setLoading]=useState(false),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const [ai,setAi]=useState<{result:Result;evidence:string}|null>(null),[thinking,setThinking]=useState(false),[updated,setUpdated]=useState('');
  const seq=useRef(0),heading=useRef<HTMLHeadingElement>(null);
  const [handoff,setHandoff]=useState(false),[context,setContext]=useState('');
  const [recordView,setRecordView]=useState(false),[preview,setPreview]=useState(false);
  function choose(key:string){setSelected(key);setHandoff(false);setRecordView(false);setPreview(false);setContext('');setNotice('');setError('');requestAnimationFrame(()=>heading.current?.focus());}
  async function refresh(){const n=++seq.current;setLoading(true);setError('');try{const r=await sessionFetch(`/api/research/diagnostics?study=${encodeURIComponent(studyId)}`);const v=await r.json();if(!r.ok)throw Error(v.error);if(n===seq.current){setData(v);setUpdated(new Date().toLocaleTimeString('zh-HK'));}}catch(e){if(n===seq.current)setError(errorText[(e as Error).message]||'資料暫時未能更新；畫面保留上次結果。');}finally{if(n===seq.current)setLoading(false);}}
  useEffect(()=>{void refresh();return()=>{seq.current++;};},[studyId]);
  const issue=data?(selected===null?recommendedSignal(data):data.signals.find(x=>x.key===selected)):undefined;
  const ordered=data?prioritizeSignals(data.signals):[];
  const guidance=data?emptyGuidance(data,readOnly):null;
  const matching=!!(ai&&data&&issue&&ai.evidence===diagnosticEvidence(signalScope(data,issue.key)));
  const factors=matching&&ai?('factors' in ai.result?ai.result.factors:[ai.result]):[];
  async function analyze(){setThinking(true);setError('');setNotice('');try{const r=await sessionFetch('/api/research/diagnostics',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({studyId,signalKey:issue?.key})});const v=await r.json();if(!r.ok)throw Error(v.error);setAi(v);}catch(e){setError(errorText[(e as Error).message]||'AI 暫時未能分析；規則結果和維護說明仍可使用。');}finally{setThinking(false);}}
  const aiSummary=matching&&ai?factors.map(f=>`- ${labels[f.cause]||f.cause}：${f.explanation}${f.quote?`（引用：${f.quote}）`:''}`).concat('uncertainties' in ai.result?ai.result.uncertainties.map(u=>`- 待確認：${u}`):[]).join('\n'):undefined;
  const brief=data&&issue?maintenanceBrief(data,issue,aiSummary)+(context.trim()?`\n## 使用者補充（待核對）\n${context.trim().split(/\r?\n/).map(line=>`> ${line}`).join('\n')}\n`:''):'';
  async function copy(){try{await navigator.clipboard.writeText(brief);setNotice('維護說明已複製，可交給開發者或 AI 編程工具。');}catch{setNotice('瀏覽器未允許複製，請使用下載說明。');}}
  function download(){const url=URL.createObjectURL(new Blob([brief],{type:'text/markdown;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=`maintenance-${issue?.key}-${new Date().toISOString().slice(0,10)}.md`;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);setNotice('已交給瀏覽器下載，請查看下載記錄。');}
  if(view==='report')return <section className={s.console}>{error&&<p role="alert" className={s.error}>{error} <button onClick={refresh}>重試</button></p>}{data?<ManagementReport data={data} studyId={studyId} readOnly={readOnly}/>:!error&&<p role="status">正在讀取資料…</p>}</section>;
  return <section className={s.console} aria-label="維護分析助手">
    <div className={s.toolbar}><span>{data?.activity?`最近記錄：${labels[data.activity.role]||data.activity.role} · ${labels[data.activity.operation]||data.activity.operation} · ${new Date(data.activity.at).toLocaleString('zh-HK')}`:updated?`上次檢查 ${updated}`:'正在讀取記錄'}</span><button disabled={loading||thinking} onClick={refresh}>{loading?'檢查中…':'重新檢查'}</button></div>
    {error&&<p role="alert" className={s.error}>{error}</p>}{notice&&<p role="status" className={s.notice}>{notice}</p>}
    {!data?<div className={s.empty} role="status">{loading?'正在查看有沒有需要處理的問題…':'暫時未能讀取，請重新檢查。'}</div>:<>
      {data.partial&&<p className={s.notice}>目前只分析部分記錄，問題數量可能不完整。</p>}
      {!issue?<>
        {ordered.length?<div className={s.list}>
          <h2 ref={heading} tabIndex={-1}>有 {ordered.length} 項問題值得檢查</h2><p className={s.subtitle}>先點第一項，看看發生什麼、接下來怎麼處理。</p>
          {ordered.map((v,i)=><button className={s.problem} key={v.key} onClick={()=>choose(v.key)}><span className={s.number}>{String(i+1).padStart(2,'0')}</span><span className={s.problemText}><strong>{v.title}</strong><small>涉及 {v.cases} 宗案件 · 記錄 {v.count} 次</small></span><span className={s.open}>查看問題 →</span></button>)}
        </div>:<div className={s.empty}>
          <h2 ref={heading} tabIndex={-1}>{data.enrolled?guidance?.title:'等待自動納入案件'}</h2><p>{data.enrolled?guidance?.description:'完成一次記錄設定後，已同意參與的員工照常建立新案件。'}</p>{guidance?.action&&<button className={s.primary} onClick={onManage}>查看研究設定</button>}
        </div>}
      </>:<>
        <button className={s.back} onClick={()=>{if(recordView)setRecordView(false);else if(preview)setPreview(false);else if(handoff)setHandoff(false);else choose('');}}>{recordView?'← 返回問題':preview?'← 返回維護說明':handoff?'← 返回處理建議':'← 返回問題清單'}</button>
        <article className={s.focusCard}>
          <span className={s.kicker}>{handoff?'交給開發者或 AI 編程工具':selected===null?'建議先檢查':'待核查問題'}</span><h2 ref={heading} tabIndex={-1}>{issue.title}</h2><p className={s.subtitle}>涉及 {issue.cases} 宗案件 · 記錄 {issue.count} 次</p>
          {recordView?<section><h3>原始記錄</h3><p>{issue.facts}</p><ul>{issue.samples.map(v=><li key={v.id}>{labels[v.role]||v.role} · {labels[v.operation]||v.operation} · {new Date(v.at).toLocaleString('zh-HK')}{v.duration!==null?` · ${(v.duration/1000).toFixed(1)} 秒`:''}</li>)}</ul></section>:preview?<pre className={s.brief}>{brief}</pre>:handoff?<>
            <label>補充操作情況（選填）<textarea maxLength={500} value={context} onChange={e=>setContext(e.target.value)} placeholder="例如：按提交後，案件列表沒有更新。"/></label>
            <div className={s.actions}><button className={s.primary} onClick={copy}>複製維護說明</button><button onClick={download}>下載說明</button><button onClick={()=>setPreview(true)}>預覽說明</button></div>
          </>:<>
            <h3>發生了什麼</h3><p>{plainIssue(issue).fact}</p>{issue.samples[0]&&<p className={s.subtitle}>最近一筆：{labels[issue.samples[0].role]||issue.samples[0].role} · {labels[issue.samples[0].operation]||issue.samples[0].operation}</p>}<h3>建議先做這件事</h3><p>{plainIssue(issue).next}</p>
            <div className={s.actions}><button className={s.primary} disabled={thinking} onClick={()=>{setHandoff(true);setPreview(false);setNotice('');requestAnimationFrame(()=>heading.current?.focus());}}>整理維護說明 →</button><button disabled={thinking||loading||readOnly} onClick={analyze}>{thinking?'AI 正在整理…':'AI 幫我解讀這項問題'}</button></div>
            {readOnly&&<p className={s.subtitle}>此資料範圍未開放收集，仍可查看與匯出。</p>}
            {ai&&!matching&&<p className={s.notice}>資料或問題已變更，舊 AI 解釋已隱藏；可以重新分析。</p>}
            {matching&&<div className={s.aiResult}><h3>AI 的解讀</h3><small>候選解釋，仍需人工確認。</small>{factors.map((f,i)=><div key={i}><h4>{labels[f.cause]||f.cause}</h4><p>{f.explanation}</p>{f.quote&&<blockquote>{f.quote}</blockquote>}</div>)}{ai&&'uncertainties' in ai.result&&!!ai.result.uncertainties.length&&<p>待核實：{ai.result.uncertainties.join('；')}</p>}</div>}
            <button className={s.back} onClick={()=>setRecordView(true)}>查看原始記錄</button>
          </>}
        </article>
      </>}
      <div className={s.overviewFoot}>已納入 {data.enrolled} 宗 · 有操作記錄 {data.runtimeCases} 宗</div>
    </>}
  </section>;
}
