'use client';
import {useState} from 'react';
import type {MaintenanceAnalysis} from '../../lib/maintenance-analysis';
import {managementModels,managementSnapshot,type ManagementModel,type ManagementReport as Report} from '../../lib/management-analysis';
import {sessionFetch} from '../../src/session-fetch';
import s from './maintenance-console.module.css';

export default function ManagementReport({data,studyId,readOnly,initialModel}:{initialModel?:ManagementModel;data:MaintenanceAnalysis;studyId:string;readOnly:boolean}){
  const [override,setOverride]=useState<ManagementModel|''>(initialModel||''),[result,setResult]=useState<{result:Report;evidence:string}|null>(null);
  const [busy,setBusy]=useState(false),[error,setError]=useState('');
  const model=override||(data.collaboration.reviewed>0?(data.collaboration.returned>0?'rework':'waiting'):'pdca');
  const selected=managementModels.find(item=>item.id===model)!;
  const snapshot=managementSnapshot(data,model);
  const report=result&&result.evidence===snapshot.evidence?result.result:null;
  const headline=new Set(model==='human_factors'?['context_total','context_sources']:model==='waiting'?['wait','baseline']:model==='rework'?['returned','pending']:['operations','pending']);
  async function generate(){
    if(!snapshot?.ready||!model)return;
    setBusy(true);setError('');
    try{const response=await sessionFetch('/api/research/diagnostics',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({studyId,managementModel:model})});
      const body=await response.json();if(!response.ok)throw new Error(body.error);setResult(body);
    }catch(e){const code=(e as Error).message;setError(code==='ai-daily-limit'?'今天的 AI 分析額度已用完。你仍可查看統計。':'暫時未能產生報告。統計仍可查看，請稍後再試。');}
    finally{setBusy(false);}
  }
  function download(){
    if(!report||!snapshot||!selected)return;
    const body=`# ${selected.title}｜${selected.method}\n\n## 已記錄的數據\n${snapshot.facts.map(f=>`- ${f.label}：${f.value}`).join('\n')}\n\n## AI 改善建議（待驗證）\n${report.finding}\n\n先試：${report.action}\n\n驗證：${report.verification}\n\n## 資料限制\n${snapshot.limits.map(s=>`- ${s}`).join('\n')}\n`;
    const url=URL.createObjectURL(new Blob([body],{type:'text/markdown;charset=utf-8'}));const link=document.createElement('a');link.href=url;link.download=`collaboration-${model}.md`;link.click();setTimeout(()=>URL.revokeObjectURL(url),10000);
  }
  return <section className={s.management} aria-label="管理分析">
    <h2>選一個分析方向</h2>
    <div className={s.modelOptions} role="group" aria-label="分析方向">{managementModels.map(item=><button key={item.id} disabled={busy} aria-pressed={model===item.id} onClick={()=>{setOverride(item.id);setResult(null);setError('');}}><strong>{item.title}</strong><small>{item.method}</small></button>)}</div>
    <h3>{selected.question}</h3>
    <dl className={s.facts}>{snapshot.facts.filter(f=>headline.has(f.id)).map(f=><div key={f.id}><dt>{f.label}</dt><dd>{f.value}</dd></div>)}</dl>
    <div className={s.actions}>{snapshot.ready&&!readOnly&&<button className={s.primary} disabled={busy} onClick={generate}>{busy?'正在整理報告…':'生成 AI 管理報告'}</button>}</div>
    {(!snapshot.ready||readOnly)&&<p className={s.subtitle}>{readOnly?'報告只在收集期間生成。':model==='human_factors'?'尚無情境核查。請先在「現場因素」記錄本人回報或現場觀察。':'記錄仍不足，請先累積提交及處理紀錄。'}</p>}
    {snapshot.ready&&model==='waiting'&&<p className={s.subtitle}>只計已配對案件的經過時間，不是人工工時。</p>}
    {error&&<p role="alert" className={s.error}>{error}</p>}
    {result&&!report&&<p role="status">資料已更新。請重新生成報告。</p>}
    {report&&<article className={s.aiResult} aria-label="AI 管理報告"><h3>改善建議（待驗證）</h3><p>{report.finding}</p><p><strong>先試：</strong>{report.action}</p><p><strong>怎麼驗證：</strong>{report.verification}</p><p className={s.subtitle}>依據：{snapshot.facts.filter(f=>report.factIds.includes(f.id)).map(f=>`${f.label} ${f.value}`).join(' · ')}</p><button onClick={download}>下載管理報告</button></article>}
  </section>;
}
