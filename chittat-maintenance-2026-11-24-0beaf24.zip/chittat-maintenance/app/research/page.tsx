import type { Metadata } from 'next';
import ResearchPanel from './research-panel';
export const metadata: Metadata={title:'研究管理 · 高陞',robots:{index:false,follow:false}};
export default function Page(){ return <ResearchPanel/>; }
