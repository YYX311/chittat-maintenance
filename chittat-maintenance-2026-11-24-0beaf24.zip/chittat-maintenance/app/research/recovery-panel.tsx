'use client';

import {useEffect, useRef, useState} from 'react';
import {sessionFetch} from '../../src/session-fetch';
import type {loadRecovery} from '../../lib/recovery-service';
import styles from './research.module.css';
import frameStyles from './recovery-panel.module.css';

type RecoveryRecord = Awaited<ReturnType<typeof loadRecovery>>['episodes'][number];
const validDay = /^\d{4}-\d{2}-\d{2}$/;
const hkDate = new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Hong_Kong', year:'numeric', month:'2-digit', day:'2-digit'});

export default function RecoveryPanel({studyId, from, to, readOnly}: {
  studyId: string; from: string; to: string; readOnly: boolean;
}) {
  const frame = useRef<HTMLIFrameElement>(null);
  const [html, setHtml] = useState('');
  const [error, setError] = useState('');
  const [retry, setRetry] = useState(0);

  useEffect(() => {
    const controller = new AbortController();
    sessionFetch('/api/research/recovery?view=interface', {signal:controller.signal})
      .then(async response => {
        if (!response.ok) throw Error('interface-unavailable');
        const document = await response.text();
        if (!controller.signal.aborted) setHtml(document);
      })
      .catch(() => {
        if (!controller.signal.aborted) setError('未能載入補填體驗研究。');
      });
    return () => controller.abort();
  }, [retry]);

  useEffect(() => {
    const controller = new AbortController();
    let updating = false;
    async function handleMessage(event: MessageEvent) {
      const target = frame.current?.contentWindow;
      if (!target || event.source !== target || event.origin !== 'null' || !event.data) return;
      const {type, requestId} = event.data;
      const reply = (payload: object) => {
        if (!controller.signal.aborted) target.postMessage({type:'recovery-response', requestId, ...payload}, '*');
      };
      if (type === 'recovery-ready') {
        target.postMessage({type:'recovery-initial', from, to, readOnly}, '*');
      } else if (type === 'recovery-demo-position' && frame.current) {
        const rect = frame.current.getBoundingClientRect();
        target.postMessage({type:'recovery-dialog-viewport', top:Math.max(0,-rect.top) + 12,
          height:Math.max(180, window.innerHeight - Math.max(0,rect.top) - 24)}, '*');
      } else if (type === 'recovery-height') {
        const height = event.data.height;
        if (Number.isFinite(height) && frame.current) {
          frame.current.style.height = `${Math.min(12000, Math.max(560, Math.ceil(height)))}px`;
        }
      } else if (type === 'recovery-data') {
        const {role, from, to} = event.data;
        if (!['office','worker'].includes(role) || typeof from !== 'string' || typeof to !== 'string' ||
          !validDay.test(from) || !validDay.test(to)) return reply({error:'請輸入有效日期。'});
        const query = new URLSearchParams({study:studyId, role, from, to});
        try {
          const response = await sessionFetch('/api/research/recovery?' + query, {signal:controller.signal});
          if (!response.ok) {
            reply({error:response.status === 400 ? '請選擇有效日期，最多 93 天。' : '未能讀取記錄，請重試。'});
            return;
          }
          const data: {episodes: RecoveryRecord[]; enabled: boolean; partial: boolean} = await response.json();
          reply({enabled:data.enabled, partial:data.partial, rows:data.episodes.map(row => ({
            episode:row.episode, date:hkDate.format(new Date(row.at)), at:row.at, role:row.role, person:row.participant,
            variant:row.variant, focused:row.focused, seconds:row.seconds, active:row.activeSeconds,
            score:row.frustration, submitted:row.submitted, left:row.left, offline:row.offline, skipped:row.skipped,
          }))});
        } catch { reply({error:'未能讀取記錄，請重試。'}); }
      } else if (type === 'recovery-configure') {
        if (readOnly || updating || typeof event.data.enabled !== 'boolean') {
          return reply({error:'目前無法更新採集設定。'});
        }
        updating = true;
        try {
          const response = await sessionFetch('/api/research/recovery', {
            method:'POST', headers:{'Content-Type':'application/json'}, signal:controller.signal,
            body:JSON.stringify({action:'configure', studyId, enabled:event.data.enabled}),
          });
          reply(response.ok ? {enabled:event.data.enabled} : {error:'未能更新採集設定。'});
        } catch { reply({error:'未能更新採集設定。'}); }
        finally { updating = false; }
      }
    }
    window.addEventListener('message', handleMessage);
    return () => {
      window.removeEventListener('message', handleMessage);
      controller.abort();
    };
  }, [studyId, from, to, readOnly]);

  if (error) return <p role="alert" className={styles.error}>{error}
    <button onClick={() => { setError(''); setRetry(n => n + 1); }}>重試</button>
  </p>;
  if (!html) return <p role="status">正在載入補填體驗研究…</p>;

  return <iframe ref={frame} title="補填體驗研究" className={frameStyles.frame}
    sandbox="allow-scripts allow-forms allow-downloads allow-modals" srcDoc={html}
    onLoad={() => frame.current?.contentWindow?.postMessage({type:'recovery-initial',from,to,readOnly}, '*')}/>;
}
