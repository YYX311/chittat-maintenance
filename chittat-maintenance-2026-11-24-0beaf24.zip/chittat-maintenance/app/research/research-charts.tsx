'use client';
import {useEffect,useState} from 'react';
import {chartGroups,researchComparison,type GroupRow} from '../../lib/research-chart-data';
import styles from './research.module.css';

type Metric={phase:string;enrolled:number;measured:number;failed:number;incomplete:number};
const phaseName=(phase:string)=>phase==='baseline'?'基線期':'改進期';
const fmt=(value:number)=>value.toLocaleString('zh-HK',{minimumFractionDigits:1,maximumFractionDigits:1});
const statuses={missing:'兩期都有測量後才能比較',method:'選一種測量方式後才能比較',difficulty:'選同一案件難度後才能比較'};

export default function ResearchCharts({rows,metrics}:{rows:GroupRow[];metrics:Metric[]}){
  const [difficulty,setDifficulty]=useState('all'),[method,setMethod]=useState('observed');
  useEffect(()=>{const q=new URLSearchParams(window.location.search);const d=q.get('chartDifficulty')||'all',m=q.get('chartMethod')||'observed';if(['all','low','medium','high'].includes(d))setDifficulty(d);if(['all','observed','self_report'].includes(m))setMethod(m);},[]);
  function filter(key:string,value:string){const u=new URL(window.location.href);u.searchParams.set(key,value);window.history.replaceState(window.history.state,'',u);if(key==='chartDifficulty')setDifficulty(value);else setMethod(value);}
  const coverage=chartGroups(rows,difficulty,'all');
  const hasCases=metrics.some(row=>row.enrolled>0);
  return <section className={styles.card} aria-label="研究可視化">
    <h2>改進前後比較</h2>
    {!hasCases?<p className={styles.muted}>加入案件並記錄人工時間或資料錯漏後，這裡會顯示比較。</p>:<>
      <div className={styles.filterRow}>
        <label>案件難度<select aria-label="圖表案件難度" value={difficulty} onChange={e=>filter('chartDifficulty',e.target.value)}><option value="all">全部難度</option><option value="low">低</option><option value="medium">中</option><option value="high">高</option></select></label>
        <label>測量方式<select aria-label="圖表測量方式" value={method} onChange={e=>filter('chartMethod',e.target.value)}><option value="observed">觀察計時</option><option value="self_report">人員回報</option><option value="all">全部方式</option></select></label>
      </div>
      <div className={styles.chartGrid}>{([{key:'minutes',title:'平均人工時間',unit:'分鐘',count:'timed'},{key:'errors',title:'平均資料錯漏',unit:'項／宗',count:'quality'}] as const).map(metric=>{
        const {groups,status,delta}=researchComparison(rows,difficulty,method,metric.key);
        const max=Math.max(1,...groups.map(group=>group[metric.key]??0));
        return <article key={metric.key} className={styles.chart} aria-label={metric.title}><h3>{metric.title}</h3>
          {groups.map((group,i)=>{const value=group[metric.key],measured=group[metric.count];return <div className={styles.barRow} key={group.phase}>
            <div className={styles.barLabel}><span>{phaseName(group.phase)}</span><strong>{value===null?'尚無數據':`${fmt(value)} ${metric.unit}`}</strong></div>
            {value!==null&&<div className={styles.comparisonBar} aria-hidden="true"><span style={{width:`${100*value/max}%`,background:i===0?'#486478':'#a45131'}}/></div>}
            <small>{metric.count==='timed'?'已計時':'已評分'} {measured} / {coverage[i].total} 宗</small>
          </div>;})}
          <p className={styles.resultLine} aria-label={`${metric.title}比較結果`}>{status!=='comparable'?statuses[status]:delta===0?'兩期平均值相同':Math.abs(delta!)<0.1?`兩期相差不足 0.1 ${metric.unit}`:`改進期比基線期 ${delta!<0?'少':'多'} ${fmt(Math.abs(delta!))} ${metric.unit}`}</p>
        </article>;
      })}</div>
      <div className={`${styles.table} ${styles.progressTable}`}><table><caption>全部案件 · 進度</caption><thead><tr><th>階段</th><th>已納入</th><th>已完成</th><th>未完成</th><th>失敗</th><th>未觀察</th></tr></thead><tbody>{['baseline','improved'].map(phase=>{const m=metrics.find(row=>row.phase===phase);return <tr key={phase}><th scope="row">{phaseName(phase)}</th><td>{m?.enrolled||0}</td><td>{(m?.measured||0)-(m?.incomplete||0)-(m?.failed||0)}</td><td>{m?.incomplete||0}</td><td>{m?.failed||0}</td><td>{(m?.enrolled||0)-(m?.measured||0)}</td></tr>;})}</tbody></table></div>
      <p className={styles.muted}>只用每宗案件最新的測量；差值是描述，不能證明改進造成變化。</p>
    </>}
  </section>;
}
