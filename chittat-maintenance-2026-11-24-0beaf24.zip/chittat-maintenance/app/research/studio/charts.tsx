'use client';
import { useId } from 'react';
import type { Coef } from '../../../lib/research-stats';
import s from '../studio.module.css';

export const pct = (v: number, d = 0) => (Number.isFinite(v) ? `${(v * 100).toFixed(d)}%` : '—');
export const num = (v: number | null | undefined, d = 1) => (v != null && Number.isFinite(v) ? v.toFixed(d) : '—');
export const mins = (v: number) => {
  if (!Number.isFinite(v)) return '—';
  if (v >= 120) return `${(v / 60).toFixed(1)} 小時`;
  if (v > 0 && v < 1) return `${Math.max(1, Math.round(v * 60))} 秒`;
  if (v >= 1 && v < 10) return `${v.toFixed(1)} 分鐘`;
  return `${v.toFixed(0)} 分鐘`;
};
export const pval = (p: number) => (!Number.isFinite(p) ? '—' : p < 0.001 ? '< .001' : p.toFixed(3).replace(/^0/, ''));

/** 水平條形圖（帕累托） */
export function Bars({ rows, color = 'var(--y)', format = (v: number) => String(v), max }: { rows: { label: string; value: number; note?: string }[]; color?: string; format?: (v: number) => string; max?: number }) {
  if (!rows.length) return <p className={s.muted}>尚無資料</p>;
  const peak = max ?? Math.max(1, ...rows.map(r => r.value));
  return <div className={s.bars}>{rows.map(r => <div key={r.label} className={s.barRow}>
    <span className={s.barLabel}>{r.label}{r.note && <small>{r.note}</small>}</span>
    <span className={s.barTrack}><i style={{ width: `${(r.value / peak) * 100}%`, background: color }} /></span>
    <b>{format(r.value)}</b>
  </div>)}</div>;
}

/** 時間分解：一條堆疊條 + 圖例 */
export function Timeline({ segments, total }: { segments: { key: string; label: string; who: string; perCase: number; median: number }[]; total: number }) {
  const colors: Record<string, string> = { fill: 'var(--x)', wait: '#9aa8ae', review: 'var(--y)', rework: 'var(--alert)', office: 'var(--w)' };
  const top = [...segments].sort((a, b) => b.perCase - a.perCase)[0];
  return <div>
    <div className={s.stack} role="img" aria-label="每宗案件平均時間分解">{segments.map(seg => <i key={seg.key} title={`${seg.label} ${mins(seg.perCase)}`} style={{ flex: Math.max(0.0001, seg.perCase), background: colors[seg.key] }} />)}</div>
    <ul className={s.legend}>{segments.map(seg => <li key={seg.key} className={seg.key === top?.key ? s.legendTop : undefined}>
      <span style={{ background: colors[seg.key] }} /><div><b>{seg.label}</b><small>{seg.who} · 中位數 {mins(seg.median)}</small></div>
      <strong>{pct(seg.perCase / total)}</strong>
    </li>)}</ul>
  </div>;
}

/** 折線圖：類別 X 軸，多條序列 */
function niceStep(range: number) {
  const raw = range / 4, mag = 10 ** Math.floor(Math.log10(raw));
  return ([1, 2, 2.5, 5, 10].find(m => m * mag >= raw) ?? 10) * mag;
}

export function LinePlot({ x, series, yMax: rawMax = 1, yMin = 0, yFormat = (v: number) => pct(v), height = 200, yLabel, ticks: customTicks }: { x: string[]; series: { name: string; color: string; values: number[]; dashed?: boolean }[]; yMax?: number; yMin?: number; yFormat?: (v: number) => string; height?: number; yLabel?: string; ticks?: number[] }) {
  const step = customTicks ? 0 : niceStep(rawMax - yMin);
  const yMax = customTicks ? rawMax : yMin + Math.ceil((rawMax - yMin) / step - 1e-9) * step;
  const W = 420, H = height, L = 50, R = 34, T = yLabel ? 30 : 14, B = 34;
  const px = (i: number) => L + 12 + (x.length === 1 ? 0 : (i * (W - L - R - 12)) / (x.length - 1));
  const py = (v: number) => T + (1 - (v - yMin) / (yMax - yMin)) * (H - T - B);
  const ticks = customTicks ?? Array.from({ length: Math.round((yMax - yMin) / step) + 1 }, (_, i) => yMin + i * step);
  return <figure className={s.plot}>
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={series.map(se => se.name).join('、')}>
      {ticks.map(t => <g key={t}><line x1={L} x2={W - R} y1={py(t)} y2={py(t)} className={s.grid} /><text x={L - 6} y={py(t) + 4} textAnchor="end" className={s.tick}>{yFormat(t)}</text></g>)}
      {x.map((label, i) => <text key={label} x={px(i)} y={H - 12} textAnchor={x.length > 2 && i === x.length - 1 ? 'end' : x.length > 2 && i === 0 ? 'start' : 'middle'} dx={x.length > 2 && i === x.length - 1 ? 8 : x.length > 2 && i === 0 ? -8 : 0} className={s.tick}>{label}</text>)}
      {yLabel && <text x={4} y={12} className={s.tick}>{yLabel}</text>}
      {series.map(se => <g key={se.name}>
        <polyline fill="none" stroke={se.color} strokeWidth="2.5" strokeDasharray={se.dashed ? '6 5' : undefined}
          points={se.values.map((v, i) => (Number.isFinite(v) ? `${px(i)},${py(v)}` : '')).filter(Boolean).join(' ')} />
        {se.values.map((v, i) => Number.isFinite(v) && <circle key={i} cx={px(i)} cy={py(v)} r="4" fill="#fff" stroke={se.color} strokeWidth="2.5"><title>{`${se.name} · ${x[i]} · ${yFormat(v)}`}</title></circle>)}
      </g>)}
    </svg>
    <figcaption className={s.seriesKey}>{series.map(se => <span key={se.name}><i style={{ background: se.color }} />{se.name}</span>)}</figcaption>
  </figure>;
}

/** 係數森林圖 */
export function Forest({ coefs, kind }: { coefs: Coef[]; kind: 'ols' | 'logit' }) {
  const rows = coefs.filter(c => c.name !== '截距');
  const lim = Math.max(0.05, ...rows.flatMap(c => [Math.abs(c.lo), Math.abs(c.hi)]).filter(Number.isFinite));
  const W = 300, x = (v: number) => W / 2 + (v / lim) * (W / 2 - 10);
  return <div className={s.forest}>
    <div className={s.forestHead}><span>變量</span><span>{kind === 'logit' ? '對數勝算 β（95% CI）' : '係數 β（95% CI）'}</span><span>{kind === 'logit' ? 'OR' : 'β'}</span><span>p</span></div>
    {rows.map(c => <div key={c.name} className={`${s.forestRow} ${c.p < 0.05 ? s.sig : ''}`}>
      <span>{c.name}</span>
      <svg viewBox={`0 0 ${W} 22`} aria-hidden="true"><line x1={W / 2} x2={W / 2} y1="0" y2="22" className={s.zero} />
        <line x1={x(c.lo)} x2={x(c.hi)} y1="11" y2="11" className={s.ci} /><rect x={x(c.b) - 5} y="6" width="10" height="10" className={s.pt} /></svg>
      <span>{kind === 'logit' ? Math.exp(c.b).toFixed(2) : c.b.toFixed(3)}</span>
      <span>{pval(c.p)}</span>
    </div>)}
  </div>;
}

/** 研究模型路徑圖：X → M → Y，W 調節，T 干預 */
export function ModelDiagram({ labels, plain = false }: { labels?: Partial<Record<'a' | 'b' | 'c' | 'w' | 't', string>>; plain?: boolean }) {
  const arrow = useId();
  const markerEnd = `url(#${arrow})`;
  return <div className={s.diagramWrap}><svg viewBox="0 0 760 250" className={s.diagram} role="img" aria-label="研究模型：數字化摩擦經心智努力影響退回，疲勞調節，核對卡干預">
    <defs><marker id={arrow} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0,0L10,5L0,10z" fill="#46565c" /></marker></defs>
    {([
      [20, 110, plain ? '填表時卡住' : 'X 數字化摩擦', '攔截 · 重填 · 斷線', 'var(--x)'],
      [290, 10, plain ? '填單費不費神' : 'M 心智努力', plain ? '提交後自評（1–9）' : 'Paas 1–9 · 提交後自評', 'var(--m)'],
      [560, 110, plain ? '交接結果' : 'Y 交接質量', '退回 · 修正欄位 · 耗時', 'var(--y)'],
      [290, 185, plain ? '提交時段與感受' : 'W 疲勞', plain ? '當日第幾張 · 自評疲倦' : '當日第 N 張 · 自評 SP', 'var(--w)'],
    ] as const).map(([x, y, t, sub, c]) => <g key={t}>
      <rect x={x} y={y} width="180" height="58" rx="10" fill="#fff" stroke={c} strokeWidth="2" />
      <rect x={x} y={y} width="6" height="58" rx="3" fill={c} />
      <text x={x + 18} y={y + 25} className={s.dTitle}>{t}</text><text x={x + 18} y={y + 44} className={s.dSub}>{sub}</text>
    </g>)}
    <line x1="200" y1="120" x2="290" y2="52" stroke="#46565c" strokeWidth="1.8" markerEnd={markerEnd} />
    <line x1="470" y1="52" x2="558" y2="118" stroke="#46565c" strokeWidth="1.8" markerEnd={markerEnd} />
    <line x1="200" y1="139" x2="556" y2="139" stroke="#46565c" strokeWidth="1.8" markerEnd={markerEnd} />
    <line x1="380" y1="185" x2="380" y2="145" stroke="var(--w)" strokeWidth="2" markerEnd={markerEnd} />
    {!plain && <><text x="196" y="80" className={s.dPath}>H2 a {labels?.a ?? ''}</text>
    <text x="520" y="80" className={s.dPath}>H2 b {labels?.b ?? ''}</text>
    <text x="214" y="131" className={s.dPath}>H1 c′ {labels?.c ?? ''}</text>
    <text x="390" y="170" className={s.dPathW}>H3 調節 {labels?.w ?? ''}</text></>}
    <g><rect x="560" y="10" width="180" height="58" rx="10" fill="var(--t-soft)" stroke="var(--t)" strokeWidth="2" strokeDasharray="5 4" />
      <text x="578" y="35" className={s.dTitle}>{plain ? '提交前的核對提示' : 'T 提交前核對卡'}</text><text x="578" y="54" className={s.dSub}>{plain ? '比較有提示和沒提示' : `微隨機分派 · H4 ${labels?.t ?? ''}`}</text></g>
    <line x1="680" y1="68" x2="680" y2="106" stroke="var(--t)" strokeWidth="1.8" strokeDasharray="5 4" markerEnd={markerEnd} />
  </svg></div>;
}

/** 週趨勢柱 */
export function Trend({ points }: { points: { week: string; fpy: number; n: number; phase: string | null }[] }) {
  const vals = points.map(p => p.fpy).filter(Number.isFinite);
  const floor = Math.max(0, Math.floor((Math.min(1, ...vals) - 0.1) * 10) / 10);
  return <div className={s.trend} aria-label={`縱軸由 ${pct(floor)} 起`}>{points.map(p => <div key={p.week} title={`${p.week} 起一週 · 首次通過率 ${pct(p.fpy)} · ${p.n} 宗`}>
    <em>{pct(p.fpy)}</em>
    <i style={{ height: `${Math.max(4, ((p.fpy - floor) / (1 - floor)) * 100)}%` }} className={p.phase === 'mrt' ? s.trendMrt : s.trendBase} /><small>{p.week.slice(5)}</small>
  </div>)}</div>;
}
