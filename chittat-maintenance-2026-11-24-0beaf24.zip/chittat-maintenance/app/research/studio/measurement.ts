/** The workbench uses everyday labels. The report can show the measurement definitions. */
export const measurementMap = [
  {
    label: '填表時卡在哪裏',
    source: '自動記錄',
    measure: '必填或格式檢查攔截、清空後重填、斷線次數',
    method: '三種次數各自標準化後取平均，形成操作摩擦指數。這是操作受阻的指標，不能直接推斷人的疲勞或能力。',
    events: ['form.validation_block', 'form.field_refill', 'net.offline'],
  },
  {
    label: '交接花了多久、有沒有退回',
    source: '自動記錄',
    measure: '提交、開啟覆核、退回、確認及出單的時間和次數',
    method: '由業務事件計算等待和交接時間，並比對提交及確認時被修改的欄位。',
    events: ['case.submitted', 'case.review_opened', 'case.returned', 'case.confirmed', 'doc.generated'],
  },
  {
    label: '今天做到第幾張',
    source: '由記錄計算',
    measure: '按每天提交的順序，分為前段與後段',
    method: '當日提交序位是工作時段的代理指標，不代表生理疲勞。分析時與問卷自評分開。',
    events: ['case.submitted'],
  },
  {
    label: '核對提示有沒有幫上忙',
    source: '自動記錄',
    measure: '是否被分到提示組、是否使用核對提示、最後有沒有退回',
    method: '在隨機比較階段以原分組比較退回率，包含看到提示後未點擊的回合。',
    events: ['check.assigned', 'check.shown', 'check.go_field', 'check.confirmed'],
  },
  {
    label: '填這張單有多費神、現在有多累',
    source: '抽樣自填',
    measure: '填單費神程度 1–9 分，當下疲倦程度 1–7 分',
    method: '參考 Paas 心智努力與 Samn–Perelli 疲勞自評量表。沒有填答時保留缺值，不用操作記錄補成自評分數。',
    events: ['survey.effort', 'survey.fatigue', 'survey.skipped'],
  },
] as const;
import type { ResearchPhase } from '../../../lib/research-events';

export const phaseLabels: Record<ResearchPhase, string> = {
  baseline: '只記錄日常操作',
  mrt: '比較有提示和沒提示',
  adaptive: '當日後段顯示提示',
};
