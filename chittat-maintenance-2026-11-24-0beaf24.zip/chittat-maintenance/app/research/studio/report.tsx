'use client';

import { useRef, useState } from 'react';
import {
  hypotheses, layerLabels, researchEvents, researchVariables,
} from '../../../lib/research-events';
import {
  pyScript, rScript, verdictLabels, type Analysis, type ResearchDataset,
} from '../../../lib/research-model';
import { Bars, Forest, LinePlot, ModelDiagram, Trend, mins, num, pct, pval } from './charts';
import { measurementMap } from './measurement';
import r from './report.module.css';
import s from '../studio.module.css';

type Snapshot = { a: Analysis; data: ResearchDataset; createdAt: Date };

const modelNames: Record<keyof Analysis['models'], string> = {
  m1: 'M1 · 摩擦與退回',
  m1b: 'M1b · 摩擦與修正欄位數',
  m2a: 'M2a · 摩擦與心智努力',
  m2b: 'M2b · 心智努力與退回',
  m3: 'M3 · 摩擦 × 班次後段',
  m3s: 'M3s · 摩擦 × 自評疲勞',
  m4f: 'M4 · 核對卡主效應',
  m4: 'M4b · 核對卡 × 班次後段',
};
const modelKeys = Object.keys(modelNames) as (keyof typeof modelNames)[];
const themeVariables = [
  '--ink', '--muted', '--soft', '--surface', '--line', '--x', '--m', '--y', '--w', '--t', '--t-soft', '--alert',
];

function saveFile(name: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type: `${type};charset=utf-8` }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function reportStyles(rules: CSSRuleList, classNames: Set<string>): string {
  const collected: string[] = [];
  for (const rule of Array.from(rules)) {
    if (rule instanceof CSSStyleRule) {
      const names = Array.from(rule.selectorText.matchAll(/\.([\w-]+)/g), match => match[1]);
      if (names.some(name => classNames.has(name))) collected.push(rule.cssText);
    } else if (rule instanceof CSSGroupingRule) {
      const nested = reportStyles(rule.cssRules, classNames);
      if (nested) collected.push(`${rule.cssText.slice(0, rule.cssText.indexOf('{'))}{${nested}}`);
    }
  }
  return collected.join('\n');
}

function exportReport(article: HTMLElement) {
  const clone = article.cloneNode(true) as HTMLElement;
  const style = getComputedStyle(article);
  for (const variable of themeVariables) {
    clone.style.setProperty(variable, style.getPropertyValue(variable).trim());
  }

  // Include the styles used by the report and its charts so the file works offline.
  const classNames = new Set([
    ...Array.from(clone.classList),
    ...Array.from(clone.querySelectorAll('[class]')).flatMap(element => Array.from(element.classList)),
  ]);
  const styles = Array.from(document.styleSheets).flatMap(sheet => {
    try { return [reportStyles(sheet.cssRules, classNames)]; }
    catch { return []; } // An unrelated cross-origin stylesheet is inaccessible.
  }).join('\n');

  return `<!doctype html>
<html lang="zh-HK">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'">
<title>數字化交接與疲勞研究報告</title>
<style>
body{margin:0;padding:16px;background:#eef2f8;font:15px/1.55 system-ui,sans-serif}
main{max-width:1080px;margin:auto} *,*::before,*::after{box-sizing:border-box}
${styles}
@media print {body{padding:0;background:white} .${s.diagram}{min-width:0} .${s.diagramWrap}{overflow:visible}}
</style>
</head>
<body><main>${clone.outerHTML}</main></body>
</html>`;
}

function ReportDocument({ snapshot }: { snapshot: Snapshot }) {
  const { a, data, createdAt } = snapshot;
  const { cfg, kpi, attribution, charts, h } = a;
  const capturedAt = createdAt.toLocaleString('zh-HK', { timeZone: 'Asia/Taipei' });
  const eventCounts = new Map(data.events.map(event => [event.name, event.count]));
  const verdicts = { H1: h.H1.v, H2: h.H2.v, H3: h.H3.v, H4: h.H4.main.v };
  const interaction = charts.interaction.flatMap(group => group.points.map(point => point.rate)).filter(Number.isFinite);
  const control = charts.armRates[0];
  const check = charts.armRates[1];
  const armRates = [control.early.rate, control.late.rate, check.early.rate, check.late.rate].filter(Number.isFinite);
  const mainEffect = a.models.m4f?.coefs.find(coef => coef.name === '核對卡');
  const mostIssues = [...attribution.steps].sort((x, y) => y.n - x.n)[0];
  return <>
    <header>
      <h2>數字化交接與疲勞研究報告</h2>
      <p>{data.study.name} · {capturedAt}（UTC+8）</p>
      <p className={r.sourceNote}>業務記錄 · 報告生成時的快照</p>
    </header>

    <section>
      <h3>研究範圍與參數</h3>
      <p>分析單位為維修人員的一次服務單提交，包含補交回合。研究以流程摩擦、主觀心智努力、班次後段及提交前核對卡，檢視退回與交接質量。</p>
      <dl>
        <div><dt>提交日期（香港時間）</dt><dd>{data.scope?.from} 至 {data.scope?.to}</dd></div>
        <div><dt>班次後段門檻</dt><dd>當日第 {cfg.lateTaskThreshold} 張起</dd></div>
        <div><dt>納入提交／員工聚類</dt><dd>{kpi.episodes} ／ {kpi.workers}</dd></div>
        <div><dt>涉及案件</dt><dd>{kpi.cases}</dd></div>
        <div><dt>問卷回應率</dt><dd>{pct(kpi.surveyResponse)}</dd></div>
      </dl>
      <ModelDiagram />
    </section>

    <section>
      <h3>交接流程結果</h3>
      <dl>
        <div><dt>首次通過率</dt><dd>{pct(kpi.fpy, 1)}</dd></div>
        <div><dt>維修部平均修正欄位</dt><dd>{num(kpi.corrected, 2)}</dd></div>
        <div><dt>交接周期中位數</dt><dd>{mins(kpi.cycle)}</dd></div>
      </dl>
      <h4>各環節記錄了多久</h4>
      {attribution.segments.some(segment => segment.n > 0)
        ? <Bars rows={attribution.segments.filter(segment => segment.n > 0).map(segment => ({ label: segment.label, value: segment.median, note: `n=${segment.n}` }))} format={mins} />
        : <p>目前沒有可分解的時間記錄。</p>}
      <h4>退回原因</h4>
      {attribution.reasons.length
        ? <Bars rows={attribution.reasons.map(reason => ({ label: reason.label, value: reason.n }))} color="var(--alert)" />
        : <p>目前沒有退回原因記錄。</p>}
      <h4>按表單步驟統計的問題</h4>
      {attribution.steps.length
        ? <Bars rows={attribution.steps.map(step => ({ label: step.step, value: step.n }))} color="var(--x)" />
        : <p>目前沒有被退回或被修正的欄位記錄。</p>}
      {attribution.fields.length > 0 && <div className={r.tableScroll} role="region" aria-label="問題欄位表" tabIndex={0}>
        <table>
          <caption>問題欄位明細</caption>
          <thead><tr><th scope="col">欄位</th><th scope="col">步驟</th><th scope="col">退回次數</th><th scope="col">修正次數</th></tr></thead>
          <tbody>{attribution.fields.map(field => <tr key={field.field}><th scope="row">{field.label}</th><td>{field.step}</td><td>{field.returned}</td><td>{field.corrected}</td></tr>)}</tbody>
        </table>
      </div>}
      <h4>首次通過率週趨勢</h4>
      {charts.trend.length ? <>
        <Trend points={charts.trend} />
        <p>按首次提交日期分組，僅計入期間內已有確認或退回結果的提交。</p>
      </> : <p>目前沒有週趨勢記錄。</p>}
      {mostIssues?.n > 0 && <>
        <h4>建議核查次序</h4>
        <ul>
          {mostIssues?.n > 0 && <li>優先查看「{mostIssues.step}」的欄位，該步驟記錄 {mostIssues.n} 次退回或修正。</li>}
        </ul>
      </>}
    </section>

    <section>
      <h3>心理測量與解讀</h3>
      <ul>
        {measurementMap.map(item => <li key={item.label}><strong>{item.label}</strong>　{item.source}，對應{item.measure}。{item.method}</li>)}
      </ul>
      <h4>班次前後段的摩擦與退回率</h4>
      {interaction.length ? <LinePlot
        x={['低摩擦', '中摩擦', '高摩擦']}
        yMax={Math.min(1, Math.max(.2, ...interaction) * 1.15)}
        yLabel="退回率"
        series={[
          { name: '班次前段', color: 'var(--y)', values: charts.interaction[0].points.map(p => p.rate) },
          { name: `班次後段（第 ${cfg.lateTaskThreshold} 張起）`, color: 'var(--w)', values: charts.interaction[1].points.map(p => p.rate) },
        ]}
      /> : <p>目前沒有可比較的退回率記錄。</p>}
      <h4>當日提交序位與自評分數</h4>
      {charts.effortBySeq.some(item => Number.isFinite(item.effort) || Number.isFinite(item.fatigue)) ? <LinePlot
        x={charts.effortBySeq.map(item => item.seq === 6 ? '6+' : String(item.seq))}
        yMin={1} yMax={9} ticks={[1, 3, 5, 7, 9]} yFormat={value => String(value)}
        series={[
          { name: '心智努力（1–9）', color: 'var(--m)', values: charts.effortBySeq.map(item => item.effort) },
          { name: '自評疲勞（1–7）', color: 'var(--w)', values: charts.effortBySeq.map(item => item.fatigue), dashed: true },
        ]}
      /> : <p>目前沒有自評記錄。</p>}
      <h4>摩擦程度與平均心智努力</h4>
      {charts.effortByBand.some(item => item.n > 0)
        ? <Bars rows={charts.effortByBand.map((item, index) => ({ label: ['低摩擦', '中摩擦', '高摩擦'][index], value: item.mean, note: `n=${item.n}` })).filter(item => Number.isFinite(item.value))} color="var(--m)" max={9} format={value => num(value, 2)} />
        : <p>目前沒有可比較的心智努力分數。</p>}
      <h4>中介路徑估計</h4>
      <p>a 路徑 {num(h.H2.a?.b, 2)}，b 路徑 {num(h.H2.b?.b, 2)}，間接效應 a×b {num(h.H2.indirect, 2)}。{h.H2.ci ? `95% 聚類自助法區間 [${num(h.H2.ci.lo, 2)}, ${num(h.H2.ci.hi, 2)}]（${h.H2.ci.reps} 次）。` : '目前沒有可用的區間估計。'}</p>
      <p>提交序位只是班次位置的代理。心理負荷及疲勞採用自願回答的單題自評，供群體分析。不同量尺上的原始分數各自解讀。</p>
      <ul>
        <li>Paas（1992），<a href="https://doi.org/10.1037/0022-0663.84.4.429">心智努力自評研究</a>。</li>
        <li>Samn 與 Perelli（1982），<a href="https://ntrs.nasa.gov/api/citations/19830027362/downloads/19830027362.pdf?attachment=true">空勤疲勞技術報告 SAM-TR-82-21 的 NASA 書目記錄</a>。</li>
      </ul>
    </section>

    <section>
      <h3>假設、實驗與回歸結果</h3>
      <ul>{hypotheses.map(item => <li key={item.id}>
        <strong>{item.id} · {item.short}</strong>　{verdictLabels[verdicts[item.id]]}
        <p>{item.text}</p>
        <p><code>{item.model}</code></p>
        {item.id === 'H2' && <p>此狀態對應心智努力與退回的條件關聯（b 路徑）。中介效應另看上一節的 a×b 區間。</p>}
      </li>)}</ul>
      <h4>核對卡微隨機實驗</h4>
      <p>本分析納入階段二已有核對內容、並完成分組的提交節點。對照組 {control.all.n} 次，核對卡組 {check.all.n} 次。後段交互作用評估為「{verdictLabels[h.H4.moderation.v]}」。</p>
      {armRates.length > 0 && <LinePlot
        x={['班次前段', '班次後段']} yMax={Math.min(1, Math.max(.2, ...armRates) * 1.2)} yLabel="退回率"
        series={[
          { name: `對照（n=${control.all.n}）`, color: '#75828b', values: [control.early.rate, control.late.rate], dashed: true },
          { name: `顯示核對卡（n=${check.all.n}）`, color: 'var(--t)', values: [check.early.rate, check.late.rate] },
        ]}
      />}
      {mainEffect && <p>核對卡主效應估計為 {num(mainEffect.b * 100, 1)} 個百分點（95% CI [{num(mainEffect.lo * 100, 1)}, {num(mainEffect.hi * 100, 1)}]）。</p>}
      {a.models.m4f && <div className={r.tableScroll} role="region" aria-label="核對卡模型森林圖" tabIndex={0}>
        <Forest coefs={a.models.m4f.coefs} kind={a.models.m4f.kind} />
      </div>}
      <p>目前採用邏輯回歸與 OLS，以員工聚類穩健標準誤及 t(G−1) 分佈估計不確定性。觀察性比較及中介模型仍依賴資料品質與模型假設，微隨機分派結果只適用於納入的決策點。</p>
      {modelKeys.map(key => {
        const fit = a.models[key];
        return <div key={key}>
          <h4>{modelNames[key]}</h4>
          {fit?.converged ? <>
            <p>n = {fit.n} · 員工聚類 G = {fit.clusters} · {fit.kind === 'logit' ? '邏輯回歸（對數勝算）' : 'OLS'}{fit.r2 != null && ` · R² = ${num(fit.r2, 3)}`}</p>
            <div className={r.tableScroll} role="region" aria-label={modelNames[key]} tabIndex={0}>
              <table>
                <thead><tr><th scope="col">變量</th><th scope="col">係數 β</th><th scope="col">95% CI</th><th scope="col">p 值</th></tr></thead>
                <tbody>{fit.coefs.map(coef => <tr key={coef.name}><th scope="row">{coef.name}</th><td>{num(coef.b, 3)}</td><td>{num(coef.lo, 3)} 至 {num(coef.hi, 3)}</td><td>{pval(coef.p)}</td></tr>)}</tbody>
              </table>
            </div>
          </> : <p>樣本不足或模型無法收斂。</p>}
        </div>;
      })}
    </section>

    <section>
      <h3>資料品質與字典</h3>
      <p>有提交記錄的維修人員 {kpi.workers} 名。報告展示群體匯總。</p>
      <div className={r.tableScroll} role="region" aria-label="事件字典" tabIndex={0}>
        <table>
          <caption>埋點事件及收集狀況</caption>
          <thead><tr><th scope="col">類別</th><th scope="col">事件</th><th scope="col">觸發時機</th><th scope="col">記錄欄位</th><th scope="col">生成變量</th><th scope="col">筆數</th></tr></thead>
          <tbody>{researchEvents.map(event => <tr key={event.name}>
            <td>{layerLabels[event.layer]}</td><th scope="row"><code>{event.name}</code></th>
            <td>{event.trigger}</td><td>{event.payload.join('、') || '—'}</td>
            <td>{event.feeds.join('、')}</td><td>{eventCounts.get(event.name) ?? '—'}</td>
          </tr>)}</tbody>
        </table>
      </div>
      <div className={r.tableScroll} role="region" aria-label="變量字典" tabIndex={0}>
        <table>
          <caption>分析變量定義</caption>
          <thead><tr><th scope="col">變量</th><th scope="col">名稱</th><th scope="col">類型</th><th scope="col">定義</th></tr></thead>
          <tbody>{researchVariables.map(variable => <tr key={variable.key}>
            <th scope="row"><code>{variable.key}</code></th><td>{variable.label}</td><td>{variable.type}</td><td>{variable.def}</td>
          </tr>)}</tbody>
        </table>
      </div>
    </section>
  </>;
}

export function ResearchReport({ a, data }: { a: Analysis; data: ResearchDataset }) {
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const article = useRef<HTMLElement>(null);
  const stale = !!snapshot && snapshot.data !== data;

  function download() {
    if (!snapshot || !article.current) return;
    const day = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Taipei', dateStyle: 'short' }).format(snapshot.createdAt);
    const filename = `research-report-${day}.html`;
    saveFile(filename, exportReport(article.current), 'text/html');
  }

  return <>
    <section className={s.card} aria-label="報告操作">
      <h2>生成研究報告</h2>
      <p className={s.muted}>按目前已儲存的參數與資料，整理圖表、研究方法及統計明細。</p>
      <div className={s.exports}>
        <button className={s.primary} onClick={() => setSnapshot({ a, data, createdAt: new Date() })}>
          {snapshot ? '重新生成報告' : '生成報告'}
        </button>
        {snapshot && <button className={s.ghost} disabled={stale} onClick={download}>下載 HTML 報告</button>}
      </div>
      {stale && <p role="status">資料或參數已更新。請重新生成報告。</p>}
      <details className={s.method}>
        <summary>分析腳本與字典</summary>
        <div className={s.exports}>
          <button className={s.ghost} onClick={() => saveFile('analysis.R', rScript, 'text/plain')}>R 分析腳本</button>
          <button className={s.ghost} onClick={() => saveFile('analysis.py', pyScript, 'text/plain')}>Python 分析腳本</button>
          <button className={s.ghost} onClick={() => saveFile('research-events.json', JSON.stringify({ events: researchEvents, variables: researchVariables }, null, 2), 'application/json')}>下載字典 JSON</button>
        </div>
      </details>
    </section>
    {snapshot && !stale && <article ref={article} className={r.document} aria-label="研究報告預覽">
      <ReportDocument snapshot={snapshot} />
    </article>}
  </>;
}
