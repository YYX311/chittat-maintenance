'use client';
import { verdictLabels, toCsv, type Analysis, type ResearchDataset, type Verdict } from '../../../lib/research-model';
import { measurementMap } from './measurement';
import { Bars, Forest, LinePlot, ModelDiagram, Trend, mins, num, pct } from './charts';
import s from '../studio.module.css';

export type Tab = 'design' | 'attribution' | 'psych' | 'experiment' | 'data' | 'report';
export const analysisTabs = [
  { id: 'attribution', name: '交接與退回' },
  { id: 'psych', name: '填單感受' },
  { id: 'experiment', name: '核對提示' },
] as const;

const Badge = ({ v }: { v: Verdict }) => <span className={`${s.badge} ${s['v_' + v]}`}>{verdictLabels[v]}</span>;
function download(name: string, text: string, type = 'text/plain') {
  const url = URL.createObjectURL(new Blob(['\ufeff' + text], { type: `${type};charset=utf-8` }));
  const a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 5000);
}

/* ============================ 1. 研究設計 ============================ */
export function DesignView({ a, onOpen }: { a: Analysis; onOpen: (t: Tab) => void }) {
  const { kpi } = a;
  return <>
    <header className={s.pageTitle}>
      <div>
        <h2>交接概況</h2>
        <p className={s.muted}>{kpi.episodes} 次提交 · {kpi.workers} 名維修人員</p>
      </div>
      <button className={s.ghost} onClick={() => onOpen('data')}>查看資料記錄</button>
    </header>

    <section className={s.kpis} aria-label="關鍵指標">
      <article><span>首次通過率</span><strong>{kpi.firstDecided ? pct(kpi.fpy, 1) : '尚無資料'}</strong><small>已處理的首次提交 · {kpi.firstDecided} 筆</small></article>
      <article><span>維修部平均修正</span><strong>{Number.isFinite(kpi.corrected) ? num(kpi.corrected, 2) : '尚無資料'}</strong><small>每張有快照的確認單 · 基本資料</small></article>
      <article><span>交接周期中位數</span><strong>{Number.isFinite(kpi.cycle) ? mins(kpi.cycle) : '尚無資料'}</strong><small>提交 → 維修部確認</small></article>
      <article><span>提示比較樣本</span><strong>{kpi.decisionPoints || '尚無資料'}</strong><small>已分組並有處理結果的提交</small></article>
      <article><span>問卷回應率</span><strong>{Number.isFinite(kpi.surveyResponse) ? pct(kpi.surveyResponse) : '尚無資料'}</strong><small>抽樣問卷的填答比例</small></article>
    </section>

    <section className={s.card}>
      <header className={s.cardHead}><h3>研究模型與待驗證關係</h3></header>
      <ModelDiagram plain />
    </section>
  </>;
}

/* ============================ 2. 流程歸因 ============================ */
export function AttributionView({ a }: { a: Analysis }) {
  const { segments, reasons, steps } = a.attribution;
  return <>
    <section className={s.card}>
      <header className={s.cardHead}><h3>各環節記錄了多久</h3></header>
      <Bars rows={segments.filter(segment => segment.n > 0).map(segment => ({ label: segment.label, value: segment.median, note: `n=${segment.n}` }))} format={mins} />
      <p className={s.muted}>各環節顯示有記錄的中位數。等待及補交時間按事件間隔計算。</p>
    </section>
    <div className={s.cols}>
      <section className={s.card}>
        <header className={s.cardHead}><h3>常見退回原因</h3><span className={s.muted}>按退回時的記錄統計</span></header>
        <Bars rows={reasons.map(r => ({ label: r.label, value: r.n }))} color="var(--alert)" />
      </section>
      <section className={s.card}>
        <header className={s.cardHead}><h3>問題集中在表單哪一步</h3><span className={s.muted}>退回欄位 + 維修部修正欄位</span></header>
        <Bars rows={steps.map(x => ({ label: x.step, value: x.n }))} color="var(--x)" />

      </section>
    </div>
    <section className={s.card}>
      <header className={s.cardHead}><h3>首次通過率 · 週趨勢</h3></header>
      <Trend points={a.charts.trend} />
      <p className={s.muted}>按首次提交的日期分組，僅計入期間內已有確認或退回結果的提交。</p>
    </section>
  </>;
}

/* ============================ 3. 心理 × 流程 ============================ */
export function PsychView({ a }: { a: Analysis }) {
  const { charts } = a;
  const bands = ['較少卡住', '偶爾卡住', '較常卡住'];
  return <>
    <div className={s.cols}>
      <section className={s.card}>
        <h3>操作受阻與退回率</h3>
        {charts.interaction.some(group => group.points.some(point => point.n > 0)) ? <LinePlot x={bands} yMax={Math.max(0.2, ...charts.interaction.flatMap(l => l.points.map(p => p.rate)).filter(Number.isFinite)) * 1.15}
          series={[
            { name: `班次前段（當日第 1–${a.cfg.lateTaskThreshold - 1} 張）`, color: 'var(--y)', values: charts.interaction[0].points.map(p => p.rate) },
            { name: `班次後段（第 ${a.cfg.lateTaskThreshold} 張起）`, color: 'var(--w)', values: charts.interaction[1].points.map(p => p.rate) },
          ]} yLabel="退回率" /> : <p>尚無可比較的操作受阻記錄。</p>}
        <p className={s.muted}>以當日提交順序分組，反映作業時段。</p>
      </section>
      <section className={s.card}>
        <h3>當日第幾張服務單與填單感受</h3>
        {charts.effortBySeq.some(point => Number.isFinite(point.effort) || Number.isFinite(point.fatigue)) ? <LinePlot x={charts.effortBySeq.map(p => (p.seq === 6 ? '6+' : String(p.seq)))} yMin={1} yMax={9} ticks={[1, 3, 5, 7, 9]} yFormat={v => v.toFixed(0)}
          series={[{ name: '填單費神程度（1–9）', color: 'var(--m)', values: charts.effortBySeq.map(p => p.effort) },
            { name: '自評有多累（1–7）', color: 'var(--w)', values: charts.effortBySeq.map(p => p.fatigue), dashed: true }]} /> : <p>尚無自評問卷資料。</p>}
        <p className={s.muted}>此圖使用與提交回合配對的自評問卷。</p>
      </section>
      <section className={s.card}>
        <h3>操作受阻與填單費神程度</h3>
        <Bars rows={charts.effortByBand.map((b, i) => ({ label: bands[i], value: b.mean, note: `n=${b.n}` })).filter(row => Number.isFinite(row.value))} color="var(--m)" max={9} format={v => num(v, 2)} />
      </section>
    </div>
  </>;
}

/* ============================ 4. 實驗與回歸 ============================ */
export function ExperimentView({ a }: { a: Analysis }) {
  const { armRates } = a.charts, ctl = armRates[0], chk = armRates[1];
  const main = a.models.m4f?.coefs.find(c => c.name === '核對卡'), mod = a.models.m4?.coefs.find(c => c.name === '核對×後段');
  return <>
    <section className={s.card}>
      <header className={s.cardHead}><h3>有提示和沒提示，退回率有甚麼差別？</h3><span className={s.muted}>{a.mrtRows.length} 筆可比較的提交</span></header>
      <div className={s.mrt}>
        {a.mrtRows.length > 0 ? <LinePlot x={['當日前段', '當日後段']} yMax={Math.max(0.2, ...[ctl.early.rate, ctl.late.rate, chk.early.rate, chk.late.rate].filter(Number.isFinite)) * 1.2}
          series={[{ name: `對照（n=${ctl.all.n}）`, color: '#8b979c', values: [ctl.early.rate, ctl.late.rate], dashed: true },
            { name: `顯示核對卡（n=${chk.all.n}）`, color: 'var(--t)', values: [chk.early.rate, chk.late.rate] }]} yLabel="退回率" /> : <p>尚無可比較的核對提示分組資料。</p>}
        <div className={s.mrtStats}>
          <div><span>整體退回率差異</span><b>{main ? `${(main.b * 100).toFixed(1)} 個百分點` : '—'}</b><Badge v={a.h.H4.main.v} /></div>
          <div><span>當日後段的額外差異</span><b>{mod ? `${(mod.b * 100).toFixed(1)} 個百分點` : '—'}</b><Badge v={a.h.H4.moderation.v} /></div>
        </div>
      </div>
    </section>
    {a.models.m4f && <section className={s.card}>
      <h3>哪些因素與退回有關</h3>
      <Forest coefs={a.models.m4f.coefs} kind={a.models.m4f.kind} />
      <p className={s.muted}>點代表估計值，橫線代表 95% 信賴區間。各模型的定義與數值可在報告查看。</p>
    </section>}
  </>;
}

/* ============================ 5. 數據與埋點 ============================ */
export function DataView({ a, data }: { a: Analysis; data: ResearchDataset }) {
  const health = new Map(data.events.map(event => [event.name, event.count]));
  const fillMissing = a.rows.length ? a.rows.filter(row => row.fillActiveMin == null).length / a.rows.length : NaN;
  return <>
    <header className={s.pageTitle}><div>
      <h2>資料記錄</h2>
      <p className={s.muted}>已授權員工使用系統時自動記錄操作。以下按所選期間統計。</p>
    </div></header>
    <section className={s.card}>
      <h3>數據品質</h3>
      <dl className={s.quality}>
        <div><dt>問卷回應率</dt><dd>{Number.isFinite(a.kpi.surveyResponse) ? pct(a.kpi.surveyResponse) : '尚無資料'}</dd></div>
        <div><dt>缺少填寫時間</dt><dd>{Number.isFinite(fillMissing) ? pct(fillMissing, 1) : '尚無資料'}</dd></div>
        <div><dt>有提交記錄的人數</dt><dd>{a.kpi.workers}</dd></div>
      </dl>
      <p className={s.muted}>匯出檔以代號標示案件和人員，內容為交接時間、狀態和欄位分類。</p>
    </section>
    <section className={s.card}>
      <header className={s.cardHead}>
        <h3>記錄了甚麼</h3>
        <button className={s.ghost} onClick={() => download(`episodes-${new Date().toISOString().slice(0, 10)}.csv`, toCsv(a.rows), 'text/csv')}>匯出分析資料 CSV（{a.rows.length} 行）</button>
      </header>
      <ul className={s.measurements}>
        {measurementMap.map(item => {
          const count = item.events.reduce((sum, name) => sum + (health.get(name) ?? 0), 0);
          return <li key={item.label}>
            <div><strong>{item.label}</strong><p>{item.measure}</p></div>
            <div><span>{item.source}</span><small>{count ? count + ' 筆記錄' : '尚無資料'}</small></div>
          </li>;
        })}
      </ul>
      <p className={s.muted}>一個提交可產生多筆記錄。埋點筆數包含期間內尚未提交的表單。匯出按提交回合整理，未量測的欄位留空。</p>
    </section>
  </>;
}
