'use client';
import {useState} from 'react';
import {defaultTelemetryGroups,telemetryGroups} from '../../lib/telemetry-catalog';
import styles from './research.module.css';
import s from './field-study-dashboard.module.css';

const stages=[
  {id:'capture',name:'填寫及儲存',roles:'維修員／維修部',signals:'畫面活動、欄位清空、快速連點、儲存與相片請求',why:'定位需要反覆操作的畫面，分清填寫活動和系統等待。清空只表示改過欄位。'},
  {id:'submit',name:'核對及提交',roles:'維修員',signals:'欄位攔截、提示曝光／點擊、提交結果',why:'看哪個必填項擋住提交，以及提示是否有人用。點擊前往不表示已改妥。'},
  {id:'review',name:'覆核及補交',roles:'維修部 ↔ 維修員',signals:'開始覆核、退回原因、再次提交、確認時間',why:'同一案件串起交接，可計算首次退回率、補交次數和交接歷時。'},
  {id:'output',name:'確認及生成文件',roles:'維修部',signals:'確認、生成請求耗時與結果',why:'分辨案件已確認與文件生成失敗；只計系統可見的請求。'},
] as const;

export default function TelemetrySettings({version,enabled,disabled,onSave}:{version:number;enabled:string[];disabled:boolean;onSave:(enabled:string[])=>void}){
  const [editing,setEditing]=useState(false),[chosen,setChosen]=useState(enabled);
  const [step,setStep]=useState(0);
  const active=stages[step];
  return <section className={s.card} aria-label="操作記錄類型"><h2>工作流埋點</h2>
    <p className={styles.muted}>按案件代號串接時間與動作，只記錄操作類別、結果和耗時。</p>
    <ol className={s.workflowSteps}>{stages.map((stage,i)=><li key={stage.id}>
      <button type="button" aria-pressed={step===i} aria-controls="workflow-point" onClick={()=>setStep(i)}>
        <small>{String(i+1).padStart(2,'0')} · {stage.roles}</small><strong>{stage.name}</strong>
      </button></li>)}</ol>
    <article id="workflow-point" className={s.pointDetail}><strong>記錄：{active.signals}</strong><p>{active.why}</p>
      {active.id==='capture'&&<p className={styles.muted}>連線中斷／恢復和至少 1.5 秒的請求也會記錄。畫面活動排除背景分頁，閒置最多計 30 秒。</p>}
      {active.id==='review'&&<p className={styles.muted}>交接歷時包含等候。心累程度只取本人選填回報，不能由操作次數推定。</p>}
    </article>
    <p className={styles.muted}>目前啟用 {enabled.length} / {telemetryGroups.length} 類操作 · 第 {version} 版</p>
    {!editing?<button disabled={disabled} onClick={()=>setEditing(true)}>調整記錄類型</button>:<form onSubmit={e=>{e.preventDefault();onSave(chosen);}}>
      <p>只影響往後的操作記錄，案件交接紀錄和已有數據會保留。</p>
      <div className={styles.grid}>{(['worker','office'] as const).map(side=><fieldset key={side}><legend>{side==='worker'?'維修師傅端':'辦公室端'}</legend>{telemetryGroups.filter(group=>group.role===side).map(group=><label className={styles.check} key={group.id}><input type="checkbox" checked={chosen.includes(group.id)} onChange={e=>setChosen(e.target.checked?[...chosen,group.id]:chosen.filter(id=>id!==group.id))}/><span>{group.title}<br/><small>{group.examples}</small></span></label>)}</fieldset>)}</div>
      <button disabled={disabled}>保存設定</button><button type="button" disabled={disabled} onClick={()=>setChosen([...defaultTelemetryGroups])}>選用預設</button><button type="button" onClick={()=>{setChosen(enabled);setEditing(false);}}>取消</button>
    </form>}
  </section>;
}
