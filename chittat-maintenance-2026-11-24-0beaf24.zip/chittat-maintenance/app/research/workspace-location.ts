export const mainSections = [
  {id:'overview',name:'總覽',description:'看最近的工作量、交接進度和操作'},
  {id:'analysis',name:'分析',description:'從操作訊號看影響，再找出值得改的地方'},
  {id:'settings',name:'研究設定',description:'查看記錄口徑、匯出資料和安排試行'},
] as const;
export const settingsSections = [
  {id:'points',name:'工作流埋點'},
  {id:'exports',name:'資料表'},
  {id:'trial',name:'防錯提示試行'},
] as const;
export type AnalysisEntry='context'|'handoff'|'report';
type AnalysisView=AnalysisEntry|'recovery'|'compare'|'cases'|'ai'|'field-ai';
type CaseParent='cases'|'report'|'handoff';
export type Location = {area:'overview';view?:'diagnostics'} |
  {area:'analysis';view:AnalysisView;caseId?:string;parent?:CaseParent} |
  {area:'settings';view:typeof settingsSections[number]['id']};
export const defaultLocation:Location={area:'overview'};
const analysisViews=['recovery','context','handoff','report','compare','cases','field-ai','ai'] as const;

export function readLocation(query:URLSearchParams):Location {
  const section=query.get('section'),view=query.get('view');
  if(section==='settings')return {area:'settings',view:settingsSections.find(s=>s.id===view)?.id??'points'};
  if(section==='analysis'){
    const selected=analysisViews.find(id=>id===view)??'context';
    const id=query.get('case');
    const from=query.get('fromView');
    return selected==='cases'&&id&&/^[\w-]{1,100}$/.test(id)
      ?{area:'analysis',view:selected,caseId:id,parent:from==='report'||from==='handoff'?from:'cases'}
      :{area:'analysis',view:selected};
  }
  return view==='diagnostics'?{area:'overview',view:'diagnostics'}:defaultLocation;
}

export function locationHref(next:Location,query=new URLSearchParams()){
  const q=new URLSearchParams(query);
  for(const key of ['section','view','case','fromView'])q.delete(key);
  if(next.area!=='overview')q.set('section',next.area);
  if(next.view)q.set('view',next.view);
  if(next.area==='analysis'&&next.view==='cases'&&next.caseId){
    q.set('case',next.caseId);
    if(next.parent&&next.parent!=='cases')q.set('fromView',next.parent);
  }
  return '/research'+(q.size?`?${q}`:'');
}

export function activeAnalysis(location:Location):AnalysisEntry {
  if(location.area!=='analysis')return 'context';
  if(location.view==='context'||location.view==='recovery')return 'context';
  if(location.view==='report'||location.view==='field-ai'||location.view==='ai'||location.parent==='report')return 'report';
  return 'handoff';
}

export function parentLocation(location:Location):{name:string;target:Location}|undefined {
  if(location.area==='overview'&&location.view==='diagnostics')return {name:'總覽',target:defaultLocation};
  if(location.area!=='analysis')return;
  if(location.view==='recovery')return {name:'總覽',target:defaultLocation};
  if(location.view==='ai')return {name:'AI 改善助手',target:{area:'analysis',view:'field-ai'}};
  if(location.view==='field-ai'||location.parent==='report')return {name:'改進建議',target:{area:'analysis',view:'report'}};
  if(location.caseId&&location.parent!=='handoff')return {name:'案件列表',target:{area:'analysis',view:'cases'}};
  if(location.view==='cases'||location.view==='compare')return {name:'多因素分析',target:{area:'analysis',view:'handoff'}};
}
