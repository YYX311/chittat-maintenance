import { redirect } from "next/navigation";

export default function WorkflowGuide() {
  redirect("/workflow-guide.html");
}
