import { env } from "cloudflare:workers";

export async function loadPdfAssets() {
  const load = async (pathname: string) => {
    const response = await env.ASSETS.fetch(new Request(`https://assets.internal${pathname}`));
    if (!response.ok) throw new Error(`pdf-asset-unavailable: ${pathname}`);
    return Buffer.from(await response.arrayBuffer());
  };
  const [font, logo] = await Promise.all([load("/pdf-assets/NotoSansHK.ttf"), load("/brand-logo.png")]);
  return { font, logo };
}
