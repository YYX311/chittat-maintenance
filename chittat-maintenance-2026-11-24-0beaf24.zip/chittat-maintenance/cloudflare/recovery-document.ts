/// <reference types="vite/client" />
import document from '../docs/recovery-study-supplied.html?raw';

export async function readRecoveryDocument() {
  return document;
}
