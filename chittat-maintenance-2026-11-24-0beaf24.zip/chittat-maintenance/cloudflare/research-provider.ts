import { env } from 'cloudflare:workers';
import { researchModel,researchModelInput,researchResponseText } from '../lib/research-ai';
export function researchAiAvailable(){return (env as typeof env & {RESEARCH_AI_ENABLED?:string}).RESEARCH_AI_ENABLED==='1'&&!!env.AI;}
export async function invokeResearchAi(evidence:string,prompt?:string):Promise<string>{
  if(!researchAiAvailable())throw new Error('ai-not-configured');
  let timer:ReturnType<typeof setTimeout>|undefined;
  try {
    const result=await Promise.race([
      env.AI.run(researchModel,researchModelInput(evidence,prompt)),
      new Promise<never>((_,reject)=>{timer=setTimeout(()=>reject(new Error('ai-timeout')),20000);})
    ]);
    return researchResponseText(result);
  }finally{clearTimeout(timer);}
}
