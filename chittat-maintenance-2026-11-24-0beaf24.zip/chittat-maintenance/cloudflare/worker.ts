import handler from "vinext/server/fetch-handler";
import { withDatabaseRequest } from "./db";

export default {
  fetch(request: Request, env: unknown, ctx: { waitUntil: (promise: Promise<unknown>) => void }) {
    return withDatabaseRequest(() => handler.fetch(request, env, ctx), promise => ctx.waitUntil(promise));
  },
};
