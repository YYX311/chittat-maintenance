import { auth } from "./auth";
import { db } from "./db";

export type StaffRole = "worker" | "office" | "manager";
export type Staff = {
  userId: string;
  staffCode: string;
  phone: string;
  email: string;
  name: string;
  role: StaffRole;
  canWork?: boolean;
};

export async function getStaff(request: Request): Promise<Staff | null> {
  const headers = new Headers(request.headers);
  if (headers.has("authorization")) headers.delete("cookie");
  const session = await auth.api.getSession({ headers });
  if (!session) return null;
  const { rows } = await db().query<{
    user_id: string; staff_code: string; phone_number: string; email: string; name: string; role: StaffRole; can_work: boolean;
  }>(`SELECT e.user_id, e.staff_code, u."phoneNumber" AS phone_number, u.email, u.name, e.role, e.can_work
      FROM employees e JOIN "user" u ON u.id = e.user_id
      WHERE e.user_id = $1 AND e.active = TRUE`, [session.user.id]);
  const found = rows[0];
  return found ? {
    userId: found.user_id,
    staffCode: found.staff_code,
    phone: found.phone_number,
    email: found.email,
    name: found.name,
    role: found.can_work && headers.get("x-workspace-role") === "worker" ? "worker" : found.role,
    canWork: found.can_work,
  } : null;
}

export function office(staff: Staff): boolean {
  return staff.role === "office" || staff.role === "manager";
}

export async function listStaff(client: Pick<ReturnType<typeof db>, "query">, staff: Staff) {
  if (staff.role !== "manager") throw new Error("forbidden");
  const { rows } = await client.query(`SELECT e.staff_code, e.role, e.active, u.name, u."phoneNumber" AS phone
    FROM employees e JOIN "user" u ON u.id=e.user_id ORDER BY e.staff_code`);
  return rows;
}
