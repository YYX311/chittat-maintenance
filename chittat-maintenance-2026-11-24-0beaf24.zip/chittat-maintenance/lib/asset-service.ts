import { createHash, randomUUID } from "node:crypto";
import { canEdit, canSee, type CaseRecord } from "./case-rules";
import type { Staff } from "./access";
import type { ObjectStore } from "./object-storage";
import type { Queryable } from "./case-service";

export type AssetRow = {
  key: string; case_id: string; object_key: string; content_type: string; byte_size: number;
};

const imageTypes: Record<string, number[]> = {
  "image/jpeg": [0xff, 0xd8, 0xff],
  "image/png": [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a],
  "image/webp": [0x52, 0x49, 0x46, 0x46],
};

export function validImage(bytes: Uint8Array, contentType: string): boolean {
  const magic = imageTypes[contentType];
  return Boolean(magic && magic.every((value, index) => bytes[index] === value) &&
    (contentType !== "image/webp" || String.fromCharCode(...bytes.slice(8, 12)) === "WEBP"));
}

export async function saveImage(client: Queryable, store: ObjectStore, staff: Staff,
  caseId: string, bytes: Uint8Array, contentType: string): Promise<AssetRow> {
  if (bytes.length === 0 || bytes.length > 20 * 1024 * 1024 || !validImage(bytes, contentType)) throw new Error("invalid-image");
  const { rows } = await client.query("SELECT data, row_version FROM cases WHERE id=$1 AND deleted_at IS NULL", [caseId]);
  if (!rows.length) throw new Error("not-found");
  const record: CaseRecord = { ...rows[0].data, serverVersion: rows[0].row_version };
  if (!canEdit(staff, record)) throw new Error("forbidden");
  const key = randomUUID();
  const objectKey = `cases/${caseId}/${key}`;
  const asset: AssetRow = { key, case_id: caseId, object_key: objectKey, content_type: contentType, byte_size: bytes.length };
  await store.put(objectKey, bytes, contentType);
  await client.query(`INSERT INTO assets(key, case_id, uploaded_by, object_key, content_type, byte_size, sha256)
    VALUES ($1,$2,$3,$4,$5,$6,$7)`, [key, caseId, staff.userId, objectKey, contentType, bytes.length,
    createHash("sha256").update(bytes).digest("hex")]);
  return asset;
}

export async function readAsset(client: Queryable, store: ObjectStore, staff: Staff, key: string): Promise<{ asset: AssetRow; bytes: Uint8Array }> {
  const { rows } = await client.query(`SELECT a.key,a.case_id,a.object_key,a.content_type,a.byte_size,c.data
    FROM assets a JOIN cases c ON c.id=a.case_id WHERE a.key=$1 AND c.deleted_at IS NULL`, [key]);
  if (!rows.length) throw new Error("not-found");
  if (!canSee(staff, rows[0].data)) throw new Error("not-found");
  const { data: _data, ...asset } = rows[0];
  return { asset, bytes: await store.get(asset.object_key) };
}

export async function saveGeneratedAsset(client: Queryable, store: ObjectStore, staff: Staff,
  caseId: string, bytes: Uint8Array, contentType: string): Promise<AssetRow> {
  if (!bytes.length || bytes.length > 20 * 1024 * 1024 || contentType !== "application/pdf") throw new Error("invalid-document");
  const key = randomUUID();
  const objectKey = `cases/${caseId}/${key}`;
  const asset: AssetRow = { key, case_id: caseId, object_key: objectKey, content_type: contentType, byte_size: bytes.length };
  await store.put(objectKey, bytes, contentType);
  await client.query(`INSERT INTO assets(key, case_id, uploaded_by, object_key, content_type, byte_size, sha256)
    VALUES ($1,$2,$3,$4,$5,$6,$7)`, [key, caseId, staff.userId, objectKey, contentType, bytes.length,
    createHash("sha256").update(bytes).digest("hex")]);
  return asset;
}
