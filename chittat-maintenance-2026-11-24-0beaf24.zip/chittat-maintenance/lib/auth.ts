import { betterAuth } from "better-auth";
import { phoneNumber, bearer } from "better-auth/plugins";
import { db } from "./db";

const localPort = new URL(process.env.BETTER_AUTH_URL || "http://localhost:3000").port;
const developmentOrigins = String(process.env.DEV_ALLOWED_ORIGINS || "").split(",").map(value=>value.trim()).filter(Boolean);

export const auth = betterAuth({
  database: db(),
  baseURL: process.env.BETTER_AUTH_URL || (process.env.NODE_ENV === "production" ? undefined : "http://localhost:3000"),
  trustedOrigins: process.env.NODE_ENV === "production" ? [] : [`http://localhost:${localPort}`, `http://127.0.0.1:${localPort}`, ...developmentOrigins],
  emailAndPassword: { enabled: true, disableSignUp: true },
  disabledPaths: [
    "/sign-up/email",
    "/sign-in/email",
    "/phone-number/send-otp",
    "/phone-number/verify",
    "/phone-number/request-password-reset",
    "/phone-number/reset-password",
    "/update-user",
  ],
  plugins: [bearer({ requireSignature: true }), phoneNumber({ sendOTP: () => { throw new Error("OTP is not configured"); } })],
  // Shared office networks must not exhaust the session-read budget together.
  // Password attempts remain bounded separately from session reads.
  rateLimit: { enabled: true, window: 60, max: 120, customRules: {
    "/get-session": false,
    "/sign-in/phone-number": { window: 60, max: 30 },
  } },
  advanced: {
    database: { validateSchema: false },
    // Only the Worker deployment trusts this header, which Cloudflare overwrites.
    ...(process.env.CLOUDFLARE_WORKER === "1" ? { ipAddress: { ipAddressHeaders: ["cf-connecting-ip"] } } : {}),
  },
});
