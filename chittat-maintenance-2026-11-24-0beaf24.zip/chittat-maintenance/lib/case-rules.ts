import {validQuantity,validMoney} from "../src/numeric-rules.js";
import {requiredIssues} from "../src/required-fields.js";
import {validDiscount, discount} from "../src/commercial-totals.js";
import type { Staff } from "./access";

export type CaseRecord = Record<string, any> & {
  id: string;
  source: "worker" | "office";
  status: string;
  owner: string;
  items: Record<string, any>[];
  photos: Record<string, any>[];
};

const commonFields = [
  "date", "address", "tower", "floor", "flat", "customerType", "customer", "contact",
  "occupant", "phone", "contractRef", "brand", "coverage", "coverageNotes", "material",
  "notes", "startedAt", "completedAt", "serviceRemark1", "serviceRemark2", "serviceRemark3",
];
const officeFields = [
  "projectId", "projectName", "projectCode", "remark", "remarkTemplate", "paymentTerms", "ledger",
  "invoiceDate", "invoiceRef", "coverage", "coverageNotes",
];

export function canSee(staff: Staff, record: CaseRecord): boolean {
  return staff.role !== "worker" || record.owner === staff.email;
}

export function canEdit(staff: Staff, record: CaseRecord): boolean {
  if (!canSee(staff, record)) return false;
  return staff.role === "worker"
    ? ["editing", "needsInfo"].includes(record.status)
    : ["submitted", "needsInfo", "draft", "revision"].includes(record.status);
}

function cleanText(value: unknown, field: string): string {
  if (typeof value !== "string" || value.length > 4000) throw new Error(`invalid-${field}`);
  return value;
}

function cleanItems(value: unknown, original: CaseRecord | null, staff: Staff) {
  if (!Array.isArray(value) || value.length > 50) throw new Error("invalid-items");
  return value.map((raw) => {
    if (!raw || typeof raw !== "object") throw new Error("invalid-item");
    const item = raw as Record<string, unknown>;
    const id = cleanText(item.id, "item-id");
    if (!id || id.length > 100) throw new Error("invalid-item-id");
    const old = original?.items.find((entry) => entry.id === id);
    const next: Record<string, unknown> = { id };
    for (const field of ["description", "model", "brand", "unit", "reference"]) {
      next[field] = cleanText(item[field] ?? "", field);
    }
    const preset = Number(item.preset);
    const qty = Number(item.qty);
    if (!Number.isInteger(preset) || preset < 0 || preset > 14 || !validQuantity(item.qty)) {
      throw new Error("invalid-item-values");
    }
    next.preset = preset;
    next.qty = qty;
    if (staff.role === "worker") next.price = old?.price ?? "";
    else {
      const price = item.price === "" || item.price == null ? "" : Number(item.price);
      if (price !== "" && !validMoney(item.price)) throw new Error("invalid-price");
      next.price = price;
    }
    return next;
  });
}

export function editableCopy(original: CaseRecord, incoming: Record<string, unknown>, staff: Staff): CaseRecord {
  if (!canEdit(staff, original)) throw new Error("forbidden");
  const next = { ...original };
  const submittedCompletion = original.source === "worker"
    ? original.serviceDocuments?.at(-1)?.snapshot?.completedAt : "";
  for (const field of [...commonFields, ...(staff.role === "worker" ? [] : officeFields)]) {
    if (!Object.hasOwn(incoming, field)) continue;
    if (field === "ledger") {
      if (!Array.isArray(incoming.ledger) || incoming.ledger.length > 200) throw new Error("invalid-ledger");
      next.ledger = incoming.ledger;
    } else next[field] = cleanText(incoming[field], field);
  }
  // The office must retain the completion reported by the latest worker submission.
  if (staff.role !== "worker" && submittedCompletion) next.completedAt = submittedCompletion;
  if(staff.role==="worker") {
    next.timeConfirmed={...original.timeConfirmed};
    for(const field of ["startedAt","completedAt"]){
      if(next[field]!==original[field])next.timeConfirmed[field]=false;
      if(incoming.timeConfirmed&&typeof incoming.timeConfirmed==="object"&&Object.hasOwn(incoming.timeConfirmed,field)){
        const confirmed=(incoming.timeConfirmed as Record<string,unknown>)[field];
        if(typeof confirmed!=="boolean")throw new Error("invalid-time-confirmation");
        next.timeConfirmed[field]=confirmed&&!!next[field];
      }
    }
  }
  if(staff.role!=="worker" && Object.hasOwn(incoming,"priceDrafts")) {
    const drafts=incoming.priceDrafts;
    if(!drafts || typeof drafts!=="object" || Array.isArray(drafts) || Object.keys(drafts).length>50)throw new Error("invalid-price-drafts");
    next.priceDrafts=Object.fromEntries(Object.entries(drafts).map(([id,value])=>{
      if(id.length>100 || typeof value!=="string" || value.length>50)throw new Error("invalid-price-drafts");
      return [id,value];
    }));
  }
  if(staff.role!=="worker" && Object.hasOwn(incoming,"chargeAmount")) {
    const charge=String(incoming.chargeAmount??"");
    if(!/^\d{0,9}(?:\.\d{0,2})?$/.test(charge))throw new Error("invalid-charge-amount");
    next.chargeAmount=charge;
  }
  if (Object.hasOwn(incoming, "items")) next.items = cleanItems(incoming.items, original, staff);
  if (staff.role !== "worker" && Object.hasOwn(incoming, "discountAmount")) {
    const value = String(incoming.discountAmount ?? "");
    // Allow incomplete decimals in autosaved drafts; confirmation validates the final amount.
    if (!/^\d{0,9}(?:\.\d{0,2})?$/.test(value)) throw new Error("invalid-discount");
    next.discountAmount = value;
  }
  // Deleted rows cannot leave an invisible price draft blocking confirmation.
  if (next.priceDrafts) next.priceDrafts = Object.fromEntries(Object.entries(next.priceDrafts).filter(([id]) => next.items.some(item => item.id === id)));
  if (Object.hasOwn(incoming, "photos")) {
    if (!Array.isArray(incoming.photos) || incoming.photos.length > 20) throw new Error("invalid-photos");
    next.photos = incoming.photos.map((raw) => {
      if (!raw || typeof raw !== "object") throw new Error("invalid-photo");
      const p = raw as Record<string, unknown>;
      const assetKey = cleanText(p.assetKey, "asset-key");
      return {
        id: cleanText(p.id, "photo-id"), assetKey,
        name: cleanText(p.name, "photo-name"), caption: cleanText(p.caption ?? "", "caption"),
        url: `/api/assets/${encodeURIComponent(assetKey)}`,
      };
    });
  }
  if (staff.role === "worker" && Object.hasOwn(incoming, "addressedFeedbackIds")) {
    if (!Array.isArray(incoming.addressedFeedbackIds) || incoming.addressedFeedbackIds.length > 50 ||
      incoming.addressedFeedbackIds.some((id) => typeof id !== "string" || id.length > 100)) {
      throw new Error("invalid-addressed-feedback");
    }
    const addressed = new Set(incoming.addressedFeedbackIds);
    const unresolved = new Set((original.feedback || []).filter((item: Record<string, unknown>) => !item.resolved).map((item: Record<string, unknown>) => item.id));
    if ([...addressed].some((id) => !unresolved.has(id))) throw new Error("invalid-addressed-feedback");
    next.feedback = (original.feedback || []).map((item: Record<string, unknown>) =>
      addressed.has(item.id) ? { ...item, addressed: true } : item);
  }
  return next;
}

export function validateWorkerSubmission(record: CaseRecord): void {
  const required=requiredIssues(record,true);
  if(required.length)throw Object.assign(new Error("missing-service-fields"),{missingFields:required.map(e=>e.field)});
  if (!record.customer?.trim() || !record.address?.trim() || !record.phone?.trim() || !record.startedAt) {
    throw Object.assign(new Error("missing-service-fields"),{missingFields:["customer","address","phone","startedAt"].filter(k=>!record[k]?.trim())});
  }
  if (record.completedAt && record.completedAt.slice(0,10) < record.startedAt.slice(0,10)) throw new Error("invalid-time-range");
  if (!record.items.length || record.items.some((item) => !validQuantity(item.qty))) throw new Error("missing-items");
  if (!record.photos.length && !record.notes?.trim()) throw new Error("missing-evidence");
  const unaddressed = (record.feedback || []).filter((item: Record<string, unknown>) => !item.resolved && !item.addressed);
  if (unaddressed.length) throw Object.assign(new Error("unaddressed-feedback"), {
    missingFields: unaddressed.map((item: Record<string, unknown>) => item.field),
  });
}

export function validateConfirmation(record: CaseRecord): void {
  if (!validDiscount(record)) throw Object.assign(new Error("invalid-discount"), {missingFields:["discountAmount"]});
  const required=requiredIssues(record,false);
  if(required.length)throw Object.assign(new Error("missing-confirmation-fields"),{missingFields:required.map(e=>e.field)});
  if(record.chargeAmount && !/^\d+(?:\.\d{1,2})?$/.test(String(record.chargeAmount)))throw Object.assign(new Error("invalid-charge-amount"),{missingFields:["chargeAmount"]});
  if (!record.customer?.trim() || !record.address?.trim() || !record.projectId || !record.projectCode?.trim()) throw Object.assign(new Error("missing-confirmation-fields"),{missingFields:["customer","address","projectId","projectCode"].filter(k=>!record[k]?.trim())});
  if (!record.items.length || record.items.some((item) => !validQuantity(item.qty) || item.price === "" || !validMoney(item.price))) {
    throw Object.assign(new Error("missing-price"),{missingFields:record.items.length?record.items.filter(i=>i.price===""||!Number.isFinite(Number(i.price))||Number(i.price)<0).map(i=>"price-"+i.id):["items"]});
  }
  if(Object.keys(record.priceDrafts||{}).length)throw Object.assign(new Error("missing-price"),{missingFields:Object.keys(record.priceDrafts).map(id=>"price-"+id)});
  if ((record.feedback || []).some((item: Record<string, unknown>) => !item.resolved)) throw new Error("unresolved-feedback");
}

export function formalContent(record: CaseRecord): string {
  return JSON.stringify({
    discountAmount: discount(record),
    fields: ["date", "address", "tower", "floor", "flat", "customer", "contact", "phone", "projectCode", "remark", "paymentTerms", "occupant", "notes", "startedAt", "completedAt", "material", "contractRef", "chargeAmount", "serviceRemark1", "serviceRemark2", "serviceRemark3"]
      .map((key) => record[key] ?? ""),
    items: record.items.map(({ preset, description, qty, price, model, brand }) => ({ preset, description, qty, price, model, brand })),
  });
}
