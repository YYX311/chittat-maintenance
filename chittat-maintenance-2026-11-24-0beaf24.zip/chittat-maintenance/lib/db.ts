import { Pool, type PoolClient } from "pg";

const globalPool = globalThis as typeof globalThis & { maintenancePool?: Pool };

export function db(): Pool {
  if (!globalPool.maintenancePool) {
    globalPool.maintenancePool = new Pool({
      connectionString: process.env.DATABASE_URL,
      // PGlite's socket multiplexer cannot isolate unnamed prepared statements.
      // Local PGlite uses one queued connection; real PostgreSQL defaults to ten.
      max: Math.max(1,Math.min(100,Number(process.env.DATABASE_POOL_MAX)||10)),
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 10_000,
    });
    globalPool.maintenancePool.on("error", (error) => {
      console.error("Idle database connection failed", error.message);
    });
  }
  return globalPool.maintenancePool;
}

export async function transaction<T>(run: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await db().connect();
  try {
    await client.query("BEGIN");
    const result = await run(client);
    await client.query("COMMIT");
    return result;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
