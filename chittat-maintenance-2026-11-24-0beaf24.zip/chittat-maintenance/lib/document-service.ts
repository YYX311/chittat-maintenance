import { randomUUID } from "node:crypto";
import { canSee, type CaseRecord } from "./case-rules";
import type { Queryable } from "./case-service";
import type { Staff } from "./access";
import type { ObjectStore } from "./object-storage";
import { saveGeneratedAsset } from "./asset-service";
import { renderDocument, type DocumentKind } from "./pdf-document";

const DOCUMENT_FORMAT_VERSION = 4;

export async function generateCaseDocument(client: Queryable, store: ObjectStore, staff: Staff,
  caseId: string, kind: DocumentKind, requestedRevision?: number): Promise<{ assetKey: string; record: CaseRecord }> {
  if (!["service", "quotation", "invoice", "confirmed-service"].includes(kind)) throw new Error("invalid-document-kind");
  const { rows } = await client.query(`SELECT data,row_version FROM cases WHERE id=$1 AND deleted_at IS NULL FOR UPDATE`, [caseId]);
  if (!rows.length) throw new Error("not-found");
  const current: CaseRecord = { ...rows[0].data, serverVersion: rows[0].row_version };
  if (!canSee(staff, current)) throw new Error("not-found");
  if (kind !== "service" && staff.role === "worker") throw new Error("forbidden");
  if (kind !== "service" && current.imported) throw new Error("missing-confirmation-fields");
  const sourceKind = kind === "service" ? "service" : "confirmation";
  if (requestedRevision !== undefined && (!Number.isInteger(requestedRevision) || requestedRevision < 0)) throw new Error("invalid-revision");
  const version = requestedRevision === undefined ?
    kind === "service" ? (current.serviceDocuments || []).length - 1 : Number(current.rev || 0) : requestedRevision;
  if (version < 0) throw new Error("not-found");
  const source = await client.query(`SELECT snapshot,asset_key,document_format_version FROM case_versions
    WHERE case_id=$1 AND kind=$2 AND revision=$3`, [caseId, sourceKind, version]);
  if (!source.rows.length) throw new Error("not-found");
  const documentVersion = kind === "service" ? source.rows[0] :
    (await client.query(`SELECT asset_key,document_format_version FROM case_versions WHERE case_id=$1 AND kind=$2 AND revision=$3`,
      [caseId, kind, version])).rows[0];
  const existing = documentVersion?.asset_key;
  const restoreIssuedStatus = async () => {
    if(kind!=="quotation" || current.status!=="approved" || Number(current.rev)!==version)return current;
    const stored:CaseRecord={...current,status:"issued"};
    delete stored.serverVersion;
    const result=await client.query("UPDATE cases SET status='issued',data=$2::jsonb,row_version=row_version+1,updated_at=now() WHERE id=$1 RETURNING row_version",[caseId,JSON.stringify(stored)]);
    return {...stored,serverVersion:result.rows[0].row_version} as CaseRecord;
  };
  if (existing && Number(documentVersion.document_format_version) >= DOCUMENT_FORMAT_VERSION) {
    return { assetKey: existing, record: await restoreIssuedStatus() };
  }
  const snapshot: CaseRecord = source.rows[0].snapshot;
  const bytes = await renderDocument(snapshot, kind);
  const asset = await saveGeneratedAsset(client, store, staff, caseId, bytes, "application/pdf");
  if (kind === "service") {
    await client.query(`UPDATE case_versions SET asset_key=$4,document_format_version=$5 WHERE case_id=$1 AND kind=$2 AND revision=$3`,
      [caseId, kind, version, asset.key, DOCUMENT_FORMAT_VERSION]);
  } else {
    await client.query(`INSERT INTO case_versions(id,case_id,kind,revision,snapshot,asset_key,created_by,document_format_version)
      VALUES ($1,$2,$3,$4,$5::jsonb,$6,$7,$8)
      ON CONFLICT (case_id,kind,revision) DO UPDATE SET
        asset_key=EXCLUDED.asset_key,document_format_version=EXCLUDED.document_format_version`,
      [randomUUID(), caseId, kind, version, JSON.stringify(snapshot), asset.key, staff.userId, DOCUMENT_FORMAT_VERSION]);
  }
  if (existing) {
    await client.query(`INSERT INTO audit_events(case_id,actor_user_id,action,detail)
      VALUES ($1,$2,$3,$4::jsonb)`, [caseId, staff.userId, `regenerate-${kind}`,
        JSON.stringify({ revision: version, formatVersion: DOCUMENT_FORMAT_VERSION, replacedAssetKey: existing })]);
    return { assetKey: asset.key, record: await restoreIssuedStatus() };
  }
  const next = { ...current };
  const entry = { at: new Date().toISOString(), rev: version, quoteRev: version,
    assetKey: asset.key, snapshot };
  if (kind === "service") next.serviceDocuments = (current.serviceDocuments || []).map((item: Record<string, unknown>) =>
    item.rev === version ? { ...item, assetKey: asset.key } : item);
  else if (kind === "quotation") {
    next.history = [...(current.history || []), entry];
    if (current.status === "approved" && Number(current.rev) === version) next.status = "issued";
  } else if (kind === "invoice") next.invoiceHistory = [...(current.invoiceHistory || []), entry];
  const { serverVersion: _serverVersion, ...stored } = next;
  const updated = await client.query(`UPDATE cases SET data=$2::jsonb,status=$3,row_version=row_version+1,updated_at=now()
    WHERE id=$1 RETURNING row_version`, [caseId, JSON.stringify(stored), next.status]);
  await client.query(`INSERT INTO audit_events(case_id,actor_user_id,action,detail)
    VALUES ($1,$2,$3,$4::jsonb)`, [caseId, staff.userId, `generate-${kind}`,
      JSON.stringify({ revision: version, formatVersion: DOCUMENT_FORMAT_VERSION, replacedAssetKey: null })]);
  return { assetKey: asset.key, record: { ...stored, serverVersion: updated.rows[0].row_version } as CaseRecord };
}
