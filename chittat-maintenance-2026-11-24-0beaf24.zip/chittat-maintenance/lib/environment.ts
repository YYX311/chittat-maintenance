type Environment = Record<string, string | undefined>;

function validUrl(value: string | undefined, protocols: string[]) {
  if (!value) return false;
  try {
    return protocols.includes(new URL(value).protocol);
  } catch {
    return false;
  }
}

export function productionConfigurationErrors(env: Environment = process.env) {
  if (env.NODE_ENV !== "production") return [];

  const errors: string[] = [];
  if (!validUrl(env.DATABASE_URL, ["postgres:", "postgresql:"])) errors.push("DATABASE_URL");
  if (!validUrl(env.BETTER_AUTH_URL, ["https:"])) errors.push("BETTER_AUTH_URL");
  if (!env.BETTER_AUTH_SECRET || env.BETTER_AUTH_SECRET.length < 32 || /replace|change-me/i.test(env.BETTER_AUTH_SECRET)) {
    errors.push("BETTER_AUTH_SECRET");
  }
  if (env.OBJECT_STORAGE_MODE !== "s3") errors.push("OBJECT_STORAGE_MODE");
  if (!env.S3_BUCKET) errors.push("S3_BUCKET");
  if (!env.S3_REGION) errors.push("S3_REGION");
  if (env.S3_ENDPOINT && !validUrl(env.S3_ENDPOINT, ["https:"])) errors.push("S3_ENDPOINT");
  for (const name of [
    "COMPANY_NAME_HK",
    "COMPANY_NAME_EN",
    "COMPANY_ADDRESS",
    "COMPANY_PHONE",
    "COMPANY_PAYMENT_DETAILS",
  ]) {
    if (!env[name]?.trim()) errors.push(name);
  }
  return errors;
}
