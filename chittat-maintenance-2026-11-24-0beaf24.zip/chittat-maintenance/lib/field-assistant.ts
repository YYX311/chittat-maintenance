import type { loadFieldReport } from "./research-field";
import { fieldEventLabels, fieldStudyFields, fieldStudyScreens } from "../src/field-study-catalog";

const targets:Record<string,string>={...fieldStudyFields,...fieldStudyScreens};
const actions:Record<string,string>=fieldEventLabels;
export const fieldAssistantPromptVersion="field-workflow-v1";

export function fieldAssistantSnapshot(data:Awaited<ReturnType<typeof loadFieldReport>>) {
  const {usage,trial,trialSummary,handoffs}=data;
  const facts=[
    {id:"activity",label:"有操作記錄的案件",value:`${usage.cases} 宗`},
    ...usage.backlog.slice(0,3).map((row,i)=>({id:`signal_${i+1}`,
      label:`${row.role==="office"?"維修部":"維修員"} · ${targets[row.target]} · ${actions[row.action]}`,
      value:`${row.cases} 宗、${row.count} 次`})),
    ...handoffs.reasons.slice(0,2).map(row=>({id:`return_${row.code}`,label:`退回 · ${row.label}`,value:`${row.count} 次`})),
    ...trialSummary.comparisons.filter(row=>row.n>0).map(row=>({id:`period_${row.label}`,label:`${row.label} 期`,
      value:`提交 ${row.n} 宗；首次退回 ${row.decided?`${row.returned}/${row.decided} 宗`:"未有覆核"}；`+
        `平均畫面活動 ${row.minutes===null?"未有量測":`${row.minutes.toFixed(1)} 分鐘（${row.timed} 宗）`}；`+
        `回報心累 ${row.pulse?`平均 ${row.strain?.toFixed(1)}/7 分（${row.pulse} 宗）`:"無配對回報"}；看到提示 ${row.exposed} 宗`})),
  ];
  const partial=usage.cases>0&&(data.truncated||trial.partial||handoffs.truncated);
  const ready=usage.cases>0&&!partial;
  const evidence=[`分析期間 ${data.from} 至 ${data.to}（香港日期）`,
    ...facts.map(f=>`${f.id}｜${f.label}：${f.value}`),
    "有記錄的案件才計入。四期比較屬描述性，請區分事實、可能解釋和下一步驗證。"].join("\n");
  return {facts,ready,partial,evidence};
}
