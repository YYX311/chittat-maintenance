type FieldColumn = readonly [key:string, label:string, meaning?:string];
const alias = ["alias","案件代號","以代號配對不同資料表。"] as const;
const person = ["participant","參與者代號","用於辨別同一人處理的多宗案件。"] as const;
const role = ["role","角色"] as const;
const phase = ["phase","比較條件"] as const;
const period = ["period","期別","OBS 是日常觀察；A/B 為試行期。"] as const;
const difficulty = ["difficulty","案件難度"] as const;
const at = ["at","事件時間","ISO 時間（UTC）。"] as const;

export const fieldExports = {
  tasks: {title:"案件成效", measures:"每列一宗自動納入的案件：比較畫面活動時間、首次退回、操作摩擦與填單後回報。", primary:["alias","period","active_minutes","friction_score","strain","first_return"], columns:[
    alias,person,period,phase,role,difficulty,["submitted","已提交／確認"],["after_17","傍晚提交","香港時間 17:00 起至午夜前。"],
    ["active_minutes","畫面活動（分鐘）","前景互動期間；不含長時間閒置，不能當人工工時。"],
    ["friction_score","操作摩擦次數","欄位攔截＋清空＋快速連點；缺記錄時留空。"],
    ["validation_errors","欄位攔截"],["field_clears","欄位清空"],["rapid_clicks","快速連點"],["net_issues","連線及慢請求訊號"],
    ["assistant_shown","提示曝光"],["assistant_accepts","點擊前往核對"],["ease","本人回報順手程度（1–7）"],
    ["strain","本人回報心累程度（1–7）"],["pulse_before_review","維修員回報早於首次覆核"],
    ["first_return","首次退回","1＝退回，0＝確認，空白＝無可配對的決定。"],
    ["handoff_minutes","交接歷時（分鐘）","由首次提交至確認，包含等候。"],
    ["tenure","年資範圍"],["specialty","工種"],["licensed","持牌狀態"],["work_area","工作區域"],
  ]},
  events: {title:"操作事件", measures:"每列一筆事件：還原提交、退回與確認的順序，定位哪個畫面或欄位容易卡住。", primary:["at","alias","role","action","surface","field"], columns:[
    at,alias,person,role,phase,["source","來源","handoff＝業務事件；request＝請求結果；screen＝畫面訊號。"],["action","操作"],
    ["outcome","結果"],["duration_ms","歷時（毫秒）"],["surface","畫面代碼"],["field","欄位代碼","只記欄位類別，沒有輸入內容。"],
  ]},
  cases: {title:"案件交接", measures:"每列一宗維修員提交的案件：看補交次數、首次覆核結果及由提交到確認的歷時。", primary:["alias","state","firstDecision","returns","elapsedMinutes"], columns:[
    alias,phase,difficulty,["state","交接狀態"],["firstDecision","首次覆核決定"],["submissions","提交次數"],["returns","退回次數"],
    ["elapsedMinutes","交接歷時（分鐘）","未確認留空；包含等候。"],["reasons","退回原因代碼"],
  ]},
  workload: {title:"階段工作負荷", measures:"每列一份員工在試行期結束後填的工作負荷回報，六個分項分開保存。", primary:["participant","period","mental","effort","frustration","raw_tlx"], columns:[
    person,role,period,at,["mental","腦力需求"],["physical","體力需求"],["temporal","時間壓力"],["performance","表現不滿意程度"],["effort","所需努力"],["frustration","挫折感"],
    ["raw_tlx","六項平均（0–100）","未加權自評。"],
  ]},
  context: {title:"情境回報", measures:"每列一份情境核查：分開本人回報與現場觀察，記錄當時的干擾、負擔或環境線索。", primary:["created_at","alias","stage","source","load","factors"], columns:[
    ["created_at","記錄時間"],alias,phase,difficulty,role,["stage","操作階段"],["source","回報或觀察來源"],["load","本人回報費力程度"],["factors","情境因素代碼"],
  ]},
} satisfies Record<string,{title:string;measures:string;primary:readonly string[];columns:readonly FieldColumn[]}>;

export type FieldExport = keyof typeof fieldExports;
