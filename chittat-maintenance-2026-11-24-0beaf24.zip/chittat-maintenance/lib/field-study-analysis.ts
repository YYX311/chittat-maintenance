import { createHash } from "node:crypto";
import type { Queryable } from "./case-service";
import type { loadResearchHandoffs } from "./research-handoffs";

export const participantCode=(studyId:string,userId:string)=>
  "P-"+createHash("sha256").update(`${studyId}:${userId}`).digest("hex").slice(0,12);

type TaskRow = {
  alias:string; period:string; phase:string; source:"worker"|"office"; user_id:string;
  difficulty:string; first_action:Date|string|null; time_ms:number|null; validations:number;
  clears:number; rapid_clicks:number; net_issues:number; assistant_shown:number;
  assistant_accepts:number; ease:number|null; strain:number|null; pulse_at:Date|string|null;
  first_decision_at:Date|string|null; tenure:string|null; specialty:string|null; licensed:boolean|null;
  work_area:string|null;
};

export function taskMeasures(row:TaskRow,studyId:string,handoff?:Awaited<ReturnType<typeof loadResearchHandoffs>>["rows"][number]) {
  const firstAction=row.first_action?new Date(row.first_action):null;
  const reportingTime=row.pulse_at?new Date(row.pulse_at):null;
  const beforeReview=Boolean(reportingTime&&row.source==="worker"&&
    (!row.first_decision_at||reportingTime<new Date(row.first_decision_at)));
  const captured=row.time_ms!==null||Boolean(row.validations+row.clears+row.rapid_clicks+row.net_issues+row.assistant_shown);
  return {
    alias:row.alias,participant:participantCode(studyId,row.user_id),period:row.period,phase:row.phase,role:row.source,
    difficulty:row.difficulty,submitted:Number(Boolean(firstAction)),after_17:firstAction?Number(firstAction.getUTCHours()>=9&&firstAction.getUTCHours()<16):null,
    active_minutes:row.time_ms===null?null:row.time_ms/60000,friction_score:captured?row.validations+row.clears+row.rapid_clicks:null,
    validation_errors:row.validations,field_clears:row.clears,rapid_clicks:row.rapid_clicks,net_issues:row.net_issues,
    assistant_shown:row.assistant_shown,assistant_accepts:row.assistant_accepts,
    ease:row.ease,strain:row.strain,pulse_before_review:Number(beforeReview),
    first_return:handoff?.firstDecision?Number(handoff.firstDecision==="return"):null,
    handoff_minutes:handoff?.elapsedMinutes??null,
    tenure:row.tenure,specialty:row.specialty,licensed:row.licensed,work_area:row.work_area,
  };
}

export async function loadTrialMeasures(db:Queryable,studyId:string,range:{start:string;end:string},handoffs:Awaited<ReturnType<typeof loadResearchHandoffs>>) {
  const [tasks,roster,workload,setup]=await Promise.all([
    db.query(`SELECT r.alias,r.trial_period AS period,r.phase,r.difficulty,c.owner_user_id AS user_id,c.source,
      timing.first_action,timing.first_decision_at,evt.*,x.ease,x.strain,x.at AS pulse_at,
      p.tenure,p.specialty,p.licensed,p.work_area
      FROM research_cases r JOIN cases c ON c.id=r.case_id
      CROSS JOIN LATERAL (SELECT min(a.created_at) FILTER (WHERE
        (c.source='worker' AND a.action='submit') OR (c.source='office' AND a.action='confirm')) AS first_action,
        min(a.created_at) FILTER (WHERE a.action IN ('confirm','return')) AS first_decision_at
        FROM research_case_audit a WHERE a.research_case_id=r.id AND a.created_at<$3) timing
      CROSS JOIN LATERAL (SELECT sum(f.duration_ms)::float AS time_ms,
        count(*) FILTER (WHERE f.kind='validation_error')::int AS validations,
        count(*) FILTER (WHERE f.kind='field_clear')::int AS clears,
        count(*) FILTER (WHERE f.kind='rage_click')::int AS rapid_clicks,
        count(*) FILTER (WHERE f.kind IN ('offline','slow_network'))::int AS net_issues,
        count(*) FILTER (WHERE f.kind='assistant_shown')::int AS assistant_shown,
        count(*) FILTER (WHERE f.kind='assistant_accept')::int AS assistant_accepts
        FROM research_field_events f WHERE f.study_case_id=r.id AND f.actor_user_id=c.owner_user_id
        AND f.at<=COALESCE(timing.first_action,$3::timestamptz) AND f.at<$3) evt
      LEFT JOIN research_task_pulse x ON x.study_case_id=r.id AND x.actor_user_id=c.owner_user_id AND x.at<$3
      LEFT JOIN LATERAL (SELECT tenure,specialty,licensed,work_area FROM research_participation
        WHERE study_id=r.study_id AND user_id=c.owner_user_id AND joined_at<=r.enrolled_at
        ORDER BY joined_at DESC LIMIT 1) p ON true
      WHERE r.study_id=$1 AND r.trial_period IS NOT NULL
        AND COALESCE(timing.first_action,r.enrolled_at)>=$2 AND COALESCE(timing.first_action,r.enrolled_at)<$3
      ORDER BY r.enrolled_at,r.id LIMIT 5001`,[studyId,range.start,range.end]),
    db.query(`SELECT e.user_id,e.role,p.joined_at,p.left_at,p.tenure,p.specialty,p.licensed,p.work_area
      FROM employees e LEFT JOIN LATERAL (SELECT joined_at,left_at,tenure,specialty,licensed,work_area
        FROM research_participation WHERE study_id=$1 AND user_id=e.user_id ORDER BY joined_at DESC LIMIT 1) p ON true
      WHERE (e.active AND e.role IN ('worker','office')) OR p.joined_at IS NOT NULL
      ORDER BY e.active DESC,(p.left_at IS NULL AND p.joined_at IS NOT NULL) DESC,e.staff_code`,[studyId]),
    db.query(`SELECT x.actor_user_id,e.role,x.period,x.at,x.ratings FROM research_phase_workload x
      JOIN employees e ON e.user_id=x.actor_user_id WHERE x.study_id=$1 AND x.at >= $2 AND x.at < $3
      ORDER BY x.at LIMIT 5001`,[studyId,range.start,range.end]),
    db.query("SELECT stopped_at FROM research_auto_collection WHERE study_id=$1",[studyId]),
  ]);
  const byAlias=new Map(handoffs.rows.map(row=>[row.alias,row]));
  const rows=tasks.rows.slice(0,5000).map(row=>taskMeasures(row,studyId,byAlias.get(row.alias)));
  return {
    enabled:setup.rows.length>0&&!setup.rows[0].stopped_at,
    roster:roster.rows.map(({user_id,joined_at,left_at,role,...profile})=>({
      participant:participantCode(studyId,user_id),role:(role==="worker"?"worker":"office") as "worker"|"office",
      status:left_at?"left":joined_at?"joined":"waiting",tenure:profile.tenure as string|null,
      specialty:profile.specialty as string|null,licensed:profile.licensed as boolean|null,work_area:profile.work_area as string|null,
    })),
    rows, partial:tasks.rows.length>5000||handoffs.truncated,
    workloadPartial:workload.rows.length>5000,
    workload:workload.rows.slice(0,5000).map(({actor_user_id,role,period,at,ratings})=>({
      participant:participantCode(studyId,actor_user_id),role:role==="worker"?"worker":"office",period,at:new Date(at).toISOString(),
      mental:ratings[0],physical:ratings[1],temporal:ratings[2],performance:ratings[3],effort:ratings[4],frustration:ratings[5],
      raw_tlx:ratings.reduce((sum:number,score:number)=>sum+score,0)/6,
    })),
  };
}

type TrialTask=ReturnType<typeof taskMeasures>;
function mean(values:number[]) {return values.length?values.reduce((a,b)=>a+b,0)/values.length:null;}

export function summarizeTrialTasks(rows:TrialTask[]) {
  const eligible=rows.filter(r=>r.role==="worker"&&r.submitted);
  const group=(items:TrialTask[])=>{
    const timed=items.flatMap(r=>r.active_minutes===null?[]:[r.active_minutes]);
    const decided=items.filter(r=>r.first_return!==null);
    const pulse=items.filter(r=>r.strain!==null&&r.pulse_before_review);
    const ease=items.filter(r=>r.ease!==null&&r.pulse_before_review);
    return {n:items.length,timed:timed.length,minutes:mean(timed),decided:decided.length,
      returned:decided.filter(r=>r.first_return===1).length,pulse:pulse.length,strain:mean(pulse.map(r=>r.strain!)),
      ease:mean(ease.map(r=>r.ease!)),easeN:ease.length,
      friction:mean(items.flatMap(r=>r.friction_score===null?[]:[r.friction_score])),
      exposed:items.filter(r=>r.assistant_shown>0).length};
  };
  const isTrial=(r:TrialTask)=>["A1","B1","A2","B2"].includes(r.period);
  const demand=(r:TrialTask)=>r.after_17===1||r.net_issues>0||r.difficulty==="high"?"high":
    r.friction_score!==null&&r.after_17===0?"usual":"unknown";
  const trial=eligible.filter(isTrial);
  return {
    paths:[{label:"沒有摩擦訊號",...group(eligible.filter(r=>r.friction_score===0&&r.net_issues===0))},
      {label:"有摩擦或弱網訊號",...group(eligible.filter(r=>r.friction_score!==null&&(r.friction_score>0||r.net_issues>0)))}],
    strain:[{label:"1–3 分",...group(eligible.filter(r=>r.pulse_before_review&&r.strain!==null&&r.strain<=3))},
      {label:"4–7 分",...group(eligible.filter(r=>r.pulse_before_review&&r.strain!==null&&r.strain>=4))}],
    comparisons:["A1","B1","A2","B2"].map(period=>({label:period,...group(eligible.filter(r=>r.period===period))})),
    context:["baseline","improved"].map(phase=>({label:phase,...group(trial.filter(r=>r.phase===phase&&demand(r)==="high"))})),
    usual:["baseline","improved"].map(phase=>({label:phase,...group(trial.filter(r=>r.phase===phase&&demand(r)==="usual"))})),
    ratings:["baseline","improved"].map(phase=>({label:phase,...group(trial.filter(r=>r.phase===phase))})),
    unknownDemand:trial.filter(r=>demand(r)==="unknown").length,
    modelCoverage:{complete:trial.filter(r=>r.active_minutes!==null).length,
      people:new Set(trial.filter(r=>r.active_minutes!==null).map(r=>r.participant)).size,
      conditions:new Set(trial.filter(r=>r.active_minutes!==null).map(r=>r.phase)).size},
  };
}
