import { randomUUID } from "node:crypto";
import type { Staff } from "./access";
import type { Queryable } from "./case-service";
import { hkDay, trialPeriods } from "./research-field";
import { fieldEventLabels, fieldStudyScreens, participantProfile, studyField } from "../src/field-study-catalog";

type Plan = { study_id: string; starts_on: string|null; weeks_per_period: number|null; consent_reference: string; enabled_by: string };
const days = 86400000;
const activePlanSql = `SELECT a.study_id,a.consent_reference,a.enabled_by,p.starts_on::text,p.weeks_per_period
  FROM research_auto_collection a JOIN research_studies s ON s.id=a.study_id
  LEFT JOIN research_trial_plans p ON p.study_id=a.study_id
  WHERE a.stopped_at IS NULL AND s.status='collecting'`;

const periodsFor = (plan:Plan) => plan.starts_on && plan.weeks_per_period ? trialPeriods(plan.starts_on,plan.weeks_per_period) : [];
export function periodFor(plan: Plan, at = new Date()) {
  const day = hkDay(at);
  return periodsFor(plan).find(period=>period.from<=day&&day<=period.to);
}

export async function enableAutoCollection(db: Queryable, studyId: string, staff: Staff, body: Record<string, unknown>) {
  const reference = typeof body.consentReference === "string" ? body.consentReference.trim() : "";
  if (body.permissionConfirmed !== true || reference.length < 1 || reference.length > 200) throw Error("invalid-consent");
  await db.query("SELECT pg_advisory_xact_lock(hashtext('research-auto-collection'))");
  const active = (await db.query("SELECT study_id FROM research_auto_collection WHERE stopped_at IS NULL")).rows[0];
  if (active && active.study_id !== studyId) throw Error("invalid-collection-already-running");
  await db.query(`INSERT INTO research_auto_collection(study_id,consent_reference,enabled_by)
    VALUES ($1,$2,$3) ON CONFLICT(study_id) DO NOTHING`, [studyId,reference,staff.userId]);
  return { ok:true };
}

export async function enrollNewFieldCase(db: Queryable, staff: Staff, caseId: string) {
  const plan: Plan | undefined = (await db.query(`${activePlanSql}
    AND EXISTS (SELECT 1 FROM research_participation c WHERE c.study_id=a.study_id AND c.user_id=$1 AND c.left_at IS NULL)
    FOR SHARE OF s`,[staff.userId])).rows[0];
  if (!plan) return;
  const period = periodFor(plan);
  await db.query(`INSERT INTO research_cases(id,study_id,case_id,alias,phase,difficulty,consent_reference,enrolled_by,trial_period,enrolled_at)
    SELECT $1,$2,$3,$4,$5,'low',$6,$7,$8,clock_timestamp() WHERE EXISTS (
      SELECT 1 FROM research_participation WHERE study_id=$2 AND user_id=$9 AND left_at IS NULL FOR SHARE
    ) ON CONFLICT(study_id,case_id) DO NOTHING`,
    [randomUUID(),plan.study_id,caseId,`R-${randomUUID()}`,period?.phase??"baseline",plan.consent_reference,plan.enabled_by,period?.label??"OBS",staff.userId]);
}

function caseAccess(staff: Staff) {
  return staff.role === "worker" ? "AND c.owner_user_id=$2" : "";
}

export async function fieldStudyConfig(db: Queryable, staff: Staff, caseId: string | null) {
  const plan: Plan | undefined = (await db.query(activePlanSql)).rows[0];
  if (!plan) return { studyId:null };
  const participant = (await db.query(`SELECT tenure,specialty,licensed,work_area,joined_at FROM research_participation
    WHERE study_id=$1 AND user_id=$2 AND left_at IS NULL`,[plan.study_id,staff.userId])).rows[0];
  const scope = participant && caseId ? (await db.query(`SELECT r.trial_period,r.phase,
      NOT EXISTS (SELECT 1 FROM research_task_pulse x WHERE x.study_case_id=r.id AND x.actor_user_id=$2) AS pulse
    FROM research_cases r JOIN cases c ON c.id=r.case_id
    WHERE r.study_id=$1 AND r.case_id=$3 AND r.trial_period IS NOT NULL AND c.deleted_at IS NULL ${caseAccess(staff)}`,
    [plan.study_id,staff.userId,caseId])).rows[0] : null;
  const periods = periodsFor(plan);
  const period = periods.find(p=>p.label===scope?.trial_period);
  const hints = staff.role === "worker" && period?.phase === "improved" ? (await db.query(`
    SELECT a.detail->>'field' AS field,count(*)::int AS count FROM research_case_audit a
    JOIN research_cases r ON r.id=a.research_case_id
    WHERE r.study_id=$1 AND r.trial_period IN ('A1','B1','A2','B2') AND a.action='return'
      AND a.created_at >= ($2::date::timestamp AT TIME ZONE 'Asia/Hong_Kong')
      AND a.created_at < ($3::date::timestamp AT TIME ZONE 'Asia/Hong_Kong') AND a.detail ? 'field'
    GROUP BY field HAVING count(*)>=2 ORDER BY count DESC,field LIMIT 4`,[plan.study_id,plan.starts_on,period.from])).rows
    .filter(row=>studyField(row.field)) : [];
  const recovery=(await db.query("SELECT enabled FROM research_recovery_settings WHERE study_id=$1",[plan.study_id])).rows[0]?.enabled===true;
  const today = hkDay();
  const workloadDone = participant ? (await db.query("SELECT period FROM research_phase_workload WHERE study_id=$1 AND actor_user_id=$2",
    [plan.study_id,staff.userId])).rows.map(row=>row.period) : [];
  const profile=participant?{tenure:participant.tenure,specialty:participant.specialty,licensed:participant.licensed,work_area:participant.work_area}:null;
  return { studyId:plan.study_id, joined:Boolean(participant), profile,
    period:periodFor(plan)?.label??null, caseId:scope?caseId:null, assignment:scope?.trial_period??null,
    recovery, assistant:period?.phase==="improved", pulse:Boolean(scope?.pulse), hints,
    workload:participant?periods.filter(p=>p.to<today&&p.to>=hkDay(participant.joined_at)&&!workloadDone.includes(p.label)).map(p=>p.label):[] };
}

function profileValue(key: keyof typeof participantProfile, value: unknown) {
  if (value == null || value === "") return null;
  if (typeof value !== "string" || !Object.hasOwn(participantProfile[key],value)) throw Error("invalid-participant-profile");
  return value;
}

export function normalizeFieldEvents(input: unknown, now = Date.now()) {
  if (!Array.isArray(input)||input.length<1||input.length>40) throw Error("invalid-field-events");
  return input.map(row => {
    if (!row || typeof row!=="object" || typeof row.id!=="string" || !/^[\w-]{8,100}$/.test(row.id) ||
      typeof row.caseId!=="string" || !/^[\w-]{1,100}$/.test(row.caseId) ||
      typeof row.kind!=="string" || !Object.hasOwn(fieldEventLabels,row.kind) ||
      typeof row.surface!=="string" || !Object.hasOwn(fieldStudyScreens,row.surface) ||
      !Number.isInteger(row.at) || row.at<now-7*days || row.at>now+60000 ||
      (row.field!=null && !studyField(row.field)) ||
      (row.kind==="screen_active" && (!Number.isInteger(row.durationMs)||row.durationMs<1000||row.durationMs>300000)))
      throw Error("invalid-field-events");
    return {id:row.id,case_id:row.caseId,kind:row.kind,surface:row.surface,at:new Date(row.at).toISOString(),
      field:studyField(row.field),duration_ms:row.kind==="screen_active"?row.durationMs:null};
  });
}

export async function fieldStudyMutation(db: Queryable, staff: Staff, body: Record<string,unknown>) {
  const plan: Plan | undefined = (await db.query(`${activePlanSql} FOR SHARE OF s`)).rows[0];
  if (!plan || body.studyId !== plan.study_id) throw Error("not-found");
  await db.query("SELECT pg_advisory_xact_lock(hashtext($1))",[`field-study:${staff.userId}`]);
  if (body.action==="join" || body.action==="profile" || body.action==="leave") {
    if (body.action==="leave") {
      await db.query("UPDATE research_participation SET left_at=clock_timestamp() WHERE study_id=$1 AND user_id=$2 AND left_at IS NULL",[plan.study_id,staff.userId]);
      return {ok:true};
    }
    const licensed = body.licensed == null ? null : body.licensed;
    if (licensed!==null && typeof licensed!=="boolean") throw Error("invalid-participant-profile");
    const profile = [profileValue("tenure",body.tenure),profileValue("specialty",body.specialty),licensed,profileValue("work_area",body.workArea)];
    if (body.action==="join") {
      if (body.agreed!==true) throw Error("invalid-consent");
      await db.query(`INSERT INTO research_participation(id,study_id,user_id,tenure,specialty,licensed,work_area,joined_at)
        VALUES($1,$2,$3,$4,$5,$6,$7,clock_timestamp()) ON CONFLICT(study_id,user_id) WHERE left_at IS NULL DO NOTHING`,[randomUUID(),plan.study_id,staff.userId,...profile]);
    } else {
      await db.query(`UPDATE research_participation SET tenure=$3,specialty=$4,licensed=$5,work_area=$6
        WHERE study_id=$1 AND user_id=$2 AND left_at IS NULL`,[plan.study_id,staff.userId,...profile]);
    }
    return {ok:true};
  }
  const joined = (await db.query(`SELECT joined_at FROM research_participation WHERE study_id=$1 AND user_id=$2 AND left_at IS NULL`,
    [plan.study_id,staff.userId])).rows[0];
  if (!joined) throw Error("forbidden");
  if (body.action==="events") {
    const rows = normalizeFieldEvents(body.events);
    const used=(await db.query(`SELECT count(*)::int AS n FROM research_field_events WHERE actor_user_id=$1 AND received_at>now()-interval '1 day'`,[staff.userId])).rows[0].n;
    if (used+rows.length>2000) return {recorded:0};
    const result = await db.query(`INSERT INTO research_field_events(study_case_id,actor_user_id,id,at,kind,surface,field,duration_ms)
      SELECT r.id,$2,x.id,x.at,x.kind,x.surface,x.field,x.duration_ms
      FROM jsonb_to_recordset($3::jsonb) AS x(id text,case_id text,at timestamptz,kind text,surface text,field text,duration_ms int)
      JOIN research_cases r ON r.study_id=$1 AND r.case_id=x.case_id
      JOIN cases c ON c.id=r.case_id
      LEFT JOIN LATERAL (SELECT enabled FROM research_telemetry_settings WHERE study_id=r.study_id ORDER BY version DESC LIMIT 1) cfg ON true
      WHERE r.trial_period IS NOT NULL AND c.deleted_at IS NULL ${caseAccess(staff)}
        AND x.at>=GREATEST($4::timestamptz,r.enrolled_at)
        AND x.surface LIKE $5
        AND (x.kind NOT IN ('assistant_shown','assistant_accept') OR r.phase='improved')
        AND (cfg.enabled IS NULL OR $6=ANY(cfg.enabled))
        AND NOT EXISTS (SELECT 1 FROM research_case_audit a WHERE a.research_case_id=r.id
          AND a.action='confirm' AND a.created_at<=x.at)
      ON CONFLICT DO NOTHING RETURNING id`,[plan.study_id,staff.userId,JSON.stringify(rows),joined.joined_at,
      staff.role==="worker"?"worker-%":"office-%",staff.role==="worker"?"field-record":"office-record"]);
    return {recorded:result.rows.length};
  }
  if (body.action==="pulse") {
    const ratings=[body.ease,body.strain];
    if (ratings.some(n=>typeof n!=="number"||!Number.isInteger(n)||n<1||n>7)||typeof body.caseId!=="string") throw Error("invalid-task-pulse");
    const actions=staff.role==="worker"?["submit"]:["return","confirm"];
    const result=await db.query(`INSERT INTO research_task_pulse(study_case_id,actor_user_id,ease,strain)
      SELECT r.id,$2,$4,$5 FROM research_cases r JOIN cases c ON c.id=r.case_id
      WHERE r.study_id=$1 AND r.case_id=$3 AND r.trial_period IS NOT NULL AND c.deleted_at IS NULL ${caseAccess(staff)}
        AND EXISTS (SELECT 1 FROM research_case_audit a WHERE a.research_case_id=r.id AND a.actor_user_id=$2
          AND a.action=ANY($6::text[]) AND a.created_at >= $7 AND a.created_at >= now()-interval '1 day')
      ON CONFLICT DO NOTHING RETURNING study_case_id`,[plan.study_id,staff.userId,body.caseId,...ratings,actions,joined.joined_at]);
    if (!result.rows.length) {
      const saved=await db.query(`SELECT 1 FROM research_task_pulse x JOIN research_cases r ON r.id=x.study_case_id
        WHERE r.study_id=$1 AND x.actor_user_id=$2 AND r.case_id=$3`,[plan.study_id,staff.userId,body.caseId]);
      if (!saved.rows.length) throw Error("invalid-task-pulse");
    }
    return {ok:true};
  }
  if (body.action==="workload") {
    const period=periodsFor(plan).find(p=>p.label===body.period&&p.to<hkDay());
    const ratings=body.ratings;
    if (!period||!Array.isArray(ratings)||ratings.length!==6||ratings.some(n=>!Number.isInteger(n)||n<0||n>100)||
      hkDay(joined.joined_at)>period.to) throw Error("invalid-workload");
    await db.query(`INSERT INTO research_phase_workload(study_id,actor_user_id,period,ratings) VALUES($1,$2,$3,$4)
      ON CONFLICT DO NOTHING`,[plan.study_id,staff.userId,period.label,ratings]);
    return {ok:true};
  }
  throw Error("invalid-action");
}
