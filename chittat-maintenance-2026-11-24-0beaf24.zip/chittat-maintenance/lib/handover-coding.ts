export const themes = {
  missing: '需要補充資料', interpretation: '需要澄清內容', coordination: '需要協調交接',
  other: '其他情況', unknown: '證據不足',
} as const;
export const actions = { submit: '師傅提交', review: '維修部覆核', return: '退回補充', confirm: '確認完成' } as const;
export type Theme = keyof typeof themes;
export type Action = keyof typeof actions;
export type HandoverData = {
  daily: { day: string; action: Action; count: number }[];
  codes: { theme: Theme | null; count: number }[];
  returns: { id: string; at: string; field: string | null; reason: string | null; theme: Theme | null }[];
};
export function dateRange(from: string | null, to: string | null) {
  function day(s: string | null) {
    if (!s || !/^\d{4}-\d\d-\d\d$/.test(s)) throw Error('invalid-date');
    const n = Date.parse(s+'T00:00:00Z');
    if (!Number.isFinite(n) || new Date(n).toISOString().slice(0,10)!==s) throw Error('invalid-date');
    return n;
  }
  const days = (day(to)-day(from))/86400000;
  if (days < 0 || days >= 93) throw Error('invalid-date-range');
  return [from,to];
}
