import type { Queryable } from './case-service';
import { participantCode } from './field-study-analysis';
import { dateRange } from './handover-coding';
import { defaultResearchConfig, fieldNames, returnReasonLabels } from './research-events';
import { activeResearchPhase, probeStudyId } from './research-probe';
import type { Episode, EventHealth, ResearchDataset } from './research-model';

type Audit = {
  id: string;
  case_id: string;
  actor_user_id: string;
  action: 'submit' | 'review' | 'return' | 'confirm' | 'withdraw' | 'generate-quotation' | 'generate-invoice' | 'generate-confirmed-service';
  created_at: Date | string;
  day: string;
  in_scope: boolean;
  reason: string | null;
  field: string | null;
  snapshot: Record<string, unknown> | null;
  version: string | null;
};

const studyId = probeStudyId;

type ProbeEvent = {
  case_id: string;
  actor_user_id: string;
  name: string;
  at: Date | string;
  in_scope: boolean;
  role: 'worker' | 'office';
  step: string | null;
  active_ms: number | null;
  rating: number | null;
  case_version: number | null;
};

const millis = (value: Date | string) => new Date(value).getTime();

function applyWorkerMeasures(episode: Episode, submission: Audit, from: number, records: ProbeEvent[]) {
  const until = millis(submission.created_at);
  const workerRecords = records.filter(event => event.role === 'worker' && event.actor_user_id === submission.actor_user_id);
  const before = workerRecords.filter(event => event.case_version == null && millis(event.at) > from && millis(event.at) <= until);
  const timed = before.filter(event => event.name === 'form.step_leave');
  if (timed.length) {
    episode.fillActiveMin = timed.reduce((sum, event) => sum + (event.active_ms ?? 0), 0) / 60000;
    episode.stepRevisits = timed.length - new Set(timed.map(event => event.step)).size;
    // Counts are observed from this browser, conditional on a recorded session.
    episode.validationBlocks = before.filter(event => event.name === 'form.validation_block').length;
    episode.fieldRefills = before.filter(event => event.name === 'form.field_refill').length;
    episode.offlineEvents = before.filter(event => event.name === 'net.offline').length;
  } else {
    // Positive events are usable individually even when the timing record is missing.
    episode.validationBlocks = before.filter(event => event.name === 'form.validation_block').length || null;
    episode.fieldRefills = before.filter(event => event.name === 'form.field_refill').length || null;
    episode.offlineEvents = before.filter(event => event.name === 'net.offline').length || null;
  }

  // Populate check-card MRT measures if check.* events were recorded in this submission window
  const assigned = before.find(event => event.name === 'check.assigned');
  if (assigned) {
    episode.phase = 'mrt';
    episode.arm = assigned.step === 'check' || assigned.step === 'control' ? assigned.step : null;
    episode.checkFlags = assigned.rating ?? null;
    if (episode.arm === 'check') {
      episode.checkAccepted = before.some(event => event.name === 'check.go_field');
    }
  }

  const survey = workerRecords.filter(event => event.case_version != null && String(event.case_version) === submission.version);
  episode.effort = survey.find(event => event.name === 'survey.effort')?.rating ?? null;
  episode.fatigue = survey.find(event => event.name === 'survey.fatigue')?.rating ?? null;
}
const comparedFields = [
  'date', 'address', 'tower', 'floor', 'flat', 'customer', 'contact', 'occupant',
  'phone', 'notes', 'startedAt', 'completedAt',
];
const minutesBetween = (start: Audit, end: Audit) =>
  (new Date(end.created_at).getTime() - new Date(start.created_at).getTime()) / 60000;

export function buildHandoverEpisodes(
  events: Audit[],
  probes: ProbeEvent[] = [],
  defaultPhase: 'baseline' | 'mrt' | 'adaptive' = activeResearchPhase(),
): Episode[] {
  const active = new Map<string, { submit: Audit; episode: Episode }>();
  const confirmed = new Map<string, { at: Audit; episode: Episode }>();
  const rounds = new Map<string, number>();
  const sequences = new Map<string, number>();
  const lastReturn = new Map<string, { at: Audit; episode: Episode }>();
  const episodes: Episode[] = [];
  const lastSubmission = new Map<string, number>();
  const probesByCase = new Map<string, ProbeEvent[]>();
  for (const event of probes) {
    if (!probesByCase.has(event.case_id)) probesByCase.set(event.case_id, []);
    probesByCase.get(event.case_id)!.push(event);
  }

  for (const event of events) {
    const key = event.case_id;
    if (event.action === 'submit') {
      const round = (rounds.get(key) ?? 0) + 1;
      rounds.set(key, round);
      const previous = lastReturn.get(key);
      if (previous) previous.episode.reworkMin = minutesBetween(previous.at, event);
      lastReturn.delete(key);
      const seqKey = event.actor_user_id + ':' + event.day;
      const seq = (sequences.get(seqKey) ?? 0) + 1;
      sequences.set(seqKey, seq);
      const episode: Episode = {
        id: 'E-' + event.id, caseId: participantCode(studyId + ':case', key),
        date: event.day, round, worker: participantCode(studyId, event.actor_user_id), reviewer: null,
        phase: defaultPhase, arm: null, checkFlags: null, checkAccepted: null,
        fillActiveMin: null, validationBlocks: null, fieldRefills: null, offlineEvents: null, stepRevisits: null,
        photoCount: typeof event.snapshot?.photoCount === 'number' ? event.snapshot.photoCount : null,
        itemCount: typeof event.snapshot?.itemCount === 'number' ? event.snapshot.itemCount : null,
        taskSeqToday: seq, hoursOnShift: null,
        effort: null, fatigue: null, returned: null, returnReason: null, returnFields: [],
        fieldsCorrected: null, correctedFields: [], reviewWaitMin: null, reviewActiveMin: null,
        reworkMin: null, cycleMin: null, officeDocMin: null,
      };
      active.set(key, { submit: event, episode });
      if (event.in_scope) {
        applyWorkerMeasures(episode, event, lastSubmission.get(key) ?? -Infinity, probesByCase.get(key) ?? []);
        episodes.push(episode);
      }
      lastSubmission.set(key, millis(event.created_at));
      continue;
    }

    if (event.action === 'generate-quotation' || event.action === 'generate-invoice' || event.action === 'generate-confirmed-service') {
      const conf = confirmed.get(key);
      if (conf && conf.episode.officeDocMin == null) {
        const diff = minutesBetween(conf.at, event);
        if (diff >= 0) conf.episode.officeDocMin = diff;
      }
      continue;
    }

    const current = active.get(key);
    if (!current) continue;
    const { submit, episode } = current;
    if (event.action === 'review') {
      episode.reviewWaitMin ??= minutesBetween(submit, event);
      continue;
    }
    active.delete(key);
    if (event.action === 'withdraw') continue;
    episode.reviewer = participantCode(studyId, event.actor_user_id);
    episode.reviewWaitMin ??= minutesBetween(submit, event);
    const officeTime = (probesByCase.get(key) ?? []).filter(probe => probe.role === 'office'
      && probe.name === 'form.step_leave' && millis(probe.at) >= millis(submit.created_at)
      && millis(probe.at) <= millis(event.created_at));
    if (officeTime.length) episode.reviewActiveMin = officeTime.reduce((sum, probe) => sum + (probe.active_ms ?? 0), 0) / 60000;
    episode.returned = event.action === 'return';
    if (episode.returned) {
      episode.returnReason = event.reason && Object.hasOwn(returnReasonLabels, event.reason) ? event.reason : 'unknown';
      episode.returnFields = event.field && Object.hasOwn(fieldNames, event.field) ? [event.field] : [];
      lastReturn.set(key, { at: event, episode });
    } else {
      episode.cycleMin = minutesBetween(submit, event);
      confirmed.set(key, { at: event, episode });
      if (submit.snapshot && event.snapshot && Date.parse(String(event.snapshot.approvedAt)) >= new Date(submit.created_at).getTime()) {
        const before = submit.snapshot;
        const after = event.snapshot;
        episode.correctedFields = comparedFields.filter(field => (before[field] ?? '') !== (after[field] ?? ''));
        episode.fieldsCorrected = episode.correctedFields.length;
      }
    }
  }
  return episodes;
}

const TEST_CASE_FILTER_SQL = `
  AND NOT EXISTS (
    SELECT 1 FROM cases tc WHERE tc.id = cohort_id
      AND (
        COALESCE(tc.data->>'address', '') ~* '(灰度|測試|测试|cloud acceptance|smoke|test[-_ ]?case)'
        OR COALESCE(tc.data->>'customer', '') ~* '(灰度|測試|测试|cloud acceptance|smoke|test[-_ ]?case)'
      )
  )
`;

export async function loadHandoverDataset(
  client: Queryable,
  from: string,
  to: string,
  options: { excludeTest?: boolean } = {},
): Promise<ResearchDataset> {
  const bounds = dateRange(from, to);
  const excludeTest = Boolean(options.excludeTest);
  const phase = activeResearchPhase();
  const result = await client.query(`
    WITH bounds AS (
      SELECT $1::date::timestamp AT TIME ZONE 'Asia/Hong_Kong' AS start_at,
             ($2::date + 1)::timestamp AT TIME ZONE 'Asia/Hong_Kong' AS end_at
    ), cohort AS (
      SELECT DISTINCT case_id FROM audit_events, bounds
      WHERE action='submit' AND created_at >= start_at AND created_at < end_at AND case_id IS NOT NULL
      ${excludeTest ? TEST_CASE_FILTER_SQL.replaceAll('cohort_id', 'audit_events.case_id') : ''}
    )
    SELECT e.id::text, e.case_id, e.actor_user_id, e.action, e.created_at,
           to_char(e.created_at AT TIME ZONE 'Asia/Hong_Kong', 'YYYY-MM-DD') AS day,
           e.created_at >= bounds.start_at AS in_scope,
           e.detail->>'reason' AS reason, e.detail->>'field' AS field, e.detail->>'version' AS version, v.snapshot
    FROM cohort JOIN audit_events e USING(case_id) CROSS JOIN bounds
    LEFT JOIN LATERAL (
      SELECT COALESCE((SELECT jsonb_object_agg(key, value) FROM jsonb_each(snapshot)
                       WHERE key=ANY($3::text[])), '{}'::jsonb)
             || jsonb_build_object(
                  'itemCount', CASE WHEN jsonb_typeof(snapshot->'items')='array' THEN jsonb_array_length(snapshot->'items') END,
                  'photoCount', CASE WHEN jsonb_typeof(snapshot->'photos')='array' THEN jsonb_array_length(snapshot->'photos') END
                ) AS snapshot
      FROM case_versions
      WHERE case_id=e.case_id
        AND kind=CASE e.action WHEN 'submit' THEN 'service' WHEN 'confirm' THEN 'confirmation' END
        AND created_by=e.actor_user_id AND created_at<=e.created_at
        AND CASE e.action
          WHEN 'submit' THEN NULLIF(snapshot->>'submittedAt','')::timestamptz
          WHEN 'confirm' THEN NULLIF(snapshot->>'approvedAt','')::timestamptz
        END BETWEEN e.created_at - interval '1 minute' AND e.created_at
      ORDER BY revision DESC LIMIT 1
    ) v ON e.created_at >= bounds.start_at AND e.action IN ('submit','confirm')
    WHERE e.action IN ('submit','review','return','confirm','withdraw','generate-quotation','generate-invoice','generate-confirmed-service')
      AND e.created_at < bounds.end_at
    ORDER BY e.created_at, e.id
  `, [...bounds, [...comparedFields, 'approvedAt']]);

  const caseIds = [...new Set(result.rows.map(row => row.case_id))];
  const probes = await client.query(`
    WITH bounds AS (
      SELECT $1::date::timestamp AT TIME ZONE 'Asia/Hong_Kong' AS start_at,
             ($2::date + 1)::timestamp AT TIME ZONE 'Asia/Hong_Kong' AS end_at
    )
    SELECT case_id,actor_user_id,role,name,at,step,active_ms,rating,case_version,at >= start_at AS in_scope
    FROM research_probe_events, bounds
    WHERE at < end_at AND (at >= start_at OR case_id=ANY($3::text[]))
      ${excludeTest ? 'AND case_id = ANY($3::text[])' : ''}
    ORDER BY at,id`, [...bounds, caseIds]);
  const episodes = buildHandoverEpisodes(result.rows, probes.rows, phase);
  const eventNames: Record<string, string> = {
    submit: 'case.submitted',
    review: 'case.review_opened',
    return: 'case.returned',
    confirm: 'case.confirmed',
    'generate-quotation': 'doc.generated',
    'generate-invoice': 'doc.generated',
    'generate-confirmed-service': 'doc.generated',
  };
  const counts = new Map<string, EventHealth>();
  const surveyKey = (event: ProbeEvent) => JSON.stringify([event.case_id, event.actor_user_id, event.case_version]);
  const answers = new Set((probes.rows as ProbeEvent[])
    .filter(event => event.name === 'survey.effort').map(surveyKey));
  const prompts = (probes.rows as ProbeEvent[]).filter(event => event.in_scope && event.name === 'survey.shown');
  for (const event of probes.rows as ProbeEvent[]) {
    if (!event.in_scope) continue;
    counts.set(event.name, { name: event.name, count: (counts.get(event.name)?.count ?? 0) + 1, lastAt: new Date(event.at).toISOString() });
  }
  for (const event of result.rows as Audit[]) {
    if (!event.in_scope || event.action === 'withdraw') continue;
    const name = eventNames[event.action];
    if (!name) continue;
    counts.set(name, { name, count: (counts.get(name)?.count ?? 0) + 1, lastAt: new Date(event.created_at).toISOString() });
  }
  return {
    study: { id: studyId, name: '服務單交接觀察', startedAt: from, config: { ...defaultResearchConfig, phase } },
    scope: { from, to },
    participants: { workers: new Set(episodes.map(row => row.worker)).size,
      office: new Set(episodes.flatMap(row => row.reviewer ? [row.reviewer] : [])).size, consented: null, invited: null },
    episodes, events: [...counts.values()],
    survey: { shown: prompts.length, answered: prompts.filter(event => answers.has(surveyKey(event))).length },
  };
}
