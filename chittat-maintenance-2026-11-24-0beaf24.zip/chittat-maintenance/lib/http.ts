export function apiError(error: unknown): Response {
  const code = error instanceof Error ? error.message : "service-unavailable";
  const status = code === "not-found" ? 404 : code === "forbidden" ? 403 :
    code === "conflict" ? 409 : /^(invalid|missing|unresolved)/.test(code) ? 400 : 503;
  const missingFields=(error as {missingFields?:string[]})?.missingFields;
  if(status===503)console.error("API operation failed",{code:(error as {code?:string})?.code,message:code});
  return Response.json({ error: status === 503 ? "service-unavailable" : code, ...(missingFields?{missingFields}:{}) }, { status });
}

export function sameOrigin(request: Request): boolean {
  const origin = request.headers.get("origin");
  if (!origin) return false;
  // Next may construct request.url from its bind address (0.0.0.0).
  // Validate against the configured public address, never an arbitrary Host header.
  const publicUrl = new URL(process.env.BETTER_AUTH_URL || request.url);
  if (origin === publicUrl.origin) return true;
  if (process.env.NODE_ENV === "production") return false;
  const configured = String(process.env.DEV_ALLOWED_ORIGINS || "").split(",").map(value=>value.trim()).filter(Boolean);
  if (configured.includes(origin)) return true;
  try {
    const incoming = new URL(origin);
    const loopback = new Set(["localhost", "127.0.0.1", "[::1]"]);
    return loopback.has(publicUrl.hostname) && loopback.has(incoming.hostname) &&
      incoming.port === publicUrl.port && incoming.protocol === publicUrl.protocol;
  } catch { return false; }
}

export async function jsonBody(request: Request): Promise<Record<string, any>> {
  if (Number(request.headers.get("content-length") || 0) > 1_000_000) throw new Error("invalid-body");
  const raw = await request.text();
  if (raw.length > 1_000_000) throw new Error("invalid-body");
  let body;
  try { body = JSON.parse(raw); } catch { throw new Error("invalid-body"); }
  if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("invalid-body");
  return body;
}
