import type {Queryable} from './case-service';
import {summarizeContext,type ContextRow} from './human-factors';

// Internal helpers: callers enforce research authorization. No free-text/consent refs returned.
export async function contextRows(db:Queryable,studyId:string,range?:{start:string;end:string}){
  const result=await db.query(`SELECT x.id,x.research_case_id,r.alias,r.phase,r.difficulty,x.role,x.stage,x.source,x.factors,x.load,x.safety,x.case_version,x.rules_version,x.created_at
    FROM research_context_reviews x JOIN research_cases r ON r.id=x.research_case_id
    WHERE r.study_id=$1 AND ($2::timestamptz IS NULL OR x.created_at >= $2)
      AND ($3::timestamptz IS NULL OR x.created_at < $3)
    ORDER BY x.created_at DESC,x.id DESC LIMIT 5001`,[studyId,range?.start??null,range?.end??null]);
  return {rows:result.rows.slice(0,5000).map(r=>({...r,created_at:new Date(r.created_at).toISOString()})) as ContextRow[],partial:result.rows.length>5000};
}
export async function contextOverview(db:Queryable,studyId:string){const data=await contextRows(db,studyId);return summarizeContext(data.rows,data.partial);}
