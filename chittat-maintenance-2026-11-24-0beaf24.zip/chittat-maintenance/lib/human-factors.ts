// Context is supplied by people, never inferred from interaction speed or error counts.
export const humanFactorsVersion='context-review-v1';
export const contextFactors=[
  {id:'interface',label:'提示或操作不清楚',group:'工具',action:'試用清楚的欄位提示與較大操作按鈕',metric:'errors',verify:'相同任務的輸入錯漏與完成時間；保留必要覆核。'},
  {id:'connection',label:'網絡或裝置受限',group:'工具',action:'測試斷線保留輸入與重試提示',metric:'errors',verify:'斷線後資料恢復率；不可重複提交。'},
  {id:'interruption',label:'填寫時被打斷',group:'任務',action:'試用恢復上次填寫位置與進度提示',metric:'time',verify:'恢復任務的人工時間與遺漏數。'},
  {id:'environment',label:'光線、噪音或手套影響',group:'環境',action:'在安全的模擬環境試用大字與高對比顯示',metric:'errors',verify:'可讀性與點選錯誤；不增加閃爍或強制聲響。'},
  {id:'handoff',label:'交接要求不一致',group:'組織',action:'試用雙方共用的提交檢查清單',metric:'returns',verify:'首次通過率與合理退回原因；不可取消必要檢查。'},
  {id:'time_pressure',label:'本人回報時間緊迫',group:'任務',action:'與現場負責人核對任務安排',metric:'time',verify:'本人負擔回報與資料品質；不以加快點擊為目標。'},
  {id:'fatigue',label:'本人回報疲勞感',group:'人員',action:'交由現場負責人按既有程序跟進',metric:'errors',verify:'只記錄回報與跟進，不以系統判定是否適合工作。'},
  {id:'unknown',label:'尚未查明',group:'待確認',action:'先核對操作記錄與當時情境',metric:'errors',verify:'保留其他可能解釋，不自動歸咎於使用者。'},
] as const;
export type ContextFactor=typeof contextFactors[number]['id'];
export const contextStages=[{id:'capture',label:'填寫資料'},{id:'submit',label:'提交與補充'},{id:'review',label:'覆核與交接'},{id:'documents',label:'生成文件'}] as const;
export type ContextInput={role:'worker'|'office';stage:string;source:'self_report'|'observed';factors:ContextFactor[];load:number|null;safety:'not_asked'|'reported'|'none_reported'};
export type ContextRow=ContextInput&{id:string;research_case_id:string;alias:string;phase:string;difficulty:string;created_at:string;case_version:number};
export function validateContext(body:Record<string,unknown>):ContextInput{
  if(body.contextPermission!==true)throw Error('invalid-context-consent');
  if(!['worker','office'].includes(String(body.role))||!contextStages.some(s=>s.id===body.stage)||!['self_report','observed'].includes(String(body.source))||!['not_asked','reported','none_reported'].includes(String(body.safety)))throw Error('invalid-research-input');
  if(!Array.isArray(body.factors)||!body.factors.length||body.factors.length>contextFactors.length||new Set(body.factors).size!==body.factors.length||body.factors.some(v=>!contextFactors.some(f=>f.id===v))||(body.factors.includes('unknown')&&body.factors.length!==1))throw Error('invalid-research-input');
  const load=body.load===null||body.load===undefined?null:body.load;
  if(load!==null&&(typeof load!=='number'||!Number.isInteger(load)||load<1||load>5))throw Error('invalid-research-input');
  if(body.source!=='self_report'&&(load!==null||body.factors.some(v=>v==='fatigue'||v==='time_pressure')))throw Error('invalid-context-source');
  return {role:body.role as ContextInput['role'],stage:body.stage as string,source:body.source as ContextInput['source'],factors:body.factors as ContextFactor[],load:load as number|null,safety:body.safety as ContextInput['safety']};
}
export function summarizeContext(rows:ContextRow[],partial=false){
  // Most recent per case/role/stage: corrections are preserved but not counted as new people.
  const latest=new Map<string,ContextRow>();
  for(const row of [...rows].sort((a,b)=>Date.parse(b.created_at)-Date.parse(a.created_at)||b.id.localeCompare(a.id))){const key=`${row.research_case_id}:${row.role}:${row.stage}`;if(!latest.has(key))latest.set(key,row);}
  const current=[...latest.values()];
  const counts=contextFactors.map(f=>({...f,count:current.filter(r=>r.factors.includes(f.id)).length}));
  return {version:humanFactorsVersion,partial,total:current.length,cases:new Set(current.map(r=>r.research_case_id)).size,
    reported:current.filter(r=>r.source==='self_report').length,observed:current.filter(r=>r.source==='observed').length,
    loadMeasured:current.filter(r=>r.load!==null).length,
    // No average fatigue score, injury probability or employee ranking.
    followup:current.filter(r=>r.safety==='reported').length,
    counts,current,lastEvent:current[0]?.created_at||null};
}
export type ContextSummary=ReturnType<typeof summarizeContext>;
export function contextBrief(summary:ContextSummary,factor:ContextFactor){
  const f=summary.counts.find(v=>v.id===factor)!;
  return `# 工作流改善候選：${f.label}\n\n規則：${summary.version}\n來源：人工核查；${f.count} 組案件／角色／步驟記錄。不是已證實根因。\n資料${summary.partial?'截斷，不能視為完整統計':'僅涵蓋已獲許可、實際收集的記錄'}。\n\n## 可試行的改變\n${f.action}\n\n## 驗證\n${f.verify}\n固定版本與條件，先記錄基線，再比較相近難度任務。記錄是否採用、拒絕或撤回以及原因。\n\n## 實施界線\n本文件是待人員評估的建議，不表示措施已實施。不得推斷疲勞診斷、個人能力或工傷概率。不得修改安全作業程序、權限、資料驗證或自動部署。先用合成任務驗證，再由負責人決定是否試行；保留回滾版本。\n`;
}
