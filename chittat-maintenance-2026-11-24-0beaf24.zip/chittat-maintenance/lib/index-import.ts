import { randomUUID } from "node:crypto";
import ExcelJS from "exceljs";
import { normalizeCell, parseIndex } from "../src/workspace-model";
import type { Queryable } from "./case-service";
import type { Staff } from "./access";
import type { CaseRecord } from "./case-rules";

export async function parseIndexWorkbook(bytes: Uint8Array, existing: CaseRecord[] = []) {
  if (!bytes.length || bytes.length > 10 * 1024 * 1024) throw new Error("invalid-workbook");
  const workbook = new ExcelJS.Workbook();
  const data = new Uint8Array(new ArrayBuffer(bytes.length));
  data.set(bytes);
  await workbook.xlsx.load(data.buffer);
  if (workbook.worksheets.some(sheet => sheet.rowCount > 10000 || sheet.columnCount > 100)) throw new Error("invalid-workbook");
  const sheet = workbook.worksheets.find(item => /^INDEX_\d{4}$/.test(item.name));
  if (!sheet) throw new Error("invalid-index");
  const rows = Array.from({ length: sheet.rowCount }, (_, index) =>
    Array.from({ length: Math.max(12, sheet.columnCount) }, (_, column) =>
      normalizeCell(sheet.getCell(index + 1, column + 1).value)));
  const result = parseIndex({ name: sheet.name, rows }, existing);
  if (result.errors.length) throw new Error("invalid-index");
  return result;
}

export async function importIndex(client: Queryable, staff: Staff, bytes: Uint8Array) {
  if (staff.role === "worker") throw new Error("forbidden");
  const existing = await client.query("SELECT data FROM cases WHERE quote_ref IS NOT NULL");
  const preview = await parseIndexWorkbook(bytes, existing.rows.map(row => row.data));
  let count = 0;
  for (const imported of preview.records) {
    const id = randomUUID();
    const entryNo = `IMPORT-${id.slice(0, 8).toUpperCase()}`;
    const record: CaseRecord = {
      ...imported, id, entryNo, owner: staff.email, createdById: staff.userId,
      createdByName: staff.name, technician: imported.technician || staff.name,
      status: "approved", imported: true, history: [], approvalHistory: [], invoiceHistory: [],
      invoiceRef: imported.ref.replace("-Q-", "-I-"),
    };
    record.approvedSnapshot = { ...record, approvedSnapshot: undefined };
    record.approvalHistory = [{ at: new Date().toISOString(), rev: record.rev, snapshot: record.approvedSnapshot }];
    const inserted = await client.query(`INSERT INTO cases(id,owner_user_id,source,status,entry_no,quote_ref,quote_revision,data)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb) ON CONFLICT(quote_ref) DO NOTHING RETURNING id`,
      [id, staff.userId, record.source, record.status, entryNo, record.ref, record.rev, JSON.stringify(record)]);
    if (!inserted.rows.length) continue;
    await client.query(`INSERT INTO case_versions(id,case_id,kind,revision,snapshot,created_by)
      VALUES ($1,$2,'confirmation',$3,$4::jsonb,$5)`,
      [randomUUID(), id, record.rev, JSON.stringify(record.approvedSnapshot), staff.userId]);
    const match = record.ref.match(/^CT-MNA(\d{2})-Q-(S-)?(\d+)/);
    if (match) await client.query(`INSERT INTO counters(key,value) VALUES ($1,$2)
      ON CONFLICT(key) DO UPDATE SET value=GREATEST(counters.value,EXCLUDED.value)`,
      [`quotation-${match[1]}-${match[2] ? "worker" : "office"}`, Number(match[3])]);
    await client.query(`INSERT INTO audit_events(case_id,actor_user_id,action,detail)
      VALUES ($1,$2,'import-index',$3::jsonb)`, [id, staff.userId, JSON.stringify({ ref: record.ref })]);
    count++;
  }
  return { count, duplicates: preview.duplicates + preview.records.length - count, rowCount: preview.rowCount };
}
