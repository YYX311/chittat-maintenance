import type { Queryable } from "./case-service";
import type { Staff } from "./access";

export async function listIndex(client:Queryable, staff:Staff, params:URLSearchParams) {
 if(staff.role==="worker") throw new Error("forbidden");
 const pageSize=Math.min(100,Math.max(1,Number(params.get("pageSize"))||6));
 const requestedPage=Math.max(1,Math.floor(Number(params.get("page"))||1));
 const values:unknown[]=[],where:string[]=[];
 const add=(sql:string,value:unknown)=>{values.push(value);where.push(sql.replaceAll("?","$"+values.length));};
 for(const [key,field] of [["year","date"],["source","source"],["project","projectCode"]]) {
  const value=params.get(key);if(value&&value!=="all")add(key==="year"?`left(q->>'${field}',4)=?`:`q->>'${field}'=?`,value);
 }
 if(params.get("from"))add("q->>'date'>=?",params.get("from"));
 if(params.get("to"))add("q->>'date'<=?",params.get("to"));
 const state=params.get("state");if(state==="revision")where.push("(q->>'rev')::int>0");else if(state)add("q->>'status'=?",state);
 if(params.get("reference"))add("concat_ws(' ',q->>'ref',q->>'invoiceRef',q->>'serviceNo') ILIKE ?","%"+params.get("reference")+"%");
 if(params.get("query"))add("q::text ILIKE ?","%"+params.get("query")+"%");
 // Only an immutable confirmed snapshot may appear. Pending edits never leak into INDEX.
 const base=`WITH confirmed AS (SELECT id,created_at,data->>'approvedAt' AS confirmed_at,status='revision' AS pending,
  (data->'approvedSnapshot') || jsonb_build_object('status',CASE WHEN status='issued' THEN 'issued' ELSE 'approved' END) AS q
  FROM cases WHERE deleted_at IS NULL AND quote_ref IS NOT NULL AND jsonb_typeof(data->'approvedSnapshot')='object'),
  filtered AS (SELECT * FROM confirmed ${where.length?'WHERE '+where.join(' AND '):''})`;
 const counts=await client.query(base+" SELECT count(*)::int AS total FROM filtered",values);
 const total=counts.rows[0].total,page=Math.min(requestedPage,Math.max(1,Math.ceil(total/pageSize)));
 const result=await client.query(base+` SELECT id,q,pending FROM filtered ORDER BY confirmed_at DESC NULLS LAST,created_at DESC,id LIMIT $${values.length+1} OFFSET $${values.length+2}`,[...values,pageSize,(page-1)*pageSize]);
 return {data:result.rows.map(r=>({...r.q,id:r.id,pendingRevision:r.pending})),total,page,pageSize};
}
