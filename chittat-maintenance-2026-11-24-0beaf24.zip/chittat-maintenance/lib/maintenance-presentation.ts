import type {Signal,MaintenanceAnalysis} from './maintenance-analysis';
// Product triage policy, not a learned risk score or a claim about root cause.
const blocking=new Set(['server_error','network','conflict','rejected']);
const plain:Record<string,{fact:string;next:string}>={
  server_error:{fact:'系統回報操作未正常完成，原因仍待確認。',next:'先查看資料有沒有保存，記下出錯時間和操作步驟，再交給開發者檢查。'},
  network:{fact:'操作沒有等到回應，資料可能已經保存。',next:'先確認網絡恢復，再查看資料是否已保存，避免重複提交。'},
  conflict:{fact:'這次更新被系統攔下，可能有其他人已修改資料。',next:'先保留正在填寫的內容，再與另一端確認是否同時修改了這宗案件。'},
  rejected:{fact:'系統沒有接受這次操作，可能需要補資料或重新登入。',next:'先查看必填提示和登入狀態；仍不能完成時，記下操作步驟交給開發者。'},
  slow:{fact:'有操作等待了至少 5 秒，需要確認等在哪一步。',next:'記下當時在上傳、保存還是生成文件；等待期間不要重複按同一按鈕。'},
  returns:{fact:'有案件被退回至少兩次，可能反覆補充或修改了資料。',next:'查看退回標註，確認對方要求補充什麼，以及要求是否曾經改變。'}
};
export function plainIssue(signal:Signal){return plain[signal.key]||{fact:signal.facts,next:signal.check};}
export function prioritizeSignals(signals:Signal[]){
  return [...signals].sort((a,b)=>Number(blocking.has(b.key))-Number(blocking.has(a.key))||b.cases-a.cases||b.count-a.count||a.key.localeCompare(b.key));
}
export function recommendedSignal(data:MaintenanceAnalysis){
  const ordered=prioritizeSignals(data.signals);
  return ordered.find(signal=>blocking.has(signal.key)&&data.activity&&signal.evidenceIds.includes(data.activity.id))||ordered[0];
}
export function signalScope(data:MaintenanceAnalysis,key:string){return {...data,signals:data.signals.filter(s=>s.key===key)};}
export function emptyGuidance(data:MaintenanceAnalysis,readOnly:boolean){
  if(!data.enrolled)return {title:'先加入一宗案件',description:'選一宗已獲研究許可的案件，之後會自動記錄它的操作情況。',action:readOnly?'設定資料收集':'加入案件'};
  if(!data.runtimeCount&&!data.flow.some(s=>s.cases))return {title:'等待第一筆使用記錄',description:'已加入案件。請讓兩端正常操作，再回來按「重新檢查」。',action:readOnly?'設定資料收集':null};
  return {title:'目前沒有需要檢查的問題',description:'現有記錄未觸發檢查規則，並不代表所有操作都已被監測。',action:readOnly?'查看資料設定':null};
}
