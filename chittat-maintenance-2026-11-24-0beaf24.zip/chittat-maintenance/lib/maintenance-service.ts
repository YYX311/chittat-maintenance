import {createHash,randomUUID} from 'node:crypto';
import type {Queryable} from './case-service';
import type {Staff} from './access';
import {requireResearchAdmin} from './research-service';
import {analyzeMaintenance,diagnosticEvidence} from './maintenance-analysis';
import {dailyLimit,researchModel,promptVersion} from './research-ai';
import {managementSnapshot,managementPromptVersion,type ManagementModel} from './management-analysis';
import {contextOverview} from './human-factors-service';
import {fieldAssistantPromptVersion,fieldAssistantSnapshot} from './field-assistant';
import {fieldRange,loadFieldReport} from './research-field';
export async function maintenanceOverview(db:Queryable,staff:Staff,studyId:string){
  requireResearchAdmin(staff);
  const exists=(await db.query('SELECT status FROM research_studies WHERE id=$1',[studyId])).rows[0];if(!exists)throw new Error('not-found');
  const [runtime,business,total]=await Promise.all([
    db.query(`SELECT e.* FROM research_runtime_events e JOIN research_cases r ON r.id=e.research_case_id WHERE r.study_id=$1 ORDER BY e.created_at DESC,e.id DESC LIMIT 2001`,[studyId]),
    db.query(`SELECT a.id::text,r.id AS research_case_id,a.action,a.created_at FROM research_cases r JOIN research_case_audit a ON a.research_case_id=r.id WHERE r.study_id=$1 ORDER BY a.created_at DESC,a.id DESC LIMIT 2001`,[studyId]),
    db.query('SELECT count(*)::int AS n FROM research_cases WHERE study_id=$1',[studyId])]);
  // pg timestamptz values are Dates locally and may be strings in other adapters.
  const normalize=(r:any)=>({...r,created_at:new Date(r.created_at).toISOString()});
  return {...analyzeMaintenance(runtime.rows.slice(0,2000).map(normalize),business.rows.slice(0,2000).map(normalize),total.rows[0].n,runtime.rows.length>2000||business.rows.length>2000),context:await contextOverview(db,studyId)};
}
// Must be called in a transaction. Snapshot + model version makes caching auditable.
export async function reserveDiagnosticAi(db:Queryable,staff:Staff,studyId:string,signalKey?:string,managementModel?:ManagementModel,
  range?:ReturnType<typeof fieldRange>){
  requireResearchAdmin(staff);
  await db.query('SELECT pg_advisory_xact_lock(hashtext($1))',[`diagnostic-${studyId}`]);
  const study=(await db.query('SELECT status FROM research_studies WHERE id=$1 FOR UPDATE',[studyId])).rows[0];
  if(!study)throw new Error('not-found');if(study.status!=='collecting')throw new Error('invalid-study-not-collecting');
  let evidence:string,version:string,factIds:string[]=[];
  if(range){
    const snapshot=fieldAssistantSnapshot(await loadFieldReport(db,studyId,range));
    if(!snapshot.ready)throw new Error('invalid-no-evidence');
    ({evidence}=snapshot);
    version=fieldAssistantPromptVersion;
    factIds=snapshot.facts.map(f=>f.id);
  }else{
    const analysis=await maintenanceOverview(db,staff,studyId);
    if(signalKey)analysis.signals=analysis.signals.filter(s=>s.key===signalKey);
    const snapshot=managementModel?managementSnapshot(analysis,managementModel):null;
    if(snapshot?!snapshot.ready:!analysis.signals.length)throw new Error('invalid-no-evidence');
    evidence=snapshot?.evidence||diagnosticEvidence(analysis);
    version=snapshot?managementPromptVersion:promptVersion;
    factIds=snapshot?.facts.map(f=>f.id)||[];
  }
  const hash=createHash('sha256').update(JSON.stringify({evidence,model:researchModel,version,managementModel})).digest('hex');
  const prior=(await db.query("SELECT *,started_at<now()-interval '2 minutes' AS stale FROM research_diagnostic_runs WHERE study_id=$1 AND input_hash=$2",[studyId,hash])).rows[0];
  if(prior?.status==='complete')return {cached:prior.result,evidence,hash};
  if(prior?.status==='running'&&!prior.stale)throw new Error('ai-running');
  const quota=await db.query(`INSERT INTO research_ai_usage(day,attempts) VALUES((now() AT TIME ZONE 'UTC')::date,1)
    ON CONFLICT(day) DO UPDATE SET attempts=research_ai_usage.attempts+1 WHERE research_ai_usage.attempts<$1 RETURNING attempts`,[dailyLimit]);
  if(!quota.rows.length)throw new Error('ai-daily-limit');
  const id=prior?.id||randomUUID(),attempt=randomUUID();
  await db.query(`INSERT INTO research_diagnostic_runs(id,study_id,input_hash,evidence,status,model,prompt_version,attempt_id)
    VALUES($1,$2,$3,$4,'running',$5,$6,$7) ON CONFLICT(study_id,input_hash) DO UPDATE SET status='running',attempt_id=$7,started_at=now(),result=NULL`,[id,studyId,hash,evidence,researchModel,version,attempt]);
  return {id,attempt,evidence,hash,factIds};
}
export async function finishDiagnosticAi(db:Queryable,id:string,attempt:string,result:unknown){
  await db.query("UPDATE research_diagnostic_runs SET status=$3,result=$4::jsonb WHERE id=$1 AND attempt_id=$2",[id,attempt,result?'complete':'failed',result?JSON.stringify(result):null]);
}
