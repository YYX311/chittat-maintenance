import { mkdir, readFile, writeFile, unlink } from "node:fs/promises";
import path from "node:path";
import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";

export type ObjectStore = {
  put: (key: string, bytes: Uint8Array, contentType: string) => Promise<void>;
  get: (key: string) => Promise<Uint8Array>;
  remove?: (key: string) => Promise<void>;
};

function assertKey(key: string) {
  if (!/^cases\/[a-f0-9-]{36}\/[a-f0-9-]{36}$/.test(key)) throw new Error("invalid-object-key");
}

export function localObjectStore(root = path.resolve(process.cwd(), ".data", "assets")): ObjectStore {
  return {
    async put(key, bytes) {
      assertKey(key);
      const file = path.join(root, ...key.split("/"));
      await mkdir(path.dirname(file), { recursive: true });
      await writeFile(file, bytes, { flag: "wx" });
    },
    async remove(key) {
      assertKey(key);
      await unlink(path.join(root, ...key.split("/"))).catch(error=>{if(error.code!=="ENOENT")throw error;});
    },
    async get(key) {
      assertKey(key);
      return readFile(path.join(root, ...key.split("/")));
    },
  };
}

export function configuredObjectStore(): ObjectStore {
  const mode = process.env.OBJECT_STORAGE_MODE || (process.env.NODE_ENV === "production" ? "s3" : "local");
  if (mode === "local") {
    if (process.env.NODE_ENV === "production") throw new Error("production-requires-private-object-storage");
    return localObjectStore(process.env.LOCAL_STORAGE_PATH || undefined);
  }
  if (mode !== "s3" || !process.env.S3_BUCKET || !process.env.S3_REGION) throw new Error("object-storage-not-configured");
  const client = new S3Client({
    region: process.env.S3_REGION,
    endpoint: process.env.S3_ENDPOINT || undefined,
    forcePathStyle: Boolean(process.env.S3_ENDPOINT),
  });
  const bucket = process.env.S3_BUCKET;
  return {
    async put(key, bytes, contentType) {
      assertKey(key);
      await client.send(new PutObjectCommand({ Bucket: bucket, Key: key, Body: bytes, ContentType: contentType }));
    },
    async remove(key) {
      assertKey(key);
      await client.send(new DeleteObjectCommand({Bucket:bucket,Key:key}));
    },
    async get(key) {
      assertKey(key);
      const response = await client.send(new GetObjectCommand({ Bucket: bucket, Key: key }));
      if (!response.Body) throw new Error("asset-missing");
      return response.Body.transformToByteArray();
    },
  };
}

export async function drainObjectDeletions(client: import("./case-service").Queryable) {
  const store=configuredObjectStore();
  const {rows}=await client.query("SELECT object_key FROM object_deletions ORDER BY queued_at LIMIT 100");
  for(const row of rows){await store.remove!(row.object_key);await client.query("DELETE FROM object_deletions WHERE object_key=$1",[row.object_key]);}
}
