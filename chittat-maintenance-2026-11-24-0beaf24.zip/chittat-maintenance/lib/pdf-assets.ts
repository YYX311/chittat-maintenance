import { readFile } from "node:fs/promises";
import path from "node:path";

export async function loadPdfAssets() {
  const [font, logo] = await Promise.all([
    readFile(path.resolve(process.cwd(), "assets/fonts/NotoSansHK.ttf")),
    readFile(path.resolve(process.cwd(), "public/brand-logo.png")),
  ]);
  return { font, logo };
}
