import { loadPdfAssets } from "./pdf-assets";
import commercialTemplate from "../assets/commercial-template.json";
import PDFDocument from "pdfkit";
import type { CaseRecord } from "./case-rules";
import {subtotal, discount, netTotal, validDiscount} from "../src/commercial-totals.js";

export type DocumentKind = "service" | "quotation" | "invoice" | "confirmed-service";
const WIDTH=595,HEIGHT=842,INK="#171717",ORANGE="#d85a35";
const documentLogos = new WeakMap<PDFKit.PDFDocument, Buffer>();

function company(){
 const hk=process.env.COMPANY_NAME_HK||(process.env.NODE_ENV==="production"?"":"捷達機電工程有限公司");
 const en=process.env.COMPANY_NAME_EN||(process.env.NODE_ENV==="production"?"":"CHIT TAT ELECTRICAL ENGINEERING LTD.");
 if(!hk||!en)throw new Error("company-details-not-configured");
 return {hk,en,address:process.env.COMPANY_ADDRESS||"",phone:process.env.COMPANY_PHONE||"",website:process.env.COMPANY_WEBSITE||"www.chittathk.com",email:process.env.COMPANY_EMAIL||"info@chittat.com.hk"};
}
const safe=(value:unknown,empty="")=>String(value??empty);
const amount=(value:unknown)=>Number(value||0).toLocaleString("en-HK",{minimumFractionDigits:2,maximumFractionDigits:2});
const line=(pdf:PDFKit.PDFDocument,x1:number,y1:number,x2:number,y2:number,width=.55)=>pdf.moveTo(x1,y1).lineTo(x2,y2).lineWidth(width).strokeColor(INK).stroke();
const box=(pdf:PDFKit.PDFDocument,x:number,y:number,w:number,h:number)=>pdf.rect(x,y,w,h).lineWidth(.55).strokeColor(INK).stroke();
function logo(pdf:PDFKit.PDFDocument,x:number,y:number,width:number){const scale=width/298;pdf.save().rect(x,y,width,52*scale).clip();pdf.image(documentLogos.get(pdf)!,x-3*scale,y-78*scale,{width:304*scale});pdf.restore()}
function label(pdf:PDFKit.PDFDocument,text:string,x:number,y:number,width:number,size=7.4){pdf.fontSize(size).fillColor(INK).text(text,x,y,{width,lineGap:0})}

function serviceDocument(pdf:PDFKit.PDFDocument,record:CaseRecord,name:ReturnType<typeof company>){
 const x=29,w=537,right=x+w;logo(pdf,112,24,370);
 pdf.fontSize(13).fillColor(INK).text("工程／維修服務單",0,82,{width:WIDTH,align:"center"});
 pdf.fontSize(13).text("PROJECT / SERVICE ORDER",0,100,{width:WIDTH,align:"center",underline:true});
 pdf.fontSize(7.5).text("編號\nOrder No:",390,92,{width:58,align:"right"});pdf.fontSize(15).fillColor(ORANGE).text(safe(record.serviceNo,"—"),454,99,{width:110,align:"center"});
 let y=126;box(pdf,x,y,w,25);line(pdf,301,y,301,y+25);label(pdf,"客戶名稱\nClient's Name",x+4,y+3,112);label(pdf,safe(record.customer),116,y+8,180,9);label(pdf,"客戶聯絡電話\nClient's Telephone No.",305,y+3,110);label(pdf,safe(record.phone),420,y+8,141,9);
 y+=25;box(pdf,x,y,w,25);label(pdf,"工作地點\nJob Location",x+4,y+3,90);label(pdf,[record.address,record.tower,record.floor,record.flat].filter(Boolean).join("  "),124,y+8,437,9);
 y+=25;box(pdf,x,y,w,170);label(pdf,"工作內容\nDescription",x+4,y+3,90);const descriptions=record.items.map((item,index)=>`${index+1}. ${safe(item.description)||safe(item.model)||`工作項目 ${Number(item.preset||0)+1}`}  × ${safe(item.qty)} ${safe(item.unit,"no.")}`).join("\n");pdf.fontSize(9).text(descriptions,x+56,y+26,{width:w-68,height:132,lineGap:4});for(let row=0;row<4;row++)line(pdf,x+56,y+54+row*30,right-14,y+54+row*30,.25);
 y+=170;box(pdf,x,y,w,150);line(pdf,301,y,301,y+150);const leftRows:[[string,unknown],[string,unknown],[string,unknown],[string,unknown],[string,unknown]]=[
  ["工程經手人\nExecuted by",record.technician],["開工時間／日期\nCommencement Time / Date",record.startedAt?.replace("T"," ")],["完工時間／日期\nCompletion Time / Date",record.completedAt?.replace("T"," ")],["工程收費\nCharge Amount (HK$)",record.chargeAmount!==""&&record.chargeAmount!=null?`HK$ ${amount(record.chargeAmount)}`:`HK$ ${amount(record.items.reduce((sum,item)=>sum+Number(item.qty||0)*Number(item.price||0),0))}`],["合約／報價編號\nContract / Quotation No.",record.contractRef]
 ];leftRows.forEach(([heading,value],index)=>{if(index)line(pdf,x,y+index*30,301,y+index*30);label(pdf,heading,x+4,y+index*30+3,105);label(pdf,safe(value),143,y+index*30+10,153,8.5)});label(pdf,"客戶簽收工程妥當（另加公司蓋章）\nCertify Acceptance By (w/Co. Chop)",306,y+4,250);
 y+=150;box(pdf,x,y,w,82);label(pdf,"材料\nMaterial",x+4,y+3,80);pdf.fontSize(9).text(safe(record.material),x+54,y+24,{width:w-65,height:52});y+=82;
 [record.serviceRemark1,record.serviceRemark2,record.serviceRemark3].forEach((value,index)=>{box(pdf,x,y+index*42,w,42);label(pdf,`備註 ${["一","二","三"][index]}\nRemarks ${index+1}`,x+4,y+index*42+3,62);pdf.fontSize(8.5).text(safe(value),x+68,y+index*42+10,{width:w-78,height:28})});y+=126;
 pdf.fontSize(7.5).text("** 此單並非收據 **\n** This is not a receipt. **",0,y+10,{width:WIDTH,align:"center"});pdf.fontSize(6.5).text("Version 2021/12",right-80,y+22,{width:80,align:"right"});
 pdf.fontSize(7).text(record.source==="worker"?"資料來源：工人 / Worker":"資料來源：辦公室 / Office",x,y+35,{width:w,align:"center"});
 const contact=[name.address,name.phone&&`電話: ${name.phone}`,`Website: ${name.website}`,`E-mail: ${name.email}`].filter(Boolean).join("    ");pdf.fontSize(6.2).text(contact,x,y+46,{width:w,align:"center"});
}

// Cell positions, row heights and rules transcribed from the supplied QUO / INVOICE workbook.
function commercialDocument(pdf:PDFKit.PDFDocument,record:CaseRecord,kind:"quotation"|"invoice",name:ReturnType<typeof company>){
 if(!validDiscount(record))throw new Error("invalid-discount");
 const invoice=kind==="invoice",template=invoice?commercialTemplate.INVOICE:commercialTemplate.QUO;
 const scale=.75,originX=28,originY=78;
 const xs=[originX],ys=[originY];
 const widthScale=539/template.widths.reduce((sum,n)=>sum+n,0);
 template.widths.forEach(n=>xs.push(xs.at(-1)!+n*widthScale));
 template.heights.forEach(n=>ys.push(ys.at(-1)!+n*scale));
 const write=(r:number,c:number,value:unknown,size=9,align:"left"|"center"|"right"="left",end=14)=>{
  pdf.fontSize(size).fillColor(INK).text(safe(value),xs[c]+2,ys[r]+1,{width:xs[end]-xs[c]-4,align,lineBreak:false});
 };
 const top=invoice?2:1,itemRow=invoice?13:12,totalRow=invoice?17:16;
 // Split long descriptions into measured lines before allocating pages; never clip work items.
 const entries: {index:number;description:string;qty:unknown;unit:unknown;price:unknown;sum:unknown}[]=[];
 record.items.forEach((item,index)=>{
  const description=[safe(item.description)||`工作項目 ${Number(item.preset||0)+1}`,item.brand||record.brand,item.model].filter(Boolean).join(" · ");
  let text="";const lines:string[]=[];pdf.fontSize(9);
  for(const ch of description){if(text&&pdf.widthOfString(text+ch)>xs[8]-xs[4]-6){lines.push(text);text="";}text+=ch;}if(text)lines.push(text);
  lines.forEach((description,n)=>entries.push({index:n===0?index+1:0,description,qty:n===0?item.qty:"",unit:n===0?item.unit||"no.":"",price:n===0?amount(item.price):"",sum:n===0?amount(Number(item.qty||0)*Number(item.price||0)):""}));
 });
 const pages=Math.max(1,Math.ceil(entries.length/4));
 const appendix:string[]=[];
 pdf.fontSize(8);
 let remarkSize=8;
 const remarkWidth=xs[14]-xs[4]-4;
 if(!invoice&&record.remark){
  // Expand the original remark block into unused page space before reducing type.
  const spare=Math.max(0,802-ys[ys.length-1]);
  const available=ys[29]-ys[21]-4+spare;
  while(remarkSize>7&&pdf.fontSize(remarkSize).heightOfString(record.remark,{width:remarkWidth,lineGap:1})>available)remarkSize-=.25;
  const required=pdf.fontSize(remarkSize).heightOfString(record.remark,{width:remarkWidth,lineGap:1});
  if(required>available)throw new Error("invalid-quotation-remarks-too-long");
  const extra=Math.max(0,required-(ys[29]-ys[21]-4));
  for(let r=29;r<ys.length;r++)ys[r]+=extra;
 }
 const longPayment=!invoice&&record.paymentTerms&&pdf.heightOfString(record.paymentTerms,{width:xs[14]-xs[4]-4})>ys[31]-ys[29]-3;
 if(longPayment)appendix.push("付款條款\n"+record.paymentTerms);
 for(let page=0;page<pages;page++){
  if(page)pdf.addPage();logo(pdf,112,18,370);
  for(const cell of template.cells){
   if(cell.r===totalRow)continue;
   if(cell.r===template.titleRow)continue;
   if(!invoice&&cell.c===3&&(cell.r===21||cell.r===29)){write(cell.r,2,cell.text,8,"left",4);continue;}
   // Custom remarks replace the source's seven remark rows, preserving their location.
   if(!invoice&&record.remark&&cell.r>=21&&cell.r<=27&&cell.c===4)continue;
   if(!invoice&&record.paymentTerms&&cell.r===29&&cell.c===4)continue;
   const next=template.cells.filter(c=>c.r===cell.r&&c.c>cell.c).sort((a,b)=>a.c-b.c)[0]?.c||14;
   write(cell.r,cell.c,cell.text,cell.size*scale,cell.align===3?"right":"left",next);
  }
  box(pdf,xs[1],ys[template.titleRow],xs[14]-xs[1],template.heights[template.titleRow]*scale);
  write(template.titleRow,1,`${invoice?"INVOICE 發票":"報價單"} · Rev ${record.rev||0}`,15,"center");
  for(const border of template.borders){if(border.r===template.titleRow||border.r===totalRow)continue;
   if(border.top)line(pdf,xs[border.c],ys[border.r],xs[border.c+1],ys[border.r]);
   if(border.bottom){line(pdf,xs[border.c],ys[border.r+1],xs[border.c+1],ys[border.r+1]);if(border.bottom===6)line(pdf,xs[border.c],ys[border.r+1]+2,xs[border.c+1],ys[border.r+1]+2);}}
  write(top,4,record.customer||record.address,9,"left",11);
  write(top,13,invoice?record.invoiceRef:record.ref,8);
  write(top+2,4,[record.contact,record.phone].filter(Boolean).join(" "),9,"left",11);
  write(top+2,13,invoice?record.ref:record.lastConfirmedByName,8);
  if(invoice)write(5,13,record.projectCode,8);
  write(top+5,4,[record.address,record.tower,record.floor,record.flat].filter(Boolean).join(" "),8,"left",11);
  write(top+5,13,invoice?record.invoiceDate||record.date:record.date,8);
  entries.slice(page*4,page*4+4).forEach((item,n)=>{const r=itemRow+n;write(r,1,item.index?item.index+".":"",9,"left",4);write(r,4,item.description,9,"left",8);write(r,8,item.qty,9,"right",9);write(r,9,item.unit,9,"left",11);write(r,11,item.price,9,"right",13);write(r,13,item.sum,9,"right");});
  const totals=[['Sub Total',amount(subtotal(record))],['Less discount',`(${amount(discount(record))})`],['Total Net Amount',amount(netTotal(record))]];
  totals.forEach(([heading,value],index)=>{
   const y=ys[totalRow+index]+1;
   pdf.fontSize(9).fillColor(index===1?'#a23d3d':INK);
   pdf.text(heading+' :',xs[8],y,{width:xs[13]-xs[8]-30,align:'right',lineBreak:false});
   pdf.text('HK$',xs[13]-27,y,{width:27,lineBreak:false});
   pdf.text(value,xs[13]+2,y,{width:xs[14]-xs[13]-4,align:'right',lineBreak:false});
   if(index===1)line(pdf,xs[13]-27,ys[totalRow+2],xs[14],ys[totalRow+2]);
  });
  line(pdf,xs[13]-27,ys[totalRow+3],xs[14],ys[totalRow+3]);
  line(pdf,xs[13]-27,ys[totalRow+3]+2,xs[14],ys[totalRow+3]+2);
  if(!invoice&&record.remark){pdf.fontSize(remarkSize).text(record.remark,xs[4]+2,ys[21],{width:remarkWidth,lineGap:1});}
  if(!invoice&&record.paymentTerms)write(29,4,longPayment?"完整付款條款請見隨附續頁。":record.paymentTerms,8);
  if(pages>1)pdf.fontSize(8).text(`${page+1} / ${pages}`,28,812,{width:539,align:"right"});
 }
 if(appendix.length){
  let y=0;const nextPage=()=>{pdf.addPage();logo(pdf,112,18,370);pdf.fontSize(10).text(`${record.ref} · 續頁`,40,90,{width:515});y=120;};nextPage();
  pdf.fontSize(9);
  for(const paragraph of appendix.join("\n\n").split("\n")){
   let row="";const emit=()=>{if(y>785){nextPage();pdf.fontSize(9);}pdf.text(row,40,y,{width:515,lineBreak:false});y+=15;row="";};
   for(const ch of paragraph){if(row&&pdf.widthOfString(row+ch)>510)emit();row+=ch;}emit();
  }
 }
}

export async function renderDocument(record:CaseRecord,kind:DocumentKind):Promise<Uint8Array>{
 const assets=await loadPdfAssets();
 const name=company(),reference=(kind==="service"||kind==="confirmed-service")?record.serviceNo:kind==="quotation"?record.ref:record.invoiceRef;
 return new Promise<Uint8Array>((resolve,reject)=>{const pdf=new PDFDocument({font:"",size:[WIDTH,HEIGHT],margin:0,compress:true,info:{Title:`${kind} ${reference||""}`,Creator:"Maintenance Operations"}});pdf.font(assets.font);documentLogos.set(pdf,assets.logo);const chunks:Buffer[]=[];pdf.on("data",(chunk:Buffer)=>chunks.push(chunk));pdf.on("error",reject);pdf.on("end",()=>resolve(new Uint8Array(Buffer.concat(chunks))));if(kind==="service"||kind==="confirmed-service")serviceDocument(pdf,record,name);else commercialDocument(pdf,record,kind,name);pdf.end()});
}
