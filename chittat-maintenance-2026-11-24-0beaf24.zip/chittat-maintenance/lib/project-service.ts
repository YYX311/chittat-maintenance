import { randomUUID } from "node:crypto";
import type { Staff } from "./access";
import type { Queryable } from "./case-service";

export async function listProjects(client: Queryable) {
  const { rows } = await client.query("SELECT id,code,name,details,active FROM projects ORDER BY name");
  return rows.map(row => ({ id: row.id, code: row.code, name: row.name, active: row.active, ...row.details }));
}

export async function createProject(client: Queryable, staff: Staff, incoming: Record<string, unknown>) {
  if (staff.role === "worker") throw new Error("forbidden");
  const name = String(incoming.name || "").trim();
  const property = String(incoming.property || "").trim();
  const code = String(incoming.code || "").trim();
  if (!name || name.length > 200 || !property || property.length > 500 ||
    !/^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$/.test(code)) throw new Error("invalid-project");
  const fields = ["contractRef", "coverage", "coverageNotes", "brand", "itemTerms"];
  const details: Record<string, string> = { property };
  for (const field of fields) {
    const value = String(incoming[field] || "").trim();
    if (value.length > 2000) throw new Error("invalid-project");
    details[field] = value;
  }
  const id = randomUUID();
  try { await client.query("INSERT INTO projects(id,code,name,details) VALUES ($1,$2,$3,$4::jsonb)",
    [id, code, name, JSON.stringify(details)]); }
  catch(error){if((error as {code?:string}).code==="23505")throw new Error("conflict");throw error;}
  return { id, code, name, active: true, ...details };
}

export async function updateProject(client:Queryable,staff:Staff,incoming:Record<string,unknown>) {
 if(staff.role==="worker")throw new Error("forbidden");
 const id=String(incoming.id||""),code=String(incoming.code||"").trim(),expected=String(incoming.expectedCode||"");
 if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$/.test(code))throw new Error("invalid-project");
 let result;
 try { result=await client.query(`UPDATE projects SET code=$2,
  details=jsonb_set(details,'{previousCodes}',COALESCE(details->'previousCodes','[]'::jsonb)||to_jsonb(code))
  WHERE id=$1 AND code=$3 AND active=TRUE RETURNING id,code,name,details`,[id,code,expected]); }
 catch(error){if((error as {code?:string}).code==="23505")throw new Error("conflict");throw error;}
 if(!result.rows.length)throw new Error("conflict");
 const row=result.rows[0];return {id:row.id,code:row.code,name:row.name,active:true,...row.details};
}

export async function deleteProject(client:Queryable,staff:Staff,incoming:Record<string,unknown>) {
 if(staff.role==="worker")throw new Error("forbidden");
 const id=String(incoming.id||""),expected=String(incoming.expectedCode||"");
 if(!id||!expected)throw new Error("invalid-project");
 // Retain the row and its ID for existing tasks and issued documents.
 const {rows}=await client.query("UPDATE projects SET active=FALSE WHERE id=$1 AND code=$2 AND active=TRUE RETURNING id,code,name,details,active",[id,expected]);
 if(!rows.length)throw new Error("conflict");
 const row=rows[0];return {id:row.id,code:row.code,name:row.name,active:row.active,...row.details};
}
