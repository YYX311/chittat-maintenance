export type RecoveryEvent={episode:string;participant:string;role:string;variant:string;kind:string;at:string;active_ms:number|null;rating:number|null};
const median=(values:number[])=>{const a=[...values].sort((x,y)=>x-y);return a.length?(a[Math.floor((a.length-1)/2)]+a[Math.floor(a.length/2)])/2:null;};

/** Cohort is defined by prompt appearance, not by outcome date. Missing is never zero. */
export function recoverySummary(events:RecoveryEvent[],start:string,end:string){
  const groups=new Map<string,RecoveryEvent[]>();
  for(const row of events){const key=`${row.participant}:${row.episode}`;groups.set(key,[...(groups.get(key)||[]),row]);}
  const episodes=[...groups.values()].flatMap(rows=>{
    rows.sort((a,b)=>Date.parse(a.at)-Date.parse(b.at));
    const shown=rows.find(r=>r.kind==='shown');
    if(!shown||shown.at<start||shown.at>=end)return [];
    const after=(kind:string)=>rows.find(r=>r.kind===kind&&r.at>=shown.at&&r.at<end);
    const left=after('left');
    const corrected=after('resolved');
    const resolved=corrected&&(!left||corrected.at<=left.at)?corrected:undefined;
    const rating=resolved?rows.find(r=>r.kind==='rating'&&r.at>=resolved.at&&r.at<end):undefined;
    const submitted=resolved?rows.find(r=>r.kind==='submitted'&&r.at>=resolved.at&&r.at<end):undefined;
    const seconds=resolved?(Date.parse(resolved.at)-Date.parse(shown.at))/1000:null;
    const active=resolved?.active_ms==null?null:resolved.active_ms/1000;
    return [{episode:shown.episode,participant:shown.participant,role:shown.role,variant:shown.variant,at:shown.at,
      focused:!!after('focus'),resolved:!!resolved,submitted:!!submitted,left:!!left&&!resolved,
      offline:!!after('offline'),seconds,activeSeconds:active!==null&&seconds!==null&&active<=seconds?active:null,
      frustration:rating?.rating??null,skipped:!!after('skip')}];
  });
  const summarize=(rows:typeof episodes)=>({n:rows.length,resolved:rows.filter(r=>r.resolved).length,
    submitted:rows.filter(r=>r.submitted).length,left:rows.filter(r=>r.left).length,
    pending:rows.filter(r=>!r.resolved&&!r.left).length,offline:rows.filter(r=>r.offline).length,
    rated:rows.filter(r=>r.frustration!==null).length,
    medianSeconds:median(rows.flatMap(r=>r.seconds===null?[]:[r.seconds])),
    medianActiveSeconds:median(rows.flatMap(r=>r.activeSeconds===null?[]:[r.activeSeconds])),
    medianFrustration:median(rows.flatMap(r=>r.frustration===null?[]:[r.frustration]))});
  const pairs=[...new Set(episodes.map(r=>r.participant))].map(participant=>({participant,
    A:summarize(episodes.filter(r=>r.participant===participant&&r.variant==='A')),
    B:summarize(episodes.filter(r=>r.participant===participant&&r.variant==='B'))}));
  return {total:summarize(episodes),conditions:['A','B','OBS'].map(variant=>({variant,...summarize(episodes.filter(r=>r.variant===variant))})),
    pairs,episodes:episodes.sort((a,b)=>b.at.localeCompare(a.at))};
}
