import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

export function readRecoveryDocument() {
  return readFile(resolve(process.cwd(), 'docs/recovery-study-supplied.html'), 'utf8');
}
