import type {Queryable} from './case-service';
import type {Staff} from './access';
import {participantCode} from './field-study-analysis';
import {recoverySummary} from './recovery-analysis';
const kinds=['shown','focus','resolved','submitted','rating','skip','left','offline','reconnect'];
export function recoveryEvents(input:unknown,now=Date.now()){
  if(!Array.isArray(input)||!input.length||input.length>40)throw Error('invalid-recovery-events');
  return input.map(row=>{
    if(!row||!['id','episode','caseId'].every(k=>typeof row[k]==='string'&&/^[\w-]{8,100}$/.test(row[k]))||
      !kinds.includes(row.kind)||!Number.isInteger(row.at)||row.at>now+60000||row.at<now-7*86400000||
      (row.kind==='resolved'&&(!Number.isInteger(row.activeMs)||row.activeMs<0||row.activeMs>86400000))||
      (row.kind==='rating'&&(!Number.isInteger(row.rating)||row.rating<1||row.rating>7)))throw Error('invalid-recovery-events');
    return {id:row.id,episode:row.episode,case_id:row.caseId,kind:row.kind,at:new Date(row.at).toISOString(),
      active_ms:row.kind==='resolved'?row.activeMs:null,rating:row.kind==='rating'?row.rating:null};
  });
}
export async function saveRecovery(db:Queryable,staff:Staff,body:Record<string,unknown>){
  const events=recoveryEvents(body.events);
  if(typeof body.studyId!=='string')throw Error('invalid-recovery-study');
  await db.query('SELECT pg_advisory_xact_lock(hashtext($1))',[`recovery:${staff.userId}`]);
  const joined=await db.query(`SELECT p.joined_at FROM research_participation p
    JOIN research_auto_collection a ON a.study_id=p.study_id JOIN research_studies s ON s.id=p.study_id
    WHERE p.study_id=$1 AND p.user_id=$2 AND p.left_at IS NULL AND a.stopped_at IS NULL AND s.status='collecting'
    AND EXISTS(SELECT 1 FROM research_recovery_settings z WHERE z.study_id=p.study_id AND z.enabled)`,[body.studyId,staff.userId]);
  if(!joined.rows.length)throw Error('forbidden');
  const count=await db.query("SELECT count(*)::int AS n FROM research_recovery_events WHERE actor_user_id=$1 AND received_at>now()-interval '1 day'",[staff.userId]);
  if(count.rows[0].n+events.length>2000)throw Error('invalid-recovery-limit');
  const result=await db.query(`INSERT INTO research_recovery_events(study_case_id,actor_user_id,id,episode,kind,at,variant,role,active_ms,rating)
    SELECT r.id,$2,x.id,x.episode,x.kind,x.at,
      CASE WHEN r.trial_period LIKE 'A%' THEN 'A' WHEN r.trial_period LIKE 'B%' THEN 'B' ELSE 'OBS' END,
      CASE WHEN $4='worker' THEN 'worker' ELSE 'office' END,x.active_ms,x.rating
    FROM jsonb_to_recordset($3::jsonb) x(id text,episode text,case_id text,kind text,at timestamptz,active_ms int,rating int)
    JOIN research_cases r ON r.case_id=x.case_id AND r.study_id=$1 JOIN cases c ON c.id=r.case_id
    LEFT JOIN LATERAL (SELECT enabled FROM research_telemetry_settings WHERE study_id=r.study_id ORDER BY version DESC LIMIT 1) cfg ON true
    WHERE r.trial_period IS NOT NULL AND c.deleted_at IS NULL AND ($4<>'worker' OR c.owner_user_id=$2)
      AND x.at>=GREATEST(r.enrolled_at,$5::timestamptz)
      AND (cfg.enabled IS NULL OR $6=ANY(cfg.enabled))
      AND (x.kind<>'submitted' OR EXISTS(SELECT 1 FROM research_case_audit a WHERE a.research_case_id=r.id
        AND a.actor_user_id=$2 AND a.action=CASE WHEN $4='worker' THEN 'submit' ELSE 'confirm' END
        AND a.created_at BETWEEN x.at-interval '2 minutes' AND x.at+interval '1 minute'))
    ON CONFLICT DO NOTHING RETURNING id`,[body.studyId,staff.userId,JSON.stringify(events),staff.role,joined.rows[0].joined_at,
      staff.role==='worker'?'field-record':'office-record']);
  return {recorded:result.rows.length};
}
export async function loadRecovery(db:Queryable,studyId:string,start:string,end:string,role="worker"){
  const data=await db.query(`SELECT e.*,s.id AS study FROM research_recovery_events e
    JOIN research_cases r ON r.id=e.study_case_id JOIN research_studies s ON s.id=r.study_id
    WHERE s.id=$1 AND e.role=$4 AND e.at >= $2 AND e.at < $3 ORDER BY e.at,e.id LIMIT 10001`,[studyId,start,end,role]);
  const partial=data.rows.length>10000;
  const events=data.rows.map(r=>({episode:r.episode,participant:participantCode(studyId,r.actor_user_id),role:r.role,
    variant:r.variant,kind:r.kind,at:new Date(r.at).toISOString(),active_ms:r.active_ms,rating:r.rating}));
  return {partial,...recoverySummary(partial?[]:events,start,end)};
}
