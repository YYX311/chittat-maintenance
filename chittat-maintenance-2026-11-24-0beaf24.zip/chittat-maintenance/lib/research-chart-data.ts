export type GroupRow={phase:string;difficulty:string;measurement_method:string|null;cases:number;timed:number;mean_minutes:string|null;quality_measured:number;mean_errors:string|null};
export function chartGroups(rows:GroupRow[],difficulty='all',method='all'){
  return ['baseline','improved'].map(phase=>{
    const selected=rows.filter(r=>r.phase===phase&&(difficulty==='all'||r.difficulty===difficulty)&&(method==='all'||r.measurement_method===method));
    const total=selected.reduce((n,r)=>n+r.cases,0);
    const timed=selected.reduce((n,r)=>n+r.timed,0),quality=selected.reduce((n,r)=>n+r.quality_measured,0);
    return {phase,total,timed,quality,
      minutes:timed?selected.reduce((n,r)=>n+Number(r.mean_minutes||0)*r.timed,0)/timed:null,
      errors:quality?selected.reduce((n,r)=>n+Number(r.mean_errors||0)*r.quality_measured,0)/quality:null};
  });
}

// Only compare measured values in one difficulty stratum and one measurement method.
export function researchComparison(rows:GroupRow[],difficulty:string,method:string,metric:'minutes'|'errors'){
  const groups=chartGroups(rows,difficulty,method);
  const [before,after]=groups;
  if(before[metric]===null||after[metric]===null)return {groups,status:'missing' as const,delta:null};
  if(method==='all')return {groups,status:'method' as const,delta:null};
  const levels=new Set(rows.filter(r=>r.measurement_method===method&&(difficulty==='all'||r.difficulty===difficulty)&&(metric==='minutes'?r.timed:r.quality_measured)>0).map(r=>r.difficulty));
  if(levels.size!==1)return {groups,status:'difficulty' as const,delta:null};
  return {groups,status:'comparable' as const,delta:after[metric]-before[metric]};
}
