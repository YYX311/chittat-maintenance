export type Diagnostic = {
  id:string; alias:string; returns:number; outcome:string|null;
  measured:boolean; timed:boolean; rule:string;
};
export type Diagnostics = {ruleVersion:string;total:number;limit:number;items:Diagnostic[]};
