import type { Queryable } from './case-service';
import type { Diagnostic, Diagnostics } from './research-diagnostic-types';

// These are triage rules, not inferred causes or individual performance scores.
// The caller must enforce research administrator authorization.
export async function researchDiagnostics(db:Queryable,studyId:string):Promise<Diagnostics> {
  const rows=(await db.query(`WITH evidence AS (
    SELECT r.id,r.alias,r.enrolled_at,
      (SELECT count(*)::int FROM research_case_audit a WHERE a.research_case_id=r.id AND a.action='return') AS returns,
      o.outcome,o.id IS NOT NULL AS measured,
      (o.worker_minutes IS NOT NULL AND o.office_minutes IS NOT NULL) AS timed
    FROM research_cases r LEFT JOIN LATERAL (
      SELECT id,outcome,worker_minutes,office_minutes FROM research_observations
      WHERE research_case_id=r.id ORDER BY created_at DESC,id DESC LIMIT 1
    ) o ON true WHERE r.study_id=$1
  ) SELECT *,count(*) OVER()::int AS total FROM evidence
    WHERE returns>=2 OR outcome='failed' OR NOT measured OR NOT timed
    ORDER BY (outcome='failed') DESC NULLS LAST,returns DESC,enrolled_at DESC,id
    LIMIT 50`,[studyId])).rows;
  return {ruleVersion:'triage-v1',total:rows[0]?.total??0,limit:50,
    items:rows.map(({id,alias,returns,outcome,measured,timed}):Diagnostic=>({
      id,alias,returns,outcome,measured,timed,
      rule:[returns>=2?'重複退回（至少 2 次）':'',outcome==='failed'?'最新人工觀察：失敗':'',!measured?'尚無人工觀察':!timed?'人工計時不完整':''].filter(Boolean).join('；')
    }))};
}
