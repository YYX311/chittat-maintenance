// 研究埋點字典 v2 —— 前端（維修人員／維修部）與研究工作台共用。
// 原則：只記錄「發生了什麼操作」，不記錄輸入文字、相片內容、定位或按鍵。

export const RESEARCH_SCHEMA_VERSION = 'workflow-fatigue-v2';

export type EventLayer = 'business' | 'interaction' | 'survey';
export type EventDef = {
  name: string;
  layer: EventLayer;
  source: 'server' | 'client';
  role: 'worker' | 'office' | 'both';
  trigger: string;
  payload: string[];
  feeds: string[]; // 生成哪些分析變量
};

export const researchEvents: EventDef[] = [
  // L1 業務事件：伺服器在狀態流轉時自動寫入，最可靠，是因變量 Y 的來源。
  { name: 'case.submitted', layer: 'business', source: 'server', role: 'worker', trigger: '維修人員提交／補交服務單', payload: ['round'], feeds: ['round', 'taskSeqToday', 'hoursOnShift'] },
  { name: 'case.review_opened', layer: 'business', source: 'server', role: 'office', trigger: '維修部首次開啟該次提交', payload: [], feeds: ['reviewWaitMin'] },
  { name: 'case.returned', layer: 'business', source: 'server', role: 'office', trigger: '維修部標註並退回', payload: ['reason', 'fields[]'], feeds: ['returned', 'returnReason', 'returnFields'] },
  { name: 'case.confirmed', layer: 'business', source: 'server', role: 'office', trigger: '維修部確認服務單（伺服器比對提交快照與確認快照）', payload: ['correctedFields[]'], feeds: ['fieldsCorrected', 'correctedFields', 'cycleMin'] },
  { name: 'doc.generated', layer: 'business', source: 'server', role: 'office', trigger: '辦公室生成報價單／發票', payload: ['type'], feeds: ['officeDocMin'] },
  // L2 交互事件：瀏覽器記錄，描述「數字化摩擦」，是自變量 X 的來源。
  { name: 'form.step_leave', layer: 'interaction', source: 'client', role: 'both', trigger: '離開表單步驟（只計前台、30 秒內有操作的時間）', payload: ['step', 'activeMs'], feeds: ['fillActiveMin', 'reviewActiveMin', 'stepRevisits'] },
  { name: 'form.validation_block', layer: 'interaction', source: 'client', role: 'both', trigger: '必填／格式檢查攔截前進或提交', payload: ['field'], feeds: ['validationBlocks'] },
  { name: 'form.field_refill', layer: 'interaction', source: 'client', role: 'both', trigger: '已填欄位被清空後重填', payload: ['field'], feeds: ['fieldRefills'] },
  { name: 'net.offline', layer: 'interaction', source: 'client', role: 'both', trigger: '填寫期間斷線', payload: [], feeds: ['offlineEvents'] },
  { name: 'check.assigned', layer: 'interaction', source: 'client', role: 'worker', trigger: '提交節點的隨機分派（微隨機實驗）', payload: ['arm', 'flags', 'late'], feeds: ['arm', 'checkFlags'] },
  { name: 'check.shown', layer: 'interaction', source: 'client', role: 'worker', trigger: '顯示提交前核對卡', payload: ['flags'], feeds: ['checkShown'] },
  { name: 'check.go_field', layer: 'interaction', source: 'client', role: 'worker', trigger: '在核對卡點擊前往欄位', payload: ['field'], feeds: ['checkAccepted'] },
  { name: 'check.confirmed', layer: 'interaction', source: 'client', role: 'worker', trigger: '核對後確認提交', payload: [], feeds: ['checkAccepted'] },
  // L3 心理測量：提交後抽樣彈出，兩題 10 秒內完成，是中介 M 與調節 W 的來源。
  { name: 'survey.shown', layer: 'survey', source: 'client', role: 'both', trigger: '顯示自評問卷', payload: ['version'], feeds: ['surveyResponse'] },
  { name: 'survey.effort', layer: 'survey', source: 'client', role: 'both', trigger: '提交／確認後抽樣：Paas 心智努力 1–9', payload: ['value'], feeds: ['effort'] },
  { name: 'survey.fatigue', layer: 'survey', source: 'client', role: 'both', trigger: '同一張卡：Samn-Perelli 疲勞 1–7', payload: ['value'], feeds: ['fatigue'] },
  { name: 'survey.skipped', layer: 'survey', source: 'client', role: 'both', trigger: '略過問卷（用作回應率）', payload: [], feeds: ['surveyResponse'] },
];

export const layerLabels: Record<EventLayer, string> = {
  business: 'L1 業務事件 · Y',
  interaction: 'L2 交互摩擦 · X',
  survey: 'L3 心理測量 · M / W',
};

// 分析單位：一次「交接回合」＝維修人員一次提交（含補交），一行一回合。
export const researchVariables = [
  { key: 'returned', role: 'Y', label: '被退回', type: '0/1', def: '該次提交是否被維修部退回' },
  { key: 'fieldsCorrected', role: 'Y', label: '維修部修正欄位數', type: '計數', def: '確認快照相對提交快照被改動的欄位數' },
  { key: 'cycleMin', role: 'Y', label: '交接周期', type: '分鐘', def: '提交 → 維修部確認' },
  { key: 'frictionZ', role: 'X', label: '數字化摩擦指數', type: 'z 分數', def: '攔截次數、重填次數、斷線次數標準化後平均' },
  { key: 'validationBlocks', role: 'X', label: '檢查攔截次數', type: '計數', def: '本回合 form.validation_block 數' },
  { key: 'fieldRefills', role: 'X', label: '欄位重填次數', type: '計數', def: '本回合 form.field_refill 數' },
  { key: 'offlineEvents', role: 'X', label: '斷線次數', type: '計數', def: '本回合 net.offline 數' },
  { key: 'effort', role: 'M', label: '心智努力 (Paas)', type: '1–9', def: '「完成這張服務單用了多少腦力？」' },
  { key: 'late', role: 'W', label: '班次後段', type: '0/1', def: '當日第 N 張以後（預設 N=4）——客觀疲勞代理' },
  { key: 'fatigue', role: 'W', label: '自評疲勞 (Samn-Perelli)', type: '1–7', def: '穩健性檢驗用；≥5 視為高疲勞' },
  { key: 'arm', role: 'T', label: '實驗分組', type: 'check / control', def: '提交節點隨機分派是否顯示核對卡' },
  { key: 'itemCount', role: 'C', label: '工作項目數', type: '計數', def: '任務複雜度控制' },
  { key: 'resubmission', role: 'C', label: '補交回合', type: '0/1', def: 'round > 1' },
] as const;

export const formSteps: Record<string, string> = {
  date: '01 基本資料', address: '01 基本資料', tower: '01 基本資料', floor: '01 基本資料', flat: '01 基本資料',
  customer: '01 基本資料', contact: '01 基本資料', occupant: '01 基本資料', phone: '01 基本資料',
  items: '02 工作內容', qty: '02 工作內容', model: '02 工作內容', brand: '02 工作內容', description: '02 工作內容',
  photo: '03 相片與時間', notes: '03 相片與時間', startedAt: '03 相片與時間', completedAt: '03 相片與時間',
};

export const fieldNames: Record<string, string> = {
  date: '日期', address: '工作地點', tower: '座數', floor: '樓層', flat: '單位', customer: '客戶名稱', contact: '聯絡人',
  occupant: '住戶資料', phone: '聯絡電話', items: '工作項目', qty: '數量', model: '型號', brand: '品牌', description: '項目說明',
  photo: '現場相片', notes: '現場描述', startedAt: '開工時間', completedAt: '完工時間',
};

export const researchPhases = [
  { id: 'baseline', name: '階段一 · 基線', weeks: '2–3 週', goal: '不加任何干預，量度摩擦、疲勞與退回的自然關係（H1–H3）' },
  { id: 'mrt', name: '階段二 · 微隨機實驗', weeks: '4–6 週', goal: '每次提交以機率 p 隨機顯示核對卡，檢驗因果效果及疲勞調節（H4）' },
  { id: 'adaptive', name: '階段三 · 疲勞自適應', weeks: '4 週', goal: '只在班次後段顯示核對卡；若成立，再比較規則核對 vs AI 助手' },
] as const;
export type ResearchPhase = typeof researchPhases[number]['id'];

export const hypotheses = [
  { id: 'H1', short: '摩擦 → 退回', text: '數字化摩擦越高，該次提交被退回的機率越高。', model: 'logit(退回) ~ 摩擦 + 項目數 + 補交 | 按員工聚類' },
  { id: 'H2', short: '摩擦 → 心智努力 → 退回', text: '摩擦透過提高心智努力而增加退回（中介）。', model: 'a: 努力 ~ 摩擦；b: logit(退回) ~ 努力 + 摩擦；a×b 聚類自助法 CI' },
  { id: 'H3', short: '疲勞放大摩擦', text: '班次後段時，摩擦對退回的影響更大（調節）。', model: 'logit(退回) ~ 摩擦 × 後段 + 控制' },
  { id: 'H4', short: '核對卡因果效果', text: '提交前核對卡降低退回率，且在班次後段效果更大。', model: 'LPM: 退回 ~ 核對 × 後段 + 摩擦 + 控制（只用階段二）' },
] as const;

// 與 src/handoff-reasons.js 的退回原因代碼一致。
export const returnReasonLabels: Record<string, string> = {
  photos: '相片', equipment: '設備資料', description: '工作說明', time: '時間資料', location: '工作地點',
  changed_request: '要求變更', other: '其他', unknown: '尚未分類',
};

export const defaultResearchConfig = { checkProbability: 0.5, surveyRate: 0.4, lateTaskThreshold: 4, targetDecisionPoints: 600 };
export type ResearchConfig = typeof defaultResearchConfig & { phase: ResearchPhase };
