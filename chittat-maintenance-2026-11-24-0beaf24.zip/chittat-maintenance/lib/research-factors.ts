// These are observable process indicators, not inferred employee productivity.
export type ProcessEvent={id:string;action:string;created_at:string|Date};
export function processEvidence(events:ProcessEvent[],truncated=false){
  const ordered=[...events].sort((a,b)=>new Date(a.created_at).getTime()-new Date(b.created_at).getTime());
  const submissions=ordered.filter(e=>e.action==='submit');
  const returns=ordered.filter(e=>e.action==='return');
  const start=submissions[0];
  const end=start?ordered.find(e=>e.action==='confirm'&&new Date(e.created_at)>=new Date(start.created_at)):undefined;
  return {submissions:submissions.length,returns:returns.length,
    elapsedMinutes:start&&end&&!truncated?(new Date(end.created_at).getTime()-new Date(start.created_at).getTime())/60000:null,
    startId:start?.id||null,endId:end?.id||null,returnIds:returns.map(e=>e.id),truncated};
}
