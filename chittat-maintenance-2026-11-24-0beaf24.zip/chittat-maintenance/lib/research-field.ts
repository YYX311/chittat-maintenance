import type { Queryable } from "./case-service";
import { contextRows } from "./human-factors-service";
import { loadResearchHandoffs } from "./research-handoffs";
import { loadTrialMeasures, participantCode, summarizeTrialTasks } from "./field-study-analysis";

const dayMs = 86400000;
const hkOffset = 8 * 3600000;
const day = (ms: number) => new Date(ms).toISOString().slice(0, 10);
export const hkDay = (at: Date | string = new Date()) => day(new Date(at).getTime() + hkOffset);

function isDay(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value) &&
    Number.isFinite(Date.parse(value)) && day(Date.parse(value)) === value;
}

export function fieldRange(from?: unknown, to?: unknown, today = hkDay()) {
  const end = to ?? today;
  if (!isDay(end)) throw Error("invalid-field-range");
  const start = from ?? day(Date.parse(end) - 27 * dayMs);
  if (!isDay(start)) throw Error("invalid-field-range");
  const span = (Date.parse(end) - Date.parse(start)) / dayMs + 1;
  if (span < 1 || span > 93) throw Error("invalid-field-range");
  return {
    from: start, to: end,
    start: new Date(Date.parse(start) - hkOffset).toISOString(),
    end: new Date(Date.parse(end) + dayMs - hkOffset).toISOString(),
    days: Array.from({ length: span }, (_, i) => day(Date.parse(start) + i * dayMs)),
  };
}

export function trialPeriods(startsOn: string, weeks: number) {
  if (!isDay(startsOn) || !Number.isInteger(weeks) || weeks < 1 || weeks > 4) {
    throw Error("invalid-trial-plan");
  }
  return ["A1", "B1", "A2", "B2"].map((label, index) => {
    const start = Date.parse(startsOn) + index * weeks * 7 * dayMs;
    return {
      label,
      phase: index % 2 ? "improved" : "baseline",
      from: day(start),
      to: day(start + (weeks * 7 - 1) * dayMs),
    };
  });
}

export async function saveTrialPlan(db: Queryable, studyId: string, startsOn: unknown, weeks: unknown) {
  if (!isDay(startsOn) || typeof weeks !== "number" || startsOn < hkDay()) throw Error("invalid-trial-plan");
  trialPeriods(startsOn, weeks);
  // The caller holds the study lock. Preserve the dates once a period has begun.
  const result = await db.query(`INSERT INTO research_trial_plans(study_id,starts_on,weeks_per_period)
    VALUES($1,$2,$3) ON CONFLICT(study_id) DO UPDATE SET starts_on=$2,weeks_per_period=$3
    WHERE research_trial_plans.starts_on>$4 OR
      (research_trial_plans.starts_on=$2 AND research_trial_plans.weeks_per_period=$3)
    RETURNING study_id`, [studyId, startsOn, weeks, hkDay()]);
  if (!result.rows.length) throw Error("invalid-trial-started");
  return { ok: true };
}

type UsageEvent = {
  at: string; alias: string; role: "worker" | "office"; participant: string;
  action: string; outcome: string; source: "handoff" | "request" | "screen"; phase: string;
  duration_ms: number | null; surface?:string|null; field?:string|null;
};

export function summarizeUsage(events: UsageEvent[], days: string[]) {
  const daily = days.map(date => ({ date, submitted: 0, confirmed: 0 }));
  const counts = new Map(daily.map(entry => [entry.date, entry]));
  const milestones = new Map<string,Set<string>>();
  const people = new Map<string, { participant: string; role: UsageEvent["role"]; days: Set<string>; cases: Set<string>; operations: number }>();
  for (const event of events) {
    const date = hkDay(event.at);
    const entry = counts.get(date);
    if (!entry) continue;
    if (event.source === "handoff" && event.action === "submit") entry.submitted++;
    if (event.source === "handoff" && event.action === "confirm") entry.confirmed++;
    if(event.source==="handoff"){
      const cases=milestones.get(event.action)??new Set<string>();
      cases.add(event.alias);milestones.set(event.action,cases);
    }
    const key = `${event.participant}:${event.role}`;
    if (!people.has(key)) people.set(key, { participant: event.participant, role: event.role, days: new Set(), cases: new Set(), operations: 0 });
    const person = people.get(key)!;
    person.days.add(date);
    person.cases.add(event.alias);
    person.operations++;
  }
  const signals=new Map<string,{role:UsageEvent["role"];action:string;target:string;cases:Set<string>;count:number}>();
  for (const event of events) {
    if (!["validation_error","field_clear","rage_click","offline","slow_network"].includes(event.action)) continue;
    const target=event.field||event.surface;
    if (!target) continue;
    const key=`${event.role}:${event.action}:${target}`;
    const signal=signals.get(key)||{role:event.role,action:event.action,target,cases:new Set<string>(),count:0};
    signal.count++;
    signal.cases.add(event.alias);
    signals.set(key,signal);
  }
  const assistant=events.filter(e=>e.action==="assistant_shown"||e.action==="assistant_accept");
  const accepted=new Set(assistant.filter(e=>e.action==="assistant_accept").map(e=>e.alias));
  const exposed=new Set(assistant.filter(e=>e.action==="assistant_shown").map(e=>e.alias));
  const surfaceTimes=new Map<string,{duration:number;segments:number;cases:Set<string>}>();
  for (const event of events) {
    if (event.action!=="screen_active"||!event.surface||event.duration_ms===null) continue;
    const current=surfaceTimes.get(event.surface)||{duration:0,segments:0,cases:new Set<string>()};
    current.duration+=event.duration_ms;current.segments++;current.cases.add(event.alias);
    surfaceTimes.set(event.surface,current);
  }
  return {
    daily,
    milestones:Object.fromEntries([...milestones].map(([action,cases])=>[action,cases.size])),
    people: [...people.values()].map(person => ({
      participant: person.participant, role: person.role, days: person.days.size,
      cases: person.cases.size, operations: person.operations,
    })).sort((a, b) => a.role.localeCompare(b.role) || a.participant.localeCompare(b.participant)),
    participants: new Set([...people.values()].map(person => person.participant)).size,
    submitted: daily.reduce((n, entry) => n + entry.submitted, 0),
    confirmed: daily.reduce((n, entry) => n + entry.confirmed, 0),
    cases: new Set(events.map(event => event.alias)).size,
    networkIssues: events.filter(event => event.action==="offline"||event.action==="slow_network"||
      (event.source === "request" && event.outcome === "network")).length,
    assistant:{accepted:[...accepted].filter(alias=>exposed.has(alias)).length,exposed:exposed.size},
    surfaces:[...surfaceTimes.entries()].map(([surface,{duration,segments,cases}])=>({surface,duration,segments,cases:cases.size})).sort((a,b)=>b.duration-a.duration),
    backlog:[...signals.values()].map(signal=>({...signal,cases:signal.cases.size}))
      .sort((a,b)=>b.cases-a.cases||b.count-a.count).slice(0,12),
    frictionGroups:["validation_error","field_clear","connection"].map(kind=>({
      kind,rows:[...signals.values()].filter(row=>kind==="connection"?["offline","slow_network"].includes(row.action):row.action===kind)
        .sort((a,b)=>b.cases.size-a.cases.size||b.count-a.count).slice(0,4)
        .map(row=>({...row,cases:row.cases.size})),
    })),
    recent: events.slice(-12).reverse(),
  };
}

export async function loadFieldReport(db: Queryable, studyId: string, range: ReturnType<typeof fieldRange>) {
  const [usageResult, handoffs, context, planResult, enrolledResult] = await Promise.all([
    db.query(`SELECT * FROM (
      SELECT a.created_at AS at,r.alias,r.phase,e.role,a.actor_user_id,a.action,'ok' AS outcome,'handoff' AS source,
        NULL::integer AS duration_ms,NULL::text AS surface,a.detail->>'field' AS field,'a:'||a.id AS tie
      FROM research_cases r JOIN research_case_audit a ON a.research_case_id=r.id
      JOIN employees e ON e.user_id=a.actor_user_id
      WHERE r.study_id=$1 AND a.action IN ('submit','withdraw','review','return','confirm')
        AND a.created_at >= $2 AND a.created_at < $3
      UNION ALL
      SELECT x.created_at,r.alias,r.phase,x.role,x.actor_user_id,x.operation,x.outcome,'request',x.duration_ms,NULL,NULL,'r:'||x.id
      FROM research_cases r JOIN research_runtime_events x ON x.research_case_id=r.id
      WHERE r.study_id=$1 AND x.created_at >= $2 AND x.created_at < $3
        AND NOT (x.outcome='ok' AND x.operation IN ('submit','return','confirm'))
      UNION ALL
      SELECT f.at,r.alias,r.phase,e.role,f.actor_user_id,f.kind,'ok','screen',f.duration_ms,f.surface,f.field,'f:'||f.id
      FROM research_cases r JOIN research_field_events f ON f.study_case_id=r.id
      JOIN employees e ON e.user_id=f.actor_user_id
      WHERE r.study_id=$1 AND f.at >= $2 AND f.at < $3
    ) events ORDER BY at,tie LIMIT 10001`, [studyId, range.start, range.end]),
    loadResearchHandoffs(db, studyId, range),
    contextRows(db, studyId, range),
    db.query("SELECT starts_on::text,weeks_per_period FROM research_trial_plans WHERE study_id=$1", [studyId]),
    db.query("SELECT count(*)::int AS n FROM research_cases WHERE study_id=$1", [studyId]),
  ]);
  const events: UsageEvent[] = usageResult.rows.slice(0, 10000).map(row => ({
    at: new Date(row.at).toISOString(), alias: row.alias, role: row.role === "worker" ? "worker" : "office",
    participant: participantCode(studyId,row.actor_user_id),
    action: row.action, outcome: row.outcome, source: row.source, phase: row.phase, duration_ms: row.duration_ms,
    surface:row.surface,field:row.field,
  }));
  const trial=await loadTrialMeasures(db,studyId,range,handoffs);
  const plan = planResult.rows[0];
  return {
    from: range.from, to: range.to,
    enrolled: enrolledResult.rows[0].n as number,
    usage: summarizeUsage(events, range.days), events, handoffs, context,
    truncated: usageResult.rows.length > 10000,
    periods: plan ? trialPeriods(plan.starts_on, plan.weeks_per_period) : [],
    burden: summarizeBurden(context.rows, handoffs.rows),
    trial, trialSummary:summarizeTrialTasks(trial.rows),
  };
}

export function summarizeBurden(context: Awaited<ReturnType<typeof contextRows>>["rows"], handoffs: Awaited<ReturnType<typeof loadResearchHandoffs>>["rows"]) {
  const reported = new Map<string, number | null>();
  for (const row of context) {
    if (row.role === "worker" && row.source === "self_report" && ["capture", "submit"].includes(row.stage) && !reported.has(row.alias)) {
      reported.set(row.alias, row.load);
    }
  }
  return ["low", "high"].map(band => {
    const cases = handoffs.filter(row => {
      const load = reported.get(row.alias);
      return load != null && (band === "low" ? load <= 3 : load >= 4);
    });
    const reviewed = cases.filter(row => row.firstDecision !== null);
    const timed = cases.flatMap(row => row.elapsedMinutes === null ? [] : [row.elapsedMinutes]).sort((a,b) => a-b);
    return {
      band, n: cases.length, decided: reviewed.length, returned: reviewed.filter(row => row.firstDecision === "return").length,
      timed: timed.length,
      medianMinutes: timed.length ? (timed[Math.floor((timed.length-1)/2)] + timed[Math.floor(timed.length/2)]) / 2 : null,
    };
  });
}

export function fieldCsv(columns: string[], rows: Record<string, unknown>[]) {
  const cell = (value: unknown) => {
    const raw = value == null ? "" : String(value);
    const safe = typeof value !== "number" && /^[\s\uFEFF]*[=+@-]|^[\t\r\n]/.test(raw) ? "'" + raw : raw;
    return '"' + safe.replaceAll('"', '""') + '"';
  };
  return "\uFEFF" + [columns.join(","), ...rows.map(row => columns.map(key => cell(row[key])).join(","))].join("\r\n") + "\r\n";
}
