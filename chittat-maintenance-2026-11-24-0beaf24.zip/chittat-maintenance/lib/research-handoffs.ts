import type { Queryable } from "./case-service";
import { handoffReason, handoffReasons } from "../src/handoff-reasons";

type Event = {
  alias: string;
  id: string;
  phase: string;
  difficulty: string;
  action: string;
  created_at: Date | string;
  reason: string | null;
};

function median(values: number[]) {
  if (!values.length) return null;
  const sorted = [...values].sort((a, b) => a - b);
  return (sorted[Math.floor((sorted.length - 1) / 2)] + sorted[Math.floor(sorted.length / 2)]) / 2;
}

// Input is ordered by server timestamp, then audit id. Each case contributes once.
export function summarizeHandoffs(events: Event[], truncated = false) {
  const cases = new Map<string, {
    alias: string; id: string; phase: string; difficulty: string; started: number;
    state: "submitted" | "withdrawn" | "needsInfo" | "confirmed";
    firstDecision: "return" | "confirm" | null;
    elapsedMinutes: number | null;
    submissions: number; reasons: string[];
  }>();
  for (const e of events) {
    let item = cases.get(e.alias);
    const at = new Date(e.created_at).getTime();
    if (e.action === "submit") {
      if (!item) {
        item = { alias: e.alias, id: e.id, phase: e.phase, difficulty: e.difficulty, started: at,
          state: "submitted", firstDecision: null, elapsedMinutes: null, submissions: 0, reasons: [] };
        cases.set(e.alias, item);
      }
      if (item.state !== "confirmed") {
        item.submissions++;
        item.state = "submitted";
      }
      continue;
    }
    if (!item || item.state !== "submitted") continue;
    if (e.action === "withdraw") item.state = "withdrawn";
    if (e.action === "return") {
      item.firstDecision ??= "return";
      item.reasons.push(String(handoffReason(e.reason)));
      item.state = "needsInfo";
    }
    if (e.action === "confirm") {
      item.firstDecision ??= "confirm";
      item.elapsedMinutes = (at - item.started) / 60_000;
      item.state = "confirmed";
    }
  }
  const rows = [...cases.values()].map(({ started: _, ...row }) => row);
  const groups = ["baseline", "improved"].flatMap(phase => ["low", "medium", "high", "all"].map(difficulty => {
    const selected = rows.filter(row => row.phase === phase && (difficulty === "all" || row.difficulty === difficulty));
    const decided = selected.filter(row => row.firstDecision !== null);
    const confirmed = selected.filter(row => row.state === "confirmed");
    return {
      phase, difficulty, submitted: selected.length, decided: decided.length,
      firstPass: decided.filter(row => row.firstDecision === "confirm").length,
      returned: selected.filter(row => row.reasons.length > 0).length,
      confirmed: confirmed.length, waitingReview: selected.filter(row => row.state === "submitted").length,
      waitingWorker: selected.filter(row => row.state === "needsInfo").length,
      withdrawn: selected.filter(row => row.state === "withdrawn").length,
      medianMinutes: median(confirmed.map(row => row.elapsedMinutes!)),
    };
  }));
  const reasons = handoffReasons.map(([code, label]) => ({
    code, label, count: rows.reduce((count, row) => count + row.reasons.filter(reason => reason === code).length, 0),
  })).filter(reason => reason.count > 0).sort((a, b) => b.count - a.count);
  return { algorithm: "handoff-v1", truncated, groups, reasons, rows };
}

export async function loadResearchHandoffs(db: Queryable, studyId: string, range?: { start: string; end: string }) {
  const result = await db.query(`SELECT r.alias,r.id,r.phase,r.difficulty,a.action,a.created_at,a.detail->>'reason' AS reason
    FROM research_cases r JOIN cases c ON c.id=r.case_id AND c.source='worker'
    JOIN research_case_audit a ON a.research_case_id=r.id
    WHERE r.study_id=$1 AND a.action IN ('submit','withdraw','return','confirm')
      AND (r.trial_period IS NULL OR NOT EXISTS (
        SELECT 1 FROM audit_events hidden WHERE hidden.case_id=r.case_id AND hidden.created_at>=r.enrolled_at
          AND hidden.created_at<LEAST(COALESCE($3::timestamptz,'infinity'),COALESCE(
            (SELECT stopped_at FROM research_auto_collection WHERE study_id=r.study_id),'infinity'))
          AND hidden.action IN ('submit','withdraw','return','confirm')
          AND NOT EXISTS (SELECT 1 FROM research_case_audit visible WHERE visible.research_case_id=r.id AND visible.id=hidden.id)
      ))
      AND ($2::timestamptz IS NULL OR (SELECT min(first.created_at) FROM research_case_audit first
        WHERE first.research_case_id=r.id AND first.action='submit') >= $2)
      AND ($3::timestamptz IS NULL OR a.created_at<$3)
    ORDER BY a.created_at,a.id LIMIT 10001`, [studyId, range?.start ?? null, range?.end ?? null]);
  return summarizeHandoffs(result.rows.slice(0, 10000), result.rows.length > 10000);
}
