// 研究分析模型：把「交接回合」資料轉成歸因、心理 × 流程、實驗與回歸結果。
import { clusterBootstrap, logit, mean, median, ols, sd, type Fit } from './research-stats';
import { fieldNames, formSteps, returnReasonLabels, type ResearchConfig, type ResearchPhase } from './research-events';

/** 一行 = 維修人員一次提交（含補交）。由後端從 L1/L2/L3 事件彙總。 */
export type Episode = {
  id: string; caseId: string; round: number; worker: string; reviewer: string | null; date: string;
  phase: ResearchPhase | null; arm: 'check' | 'control' | null; checkFlags: number | null; checkAccepted: boolean | null;
  fillActiveMin: number | null; validationBlocks: number | null; fieldRefills: number | null; offlineEvents: number | null; stepRevisits: number | null;
  photoCount: number | null; itemCount: number | null; taskSeqToday: number; hoursOnShift: number | null;
  effort: number | null; fatigue: number | null;
  returned: boolean | null; returnReason: string | null; returnFields: string[];
  fieldsCorrected: number | null; correctedFields: string[];
  reviewWaitMin: number | null; reviewActiveMin: number | null; reworkMin: number | null;
  cycleMin: number | null; officeDocMin: number | null;
};
export type EventHealth = { name: string; count: number; lastAt: string | null };
export type ResearchDataset = {
  study: { id: string; name: string; startedAt: string; config: ResearchConfig };
  participants: { workers: number; office: number; consented: number | null; invited: number | null };
  episodes: Episode[]; events: EventHealth[]; scope?: { from: string; to: string };
  survey?: { shown: number; answered: number };
};

export type Verdict = 'supported' | 'trend' | 'not_supported' | 'insufficient';
export const verdictLabels: Record<Verdict, string> = { supported: '支持', trend: '方向一致 · 未顯著', not_supported: '不支持', insufficient: '數據不足' };

type Row = Episode & { frictionZ: number; late: 0 | 1; resub: 0 | 1 };
const verdict = (fit: Fit | null, name: string, sign: 1 | -1, minN: number): { v: Verdict; coef?: Fit['coefs'][number] } => {
  const coef = fit?.coefs.find(c => c.name === name);
  if (!fit || !coef || fit.n < minN || fit.clusters < 4) return { v: 'insufficient', coef };
  if (Math.sign(coef.b) !== sign) return { v: 'not_supported', coef };
  return { v: coef.p < 0.05 ? 'supported' : 'trend', coef };
};

export function prepare(episodes: Episode[], cfg: ResearchConfig): Row[] {
  const comp = (k: 'validationBlocks' | 'fieldRefills' | 'offlineEvents') => {
    const v = episodes.flatMap(e => e[k] == null ? [] : [e[k]]), m = mean(v), s = sd(v);
    return (e: Episode) => e[k] == null ? NaN : (e[k] - m) / s;
  };
  const zb = comp('validationBlocks'), zr = comp('fieldRefills'), zo = comp('offlineEvents');
  return episodes.map(e => ({ ...e, frictionZ: (zb(e) + zr(e) + zo(e)) / 3, late: e.taskSeqToday >= cfg.lateTaskThreshold ? 1 : 0, resub: e.round > 1 ? 1 : 0 }));
}

function design(rows: Row[], allSpec: [string, (r: Row) => number][]) {
  // 自動剔除在該樣本內恆定的變量（例如只有首次提交才有問卷時的「補交回合」）
  const spec = allSpec.filter(([, f]) => rows.length > 0 && rows.some(r => f(r) !== f(rows[0])));
  return { X: rows.map(r => [1, ...spec.map(([, f]) => f(r))]), names: ['截距', ...spec.map(([n]) => n)], cluster: rows.map(r => r.worker) };
}
const controls: [string, (r: Row) => number][] = [['項目數', r => r.itemCount ?? NaN], ['補交回合', r => r.resub]];

export function analyze(data: ResearchDataset) {
  const cfg = data.study.config;
  const rows = prepare(data.episodes, cfg);
  const decided = rows.filter(r => r.returned != null);
  const first = decided.filter(r => r.round === 1);
  const measured = rows.filter(r => Number.isFinite(r.frictionZ) && r.itemCount != null);
  const modeled = measured.filter(r => r.returned != null);
  const fpy = first.length ? first.filter(r => !r.returned).length / first.length : NaN;
  // 微隨機實驗只在「有可核對內容」的提交節點隨機化（flags 在分派前計算，兩組可比）
  const mrtRows = modeled.filter(r => r.phase === 'mrt' && r.arm && (r.checkFlags ?? 0) > 0);
  const val = (v: (number | null)[]) => v.filter((x): x is number => x != null);

  // ---------- 1. 流程歸因：時間分解 ----------
  const caseIds = [...new Set(rows.map(r => r.caseId))];
  const segments = [
    { key: 'fill', label: '維修人員填寫', who: '現場', values: val(rows.map(r => r.fillActiveMin)) },
    { key: 'wait', label: '等待維修部首次處理', who: '維修部', values: val(rows.map(r => r.reviewWaitMin)) },
    { key: 'review', label: '維修部覆核修正', who: '維修部', values: val(rows.map(r => r.reviewActiveMin)) },
    { key: 'rework', label: '退回至補交', who: '兩端', values: val(rows.map(r => r.reworkMin)) },
    { key: 'office', label: '辦公室報價／發票', who: '辦公室', values: val(rows.map(r => r.officeDocMin)) },
  ].map(s => ({ ...s, median: median(s.values), mean: mean(s.values), n: s.values.length }));
  // 每宗案件分攤：返工只發生在部分案件，按案件平均更能反映對整體周期的貢獻
  const perCase = segments.map(s => ({ ...s, perCase: s.values.reduce((a, b) => a + b, 0) / Math.max(1, caseIds.length) }));
  const totalPerCase = perCase.reduce((a, s) => a + s.perCase, 0);

  const reasonCounts = new Map<string, number>();
  rows.filter(r => r.returned === true).forEach(r => reasonCounts.set(r.returnReason || 'unknown', (reasonCounts.get(r.returnReason || 'unknown') || 0) + 1));
  const reasons = [...reasonCounts].map(([code, n]) => ({ code, label: returnReasonLabels[code] || code, n })).sort((a, b) => b.n - a.n);

  const fieldCounts = new Map<string, { returned: number; corrected: number }>();
  rows.forEach(r => {
    r.returnFields.forEach(f => { const c = fieldCounts.get(f) || { returned: 0, corrected: 0 }; c.returned++; fieldCounts.set(f, c); });
    r.correctedFields.forEach(f => { const c = fieldCounts.get(f) || { returned: 0, corrected: 0 }; c.corrected++; fieldCounts.set(f, c); });
  });
  const fields = [...fieldCounts].map(([f, c]) => ({ field: f, label: fieldNames[f] || f, step: formSteps[f] || '其他', ...c, total: c.returned + c.corrected })).sort((a, b) => b.total - a.total);
  const stepTotals = new Map<string, number>();
  fields.forEach(f => stepTotals.set(f.step, (stepTotals.get(f.step) || 0) + f.total));
  const steps = [...stepTotals].map(([step, n]) => ({ step, n })).sort((a, b) => a.step.localeCompare(b.step));

  // ---------- 2. 回歸模型 ----------
  const m1d = design(modeled, [['摩擦指數', r => r.frictionZ], ...controls]);
  const m1 = logit(modeled.map(r => Number(r.returned)), m1d.X, m1d.names, m1d.cluster);
  const m1bd = design(measured.filter(r => r.fieldsCorrected != null), [['摩擦指數', r => r.frictionZ], ...controls]);
  const m1b = ols(measured.filter(r => r.fieldsCorrected != null).map(r => r.fieldsCorrected!), m1bd.X, m1bd.names, m1bd.cluster);

  const withEffort = rows.filter(r => r.effort != null);
  const effortModel = modeled.filter(r => r.effort != null);
  const aFit = (rs: Row[]) => { const d = design(rs, [['摩擦指數', r => r.frictionZ], ['項目數', r => r.itemCount ?? NaN]]); return ols(rs.map(r => r.effort!), d.X, d.names, d.cluster); };
  const bFit = (rs: Row[]) => { const d = design(rs, [['心智努力', r => r.effort!], ['摩擦指數', r => r.frictionZ], ...controls]); return logit(rs.map(r => Number(r.returned)), d.X, d.names, d.cluster); };
  const m2a = aFit(effortModel), m2b = bFit(effortModel);
  const a = m2a?.coefs.find(c => c.name === '摩擦指數'), b = m2b?.coefs.find(c => c.name === '心智努力');
  const indirect = a && b ? a.b * b.b : null;
  const indirectCI = indirect != null && effortModel.length >= 60
    ? clusterBootstrap(effortModel, 200, rs => { const fa = aFit(rs), fb = bFit(rs); const x = fa?.coefs[1].b, y = fb?.coefs[1].b; return x != null && y != null ? x * y : null; })
    : null;

  const m3d = design(modeled, [['摩擦指數', r => r.frictionZ], ['班次後段', r => r.late], ['摩擦×後段', r => r.frictionZ * r.late], ...controls]);
  const m3 = logit(modeled.map(r => Number(r.returned)), m3d.X, m3d.names, m3d.cluster);
  const selfFat = rows.filter(r => r.fatigue != null);
  const modeledFat = modeled.filter(r => r.fatigue != null);
  const m3sd = design(modeledFat, [['摩擦指數', r => r.frictionZ], ['自評高疲勞', r => +(r.fatigue! >= 5)], ['摩擦×高疲勞', r => r.frictionZ * +(r.fatigue! >= 5)], ...controls]);
  const m3s = logit(modeledFat.map(r => Number(r.returned)), m3sd.X, m3sd.names, m3sd.cluster);

  const m4d = design(mrtRows, [['核對卡', r => +(r.arm === 'check')], ['班次後段', r => r.late], ['核對×後段', r => +(r.arm === 'check') * r.late], ['摩擦指數', r => r.frictionZ], ...controls]);
  const m4 = ols(mrtRows.map(r => Number(r.returned)), m4d.X, m4d.names, m4d.cluster);
  const m4fd = design(mrtRows, [['核對卡', r => +(r.arm === 'check')], ['摩擦指數', r => r.frictionZ], ...controls]);
  const m4f = ols(mrtRows.map(r => Number(r.returned)), m4fd.X, m4fd.names, m4fd.cluster);

  // ---------- 3. 描述性圖表資料 ----------
  const tercile = (rs: Row[]) => { const s = [...rs.map(r => r.frictionZ)].sort((x, y) => x - y); return [s[Math.floor(s.length / 3)], s[Math.floor((2 * s.length) / 3)]]; };
  const [t1, t2] = measured.length >= 9 ? tercile(measured) : [0, 0];
  const band = (r: Row) => (r.frictionZ <= t1 ? 0 : r.frictionZ <= t2 ? 1 : 2);
  const rate = (rs: Row[]) => ({ n: rs.length, rate: rs.length ? rs.filter(r => r.returned).length / rs.length : NaN });
  const interaction = [0, 1].map(late => ({ late, points: [0, 1, 2].map(bd => rate(modeled.filter(r => r.late === late && band(r) === bd))) }));
  const effortByBand = [0, 1, 2].map(bd => { const v = withEffort.filter(r => Number.isFinite(r.frictionZ) && band(r) === bd).map(r => r.effort!); return { n: v.length, mean: mean(v) }; });
  const effortBySeq = Array.from({ length: 6 }, (_, i) => { const v = withEffort.filter(r => Math.min(6, r.taskSeqToday) === i + 1).map(r => r.effort!); const f = selfFat.filter(r => Math.min(6, r.taskSeqToday) === i + 1).map(r => r.fatigue!); return { seq: i + 1, effort: mean(v), fatigue: mean(f), n: v.length }; });
  const armRates = (['control', 'check'] as const).map(arm => ({ arm, all: rate(mrtRows.filter(r => r.arm === arm)), early: rate(mrtRows.filter(r => r.arm === arm && !r.late)), late: rate(mrtRows.filter(r => r.arm === arm && r.late)) }));

  const weekly = new Map<string, { n: number; ret: number; phase: ResearchPhase | null }>();
  first.forEach(r => {
    const d = new Date(r.date + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
    const k = d.toISOString().slice(0, 10), w = weekly.get(k) || { n: 0, ret: 0, phase: r.phase };
    w.n++; if (r.returned) w.ret++; weekly.set(k, w);
  });
  const trend = [...weekly].sort(([x], [y]) => x.localeCompare(y)).map(([week, w]) => ({ week, fpy: 1 - w.ret / w.n, n: w.n, phase: w.phase }));

  const h = {
    H1: verdict(m1, '摩擦指數', 1, 80),
    H2: { ...verdict(m2b, '心智努力', 1, 60), a, b, indirect, ci: indirectCI, aVerdict: verdict(m2a, '摩擦指數', 1, 60).v },
    H3: verdict(m3, '摩擦×後段', 1, 120),
    H4: { main: verdict(m4f, '核對卡', -1, 120), moderation: verdict(m4, '核對×後段', -1, 120) },
  };
  return {
    cfg, rows, mrtRows,
    kpi: {
      episodes: rows.length, firstDecided: first.length, cases: caseIds.length, fpy, workers: new Set(rows.map(r => r.worker)).size,
      corrected: mean(val(rows.map(r => r.fieldsCorrected))), cycle: median(val(rows.map(r => r.cycleMin))),
      decisionPoints: mrtRows.length, target: cfg.targetDecisionPoints,
      surveyResponse: data.survey?.shown ? data.survey.answered / data.survey.shown : NaN,
    },
    attribution: { segments: perCase, totalPerCase, reasons, fields, steps },
    models: { m1, m1b, m2a, m2b, m3, m3s, m4, m4f },
    charts: { interaction, effortByBand, effortBySeq, armRates, trend },
    h,
  };
}
export type Analysis = ReturnType<typeof analyze>;

// ---------- 匯出 ----------
const csvCols: (keyof Episode | 'frictionZ' | 'late')[] = ['id', 'caseId', 'round', 'worker', 'reviewer', 'date', 'phase', 'arm', 'checkFlags', 'checkAccepted', 'fillActiveMin', 'validationBlocks', 'fieldRefills', 'offlineEvents', 'stepRevisits', 'photoCount', 'itemCount', 'taskSeqToday', 'hoursOnShift', 'frictionZ', 'late', 'effort', 'fatigue', 'returned', 'returnReason', 'fieldsCorrected', 'reviewWaitMin', 'reviewActiveMin', 'reworkMin', 'cycleMin', 'officeDocMin'];
export function toCsv(rows: Row[]) {
  const cell = (v: unknown) => (v == null ? '' : typeof v === 'boolean' ? (v ? 1 : 0) : typeof v === 'number' ? (Number.isFinite(v) ? +v.toFixed(4) : '') : /[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
  return [csvCols.join(','), ...rows.map(r => csvCols.map(c => cell((r as Record<string, unknown>)[c])).join(','))].join('\n');
}
export const rScript = `# 工作流 × 疲勞研究 · 正式分析（R）
library(lme4); library(mediation); library(sandwich); library(lmtest)
d <- read.csv("episodes.csv"); d$check <- as.integer(d$arm == "check"); d$resub <- as.integer(d$round > 1)

# H1 摩擦 → 退回（員工隨機截距）
m1 <- glmer(returned ~ frictionZ + itemCount + resub + (1|worker), data=d, family=binomial); summary(m1)

# H2 中介：摩擦 → 心智努力 → 退回
e <- subset(d, !is.na(effort))
ma <- lm(effort ~ frictionZ + itemCount, data=e)
mb <- glm(returned ~ effort + frictionZ + itemCount + resub, data=e, family=binomial)
summary(mediate(ma, mb, treat="frictionZ", mediator="effort", boot=TRUE, sims=2000))

# H3 疲勞調節
m3 <- glmer(returned ~ frictionZ * late + itemCount + resub + (1|worker), data=d, family=binomial); summary(m3)

# H4 微隨機實驗（只用階段二；隨機化機率固定，可直接比較）
t <- subset(d, phase == "mrt" & arm != "")
m4 <- lm(returned ~ check * late + frictionZ + itemCount + resub, data=t)
coeftest(m4, vcov = vcovCL, cluster = ~worker)
`;
export const pyScript = `# 工作流 × 疲勞研究 · 正式分析（Python）
import pandas as pd, statsmodels.formula.api as smf
d = pd.read_csv("episodes.csv"); d["check"] = (d.arm == "check").astype(int); d["resub"] = (d["round"] > 1).astype(int)
g = {"groups": d["worker"]}
print(smf.logit("returned ~ frictionZ + itemCount + resub", d).fit(cov_type="cluster", cov_kwds=g).summary())          # H1
print(smf.logit("returned ~ frictionZ * late + itemCount + resub", d).fit(cov_type="cluster", cov_kwds=g).summary())   # H3
t = d[(d.phase == "mrt") & d.arm.notna()]
print(smf.ols("returned ~ check * late + frictionZ + itemCount + resub", t).fit(cov_type="cluster", cov_kwds={"groups": t["worker"]}).summary())  # H4
`;
