import type { Staff } from './access';
import type { Queryable } from './case-service';
import { defaultResearchConfig, RESEARCH_SCHEMA_VERSION } from './research-events';
import { fieldStudyScreens, studyField } from '../src/field-study-catalog';

export const probeStudyId = 'service-handover';
const interactionNames = ['form.step_leave', 'form.validation_block', 'form.field_refill', 'net.offline'];
const surveyNames = ['survey.shown', 'survey.effort', 'survey.fatigue', 'survey.skipped'];
const checkNames = ['check.assigned', 'check.shown', 'check.go_field', 'check.confirmed'];
const validPhases = new Set(['baseline', 'mrt', 'adaptive']);
const identifier = /^[\w-]{1,100}$/;

export function activeResearchPhase(): 'baseline' | 'mrt' | 'adaptive' {
  const raw = (process.env.RESEARCH_PHASE || 'baseline').trim().toLowerCase();
  return validPhases.has(raw) ? (raw as 'baseline' | 'mrt' | 'adaptive') : 'baseline';
}

export async function probeConfig(client: Queryable, _staff: Staff) {
  const result = await client.query('SELECT enabled_at FROM research_probe_collection WHERE singleton=true');
  return { studyId: probeStudyId, joined: result.rows.length > 0, mode: 'automatic',
    phase: activeResearchPhase(), surveyRate: defaultResearchConfig.surveyRate };
}

export function normalizeProbeEvents(input: unknown, role: 'worker' | 'office', now = Date.now()) {
  if (!Array.isArray(input) || input.length < 1 || input.length > 40) throw Error('invalid-probe-events');
  return input.map(row => {
    if (!row || row.schema !== RESEARCH_SCHEMA_VERSION || typeof row.id !== 'string' || !identifier.test(row.id)
      || typeof row.caseId !== 'string' || !identifier.test(row.caseId)
      || !Number.isSafeInteger(row.at) || row.at < now - 7 * 86400000 || row.at > now + 60000)
      throw Error('invalid-probe-events');

    const interaction = interactionNames.includes(row.name);
    const survey = surveyNames.includes(row.name);
    const check = checkNames.includes(row.name);
    if (!interaction && !survey && !check) throw Error('invalid-probe-events');
    if (interaction && (typeof row.step !== 'string' || !Object.hasOwn(fieldStudyScreens, row.step) || !row.step.startsWith(role + '-')))
      throw Error('invalid-probe-step');

    const ratingMax = row.name === 'survey.effort' ? 9 : row.name === 'survey.fatigue' ? 7 : null;
    if (ratingMax && (!Number.isInteger(row.value) || row.value < 1 || row.value > ratingMax))
      throw Error('invalid-probe-rating');
    if (survey && (!Number.isSafeInteger(row.version) || row.version < 1 || row.version > 2147483647))
      throw Error('invalid-probe-version');
    const timed = row.name === 'form.step_leave';
    if (timed && (!Number.isInteger(row.activeMs) || row.activeMs < 1000 || row.activeMs > 600000))
      throw Error('invalid-probe-duration');

    // For check.assigned, preserve arm ('control' | 'check') in step and flag count (1..9) in rating
    const checkArm = row.name === 'check.assigned' && (row.arm === 'control' || row.arm === 'check') ? row.arm : null;
    const checkFlags = (row.name === 'check.assigned' || row.name === 'check.shown') && Number.isInteger(row.flags)
      ? Math.max(1, Math.min(9, row.flags)) : null;

    return {
      id: row.id, case_id: row.caseId, name: row.name, at: new Date(row.at).toISOString(),
      step: interaction ? row.step : checkArm,
      field: interaction || row.name === 'check.go_field' ? studyField(row.field) : null,
      active_ms: timed ? row.activeMs : null,
      rating: ratingMax ? row.value : checkFlags,
      case_version: survey ? row.version : null,
    };
  });
}

export async function mutateProbe(client: Queryable, staff: Staff, body: Record<string, unknown>) {
  if (body.studyId !== probeStudyId) throw Error('invalid-probe-study');
  await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`research-probe:${staff.userId}`]);
  if (body.action === 'consent') {
    if (typeof body.joined !== 'boolean') throw Error('invalid-consent');
    // Older open tabs may still send this action. Collection follows the system policy.
    return { ok: true, mode: 'automatic' };
  }
  if (body.action !== 'events') throw Error('invalid-probe-action');
  const role = staff.role === 'worker' ? 'worker' : 'office';
  const rows = normalizeProbeEvents(body.events, role);
  const result = await client.query(`WITH participation AS (
      SELECT enabled_at AS joined_at FROM research_probe_collection WHERE singleton=true
    ), budget AS (
      SELECT count(*) AS used FROM research_probe_events WHERE actor_user_id=$1 AND received_at > now() - interval '1 day'
    )
    INSERT INTO research_probe_events(actor_user_id,id,case_id,role,name,at,step,field,active_ms,rating,case_version)
    SELECT $1,x.id,x.case_id,$2,x.name,x.at,x.step,x.field,x.active_ms,x.rating,x.case_version
    FROM jsonb_to_recordset($3::jsonb) AS x(id text,case_id text,name text,at timestamptz,
      step text,field text,active_ms integer,rating integer,case_version integer)
    JOIN cases c ON c.id=x.case_id CROSS JOIN participation p CROSS JOIN budget
    WHERE c.deleted_at IS NULL AND ($2='office' OR c.owner_user_id=$1)
      AND x.at >= p.joined_at AND budget.used + $4 <= 2000
      AND (x.case_version IS NULL OR EXISTS (
        SELECT 1 FROM audit_events a WHERE a.case_id=x.case_id AND a.actor_user_id=$1
          AND a.action=CASE $2 WHEN 'worker' THEN 'submit' ELSE 'confirm' END
          AND a.detail->>'version'=x.case_version::text AND x.at>=a.created_at - interval '1 minute'
          AND x.at<a.created_at + interval '1 day' AND a.created_at>=p.joined_at
      ))
    ON CONFLICT DO NOTHING RETURNING id`, [staff.userId, role, JSON.stringify(rows), rows.length]);
  return { recorded: result.rows.length };
}
