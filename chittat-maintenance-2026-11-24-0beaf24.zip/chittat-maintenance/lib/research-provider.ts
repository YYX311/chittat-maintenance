import { researchModel, researchModelInput, researchResponseText } from "./research-ai";

// Local Node can use the approved Cloudflare account after explicit configuration.
// Vite aliases this module to the native binding for the Cloudflare deployment.
export function researchAiAvailable() {
  return process.env.RESEARCH_AI_ENABLED==="1"&&
    /^[a-f0-9]{32}$/i.test(process.env.RESEARCH_AI_CLOUDFLARE_ACCOUNT_ID||"")&&
    Boolean(process.env.RESEARCH_AI_CLOUDFLARE_API_TOKEN?.trim());
}

export async function invokeResearchAi(evidence:string,prompt?:string):Promise<string> {
  if(!researchAiAvailable())throw Error("ai-not-configured");
  const account=process.env.RESEARCH_AI_CLOUDFLARE_ACCOUNT_ID;
  const token=process.env.RESEARCH_AI_CLOUDFLARE_API_TOKEN;
  let result;
  try{
    const response=await fetch(`https://api.cloudflare.com/client/v4/accounts/${account}/ai/run/${researchModel}`,{
      method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},
      body:JSON.stringify(researchModelInput(evidence,prompt)),cache:"no-store",signal:AbortSignal.timeout(20000),
    });
    if(response.status===429)throw Error("ai-provider-quota");
    if(!response.ok)throw Error("ai-unavailable");
    result=await response.json();
  }catch(error){
    if(error instanceof Error&&error.message==="ai-provider-quota")throw error;
    if(error instanceof Error&&error.name==="TimeoutError")throw Error("ai-timeout");
    throw Error("ai-unavailable");
  }
  if(result?.success!==true)throw Error("ai-unavailable");
  return researchResponseText(result.result);
}
