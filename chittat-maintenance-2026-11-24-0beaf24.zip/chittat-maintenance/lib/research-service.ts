import { createHash,randomUUID } from 'node:crypto';
import { handoffReason } from "../src/handoff-reasons";
import { loadResearchHandoffs } from "./research-handoffs";
import { processEvidence } from './research-factors';
import { researchDiagnostics } from './research-diagnostics';
import type { Staff } from './access';
import type { Queryable } from './case-service';
import {defaultTelemetryGroups,telemetryCategory} from './telemetry-catalog';
import {validateContext,humanFactorsVersion} from './human-factors';
import {contextOverview} from './human-factors-service';
import {saveTrialPlan} from './research-field';
import {enableAutoCollection} from './field-study-service';

// A role alone never grants research access. Empty configuration denies everybody.
export function requireResearchAdmin(staff: Staff, configured = process.env.RESEARCH_ADMIN_PHONE) {
  const normalize = (value: string) => value.replace(/[\s()-]/g, '').replace(/^00852/, '+852');
  const expected = normalize(configured || '');
  if (!/^\+852\d{8}$/.test(expected) || normalize(staff.phone || '') !== expected) throw new Error('forbidden');
}
function text(value: unknown, max: number, min = 1) {
  if (typeof value !== 'string' || value.trim().length < min || value.length > max) throw new Error('invalid-research-input');
  return value.trim();
}
function choice(value: unknown, values: string[]) {
  if (typeof value !== 'string' || !values.includes(value)) throw new Error('invalid-research-input');
  return value;
}
function numberOrNull(value: unknown, max: number, integer = false) {
  if (value === null || value === undefined || value === '') return null;
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > max || (integer && !Number.isInteger(value))) throw new Error('invalid-research-input');
  return value;
}
export async function researchOverview(db: Queryable, staff: Staff, studyId: string | null, page = 1) {
  requireResearchAdmin(staff);
  const studies = (await db.query('SELECT id,title,protocol,status,created_at FROM research_studies ORDER BY created_at DESC')).rows;
  if (!studyId) {
    const active=studies.filter(s=>s.status==='collecting');
    const automatic=active.length>1?(await db.query("SELECT study_id FROM research_auto_collection WHERE stopped_at IS NULL")).rows[0]?.study_id:null;
    const recent=active.length>1&&!automatic?(await db.query(`SELECT r.study_id FROM research_runtime_events e
      JOIN research_cases r ON r.id=e.research_case_id JOIN research_studies s ON s.id=r.study_id
      WHERE s.status='collecting' ORDER BY e.created_at DESC,e.id DESC LIMIT 1`)).rows[0]?.study_id:null;
    const withCases=active.length>1&&!automatic&&!recent?(await db.query(`SELECT r.study_id FROM research_cases r JOIN research_studies s ON s.id=r.study_id
      WHERE s.status='collecting' ORDER BY r.enrolled_at DESC,r.id DESC LIMIT 1`)).rows[0]?.study_id:null;
    return { studies, suggestedStudyId:automatic||recent||withCases||active[0]?.id||studies.find(s=>s.status==='draft')?.id||studies[0]?.id||null, cases: [], total: 0, page: 1, metrics: [] };
  }
  page = Math.max(1, Math.min(100000, Math.floor(page) || 1));
  const cases = (await db.query(`SELECT r.id,r.alias,r.phase,r.difficulty,r.enrolled_at,COALESCE(c.entry_no,r.alias) AS entry_no,COALESCE(c.status,'deleted') AS status,
    o.worker_minutes,o.office_minutes,o.quality_errors,o.outcome,o.cause,o.measurement_method
    FROM research_cases r LEFT JOIN cases c ON c.id=r.case_id
    LEFT JOIN LATERAL (SELECT * FROM research_observations WHERE research_case_id=r.id ORDER BY created_at DESC,id DESC LIMIT 1) o ON true
    WHERE r.study_id=$1 ORDER BY r.enrolled_at DESC,r.id LIMIT 25 OFFSET $2`, [studyId,(page-1)*25])).rows;
  const total = (await db.query('SELECT count(*)::int AS n FROM research_cases WHERE study_id=$1',[studyId])).rows[0].n;
  const metrics = (await db.query(`SELECT r.phase,count(*)::int AS enrolled,
    count(o.id)::int AS measured,
    sum((SELECT count(*) FROM research_case_audit a WHERE a.research_case_id=r.id AND a.action='return'))::int AS return_count,
    count(*) FILTER(WHERE o.outcome='failed')::int AS failed,
    count(*) FILTER(WHERE o.outcome='incomplete')::int AS incomplete,
    count(*) FILTER(WHERE o.worker_minutes IS NOT NULL AND o.office_minutes IS NOT NULL)::int AS timed,
    avg(o.worker_minutes+o.office_minutes) AS mean_minutes,
    count(o.quality_errors)::int AS quality_measured,avg(o.quality_errors) AS mean_errors
    FROM research_cases r LEFT JOIN LATERAL (SELECT * FROM research_observations WHERE research_case_id=r.id ORDER BY created_at DESC,id DESC LIMIT 1) o ON true
    WHERE r.study_id=$1 GROUP BY r.phase`, [studyId])).rows;
  const improvements=(await db.query('SELECT id,change_text,rationale,metric,applied_on::text AS applied_on,created_at FROM research_improvements WHERE study_id=$1 ORDER BY created_at DESC,id DESC',[studyId])).rows;
  const breakdown=(await db.query(`SELECT r.phase,r.difficulty,o.measurement_method,count(*)::int AS cases,
    count(o.id)::int AS measured,count(*) FILTER(WHERE o.worker_minutes IS NOT NULL AND o.office_minutes IS NOT NULL)::int AS timed,
    avg(o.worker_minutes+o.office_minutes) AS mean_minutes,avg(o.quality_errors) AS mean_errors,count(o.quality_errors)::int AS quality_measured
    FROM research_cases r LEFT JOIN LATERAL(SELECT * FROM research_observations WHERE research_case_id=r.id ORDER BY created_at DESC,id DESC LIMIT 1)o ON true
    WHERE r.study_id=$1 GROUP BY r.phase,r.difficulty,o.measurement_method ORDER BY r.phase,r.difficulty,o.measurement_method`,[studyId])).rows;
  const diagnostics=await researchDiagnostics(db,studyId);
  const telemetry=(await db.query('SELECT version,enabled FROM research_telemetry_settings WHERE study_id=$1 ORDER BY version DESC LIMIT 1',[studyId])).rows[0]||{version:1,enabled:defaultTelemetryGroups};
  const [context,handoffs]=await Promise.all([contextOverview(db,studyId),loadResearchHandoffs(db,studyId)]);
  return { studies,cases,total,page,metrics,improvements,breakdown,diagnostics,telemetry,context,handoffs };
}
export async function researchDetail(db: Queryable, staff: Staff, id: string) {
  requireResearchAdmin(staff);
  const rows=(await db.query(`SELECT r.*,COALESCE(c.entry_no,r.alias) AS entry_no,COALESCE(c.status,'deleted') AS status,c.row_version FROM research_cases r LEFT JOIN cases c ON c.id=r.case_id WHERE r.id=$1`,[id])).rows;
  if (!rows.length) throw new Error('not-found');
  const record=rows[0];
  const events=(await db.query(`SELECT a.id::text,a.action,a.created_at,e.role,a.detail->>'reason' AS reason FROM research_case_audit a
    JOIN employees e ON e.user_id=a.actor_user_id WHERE a.research_case_id=$1
    ORDER BY a.created_at,a.id LIMIT 1001`,[record.id])).rows;
  const observations=(await db.query(`SELECT o.id,worker_minutes,office_minutes,quality_errors,outcome,cause,evidence,
    measurement_method,case_version,o.created_at,a.result AS ai_result,a.status AS ai_status,a.model,a.prompt_version,a.error_code
    FROM research_observations o LEFT JOIN research_ai_runs a ON a.observation_id=o.id
    WHERE research_case_id=$1 ORDER BY o.created_at DESC,o.id DESC LIMIT 100`,[id])).rows;
  const reviews=(await db.query(`SELECT v.id,v.observation_id,v.verdict,v.correction,v.result_snapshot,v.model,v.prompt_version,v.created_at
    FROM research_ai_reviews v JOIN research_observations o ON o.id=v.observation_id WHERE o.research_case_id=$1 ORDER BY v.created_at DESC,v.id DESC`,[id])).rows;
  return { record,events:events.slice(0,1000).map(e=>({...e,reason:e.action==='return'?handoffReason(e.reason):null})),eventsTruncated:events.length>1000,process:processEvidence(events.slice(0,1000),events.length>1000),observations,reviews };
}
// Call mutations in a transaction. Locking the study prevents enrollment/observations racing closure.
export async function researchMutation(db: Queryable, staff: Staff, body: Record<string,unknown>) {
  requireResearchAdmin(staff);
  if(body.action==='create-preset'){
    const prefix=`preset-${createHash('sha256').update(staff.userId).digest('hex').slice(0,24)}`;
    await db.query('SELECT pg_advisory_xact_lock(hashtext($1))',[prefix]);
    const preset=(await db.query(`SELECT id FROM research_studies WHERE created_by=$1 AND (id=$2 OR id LIKE $3) AND status='collecting' ORDER BY created_at DESC,id DESC LIMIT 1`,[staff.userId,prefix,`${prefix}-%`])).rows[0];
    if(preset)return {id:preset.id};
    const id=`${prefix}-${randomUUID()}`;
    await db.query(`INSERT INTO research_studies(id,title,protocol,status,created_by) VALUES($1,$2,$3,'collecting',$4)`,[id,'維修協作改善','以案件為單位記錄提交、處理、退回及操作結果。比較改進前後的交接歷時、返工和資料品質。',staff.userId]);
    return {id};
  }
  if (body.action==='create-study') {
    const id=randomUUID();
    await db.query(`INSERT INTO research_studies(id,title,protocol,created_by) VALUES($1,$2,$3,$4)`,
      [id,text(body.title,120),text(body.protocol,4000,10),staff.userId]);
    return { id };
  }
  const studyId=text(body.studyId,100);
  const study=(await db.query('SELECT status FROM research_studies WHERE id=$1 FOR UPDATE',[studyId])).rows[0];
  if (!study) throw new Error('not-found');
  if(body.action==='telemetry-settings'){
    if(study.status==='closed')throw new Error('invalid-study-not-collecting');
    const enabled=body.enabled;
    if(!Array.isArray(enabled)||enabled.length>defaultTelemetryGroups.length||enabled.some(id=>!defaultTelemetryGroups.includes(id))||new Set(enabled).size!==enabled.length)throw new Error('invalid-research-input');
    const current=(await db.query('SELECT version,enabled FROM research_telemetry_settings WHERE study_id=$1 ORDER BY version DESC LIMIT 1',[studyId])).rows[0]||{version:1,enabled:defaultTelemetryGroups};
    if(current.enabled.length===enabled.length&&enabled.every(id=>current.enabled.includes(id)))return {version:current.version};
    const version=current.version+1;
    await db.query('INSERT INTO research_telemetry_settings(study_id,version,enabled) VALUES($1,$2,$3)',[studyId,version,enabled]);
    return {version};
  }
  if (body.action==='study-status') {
    const status=choice(body.status,['collecting','closed']);
    if (study.status==='closed' || (status==='collecting' && study.status!=='draft')) throw new Error('invalid-study-transition');
    await db.query('UPDATE research_studies SET status=$2 WHERE id=$1',[studyId,status]);
    if (status==='closed') await db.query('UPDATE research_auto_collection SET stopped_at=clock_timestamp() WHERE study_id=$1 AND stopped_at IS NULL',[studyId]);
    return { status };
  }
  if (study.status!=='collecting') throw new Error('invalid-study-not-collecting');
  if (body.action==='trial-plan') return saveTrialPlan(db,studyId,body.startsOn,body.weeks);
  if (body.action==='auto-collection') return enableAutoCollection(db,studyId,staff,body);
  if(body.action==='context-review'){
    const data=validateContext(body);
    const entryNo=text(body.entryNo,80);
    const record=(await db.query(`SELECT r.id,c.row_version FROM research_cases r JOIN cases c ON c.id=r.case_id
      WHERE r.study_id=$1 AND c.entry_no=$2 AND c.deleted_at IS NULL`,[studyId,entryNo])).rows[0];
    if(!record)throw Error('invalid-context-case');
    const id=randomUUID();
    await db.query(`INSERT INTO research_context_reviews(id,research_case_id,role,stage,source,factors,load,safety,consent_reference,case_version,rules_version,created_by)
      VALUES($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9,$10,$11,$12)`,[id,record.id,data.role,data.stage,data.source,JSON.stringify(data.factors),data.load,data.safety,text(body.consentReference,200),record.row_version,humanFactorsVersion,staff.userId]);
    return {id};
  }
  if (body.action==='review-ai') {
    const observationId=text(body.observationId,100);
    const run=(await db.query(`SELECT a.result,a.model,a.prompt_version FROM research_ai_runs a
      JOIN research_observations o ON o.id=a.observation_id JOIN research_cases r ON r.id=o.research_case_id
      WHERE a.observation_id=$1 AND r.study_id=$2 AND a.status='complete' FOR UPDATE OF a`,[observationId,studyId])).rows[0];
    if(!run)throw new Error('invalid-ai-review');
    const id=randomUUID();
    await db.query(`INSERT INTO research_ai_reviews(id,observation_id,verdict,correction,result_snapshot,model,prompt_version,created_by)
      VALUES($1,$2,$3,$4,$5::jsonb,$6,$7,$8)`,[id,observationId,choice(body.verdict,['agree','partial','disagree']),text(body.correction,2000,5),JSON.stringify(run.result),run.model,run.prompt_version,staff.userId]);
    return {id};
  }
  if(body.action==='improvement') {
    const appliedOn=text(body.appliedOn,10);
    if(!/^\d{4}-\d{2}-\d{2}$/.test(appliedOn)||!Number.isFinite(Date.parse(appliedOn))||new Date(appliedOn).toISOString().slice(0,10)!==appliedOn)throw new Error('invalid-research-input');
    const id=randomUUID();
    await db.query(`INSERT INTO research_improvements(id,study_id,change_text,rationale,metric,applied_on,created_by)
      VALUES($1,$2,$3,$4,$5,$6,$7)`,[id,studyId,text(body.changeText,1000,5),text(body.rationale,2000,5),choice(body.metric,['time','errors','returns']),appliedOn,staff.userId]);
    return {id};
  }
  if (body.action==='enroll') {
    if (body.permissionConfirmed!==true) throw new Error('invalid-consent');
    const entry=text(body.entryNo,80);
    const c=(await db.query('SELECT id FROM cases WHERE entry_no=$1 AND deleted_at IS NULL',[entry])).rows[0];
    if (!c) throw new Error('not-found');
    const id=randomUUID();
    const result=await db.query(`INSERT INTO research_cases(id,study_id,case_id,alias,phase,difficulty,consent_reference,enrolled_by)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT(study_id,case_id) DO NOTHING RETURNING id`,
      [id,studyId,c.id,`R-${randomUUID()}`,choice(body.phase,['baseline','improved']),choice(body.difficulty,['low','medium','high']),text(body.consentReference,200),staff.userId]);
    if (!result.rows.length) throw new Error('invalid-already-enrolled');
    return { id };
  }
  if (body.action==='observe') {
    const id=text(body.id,100);
    const c=(await db.query(`SELECT c.row_version FROM research_cases r JOIN cases c ON c.id=r.case_id WHERE r.id=$1 AND r.study_id=$2`,[id,studyId])).rows[0];
    if (!c) throw new Error('not-found');
    const observationId=randomUUID();
    await db.query(`INSERT INTO research_observations(id,research_case_id,worker_minutes,office_minutes,quality_errors,outcome,cause,evidence,measurement_method,case_version,created_by)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,[observationId,id,numberOrNull(body.workerMinutes,10080),numberOrNull(body.officeMinutes,10080),numberOrNull(body.qualityErrors,1000,true),
      choice(body.outcome,['complete','incomplete','failed']),choice(body.cause,['missing_information','changed_requirement','technical_failure','other','unknown']),
      text(body.evidence,2000),choice(body.method,['observed','self_report']),c.row_version,staff.userId]);
    return { id:observationId };
  }
  throw new Error('invalid-action');
}
export async function researchExport(db: Queryable, staff: Staff, studyId: string) {
  requireResearchAdmin(staff);
  // No names, phones, addresses, real case IDs or free text in research export.
  const rows=(await db.query(`SELECT r.alias,r.phase,r.difficulty,r.enrolled_at,o.id AS observation_id,c.owner_user_id AS participant_id,c.source,
    o.worker_minutes,o.office_minutes,o.quality_errors,o.outcome,o.cause,o.measurement_method,o.case_version,o.created_at,
    ai.model,ai.prompt_version,ai.status AS ai_status,ai.result->>'cause' AS ai_cause,
    (SELECT COALESCE(json_agg(f->>'cause'),'[]'::json) FROM jsonb_array_elements(CASE WHEN jsonb_typeof(ai.result->'factors')='array' THEN ai.result->'factors' ELSE '[]'::jsonb END) f) AS ai_factors,
    (SELECT COALESCE(json_agg(json_build_object('verdict',v.verdict,'at',v.created_at,'model',v.model,'promptVersion',v.prompt_version) ORDER BY v.created_at,v.id),'[]'::json)
      FROM research_ai_reviews v WHERE v.observation_id=o.id) AS ai_reviews,
    (SELECT COALESCE(json_agg(json_build_object('actor',a.actor_user_id,'role',e.role,'action',a.action,'at',a.created_at) ORDER BY a.created_at,a.id),'[]'::json)
      FROM research_case_audit a JOIN employees e ON e.user_id=a.actor_user_id WHERE a.research_case_id=r.id) AS events
    FROM research_cases r LEFT JOIN research_observations o ON o.research_case_id=r.id
    LEFT JOIN cases c ON c.id=r.case_id LEFT JOIN research_ai_runs ai ON ai.observation_id=o.id
    WHERE r.study_id=$1 ORDER BY r.alias,o.created_at,o.id`,[studyId])).rows;
  const pseudonym=(id:string|null)=>id?`P-${createHash('sha256').update(`${studyId}:${id}`).digest('hex').slice(0,16)}`:null;
  return rows.map(({participant_id,events,...row})=>({...row,participant:pseudonym(participant_id),
    events:events.map(({actor,...event}:{actor:string;role:string;action:string;at:string})=>({...event,participant:pseudonym(actor)}))}));
}
export async function researchRuntimeExport(db:Queryable,staff:Staff,studyId:string){
  requireResearchAdmin(staff);
  const rows=(await db.query(`SELECT r.alias,r.phase,r.difficulty,e.role,e.operation,e.outcome,e.duration_ms,e.release,e.collection_version,
    round(extract(epoch FROM (e.created_at-r.enrolled_at)))::int AS seconds_since_enrollment
    FROM research_runtime_events e JOIN research_cases r ON r.id=e.research_case_id
    WHERE r.study_id=$1 ORDER BY e.created_at,e.id LIMIT 20001`,[studyId])).rows;
  const revisions=(await db.query('SELECT version,enabled,created_at FROM research_telemetry_settings WHERE study_id=$1 ORDER BY version',[studyId])).rows;
  return {rows:rows.slice(0,20000).map(row=>({...row,category:telemetryCategory(row.role,row.operation)||null})),truncated:rows.length>20000,collectionVersions:[{version:1,enabled:defaultTelemetryGroups},...revisions]};
}
