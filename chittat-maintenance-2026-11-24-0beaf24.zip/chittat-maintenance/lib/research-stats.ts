// 輕量統計工具：OLS、Logistic（IRLS）、按員工聚類穩健標準誤（CR1）、聚類自助法。
// 用於工作台即時估計；正式論文建議匯出 CSV 後以 R lme4 / Python statsmodels 重算混合效應模型。

export type Coef = { name: string; b: number; se: number; t: number; p: number; lo: number; hi: number };
export type Fit = { kind: 'ols' | 'logit'; n: number; clusters: number; coefs: Coef[]; converged: boolean; r2?: number };

function solve(A: number[][], b: number[]): number[] | null {
  const n = A.length, M = A.map((row, i) => [...row, b[i]]);
  for (let c = 0; c < n; c++) {
    let piv = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[piv][c])) piv = r;
    if (Math.abs(M[piv][c]) < 1e-12) return null;
    [M[c], M[piv]] = [M[piv], M[c]];
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c] / M[c][c];
      if (f) for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  return M.map((row, i) => row[n] / row[i]);
}
function invert(A: number[][]): number[][] | null {
  const n = A.length, cols: number[][] = [];
  for (let j = 0; j < n; j++) {
    const col = solve(A, A.map((_, i) => (i === j ? 1 : 0)));
    if (!col) return null;
    cols.push(col);
  }
  return A.map((_, i) => cols.map(col => col[i]));
}
const matmul = (A: number[][], B: number[][]) => A.map(r => B[0].map((_, j) => r.reduce((s, v, k) => s + v * B[k][j], 0)));

// --- 分佈函數 ---
function lgamma(x: number): number {
  const c = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
  let y = x, tmp = x + 5.5, ser = 1.000000000190015;
  tmp -= (x + 0.5) * Math.log(tmp);
  for (const v of c) ser += v / ++y;
  return -tmp + Math.log((2.5066282746310005 * ser) / x);
}
function betacf(a: number, b: number, x: number) {
  let c = 1, d = 1 - ((a + b) * x) / (a + 1);
  d = 1 / (Math.abs(d) < 1e-30 ? 1e-30 : d);
  let h = d;
  for (let m = 1; m <= 200; m++) {
    const m2 = 2 * m;
    let aa = (m * (b - m) * x) / ((a + m2 - 1) * (a + m2));
    d = 1 + aa * d; d = 1 / (Math.abs(d) < 1e-30 ? 1e-30 : d); c = 1 + aa / c; c = Math.abs(c) < 1e-30 ? 1e-30 : c; h *= d * c;
    aa = (-(a + m) * (a + b + m) * x) / ((a + m2) * (a + m2 + 1));
    d = 1 + aa * d; d = 1 / (Math.abs(d) < 1e-30 ? 1e-30 : d); c = 1 + aa / c; c = Math.abs(c) < 1e-30 ? 1e-30 : c;
    const del = d * c; h *= del;
    if (Math.abs(del - 1) < 3e-12) break;
  }
  return h;
}
function ibeta(a: number, b: number, x: number) {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const bt = Math.exp(lgamma(a + b) - lgamma(a) - lgamma(b) + a * Math.log(x) + b * Math.log(1 - x));
  return x < (a + 1) / (a + b + 2) ? (bt * betacf(a, b, x)) / a : 1 - (bt * betacf(b, a, 1 - x)) / b;
}
/** 雙尾 t 檢定 p 值 */
export function tPValue(t: number, df: number) {
  if (!Number.isFinite(t)) return NaN;
  return ibeta(df / 2, 0.5, df / (df + t * t));
}
/** t 分佈 97.5% 分位數（二分搜尋） */
export function tCrit(df: number) {
  let lo = 1.9, hi = 30;
  for (let i = 0; i < 60; i++) { const mid = (lo + hi) / 2; if (tPValue(mid, df) > 0.05) lo = mid; else hi = mid; }
  return (lo + hi) / 2;
}

function sandwich(X: number[][], scores: number[], bread: number[][], cluster: string[]) {
  const k = X[0].length, n = X.length;
  const groups = new Map<string, number[]>();
  X.forEach((row, i) => {
    const g = groups.get(cluster[i]) || Array(k).fill(0);
    row.forEach((v, j) => (g[j] += v * scores[i]));
    groups.set(cluster[i], g);
  });
  const meat = Array.from({ length: k }, () => Array(k).fill(0));
  for (const u of groups.values()) for (let a = 0; a < k; a++) for (let b = 0; b < k; b++) meat[a][b] += u[a] * u[b];
  const G = groups.size;
  const adj = G > 1 ? (G / (G - 1)) * ((n - 1) / Math.max(1, n - k)) : 1;
  return { V: matmul(matmul(bread, meat), bread).map(r => r.map(v => v * adj)), G };
}

function table(names: string[], beta: number[], V: number[][], df: number): Coef[] {
  const crit = tCrit(df);
  return names.map((name, i) => {
    const se = Math.sqrt(Math.max(0, V[i][i])), t = beta[i] / se;
    return { name, b: beta[i], se, t, p: tPValue(t, df), lo: beta[i] - crit * se, hi: beta[i] + crit * se };
  });
}

export function ols(y: number[], X: number[][], names: string[], cluster: string[]): Fit | null {
  const n = y.length, k = names.length;
  if (n <= k + 2) return null;
  const XtX = Array.from({ length: k }, (_, a) => Array.from({ length: k }, (_, b) => X.reduce((s, r) => s + r[a] * r[b], 0)));
  const bread = invert(XtX);
  if (!bread) return null;
  const Xty = Array.from({ length: k }, (_, a) => X.reduce((s, r, i) => s + r[a] * y[i], 0));
  const beta = bread.map(r => r.reduce((s, v, j) => s + v * Xty[j], 0));
  const resid = y.map((v, i) => v - X[i].reduce((s, x, j) => s + x * beta[j], 0));
  const { V, G } = sandwich(X, resid, bread, cluster);
  const mean = y.reduce((a, b) => a + b, 0) / n;
  const r2 = 1 - resid.reduce((s, e) => s + e * e, 0) / y.reduce((s, v) => s + (v - mean) ** 2, 0);
  return { kind: 'ols', n, clusters: G, coefs: table(names, beta, V, Math.max(1, G - 1)), converged: true, r2 };
}

export function logit(y: number[], X: number[][], names: string[], cluster: string[]): Fit | null {
  const n = y.length, k = names.length;
  if (n <= k + 2 || y.every(v => v === y[0])) return null;
  let beta = Array(k).fill(0), converged = false, bread: number[][] | null = null;
  for (let iter = 0; iter < 50; iter++) {
    const p = X.map(r => 1 / (1 + Math.exp(-r.reduce((s, x, j) => s + x * beta[j], 0))));
    const H = Array.from({ length: k }, (_, a) => Array.from({ length: k }, (_, b) => X.reduce((s, r, i) => s + r[a] * r[b] * p[i] * (1 - p[i]), 0)));
    const g = Array.from({ length: k }, (_, a) => X.reduce((s, r, i) => s + r[a] * (y[i] - p[i]), 0));
    const step = solve(H, g);
    if (!step) return null;
    beta = beta.map((b, j) => b + step[j]);
    if (Math.max(...step.map(Math.abs)) < 1e-8) { converged = true; break; }
  }
  const p = X.map(r => 1 / (1 + Math.exp(-r.reduce((s, x, j) => s + x * beta[j], 0))));
  const H = Array.from({ length: k }, (_, a) => Array.from({ length: k }, (_, b) => X.reduce((s, r, i) => s + r[a] * r[b] * p[i] * (1 - p[i]), 0)));
  bread = invert(H);
  if (!bread || beta.some(b => !Number.isFinite(b) || Math.abs(b) > 20)) return null;
  const { V, G } = sandwich(X, y.map((v, i) => v - p[i]), bread, cluster);
  return { kind: 'logit', n, clusters: G, coefs: table(names, beta, V, Math.max(1, G - 1)), converged };
}

/** 可重現的隨機數 */
export function rng(seed: number) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

/** 按聚類（員工）重抽樣的自助法 */
export function clusterBootstrap<T extends { worker: string }>(rows: T[], reps: number, stat: (rows: T[]) => number | null, seed = 7) {
  const byWorker = new Map<string, T[]>();
  rows.forEach(r => byWorker.set(r.worker, [...(byWorker.get(r.worker) || []), r]));
  const groups = [...byWorker.values()], rand = rng(seed), out: number[] = [];
  for (let i = 0; i < reps; i++) {
    const sample: T[] = [];
    groups.forEach((_, gi) => {
      const g = groups[Math.floor(rand() * groups.length)];
      g.forEach(r => sample.push({ ...r, worker: `${r.worker}#${gi}` }));
    });
    const v = stat(sample);
    if (v != null && Number.isFinite(v)) out.push(v);
  }
  out.sort((a, b) => a - b);
  const q = (x: number) => out[Math.min(out.length - 1, Math.max(0, Math.floor(x * out.length)))];
  return out.length >= reps * 0.8 ? { lo: q(0.025), hi: q(0.975), reps: out.length } : null;
}

export const mean = (v: number[]) => (v.length ? v.reduce((a, b) => a + b, 0) / v.length : NaN);
export const median = (v: number[]) => {
  if (!v.length) return NaN;
  const s = [...v].sort((a, b) => a - b), m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};
export const sd = (v: number[]) => { const m = mean(v); return Math.sqrt(mean(v.map(x => (x - m) ** 2))) || 1; };
