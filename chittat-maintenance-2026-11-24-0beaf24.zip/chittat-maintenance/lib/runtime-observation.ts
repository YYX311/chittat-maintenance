import type {Staff} from './access';
import type {Queryable} from './case-service';
import {telemetryCategory} from './telemetry-catalog';
export async function storeRuntime(db:Queryable,staff:Staff,body:Record<string,unknown>) {
  if(typeof body.id!=='string'||!/^[\w-]{8,100}$/.test(body.id)||typeof body.caseId!=='string'||!/^[\w-]{1,100}$/.test(body.caseId)||
    !['save','assets','documents','submit','return','confirm','reopen'].includes(String(body.operation))||
    !['ok','rejected','conflict','server_error','network'].includes(String(body.outcome))||
    !Number.isInteger(body.durationMs)||Number(body.durationMs)<0||Number(body.durationMs)>300000||body.release!=='workflow-assistant-2026-11-06')throw new Error('invalid-runtime-event');
  const category=telemetryCategory(staff.role,String(body.operation));
  if(!category)return {recorded:false};
  // Transaction-scoped lock bounds concurrent submissions by a single account.
  await db.query('SELECT pg_advisory_xact_lock(hashtext($1))',[`runtime-${staff.userId}`]);
  const count=(await db.query("SELECT count(*)::int AS n FROM research_runtime_events WHERE actor_user_id=$1 AND created_at>now()-interval '1 day'",[staff.userId])).rows[0].n;
  if(count>=1000)return {recorded:false,reason:'limit'};
  const result=await db.query(`INSERT INTO research_runtime_events(id,research_case_id,actor_user_id,role,operation,outcome,duration_ms,release,collection_version)
    SELECT $1||':'||r.id,r.id,$3,$4,$5,$6,$7,$8,COALESCE(cfg.version,1) FROM research_cases r
    JOIN cases c ON c.id=r.case_id JOIN research_studies s ON s.id=r.study_id
    LEFT JOIN LATERAL(SELECT version,enabled FROM research_telemetry_settings WHERE study_id=r.study_id ORDER BY version DESC LIMIT 1) cfg ON true
    WHERE r.case_id=$2 AND s.status='collecting' AND c.deleted_at IS NULL
      AND ($4 IN ('office','manager') OR c.owner_user_id=$3)
      AND (r.trial_period IS NULL OR EXISTS (SELECT 1 FROM research_participation p
        WHERE p.study_id=r.study_id AND p.user_id=$3 AND p.left_at IS NULL))
      AND (cfg.version IS NULL OR $9=ANY(cfg.enabled))
    ON CONFLICT(id) DO NOTHING RETURNING id`,[body.id,body.caseId,staff.userId,staff.role,body.operation,body.outcome,body.durationMs,body.release,category]);
  return {recorded:result.rows.length>0};
}
