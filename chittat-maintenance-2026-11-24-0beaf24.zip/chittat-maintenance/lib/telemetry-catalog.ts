export const telemetryGroups=[
  {id:'field-record',role:'worker',title:'填寫維修資料',examples:'保存、上傳相片',operations:['save','assets']},
  {id:'field-handoff',role:'worker',title:'提交與補充',examples:'提交、重新修改',operations:['submit','reopen']},
  {id:'field-document',role:'worker',title:'生成文件',examples:'生成文件',operations:['documents']},
  {id:'office-record',role:'office',title:'整理案件資料',examples:'保存、上傳相片',operations:['save','assets']},
  {id:'office-review',role:'office',title:'復核與回饋',examples:'提交、退回、確認、重新修改',operations:['submit','return','confirm','reopen']},
  {id:'office-document',role:'office',title:'生成文件',examples:'生成文件',operations:['documents']},
] as const;
export const defaultTelemetryGroups=telemetryGroups.map(group=>group.id);
export function telemetryCategory(role:string,operation:string){
  const side=role==='manager'?'office':role;
  return telemetryGroups.find(group=>group.role===side&&(group.operations as readonly string[]).includes(operation))?.id;
}
