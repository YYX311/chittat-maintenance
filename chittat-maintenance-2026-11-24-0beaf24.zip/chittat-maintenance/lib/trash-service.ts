import type { Staff } from "./access";
import { actionCase, type Queryable } from "./case-service";
import { canSee } from "./case-rules";

// Called within one transaction: validate and lock every item before changing any.
export async function updateTrash(client: Queryable, staff: Staff, items: {id:string;serverVersion:number}[], action:string) {
  if (!Array.isArray(items) || !items.length || items.length>500 || !["restore","permanent-delete"].includes(action)) throw new Error("invalid-trash-request");
  if (new Set(items.map(i=>i.id)).size !== items.length) throw new Error("invalid-trash-request");
  const records=[];
  for (const item of [...items].sort((a,b)=>a.id.localeCompare(b.id))) {
    const {rows}=await client.query("SELECT data,row_version FROM cases WHERE id=$1 AND deleted_at IS NOT NULL FOR UPDATE",[item.id]);
    const row=rows[0];
    if (!row || !canSee(staff,row.data)) throw new Error("not-found");
    if (row.row_version!==item.serverVersion) throw new Error("conflict");
    if (staff.role==="worker" ? row.data.status!=="editing" : row.data.status!=="draft") throw new Error("forbidden");
    records.push({...row.data,serverVersion:row.row_version});
  }
  for (const record of records) {
    if (action==="restore") await actionCase(client,staff,record.id,"restore-draft",record.serverVersion);
    else {
      await client.query("INSERT INTO object_deletions(object_key) SELECT object_key FROM assets WHERE case_id=$1 ON CONFLICT DO NOTHING",[record.id]);
      await client.query("UPDATE audit_events SET detail=detail || jsonb_build_object('deletedCaseId',case_id),case_id=NULL WHERE case_id=$1",[record.id]);
      await client.query("DELETE FROM case_versions WHERE case_id=$1",[record.id]);
      await client.query("DELETE FROM assets WHERE case_id=$1",[record.id]);
      await client.query("DELETE FROM cases WHERE id=$1",[record.id]);
      await client.query("INSERT INTO audit_events(actor_user_id,action,detail) VALUES ($1,'permanent-delete',$2::jsonb)",[staff.userId,JSON.stringify({deletedCaseId:record.id})]);
    }
  }
  return {count:records.length};
}
