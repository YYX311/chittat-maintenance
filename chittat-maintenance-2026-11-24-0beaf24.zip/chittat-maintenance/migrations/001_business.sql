CREATE TABLE employees (
  user_id text PRIMARY KEY REFERENCES "user"(id) ON DELETE RESTRICT,
  staff_code text NOT NULL UNIQUE,
  role text NOT NULL CHECK (role IN ('worker', 'office', 'manager')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE projects (
  id text PRIMARY KEY,
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE cases (
  id text PRIMARY KEY,
  owner_user_id text NOT NULL REFERENCES employees(user_id),
  source text NOT NULL CHECK (source IN ('worker', 'office')),
  status text NOT NULL CHECK (status IN ('editing', 'submitted', 'needsInfo', 'draft', 'revision', 'approved', 'issued')),
  row_version integer NOT NULL DEFAULT 0 CHECK (row_version >= 0),
  entry_no text UNIQUE,
  service_no text UNIQUE,
  quote_ref text UNIQUE,
  quote_revision integer NOT NULL DEFAULT 0 CHECK (quote_revision >= 0),
  project_id text REFERENCES projects(id),
  data jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  deleted_at timestamptz
);
CREATE INDEX cases_owner_status_idx ON cases(owner_user_id, status) WHERE deleted_at IS NULL;
CREATE INDEX cases_status_updated_idx ON cases(status, updated_at DESC) WHERE deleted_at IS NULL;

CREATE TABLE case_versions (
  id text PRIMARY KEY,
  case_id text NOT NULL REFERENCES cases(id) ON DELETE RESTRICT,
  kind text NOT NULL CHECK (kind IN ('service', 'confirmation', 'quotation', 'invoice')),
  revision integer NOT NULL CHECK (revision >= 0),
  snapshot jsonb NOT NULL,
  asset_key text,
  created_by text NOT NULL REFERENCES employees(user_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (case_id, kind, revision)
);

CREATE TABLE assets (
  key text PRIMARY KEY,
  case_id text NOT NULL REFERENCES cases(id) ON DELETE RESTRICT,
  uploaded_by text NOT NULL REFERENCES employees(user_id),
  object_key text NOT NULL UNIQUE,
  content_type text NOT NULL,
  byte_size integer NOT NULL CHECK (byte_size > 0 AND byte_size <= 20971520),
  sha256 text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE case_versions ADD CONSTRAINT case_versions_asset_fk FOREIGN KEY (asset_key) REFERENCES assets(key);

CREATE TABLE audit_events (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  case_id text REFERENCES cases(id),
  actor_user_id text NOT NULL REFERENCES employees(user_id),
  action text NOT NULL,
  detail jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_events_case_idx ON audit_events(case_id, created_at DESC);

CREATE TABLE counters (
  key text PRIMARY KEY,
  value bigint NOT NULL CHECK (value >= 0)
);
