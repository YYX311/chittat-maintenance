CREATE UNIQUE INDEX projects_code_lower_unique ON projects(lower(code));
