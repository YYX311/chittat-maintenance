ALTER TABLE case_versions
  ADD COLUMN document_format_version integer NOT NULL DEFAULT 0
  CHECK (document_format_version >= 0);
