CREATE TABLE object_deletions (
  object_key text PRIMARY KEY,
  queued_at timestamptz NOT NULL DEFAULT now()
);
