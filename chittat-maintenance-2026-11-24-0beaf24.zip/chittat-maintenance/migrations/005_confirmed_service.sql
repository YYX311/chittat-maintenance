ALTER TABLE case_versions DROP CONSTRAINT case_versions_kind_check;
ALTER TABLE case_versions ADD CONSTRAINT case_versions_kind_check
  CHECK (kind IN ('service', 'confirmation', 'quotation', 'invoice', 'confirmed-service'));
