-- Preserve existing service numbers. Allocate from the same global counter for
-- office tasks and worker drafts; immutable historical PDFs are untouched.
INSERT INTO counters(key,value)
SELECT 'service',COALESCE(MAX(substring(service_no from '([0-9]+)$')::bigint),0) FROM cases
ON CONFLICT(key) DO UPDATE SET value=GREATEST(counters.value,EXCLUDED.value);
WITH numbered AS (
 SELECT id,(SELECT value FROM counters WHERE key='service')+row_number() OVER(ORDER BY created_at,id) AS n
 FROM cases WHERE service_no IS NULL
)
UPDATE cases SET service_no='CT-MNA-'||lpad(numbered.n::text,GREATEST(4,length(numbered.n::text)), '0'),
 data=jsonb_set(data,'{serviceNo}',to_jsonb('CT-MNA-'||lpad(numbered.n::text,GREATEST(4,length(numbered.n::text)),'0'))),
 row_version=row_version+1 FROM numbered WHERE cases.id=numbered.id;
UPDATE counters SET value=(SELECT COALESCE(MAX(substring(service_no from '([0-9]+)$')::bigint),0) FROM cases) WHERE key='service';
