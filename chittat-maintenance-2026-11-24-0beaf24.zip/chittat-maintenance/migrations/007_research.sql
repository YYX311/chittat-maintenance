CREATE TABLE research_studies (
  id text PRIMARY KEY,
  title text NOT NULL,
  protocol text NOT NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','collecting','closed')),
  created_by text NOT NULL REFERENCES employees(user_id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE research_cases (
  id text PRIMARY KEY,
  study_id text NOT NULL REFERENCES research_studies(id),
  case_id text REFERENCES cases(id) ON DELETE SET NULL,
  alias text NOT NULL UNIQUE,
  phase text NOT NULL CHECK (phase IN ('baseline','improved')),
  difficulty text NOT NULL CHECK (difficulty IN ('low','medium','high')),
  consent_reference text NOT NULL,
  enrolled_by text NOT NULL REFERENCES employees(user_id),
  enrolled_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(study_id,case_id)
);
CREATE TABLE research_observations (
  id text PRIMARY KEY,
  research_case_id text NOT NULL REFERENCES research_cases(id),
  worker_minutes numeric CHECK(worker_minutes >= 0 AND worker_minutes <= 10080),
  office_minutes numeric CHECK(office_minutes >= 0 AND office_minutes <= 10080),
  quality_errors integer CHECK(quality_errors >= 0 AND quality_errors <= 1000),
  outcome text NOT NULL CHECK(outcome IN ('complete','incomplete','failed')),
  cause text NOT NULL CHECK(cause IN ('missing_information','changed_requirement','technical_failure','other','unknown')),
  evidence text NOT NULL,
  measurement_method text NOT NULL CHECK(measurement_method IN ('observed','self_report')),
  case_version integer NOT NULL,
  created_by text NOT NULL REFERENCES employees(user_id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX research_cases_study_idx ON research_cases(study_id,enrolled_at DESC);
CREATE INDEX research_observations_case_idx ON research_observations(research_case_id,created_at DESC);
CREATE TABLE research_ai_usage (
  day date PRIMARY KEY,
  attempts integer NOT NULL CHECK(attempts >= 0)
);
CREATE TABLE research_ai_runs (
  observation_id text PRIMARY KEY REFERENCES research_observations(id),
  model text NOT NULL,
  prompt_version text NOT NULL,
  input_hash text NOT NULL,
  status text NOT NULL CHECK(status IN ('running','complete','failed')),
  result jsonb,
  error_code text,
  attempt_id text NOT NULL,
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  created_by text NOT NULL REFERENCES employees(user_id)
);
