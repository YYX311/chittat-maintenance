CREATE TABLE research_ai_reviews (
  id text PRIMARY KEY,
  observation_id text NOT NULL REFERENCES research_observations(id),
  verdict text NOT NULL CHECK(verdict IN ('agree','partial','disagree')),
  correction text NOT NULL,
  result_snapshot jsonb NOT NULL,
  model text NOT NULL,
  prompt_version text NOT NULL,
  created_by text NOT NULL REFERENCES employees(user_id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX research_ai_reviews_observation_idx ON research_ai_reviews(observation_id,created_at DESC);
CREATE TABLE research_improvements (
  id text PRIMARY KEY,
  study_id text NOT NULL REFERENCES research_studies(id),
  change_text text NOT NULL,
  rationale text NOT NULL,
  metric text NOT NULL CHECK(metric IN ('time','errors','returns')),
  applied_on date NOT NULL,
  created_by text NOT NULL REFERENCES employees(user_id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX research_improvements_study_idx ON research_improvements(study_id,created_at DESC);
