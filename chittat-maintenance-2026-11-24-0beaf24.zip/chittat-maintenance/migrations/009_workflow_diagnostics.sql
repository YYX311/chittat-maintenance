-- Minimal, opt-in study telemetry. No form content, URL queries or customer data.
CREATE TABLE research_runtime_events (
  id text PRIMARY KEY,
  research_case_id text NOT NULL REFERENCES research_cases(id) ON DELETE CASCADE,
  actor_user_id text NOT NULL REFERENCES employees(user_id),
  role text NOT NULL,
  operation text NOT NULL,
  outcome text NOT NULL CHECK(outcome IN ('ok','rejected','conflict','server_error','network')),
  duration_ms integer NOT NULL CHECK(duration_ms BETWEEN 0 AND 300000),
  release text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX research_runtime_case_time ON research_runtime_events(research_case_id,created_at DESC);
CREATE INDEX research_runtime_actor_time ON research_runtime_events(actor_user_id,created_at DESC);
CREATE TABLE research_diagnostic_runs (
  id text PRIMARY KEY, study_id text NOT NULL REFERENCES research_studies(id),
  input_hash text NOT NULL, evidence text NOT NULL,
  status text NOT NULL, result jsonb, model text NOT NULL, prompt_version text NOT NULL,
  attempt_id text NOT NULL, started_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(study_id,input_hash)
);
