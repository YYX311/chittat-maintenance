CREATE TABLE research_telemetry_settings (
  study_id text NOT NULL REFERENCES research_studies(id),
  version integer NOT NULL CHECK(version > 1),
  enabled text[] NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(study_id,version)
);

ALTER TABLE research_runtime_events ADD COLUMN collection_version integer NOT NULL DEFAULT 1;
