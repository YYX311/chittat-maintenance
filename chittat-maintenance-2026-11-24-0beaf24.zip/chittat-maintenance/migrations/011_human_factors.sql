-- Explicit, permissioned contextual review. No passive fatigue inference or biometrics.
CREATE TABLE research_context_reviews (
  id text PRIMARY KEY,
  research_case_id text NOT NULL REFERENCES research_cases(id),
  role text NOT NULL CHECK(role IN ('worker','office')),
  stage text NOT NULL CHECK(stage IN ('capture','submit','review','documents')),
  source text NOT NULL CHECK(source IN ('self_report','observed')),
  factors jsonb NOT NULL CHECK(jsonb_typeof(factors)='array'),
  load smallint CHECK(load BETWEEN 1 AND 5),
  safety text NOT NULL CHECK(safety IN ('not_asked','reported','none_reported')),
  consent_reference text NOT NULL,
  case_version integer NOT NULL,
  rules_version text NOT NULL,
  created_by text NOT NULL REFERENCES employees(user_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK(source='self_report' OR (load IS NULL AND NOT factors ?| array['fatigue','time_pressure']))
);
CREATE INDEX research_context_case_time ON research_context_reviews(research_case_id,created_at DESC,id DESC);
ALTER TABLE research_context_reviews ENABLE ROW LEVEL SECURITY;
