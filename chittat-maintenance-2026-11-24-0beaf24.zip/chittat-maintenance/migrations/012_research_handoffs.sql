-- Read committed business actions in order for the study's enrolled cases.
CREATE INDEX audit_events_handoff_idx
  ON audit_events (case_id, created_at, id)
  WHERE action IN ('submit','withdraw','return','confirm');
