CREATE TABLE research_trial_plans (
  study_id text PRIMARY KEY REFERENCES research_studies(id) ON DELETE CASCADE,
  starts_on date NOT NULL,
  weeks_per_period integer NOT NULL CHECK (weeks_per_period BETWEEN 1 AND 4),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE research_trial_plans ENABLE ROW LEVEL SECURITY;
