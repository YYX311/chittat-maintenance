CREATE TABLE research_auto_collection (
  study_id text PRIMARY KEY REFERENCES research_studies(id),
  consent_reference text NOT NULL,
  enabled_by text NOT NULL REFERENCES employees(user_id),
  enabled_at timestamptz NOT NULL DEFAULT now(),
  stopped_at timestamptz
);
CREATE UNIQUE INDEX research_one_auto_collection ON research_auto_collection ((true)) WHERE stopped_at IS NULL;

CREATE TABLE research_participation (
  id text PRIMARY KEY,
  study_id text NOT NULL REFERENCES research_auto_collection(study_id),
  user_id text NOT NULL REFERENCES employees(user_id),
  joined_at timestamptz NOT NULL DEFAULT now(),
  left_at timestamptz,
  tenure text CHECK (tenure IN ('under_1','1_to_3','3_to_5','over_5')),
  specialty text CHECK (specialty IN ('hvac','electrical','plumbing','administration','other')),
  licensed boolean,
  work_area text CHECK (work_area IN ('hong_kong','kowloon','new_territories','mixed','office')),
  CHECK (left_at IS NULL OR left_at >= joined_at)
);
CREATE UNIQUE INDEX research_participation_current ON research_participation(study_id,user_id) WHERE left_at IS NULL;
CREATE INDEX research_participation_history ON research_participation(study_id,user_id,joined_at);

ALTER TABLE research_cases ADD COLUMN trial_period text CHECK (trial_period IN ('A1','B1','A2','B2'));
CREATE INDEX research_auto_case_idx ON research_cases(case_id) WHERE trial_period IS NOT NULL;

CREATE TABLE research_field_events (
  study_case_id text NOT NULL REFERENCES research_cases(id),
  actor_user_id text NOT NULL REFERENCES employees(user_id),
  id text NOT NULL,
  at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  kind text NOT NULL CHECK (kind IN ('screen_active','validation_error','field_clear','rage_click',
    'offline','reconnect','slow_network','assistant_shown','assistant_accept')),
  surface text NOT NULL,
  field text,
  duration_ms integer CHECK (duration_ms BETWEEN 0 AND 300000),
  PRIMARY KEY (study_case_id, actor_user_id, id)
);
CREATE INDEX research_field_events_time ON research_field_events(study_case_id,at);
CREATE INDEX research_field_events_actor ON research_field_events(actor_user_id,received_at);

CREATE TABLE research_task_pulse (
  study_case_id text NOT NULL REFERENCES research_cases(id),
  actor_user_id text NOT NULL REFERENCES employees(user_id),
  at timestamptz NOT NULL DEFAULT now(),
  ease integer NOT NULL CHECK (ease BETWEEN 1 AND 7),
  strain integer NOT NULL CHECK (strain BETWEEN 1 AND 7),
  PRIMARY KEY (study_case_id, actor_user_id)
);

CREATE TABLE research_phase_workload (
  study_id text NOT NULL REFERENCES research_auto_collection(study_id),
  actor_user_id text NOT NULL REFERENCES employees(user_id),
  period text NOT NULL CHECK (period IN ('A1','B1','A2','B2')),
  at timestamptz NOT NULL DEFAULT now(),
  ratings integer[] NOT NULL CHECK (cardinality(ratings)=6 AND
    array_position(ratings,NULL) IS NULL AND 0<=ALL(ratings) AND 100>=ALL(ratings)),
  PRIMARY KEY (study_id, actor_user_id, period)
);

ALTER TABLE research_auto_collection ENABLE ROW LEVEL SECURITY;
ALTER TABLE research_participation ENABLE ROW LEVEL SECURITY;
ALTER TABLE research_field_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE research_task_pulse ENABLE ROW LEVEL SECURITY;
ALTER TABLE research_phase_workload ENABLE ROW LEVEL SECURITY;

-- Business audit remains independent. Only eligible actions enter research.
CREATE VIEW research_case_audit WITH (security_invoker = true) AS
  SELECT r.id AS research_case_id,a.id,a.case_id,a.actor_user_id,a.action,a.detail,a.created_at
  FROM research_cases r JOIN audit_events a ON a.case_id=r.case_id AND a.created_at>=r.enrolled_at
  WHERE r.trial_period IS NULL OR EXISTS (
    SELECT 1 FROM research_auto_collection c JOIN research_participation p ON p.study_id=c.study_id
    WHERE c.study_id=r.study_id AND p.user_id=a.actor_user_id AND a.created_at>=p.joined_at
      AND a.created_at<COALESCE(p.left_at,'infinity') AND a.created_at<COALESCE(c.stopped_at,'infinity')
  );
