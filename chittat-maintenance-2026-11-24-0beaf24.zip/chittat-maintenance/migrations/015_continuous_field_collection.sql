-- OBS is routine observation outside the optional A/B schedule. It uses the
-- same consent-filtered audit and telemetry path as the four trial periods.
ALTER TABLE research_cases DROP CONSTRAINT research_cases_trial_period_check;
ALTER TABLE research_cases ADD CONSTRAINT research_cases_trial_period_check
  CHECK (trial_period IN ('OBS','A1','B1','A2','B2'));
