-- One narrowly scoped episode: phone validation -> correction -> business submission.
CREATE TABLE research_recovery_events (
  study_case_id text NOT NULL REFERENCES research_cases(id),
  actor_user_id text NOT NULL REFERENCES employees(user_id),
  id text NOT NULL,
  episode text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('shown','focus','resolved','submitted','rating','skip','left','offline','reconnect')),
  at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  variant text NOT NULL CHECK (variant IN ('A','B','OBS')),
  role text NOT NULL CHECK (role IN ('worker','office')),
  active_ms integer CHECK (active_ms BETWEEN 0 AND 86400000),
  rating integer CHECK (rating BETWEEN 1 AND 7),
  protocol text NOT NULL DEFAULT 'phone-recovery-v1',
  PRIMARY KEY (study_case_id,actor_user_id,id),
  UNIQUE (study_case_id,actor_user_id,episode,kind)
);
CREATE INDEX research_recovery_period ON research_recovery_events(at,study_case_id);
ALTER TABLE research_recovery_events ENABLE ROW LEVEL SECURITY;

CREATE TABLE research_recovery_settings (
 study_id text PRIMARY KEY REFERENCES research_studies(id),
 enabled boolean NOT NULL DEFAULT false,
 updated_by text NOT NULL REFERENCES employees(user_id),
 updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE research_recovery_settings ENABLE ROW LEVEL SECURITY;
