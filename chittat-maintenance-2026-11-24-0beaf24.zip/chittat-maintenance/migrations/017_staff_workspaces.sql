ALTER TABLE employees ADD COLUMN IF NOT EXISTS can_work boolean NOT NULL DEFAULT false;
