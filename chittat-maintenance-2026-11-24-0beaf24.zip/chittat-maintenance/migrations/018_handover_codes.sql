CREATE TABLE research_handover_codes (
  event_id bigint PRIMARY KEY REFERENCES audit_events(id) ON DELETE CASCADE,
  theme text NOT NULL CHECK (theme IN ('missing','interpretation','coordination','other','unknown')),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE research_handover_codes ENABLE ROW LEVEL SECURITY;
CREATE INDEX audit_handover_time ON audit_events(created_at, id)
  WHERE action IN ('submit','review','return','confirm');
