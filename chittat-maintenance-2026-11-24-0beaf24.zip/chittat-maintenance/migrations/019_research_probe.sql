CREATE TABLE research_probe_participation (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  actor_user_id text NOT NULL REFERENCES employees(user_id),
  joined_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  left_at timestamptz,
  CHECK (left_at IS NULL OR left_at >= joined_at)
);

CREATE UNIQUE INDEX research_probe_participation_current
  ON research_probe_participation(actor_user_id) WHERE left_at IS NULL;

CREATE TABLE research_probe_events (
  actor_user_id text NOT NULL REFERENCES employees(user_id),
  id text NOT NULL,
  case_id text NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('worker','office')),
  name text NOT NULL CHECK (name IN ('form.step_leave','form.validation_block','form.field_refill','net.offline',
    'survey.shown','survey.effort','survey.fatigue','survey.skipped')),
  at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  step text,
  field text,
  active_ms integer CHECK (active_ms BETWEEN 1000 AND 600000),
  rating integer CHECK (rating BETWEEN 1 AND 9),
  case_version integer CHECK (case_version > 0),
  PRIMARY KEY (actor_user_id,id)
);

CREATE INDEX research_probe_case_time ON research_probe_events(case_id,at);
CREATE INDEX research_probe_time ON research_probe_events(at);
CREATE INDEX research_probe_actor_received ON research_probe_events(actor_user_id,received_at);
CREATE UNIQUE INDEX research_probe_one_survey_event ON research_probe_events(case_id,actor_user_id,case_version,name)
  WHERE case_version IS NOT NULL;

ALTER TABLE research_probe_participation ENABLE ROW LEVEL SECURITY;
ALTER TABLE research_probe_events ENABLE ROW LEVEL SECURITY;
