CREATE TABLE research_probe_collection (
  singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  enabled_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  mode text NOT NULL DEFAULT 'automatic' CHECK (mode='automatic')
);

INSERT INTO research_probe_collection(singleton) VALUES (true);
ALTER TABLE research_probe_collection ENABLE ROW LEVEL SECURITY;
