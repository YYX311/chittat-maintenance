-- Performance indexes for high-concurrency workspace / ETag / research queries
CREATE INDEX IF NOT EXISTS cases_owner_created_idx ON cases(owner_user_id, created_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS cases_status_updated_idx ON cases(status, updated_at DESC) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS audit_events_case_action_time_idx ON audit_events(case_id, action, created_at DESC);

-- Extend research_probe_events name constraint to accept check-card MRT events
ALTER TABLE research_probe_events DROP CONSTRAINT IF EXISTS research_probe_events_name_check;

ALTER TABLE research_probe_events
  ADD CONSTRAINT research_probe_events_name_check
  CHECK (name IN (
    'form.step_leave','form.validation_block','form.field_refill','net.offline',
    'survey.shown','survey.effort','survey.fatigue','survey.skipped',
    'check.assigned','check.shown','check.go_field','check.confirmed'
  ));

