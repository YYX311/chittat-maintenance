/** @type {import('next').NextConfig} */
const nextConfig = {
  distDir: process.env.LOCAL_RESEARCH_PREVIEW === "1" ? ".next-preview" : process.env.E2E_ISOLATED === "1" ? ".next-e2e" : ".next",
  devIndicators: false,
  allowedDevOrigins: ["127.0.0.1", ...String(process.env.DEV_ALLOWED_ORIGINS || "").split(",").map(value=>{try{return new URL(value.trim()).hostname}catch{return ""}}).filter(Boolean)],
  output: "standalone",
  outputFileTracingIncludes: {
    "/api/research/recovery": ["./docs/recovery-study-supplied.html"],
    "/api/cases/[id]/documents": ["./assets/fonts/**/*"],
    "/api/cases/[id]/preview": ["./assets/fonts/**/*", "./public/brand-logo.png"],
  },
};

export default nextConfig;
