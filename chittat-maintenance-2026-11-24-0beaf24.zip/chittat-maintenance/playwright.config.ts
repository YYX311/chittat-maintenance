import {defineConfig} from "@playwright/test";
if(process.env.E2E_ISOLATED!=="1")throw new Error("Run npm run test:e2e to use the isolated acceptance database.");
export default defineConfig({
 testDir:"./tests/e2e",workers:1,timeout:45000,
 use:{baseURL:process.env.E2E_BASE_URL||"http://localhost:3100",channel:"msedge",headless:true,trace:"retain-on-failure"},
 reporter:[["list"]],
});
