# Run with: Rscript field-study-analysis.R research-tasks-YYYY-MM-DD-YYYY-MM-DD.csv
# install.packages("lme4")
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Supply the trial tasks CSV as the first argument.")
d <- read.csv(args[1], fileEncoding = "UTF-8-BOM", na.strings = c("", "NA"))
d <- subset(d, role == "worker" & submitted == 1 & period %in% c("A1", "B1", "A2", "B2"))
if (!nrow(d)) stop("There are no submitted worker cases in this selection.")
d$condition <- factor(d$phase, levels = c("baseline", "improved"))
d$period_index <- match(d$period, c("A1", "B1", "A2", "B2"))
d$high_demand <- as.integer(d$after_17 == 1 | d$net_issues > 0 | d$difficulty == "high")
# Lack of an event record leaves exposure to software friction unknown.
d$high_demand[is.na(d$friction_score) & d$high_demand == 0] <- NA

cat("Coverage by period; missing values must be reported.\n")
print(with(d, table(period, useNA = "ifany")))
print(with(d, table(period, has_strain = !is.na(strain), has_first_review = !is.na(first_return))))
print(with(d, table(period, assistant_seen = assistant_shown > 0)))
if (!requireNamespace("lme4", quietly = TRUE)) stop("Install lme4 to fit the exploratory models.")

fit <- function(name, formula, data, logistic = FALSE) {
  cat("\n", name, "\n", sep = "")
  sample <- model.frame(lme4::subbars(formula), data, na.action = na.omit)
  data <- droplevels(data[rownames(sample), , drop = FALSE])
  if (nrow(data) < 20L || length(unique(data$participant)) < 3L ||
      length(unique(data$condition)) < 2L || nrow(data) <= length(unique(data$participant)) ||
      (logistic && (length(unique(data$first_return)) < 2L || min(table(data$first_return)) < 5L))) {
    cat("Too few complete or varied records for this template. Report descriptive results.\n")
    return(invisible(NULL))
  }
  cat(nrow(data), "complete records across", length(unique(data$participant)), "participants.\n")
  tryCatch({
    model <- if (logistic) lme4::glmer(formula, data = data, family = binomial()) else lme4::lmer(formula, data = data)
    print(summary(model))
    if (lme4::isSingular(model) || length(model@optinfo$conv$lme4$messages)) {
      cat("Singular or non-convergent fit; no coefficient plot was produced.\n")
      return(invisible(NULL))
    }
    coefficients <- summary(model)$coefficients
    terms <- setdiff(rownames(coefficients), "(Intercept)")
    estimate <- coefficients[terms, "Estimate"]
    se <- coefficients[terms, "Std. Error"]
    bounds <- cbind(estimate - 1.96 * se, estimate + 1.96 * se)
    limits <- range(bounds, 0)
    if (!all(is.finite(limits)) || !all(is.finite(estimate)) || diff(limits) <= 0) {
      cat("Unusable interval estimates; no plot was produced.\n")
      return(invisible(NULL))
    }
    old_par <- par(mar = c(5, 16, 4, 2))
    on.exit(par(old_par), add = TRUE)
    y <- rev(seq_along(terms))
    plot(estimate, y, xlim = limits, yaxt = "n", xaxt = if (logistic) "n" else "s", ylab = "",
         xlab = if (logistic) "Odds ratio (log scale)" else "Coefficient", pch = 19, col = "#A9482B",
         main = name, sub = paste(nrow(data), "records; approximate 95% Wald intervals"))
    if (logistic) {
      ticks <- pretty(limits)
      axis(1, at = ticks, labels = signif(exp(ticks), 3))
    }
    axis(2, at = y, labels = terms, las = 1, cex.axis = 0.72)
    abline(v = 0, lty = 2, col = "#53686E")
    segments(bounds[, 1], y, bounds[, 2], y, col = "#52707B", lwd = 2)
    points(estimate, y, pch = 19, col = "#A9482B")
  }, error = function(e) cat("Model could not be estimated:", conditionMessage(e), "\n"))
}

plot_file <- sub("\\.[Cc][Ss][Vv]$", "", args[1])
plot_file <- paste0(plot_file, "-regression.pdf")
pdf(plot_file, width = 11, height = 7)
timely <- subset(d, pulse_before_review == 1)
fit("X -> M: friction, connection signals and self-reported strain",
    strain ~ condition + log1p(friction_score) + log1p(net_issues) + difficulty + period_index + (1|participant), timely)
fit("Engineering outcome: active screen minutes by assigned condition",
    log1p(active_minutes) ~ condition + difficulty + after_17 + period_index + (1|participant), d)
fit("M -> Y: prior strain and first return",
    first_return ~ condition + strain + difficulty + period_index + (1|participant), timely, logistic = TRUE)
fit("Exploratory interaction: assigned condition and high-demand context",
    first_return ~ condition * high_demand + period_index + (1|participant), d, logistic = TRUE)
dev.off()
cat("Regression plot file (no model pages if all checks failed):", plot_file, "\n")

# These are associations from a scheduled pilot. For a moderation test, use
# pre-intervention context. The bundled high-demand flag includes observations
# made after assignment; treat this interaction as exploratory.
# Do not infer an indirect causal effect by combining the separate fits.
