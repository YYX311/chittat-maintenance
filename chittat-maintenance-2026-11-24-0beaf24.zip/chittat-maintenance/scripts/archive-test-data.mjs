import nextEnv from "@next/env";
import pg from "pg";
import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { archiveCandidates } from "./test-data-selection.mjs";
nextEnv.loadEnvConfig(process.cwd());
const url=new URL(process.env.DATABASE_URL);
if(process.env.NODE_ENV==="production" || !["localhost","127.0.0.1"].includes(url.hostname))throw new Error("Local development database only");
const client=new pg.Client({connectionString:process.env.DATABASE_URL});
await client.connect();
try {
  await client.query("BEGIN");
  const records=(await client.query("SELECT * FROM cases FOR UPDATE")).rows;
  const targets=archiveCandidates(records),ids=targets.map(r=>r.id);
  console.log(JSON.stringify({matched:ids.length,retained:records.length-ids.length,apply:process.argv.includes("--apply")}));
  if(!process.argv.includes("--apply") || !ids.length){await client.query("ROLLBACK");}
  else {
    const backup={cases:targets};
    for(const table of ["case_versions","assets","audit_events"]){
      backup[table]=(await client.query(`SELECT * FROM ${table} WHERE case_id=ANY($1::text[])`,[ids])).rows;
    }
    const directory=resolve(".data","test-data-archives");await mkdir(directory,{recursive:true});
    const file=resolve(directory,new Date().toISOString().replaceAll(":","-")+".json");
    await writeFile(file,JSON.stringify(backup,null,2),{flag:"wx"});
    // Archive only these exact records; retain stored files and all number counters.
    for(const table of ["case_versions","assets","audit_events"]){
      await client.query(`DELETE FROM ${table} WHERE case_id=ANY($1::text[])`,[ids]);
    }
    await client.query("DELETE FROM cases WHERE id=ANY($1::text[])",[ids]);
    await client.query("COMMIT");console.log("Backup: "+file);
  }
} catch(error){await client.query("ROLLBACK");throw error;}
finally {await client.end();}
