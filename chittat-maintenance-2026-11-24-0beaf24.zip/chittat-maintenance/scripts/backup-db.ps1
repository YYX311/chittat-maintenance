param(
  [Parameter(Mandatory = $true)][string]$DatabaseUrl,
  [string]$OutputDirectory = (Join-Path $PSScriptRoot "..\backups")
)
$ErrorActionPreference = "Stop"
$resolvedOutput = [System.IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Force -Path $resolvedOutput | Out-Null
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$target = Join-Path $resolvedOutput "maintenance-$stamp.dump"
& pg_dump --dbname=$DatabaseUrl --format=custom --no-owner --file=$target
if ($LASTEXITCODE -ne 0) { throw "pg_dump failed" }
Write-Output $target
