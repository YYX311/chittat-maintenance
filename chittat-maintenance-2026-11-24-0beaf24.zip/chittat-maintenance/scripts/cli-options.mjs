export function parseOptions(args) {
  const options = {};
  for (let index = 0; index < args.length; index += 1) {
    const argument = args[index];
    const inline = argument.match(/^--([a-z-]+)=(.+)$/);
    if (inline) {
      options[inline[1]] = inline[2];
      continue;
    }
    const name = argument.match(/^--([a-z-]+)$/)?.[1];
    const value = args[index + 1];
    if (!name || !value || value.startsWith("--")) throw new Error(`Invalid argument: ${argument}`);
    options[name] = value;
    index += 1;
  }
  return options;
}
