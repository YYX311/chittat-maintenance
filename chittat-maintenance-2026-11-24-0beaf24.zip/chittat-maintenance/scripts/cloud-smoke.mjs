import assert from "node:assert/strict";
import { writeFileSync, mkdirSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { PDFDocument } from "pdf-lib";

const base = process.env.CLOUD_TEST_URL;
const password = process.env.CLOUD_TEST_PASSWORD;
if (!base || !password) throw new Error("CLOUD_TEST_URL and CLOUD_TEST_PASSWORD required; creates labelled test records");
const run = randomUUID();
const created = { run, cases: [], projects: [], assets: [] };
mkdirSync("tmp", { recursive: true });
const save = () => writeFileSync(`tmp/cloud-smoke-${run}.json`, JSON.stringify(created));
async function login(phoneNumber) {
  const response = await fetch(base + "/api/auth/sign-in/phone-number", {
    method: "POST", headers: { "Content-Type": "application/json", Origin: base },
    body: JSON.stringify({ phoneNumber, password }),
  });
  assert.equal(response.status, 200, "cloud login");
  const token = response.headers.get("set-auth-token");
  assert.ok(token);
  return async (path, method = "GET", body) => {
    const response = await fetch(base + path, { method, headers: {
      Authorization: `Bearer ${token}`, Origin: base, "Content-Type": "application/json",
    }, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await response.text();
    assert.ok(response.ok, `${method} ${path}: ${response.status} ${text.slice(0,200)}`);
    return JSON.parse(text);
  };
}
const [worker, office, workerAgain] = await Promise.all([
  login(process.env.CLOUD_WORKER_PHONE || "+85291234567"),
  login(process.env.CLOUD_OFFICE_PHONE || "+85292345678"),
  login(process.env.CLOUD_WORKER_PHONE || "+85291234567"),
]);
await Promise.all([worker("/api/me"), office("/api/me"), workerAgain("/api/me")]);
console.log("Three simultaneous sessions remain active.");
const project = await office("/api/projects", "POST", {name:`Cloud acceptance ${run}`,code:run.slice(0,8),property:"Test only"});
created.projects.push(project.id); save();
let [record, draft] = await Promise.all([worker("/api/cases", "POST", {
  timeConfirmed:{startedAt:true,completedAt:true},tower:"A",floor:"1",flat:"101",contact:"Test contact",occupant:"Test occupant",customer:`Cloud acceptance ${run}`,address:"Test site",phone:"91234567",notes:"Inspected",
  startedAt:"2026-09-22T09:00",completedAt:"2026-09-22T10:00",items:[{brand:"Test brand",model:"Test model",id:"i",preset:0,qty:1,description:"Inspection"}],
}),office("/api/cases", "POST", {customer:`Cloud acceptance ${run}`,address:"Office test"})]);
created.cases.push(record.id,draft.id); save();
record = await worker(`/api/cases/${record.id}/actions`, "POST", {action:"submit",serverVersion:record.serverVersion});
assert.ok((await office("/api/workspace")).records.some(row=>row.id===record.id && row.status==="submitted"));
record = await office(`/api/cases/${record.id}/actions`, "POST", {action:"return",serverVersion:record.serverVersion,payload:{text:"Check site notes",field:"notes"}});
assert.ok((await worker("/api/workspace")).records.some(row=>row.id===record.id && row.status==="needsInfo"));
record = await worker(`/api/cases/${record.id}`, "PATCH", {serverVersion:record.serverVersion,notes:"Checked site again",addressedFeedbackIds:[record.feedback.at(-1).id]});
record = await worker(`/api/cases/${record.id}/actions`, "POST", {action:"submit",serverVersion:record.serverVersion});
assert.equal(record.feedback.at(-1).resolved,true);
console.log("Office feedback, worker correction and resubmission passed.");
record = await office(`/api/cases/${record.id}`, "PATCH", {serverVersion:record.serverVersion,projectId:project.id,projectCode:project.code,items:[{brand:"Test brand",model:"Test model",id:"i",preset:0,qty:1,price:100,description:"Inspection"}]});
record = await office(`/api/cases/${record.id}/actions`, "POST", {action:"confirm",serverVersion:record.serverVersion});
assert.ok((await office("/api/index?page=1&pageSize=6")).data.some(row=>row.id===record.id));
assert.ok((await worker("/api/workspace")).records.some(row=>row.id===record.id && row.status==="approved"));
console.log("Concurrent creation, submission, confirmation and both-role synchronization passed.");
for (const kind of ["confirmed-service","quotation","invoice"]) {
  const document = await office(`/api/cases/${record.id}/documents`, "POST", {kind});
  created.assets.push(document.assetKey); save();
  // Login again obtains a fresh independent session without displacing the original ones.
  const loginResponse=await fetch(base+"/api/auth/sign-in/phone-number",{method:"POST",headers:{"Content-Type":"application/json",Origin:base},body:JSON.stringify({phoneNumber:process.env.CLOUD_OFFICE_PHONE||"+85292345678",password})});
  const cookie=loginResponse.headers.getSetCookie().map(v=>v.split(";")[0]).join("; ");
  const url=base+"/api/assets/"+encodeURIComponent(document.assetKey);
  const response=await fetch(url,{headers:{Cookie:cookie}});
  assert.equal(response.status,200);
  const bytes=new Uint8Array(await response.arrayBuffer());
  assert.ok(bytes.length>1000);
  assert.ok((await PDFDocument.load(bytes)).getPageCount()>0);
  const denied=await fetch(url);assert.ok([401,403,404].includes(denied.status));
  console.log(`${kind}: valid private PDF, ${bytes.length} bytes; anonymous access denied.`);
}
await Promise.all([worker("/api/me"),office("/api/me"),workerAgain("/api/me")]);
assert.ok((await office("/api/index?page=1&pageSize=6")).data.some(row=>row.id===record.id && row.status==="issued"));
console.log(`Cloud acceptance passed. Test manifest: tmp/cloud-smoke-${run}.json`);
