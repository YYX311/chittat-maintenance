import nextEnv from "@next/env";
nextEnv.loadEnvConfig(process.cwd());

import { mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { PGLiteSocketServer } from "@electric-sql/pglite-socket";

const directory = process.env.PGLITE_DATA_DIR
  ? resolve(process.env.PGLITE_DATA_DIR)
  : fileURLToPath(new URL("../.data/pglite/", import.meta.url));
const port = Number(process.env.PGLITE_PORT || (process.env.DATABASE_URL ? new URL(process.env.DATABASE_URL).port : "") || 5432);
await mkdir(directory, { recursive: true });
const database = new PGlite(directory);
await database.waitReady;
// Both role sessions, Better Auth and the app pool need concurrent connections.
const server = new PGLiteSocketServer({ db: database, port, host: "127.0.0.1", maxConnections: 32 });
await server.start();
process.stdout.write(`Development PostgreSQL-compatible socket ready on 127.0.0.1:${port}\n`);
async function close() {
  await server.stop();
  await database.close();
  process.exit(0);
}
process.on("SIGINT", close);
process.on("SIGTERM", close);
