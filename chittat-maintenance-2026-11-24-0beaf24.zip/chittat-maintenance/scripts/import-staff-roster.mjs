import {randomUUID} from 'node:crypto';
import ExcelJS from 'exceljs';
import pg from 'pg';
import {hashPassword} from 'better-auth/crypto';
import {normalizeLoginPhone} from '../src/phone.js';

const workbook = new ExcelJS.Workbook();
await workbook.xlsx.readFile(process.argv[2]);
const people = new Map();
let role;
workbook.worksheets[0].eachRow(row => {
  const name = String(row.getCell(1).value || '').trim();
  if (name === '編輯報價') { role = 'office'; return; }
  if (name === '師傅名單') { role = 'worker'; return; }
  if (!name || !row.getCell(2).value) return;
  if (!role) throw Error('Missing role heading');
  const digits = String(row.getCell(2).value).replace(/\s/g, '');
  const phone = normalizeLoginPhone(digits);
  const person = people.get(phone) || {name, phone, digits, roles: new Set()};
  if (person.name !== name) throw Error('Conflicting names for one account');
  person.roles.add(role);
  people.set(phone, person);
});
if (!people.size) throw Error('Empty roster');
const client = new pg.Client({connectionString:process.env.DATABASE_URL,connectionTimeoutMillis:15000});
await client.connect();
try {
  await client.query('BEGIN');
  for (const person of people.values()) {
    const existing = await client.query('SELECT id FROM "user" WHERE "phoneNumber"=$1', [person.phone]);
    const id = existing.rows[0]?.id || randomUUID();
    if (existing.rows.length) await client.query('UPDATE "user" SET name=$2 WHERE id=$1',[id,person.name]);
    else await client.query('INSERT INTO "user"(id,name,email,"phoneNumber") VALUES($1,$2,$3,$4)',[id,person.name,id+'@staff.invalid',person.phone]);
    const hash = await hashPassword(person.digits);
    const credential = await client.query('SELECT id FROM account WHERE "userId"=$1 AND "providerId"=$2',[id,'credential']);
    if (credential.rows.length) await client.query('UPDATE account SET password=$2,"updatedAt"=now() WHERE id=$1',[credential.rows[0].id,hash]);
    else await client.query('INSERT INTO account(id,"accountId","providerId","userId",password,"updatedAt") VALUES($1,$2,$3,$2,$4,now())',[randomUUID(),id,'credential',hash]);
    await client.query('INSERT INTO employees(user_id,staff_code,role,can_work) VALUES($1,$2,$3,$4) ON CONFLICT(user_id) DO UPDATE SET role=excluded.role,can_work=excluded.can_work,active=true',[id,person.digits,person.roles.has('office')?'office':'worker',person.roles.size===2]);
  }
  await client.query('COMMIT');
  console.log('Imported',people.size,'accounts');
} catch(error) { await client.query('ROLLBACK'); throw error; }
finally { await client.end(); }
