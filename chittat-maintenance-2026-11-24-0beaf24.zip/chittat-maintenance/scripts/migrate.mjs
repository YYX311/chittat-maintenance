import { readFile, readdir } from "node:fs/promises";
import {migrationHash,matchesMigration} from './migration-checksum.mjs';
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const directory = fileURLToPath(new URL("../migrations/", import.meta.url));
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
try {
  await client.query("SELECT pg_advisory_lock(hashtext('chittat-maintenance-migrations'))");
  await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
    name text PRIMARY KEY, sha256 text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now()
  )`);
  for (const name of (await readdir(directory)).filter((name) => name.endsWith(".sql")).sort()) {
    const sql = await readFile(join(directory, name), "utf8");
    const sha256 = migrationHash(sql);
    const existing = await client.query("SELECT sha256 FROM schema_migrations WHERE name = $1", [name]);
    if (existing.rows.length) {
      if (!matchesMigration(sql,existing.rows[0].sha256)) throw new Error(`Applied migration changed: ${name}`);
      continue;
    }
    await client.query("BEGIN");
    try {
      for (const statement of sql.split(/;\s*(?:\r?\n|$)/).map((part) => part.trim()).filter(Boolean)) {
        await client.query(statement);
      }
      await client.query("INSERT INTO schema_migrations(name, sha256) VALUES ($1, $2)", [name, sha256]);
      await client.query("COMMIT");
      process.stdout.write(`Applied ${name}\n`);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  }
} finally {
  try { await client.query("SELECT pg_advisory_unlock(hashtext('chittat-maintenance-migrations'))"); } catch {}
  await client.end();
}
