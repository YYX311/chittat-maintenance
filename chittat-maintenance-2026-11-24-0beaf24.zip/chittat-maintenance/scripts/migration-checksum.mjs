import {createHash} from 'node:crypto';
export const migrationHash=sql=>createHash('sha256').update(sql).digest('hex');
export function matchesMigration(sql,hash){
  const lf=sql.replace(/\r\n/g,'\n');
  return [sql,lf,lf.replace(/\n/g,'\r\n')].some(value=>migrationHash(value)===hash);
}
