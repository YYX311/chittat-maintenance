import {mkdir,readFile,writeFile,copyFile} from 'node:fs/promises';
import {resolve,dirname,extname,relative} from 'node:path';
import {execFileSync} from 'node:child_process';
const root=process.cwd(),out=resolve(root,'output/frontend-2026-11-05');
await mkdir(out,{recursive:true});
const visited=new Set();
async function copy(path){
 if(visited.has(path))return;visited.add(path);
 const dest=resolve(out,relative(root,path));await mkdir(dirname(dest),{recursive:true});await copyFile(path,dest);
 if(!/\.(jsx?|tsx?)$/.test(path))return;
 const source=await readFile(path,'utf8');
 for(const match of source.matchAll(/(?:from\s*|import\s*\(?\s*)["'](\.[^"']+)["']/g)){
  const base=resolve(dirname(path),match[1]);let found;
  for(const suffix of ['', '.js','.jsx','.ts','.tsx','.json','.css']){try{await readFile(base+suffix);found=base+suffix;break;}catch{}}
  if(!found)throw Error('Unresolved '+match[1]);await copy(found);
 }
}
await copy(resolve(root,'src/main.jsx'));await copy(resolve(root,'app/research/research-panel.tsx'));
await mkdir(resolve(out,'public'),{recursive:true});await copyFile('public/brand-logo.png',resolve(out,'public/brand-logo.png'));
await writeFile(resolve(out,'entry.jsx'),`import React from 'react';import {createRoot} from 'react-dom/client';import Workspace from './src/Workspace.jsx';import Research from './app/research/research-panel.tsx';import './src/styles.css';createRoot(document.getElementById('root')).render(location.pathname.startsWith('/research')?<Research/>:<Workspace/>);`);
await writeFile(resolve(out,'index.html'),'<!doctype html><html lang="zh-HK"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>高陞機電維修</title></head><body><div id="root"></div><script type="module" src="/entry.jsx"></script></body></html>');
await writeFile(resolve(out,'vite.config.mjs'),`import {defineConfig} from 'vite';import react from '@vitejs/plugin-react';const target=process.env.FRONTEND_API_TARGET;const proxy=target?{'/api':{target,changeOrigin:true,headers:{Origin:new URL(target).origin}}}:undefined;export default defineConfig({plugins:[react()],server:{host:'127.0.0.1',proxy},preview:{host:'127.0.0.1',proxy}});`);
const source=JSON.parse(await readFile('package.json','utf8')),dependencies={};
for(const name of ['react','react-dom','opencc-js','exceljs','jszip','@phosphor-icons/react'])dependencies[name]=source.dependencies[name];
await writeFile(resolve(out,'package.json'),JSON.stringify({name:'chittat-frontend-share',version:'1.0.0',private:true,type:'module',scripts:{dev:'vite',build:'vite build',preview:'vite preview'},dependencies,devDependencies:{vite:source.devDependencies.vite,'@vitejs/plugin-react':source.devDependencies['@vitejs/plugin-react']}},null,2));
const commit=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
await writeFile(resolve(out,'README.md'),`# 高陞機電維修前端分享包\n\n日期 2026-11-05；源码版本 ${commit}\n\n包含维修人员、维修部及研究界面，仅前端源码和构建结果。没有数据库、后台 API、密码、密钥、客户记录或上传文件。不是可离线运行的完整系统。研究权限必须由后端验证，隐藏入口不构成权限保护。\n\n## 启动\n安装 Node.js 22.12+，在本目录运行 npm ci，再运行 npm run dev。npm run build 构建；npm run preview 查看构建结果。不要双击 dist/index.html，需 HTTP 服务。\n\n不配置后端时可以查看登录界面，但不能登录和读取业务。开发联调在 PowerShell 设置 $env:FRONTEND_API_TARGET='https://你的获授权后端域名'，再运行 npm run dev。该代理只供本机开发；联调真实服务的操作会写入真实数据。未附任何登录凭证。\n\n正式部署需把 dist 与兼容 /api 后端放在同源域名下。依赖已有身份认证、案件、项目、INDEX、附件、PDF 和研究 API；纯前端托管不能实现这些服务。仅审阅源码无需连接后端。\n\n现有系统：https://chittat-maintenance-test.yjsyyx00.workers.dev/\n\n构建的 JS 是公开客户端代码，研究业务数据不在包内；请确认公司允许外发品牌与业务界面源码。\n`);
console.log('Frontend prepared:',out,'source files:',visited.size);
