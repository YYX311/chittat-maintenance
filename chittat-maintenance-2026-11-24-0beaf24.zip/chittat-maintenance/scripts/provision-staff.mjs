import { randomUUID } from "node:crypto";
import pg from "pg";
import { hashPassword } from "better-auth/crypto";
import { normalizeLoginPhone } from "../src/phone.js";
import { parseOptions } from "./cli-options.mjs";

const options = parseOptions(process.argv.slice(2));
const role = options.role;
const phone = normalizeLoginPhone(options.phone);
const staffCode = options["staff-code"];
const name = options.name;
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
if (!name?.trim() || !staffCode?.trim() || !["worker", "office", "manager"].includes(role)) {
  throw new Error("Required: --phone, --name, --staff-code and --role=worker|office|manager");
}
if (!process.stdin.isTTY) throw new Error("Run interactively to enter the initial password");

function readPassword() {
  return new Promise((resolve, reject) => {
    let value = "";
    process.stdout.write("Initial password (hidden): ");
    process.stdin.setRawMode(true);
    process.stdin.resume();
    const done = (error) => {
      process.stdin.setRawMode(false);
      process.stdin.pause();
      process.stdin.off("data", onData);
      process.stdout.write("\n");
      if (error) reject(error);
      else resolve(value);
    };
    const onData = (chunk) => {
      for (const char of chunk.toString("utf8")) {
        if (char === "\r" || char === "\n") return done();
        if (char === "\u0003") return done(new Error("Cancelled"));
        if (char === "\u007f" || char === "\b") value = value.slice(0, -1);
        else value += char;
      }
    };
    process.stdin.on("data", onData);
  });
}

const password = await readPassword();
if (password.length < 12 || password.length > 128) throw new Error("Password must be 12–128 characters");
const hash = await hashPassword(password);
const userId = randomUUID();
const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();
try {
  await client.query("BEGIN");
  await client.query(`INSERT INTO "user"(id, name, email, "phoneNumber", "phoneNumberVerified")
    VALUES ($1, $2, $3, $4, false)`, [userId, name.trim(), `${userId}@staff.invalid`, phone]);
  await client.query(`INSERT INTO account(id, "accountId", "providerId", "userId", password, "updatedAt")
    VALUES ($1, $2, 'credential', $2, $3, now())`, [randomUUID(), userId, hash]);
  await client.query(`INSERT INTO employees(user_id, staff_code, role)
    VALUES ($1, $2, $3)`, [userId, staffCode.trim(), role]);
  await client.query("COMMIT");
  process.stdout.write(`Provisioned ${staffCode} (${role})\n`);
} catch (error) {
  await client.query("ROLLBACK");
  throw error;
} finally {
  await client.end();
}
