import {readFile,writeFile,mkdir} from 'node:fs/promises';
const source=await readFile('docs/RESEARCH_ADAPTIVE_SOFTWARE.md','utf8');
const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const inline=s=>escape(s).replace(/https:\/\/[^\s<]+/g,url=>`<a href="${url}">${url}</a>`);
const sections=[];let list=false;
const body=source.split(/\r?\n/).map(line=>{
 let prefix='';if(list&&!/^\d+\. /.test(line)){prefix='</ol>';list=false;}
 const heading=/^(#{1,2}) (.*)/.exec(line);
 if(heading){const id=heading[1].length===1?'title':`section-${sections.length}`;if(heading[1].length===2)sections.push({id,title:heading[2]});return `${prefix}<h${heading[1].length} id="${id}">${inline(heading[2])}</h${heading[1].length}>`;}
 if(/^\d+\. /.test(line)){if(!list){prefix+='<ol>';list=true;}return `${prefix}<li>${inline(line.replace(/^\d+\. /,''))}</li>`;}
 return prefix+(line.trim()?`<p>${inline(line)}</p>`:'');
}).join('\n')+(list?'</ol>':'');
await mkdir('output',{recursive:true});
await writeFile('output/研究讨论方案-2026-11-05.html',`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>企业维修软件迭代研究方案</title><style>body{margin:0;background:#eff2f2;color:#243238;font:17px/1.9 system-ui,"Microsoft YaHei",sans-serif}main{max-width:900px;margin:30px auto;padding:48px;background:#fff;border:1px solid #d5dfe0}h1{font-size:30px;line-height:1.4}h2{margin-top:44px;font-size:23px;border-top:1px solid #ccd6da;padding-top:24px}p,li{overflow-wrap:anywhere}nav{padding:20px;background:#f2f5f5}nav a{display:block;font-size:15px}a{color:#225775}button{padding:10px 18px;font:inherit} @media(max-width:600px){main{margin:0;padding:22px}h1{font-size:25px}}@media print{body{background:white;font-size:11pt}main{border:0;margin:0;padding:0;max-width:none}nav,button{display:none}h2{break-after:avoid}p{orphans:3;widows:3}a{color:inherit;text-decoration:none}@page{size:A4;margin:18mm}}</style><main><button onclick="window.print()">打印／另存 PDF</button><nav aria-label="目录">${sections.map(s=>`<a href="#${s.id}">${escape(s.title)}</a>`).join('')}</nav>${body}</main></html>`);
console.log('Created output/研究讨论方案-2026-11-05.html');
