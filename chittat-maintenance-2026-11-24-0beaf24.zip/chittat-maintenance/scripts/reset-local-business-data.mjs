import nextEnv from "@next/env";
import pg from "pg";
import { mkdir, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";

export const BUSINESS_TABLES = ["case_versions", "assets", "audit_events", "cases", "projects", "counters", "object_deletions"];

export async function snapshotBusinessData(client) {
  const backup = {};
  for (const table of BUSINESS_TABLES) backup[table] = (await client.query(`SELECT * FROM ${table}`)).rows;
  return backup;
}

export async function resetBusinessData(client) {
  for (const table of BUSINESS_TABLES) await client.query(`DELETE FROM ${table}`);
}

async function main() {
  nextEnv.loadEnvConfig(process.cwd());
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  const url = new URL(process.env.DATABASE_URL);
  if (process.env.NODE_ENV === "production" || !["localhost", "127.0.0.1"].includes(url.hostname)) {
    throw new Error("Local development database only");
  }
  if (!process.argv.includes("--apply")) throw new Error("Pass --apply to reset local business data");
  const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();
  try {
    await client.query("BEGIN");
    const backup = await snapshotBusinessData(client);
    const directory = resolve(".data", "local-reset-backups");
    await mkdir(directory, { recursive: true });
    const file = resolve(directory, new Date().toISOString().replaceAll(":", "-") + ".json");
    await writeFile(file, JSON.stringify(backup, (_key, value) => typeof value === "bigint" ? value.toString() : value, 2), { flag: "wx" });
    await resetBusinessData(client);
    await client.query("COMMIT");
    console.log(`Local business data reset. Backup: ${file}`);
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    await client.end();
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) await main();
