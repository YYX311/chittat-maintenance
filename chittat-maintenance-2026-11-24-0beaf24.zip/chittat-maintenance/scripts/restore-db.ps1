param(
  [Parameter(Mandatory = $true)][string]$DatabaseUrl,
  [Parameter(Mandatory = $true)][string]$BackupFile
)
$ErrorActionPreference = "Stop"
$source = (Resolve-Path -LiteralPath $BackupFile).Path
& pg_restore --dbname=$DatabaseUrl --clean --if-exists --no-owner --exit-on-error $source
if ($LASTEXITCODE -ne 0) { throw "pg_restore failed" }
