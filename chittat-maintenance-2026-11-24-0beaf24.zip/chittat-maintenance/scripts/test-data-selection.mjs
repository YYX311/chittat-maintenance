export function isAutomatedTestCase(row) {
  const name=String(row.data?.customer||"");
  const created=Date.parse(row.created_at),updated=Date.parse(row.updated_at);
  return /^(?:E2E-|SYNC-\d+$)/.test(name) && Number.isFinite(created) && Number.isFinite(updated)
    && updated>=created;
}
export function archiveCandidates(records) {
  return records.filter(isAutomatedTestCase).sort((a,b)=>Date.parse(b.updated_at)-Date.parse(a.updated_at)).slice(3);
}
