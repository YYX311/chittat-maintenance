// Fresh in-memory database and private files for every acceptance run.
import { PGlite } from "@electric-sql/pglite";
import { PGLiteSocketServer } from "@electric-sql/pglite-socket";
import { hashPassword } from "better-auth/crypto";
import { randomUUID } from "node:crypto";
import { readdir, readFile, mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { createServer } from "node:net";

const preview = process.argv[2] === "--preview";
const webPort = preview ? 3112 : 3100;
const dbPort = preview ? 5552 : 5544;
const baseUrl = `http://localhost:${webPort}`;
const researchPhone = preview ? "+85259849530" : "+85293456789";

// Refuse an occupied test port instead of testing against someone else's service.
await new Promise((resolve,reject)=>{
  const probe=createServer();probe.once("error",reject);
  probe.listen(webPort,"127.0.0.1",()=>probe.close(resolve));
});

const database = new PGlite();
await database.waitReady;
for (const file of (await readdir("migrations")).filter(f=>f.endsWith(".sql")).sort()) {
  await database.exec(await readFile(join("migrations",file),"utf8"));
}
const password = "Acceptance-"+randomUUID();
const hash = await hashPassword(password);
const accounts = [["worker","+85291234567"],["office","+85292345678"],["manager",researchPhone]];
for (const [role,phone] of accounts) {
  const id=randomUUID();
  await database.query('INSERT INTO "user" (id,name,email,"phoneNumber") VALUES ($1,$2,$3,$4)',[id,"驗收 "+role,id+"@staff.invalid",phone]);
  await database.query('INSERT INTO account (id,"accountId","providerId","userId",password,"updatedAt") VALUES ($1,$2,\'credential\',$2,$3,now())',[randomUUID(),id,hash]);
  await database.query('INSERT INTO employees (user_id,staff_code,role) VALUES ($1,$2,$3)',[id,role,role]);
}
const socket = new PGLiteSocketServer({db:database,host:"127.0.0.1",port:dbPort,maxConnections:32});
await socket.start();
const env={...process.env,E2E_ISOLATED:"1",LOCAL_RESEARCH_PREVIEW:preview?"1":"0",E2E_BASE_URL:baseUrl,E2E_PASSWORD:password,
  DATABASE_URL:`postgresql://postgres:postgres@127.0.0.1:${dbPort}/postgres`,DATABASE_POOL_MAX:"1",RESEARCH_ADMIN_PHONE:researchPhone,
  BETTER_AUTH_URL:baseUrl,BETTER_AUTH_SECRET:randomUUID()+randomUUID(),
  OBJECT_STORAGE_MODE:"local",LOCAL_STORAGE_PATH:await mkdtemp(join(tmpdir(),"maintenance-e2e-assets-"))};
const server=spawn(process.execPath,["node_modules/next/dist/bin/next","dev","--port",String(webPort),"--hostname",preview?"127.0.0.1":"0.0.0.0"],{env,stdio:["ignore","pipe","pipe"],windowsHide:true});
let logs="";
server.stdout.on("data",d=>{logs=(logs+d).slice(-10000);});server.stderr.on("data",d=>{logs=(logs+d).slice(-10000);});
try {
  let ready=false;
  for(let attempt=0;attempt<60;attempt++){
    if(server.exitCode!==null)throw new Error("Acceptance server exited");
    try{const response=await fetch(env.E2E_BASE_URL+"/api/health",{signal:AbortSignal.timeout(2000)});if(response.ok){ready=true;break;}}catch{}
    await new Promise(r=>setTimeout(r,500));
  }
  if(!ready)throw new Error("Acceptance server did not become ready");
  console.log(`Using a temporary database at ${baseUrl}.`);
  if (preview) {
    const login = await fetch(baseUrl + "/api/auth/sign-in/phone-number", {
      method: "POST", headers: { Origin: baseUrl, "Content-Type": "application/json" },
      body: JSON.stringify({ phoneNumber: researchPhone, password }),
    });
    const token = login.headers.get("set-auth-token");
    if (!login.ok || !token) throw Error("Preview research login failed");
    const study = await fetch(baseUrl + "/api/research", {
      method: "POST", headers: { Authorization: `Bearer ${token}`, Origin: baseUrl, "Content-Type": "application/json" },
      body: JSON.stringify({ action: "create-preset" }),
    });
    if (!study.ok) throw Error(`Preview research setup failed: ${await study.text()}`);
    console.log(`Preview ready: ${baseUrl}/research`);
    console.log(`Local preview only. Research: ${researchPhone}; Office: +85292345678; Worker: +85291234567`);
    console.log(`Temporary password for all three local accounts: ${password}`);
    await new Promise(resolve => {
      process.once("SIGINT", resolve);
      process.once("SIGTERM", resolve);
      server.once("exit", resolve);
    });
  } else {
    const tests=spawn(process.execPath,["node_modules/@playwright/test/cli.js","test",...process.argv.slice(2)],{env,stdio:"inherit",windowsHide:true});
    process.exitCode=await new Promise((resolve,reject)=>{tests.on("error",reject);tests.on("exit",code=>resolve(code??1));});
  }
}catch(error){console.error(logs);throw error;}
finally{
  if(process.platform==="win32"&&server.pid){
    const stop=spawn("taskkill",["/PID",String(server.pid),"/T","/F"],{stdio:"ignore",windowsHide:true});
    await new Promise(r=>stop.on("exit",r));
  }else server.kill("SIGTERM");
  await socket.stop();await database.close();
}
