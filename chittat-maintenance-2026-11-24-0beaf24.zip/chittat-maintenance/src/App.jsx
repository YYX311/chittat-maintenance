import { useEffect, useRef, useState } from 'react'
import mermaid from 'mermaid'
import {
  ArrowLeft, ArrowRight, Bell, Camera, CaretDown, CaretRight, Check, CheckCircle,
  ClipboardText, Clock, CloudSlash, Cube, Database, DownloadSimple, FileArrowUp,
  FilePdf, Funnel, Gear, House, MagnifyingGlass, MapPin, Package, PencilSimple,
  Plus, Receipt, Rows, ShieldCheck, SignOut, SlidersHorizontal, Table, UploadSimple,
  User, Users, Warning, Wrench, X
} from '@phosphor-icons/react'
import { indexRows, roles, screenGroups, taskData, workItems } from './catalog'
import { locales, tx } from './i18n'

function usePrototypeRoute() {
  const params = new URLSearchParams(location.search)
  const initialRole = params.get('role') || 'worker'
  const initialScreen = params.get('screen') || roles[initialRole]?.home || 'worker-tasks'
  const initialItem = params.get('item') || '检查室外机'
  const requestedLang = params.get('lang') || 'zh-HK'
  const initialLang = locales.some(([value])=>value===requestedLang) ? requestedLang : 'zh-HK'
  const [role, setRoleState] = useState(initialRole)
  const [screen, setScreenState] = useState(initialScreen)
  const [item, setItemState] = useState(initialItem)
  const [lang, setLangState] = useState(initialLang)
  const go = (next, nextRole, extra={}) => {
    const r = nextRole || role
    const nextItem = extra.item || item
    setRoleState(r); setScreenState(next)
    setItemState(nextItem)
    const itemQuery = next==='worker-item-edit' ? `&item=${encodeURIComponent(nextItem)}` : ''
    history.replaceState({}, '', `?role=${r}&screen=${next}&lang=${lang}${itemQuery}`)
    scrollTo({ top:0, behavior:'smooth' })
  }
  const setLang = nextLang => {
    setLangState(nextLang)
    const itemQuery = screen==='worker-item-edit' ? `&item=${encodeURIComponent(item)}` : ''
    history.replaceState({}, '', `?role=${role}&screen=${screen}&lang=${nextLang}${itemQuery}`)
  }
  return { role, screen, item, lang, setLang, go }
}

const Badge=({children,kind='neutral'})=><span className={`badge badge-${kind}`}>{children}</span>
const IconButton=({label,children,onClick})=><button className="icon-button" aria-label={label} onClick={onClick}>{children}</button>
const Button=({children,variant='primary',icon,onClick,type='button',disabled=false})=><button type={type} disabled={disabled} className={`button button-${variant}`} onClick={onClick}>{icon}{children}</button>
function Field({label,value,placeholder,required,wide,type='text',children}) { return <label className={`field ${wide?'field-wide':''}`}><span>{label}{required&&<b>*</b>}</span>{children || <input type={type} defaultValue={value} placeholder={placeholder}/>}</label> }
const SelectField=({label,value,required})=><Field label={label} required={required}><div className="selectlike"><span>{value}</span><CaretDown size={16}/></div></Field>
const Stat=({label,value,hint})=><div className="stat"><span>{label}</span><strong>{value}</strong><small>{hint}</small></div>
function Toast({message,onClose}) { return <div className="toast"><CheckCircle weight="fill"/><span>{message}</span><button onClick={onClose}><X/></button></div> }
function LanguageSwitcher({route,compact=false}) { return <label className={`language-switcher ${compact?'compact':''}`}><span className="sr-only">Language</span><select aria-label="Language" value={route.lang} onChange={e=>route.setLang(e.target.value)}>{locales.map(([value,label])=><option key={value} value={value}>{compact?(value==='zh-HK'?'繁':value==='zh-CN'?'简':'EN'):label}</option>)}</select></label> }

function PrototypeMenu({open,onClose,route}) {
  if(!open)return null
  return <div className="prototype-overlay" onClick={onClose}><aside className="prototype-menu" onClick={e=>e.stopPropagation()}>
    <div className="menu-head"><div><b>全端页面导航</b><span>共 {screenGroups.reduce((n,g)=>n+g.screens.length,0)} 个关键页面／状态</span></div><IconButton label="关闭" onClick={onClose}><X/></IconButton></div>
    {screenGroups.map(group=><section key={group.label}><h4>{group.label}</h4><div className="screen-links">{group.screens.map(([id,label])=><button className={route.screen===id?'active':''} key={id} onClick={()=>{route.go(id,group.role||route.role);onClose()}}><span>{label}</span><CaretRight/></button>)}</div></section>)}
  </aside></div>
}

function Topbar({route}) { return <header className="topbar"><button className="brand" onClick={()=>route.go(roles[route.role].home)}><span className="brand-mark">CT</span><span><b>{tx(route.lang,'维修业务系统')}</b><small>{tx(route.lang,roles[route.role]?.hint)}</small></span></button><div className="top-actions"><LanguageSwitcher route={route}/><div className="role-identity" title={tx(route.lang,'岗位权限由服务器签发，前端不能自行切换')}><ShieldCheck/><span><b>{tx(route.lang,roles[route.role]?.label)}</b><small>{tx(route.lang,roles[route.role]?.scope)}</small></span></div><IconButton label={tx(route.lang,'搜索')} onClick={()=>route.go('global-search')}><MagnifyingGlass/></IconButton><IconButton label={tx(route.lang,'通知')} onClick={()=>route.go('notifications')}><Bell/></IconButton><div className="avatar" title="Account">楊</div></div></header> }

const navByRole={
  office:[['office-inbox','收件箱',ClipboardText],['office-index','INDEX',Table],['office-quote','报价',FilePdf],['office-items','资料库',Database]],
  supervisor:[['supervisor-approvals','审批',CheckCircle],['supervisor-workorders','工单',Wrench],['supervisor-schedule','排期',Clock],['supervisor-exceptions','异常',Warning]],
  warehouse:[['warehouse-stock','库存',Package],['warehouse-reserve','预留',ClipboardText],['warehouse-pick','领退料',Cube],['warehouse-adjust','调整',SlidersHorizontal]],
  finance:[['finance-invoices','发票',Receipt],['finance-payments','收款',ClipboardText],['finance-allocation','核销',CheckCircle],['finance-accounting','会计',Database]],
  admin:[['admin-users','用户',Users],['admin-roles','权限',ShieldCheck],['admin-templates','模板',FilePdf],['admin-operations','运维',Gear]]
}
function DesktopShell({route,children}) { const nav=navByRole[route.role]||navByRole.office; return <div className="app-shell desktop-shell"><Topbar route={route}/><div className="shell-body"><nav className="side-nav">{nav.map(([id,label,Icon])=><button key={id} className={route.screen===id?'active':''} onClick={()=>route.go(id)}><Icon/><span>{tx(route.lang,label)}</span></button>)}<span className="nav-spacer"/><button onClick={()=>route.go('login')}><SignOut/><span>{tx(route.lang,'退出登录')}</span></button></nav><main className="desktop-main">{children}</main></div></div> }
function workerActive(screen){ if(screen==='worker-offline')return 'drafts'; if(screen==='worker-timeline')return 'progress'; if(screen==='worker-profile')return 'profile'; return 'tasks' }
function WorkerShell({route,children,active}) { const selected=active||workerActive(route.screen); return <div className="app-shell worker-shell"><header className="worker-top"><button className="worker-brand" onClick={()=>route.go('worker-tasks')}><span>CT</span><b>{tx(route.lang,'现场助手')}</b></button><div><LanguageSwitcher route={route} compact/><button aria-label={tx(route.lang,'离线草稿')} onClick={()=>route.go('worker-offline')}><CloudSlash/></button><button aria-label={tx(route.lang,'工人通知')} onClick={()=>route.go('worker-notifications')}><Bell/></button></div></header><main className="worker-main">{children}</main><nav className="bottom-nav"><button className={selected==='tasks'?'active':''} onClick={()=>route.go('worker-tasks')}><House/><span>{tx(route.lang,'任务')}</span></button><button className={selected==='drafts'?'active':''} onClick={()=>route.go('worker-offline')}><ClipboardText/><span>{tx(route.lang,'草稿')}</span></button><button className={selected==='progress'?'active':''} onClick={()=>route.go('worker-timeline')}><Clock/><span>{tx(route.lang,'进度')}</span></button><button className={selected==='profile'?'active':''} onClick={()=>route.go('worker-profile')}><User/><span>{tx(route.lang,'我的')}</span></button></nav></div> }

function AuthScreen({screen,route}) {
  const config={login:['登录维修业务系统','同一个网址，系统按账号权限进入唯一工作台'],mfa:['验证身份','请输入验证器或短信中的 6 位验证码'],'forgot-password':['忘记密码','输入账号，我们会发送安全的重设指引'],'reset-sent':['请检查信息','如果账号存在，重设指引已经发送'],'access-denied':['此账号没有访问权限','请联系管理员确认所属岗位与项目范围'],'session-expired':['登录已过期','为保护客户资料，请重新验证身份']}[screen]
  const [loginRole,setLoginRole]=useState(route.role==='office'?'office':'worker')
  const loginAccount=loginRole==='office'?'sammi@chittat.hk':'worker@chittat.hk'
  const mfaButton=route.role==='office'?'验证并进入维修部工作台':'验证并进入工人师傅工作台'
  return <div className="auth-page"><div className="auth-card"><div className="auth-toolbar"><div className="auth-brand"><span>CT</span><b>高陞集团机电维修</b></div><LanguageSwitcher route={route}/></div><h1>{tx(route.lang,config[0])}</h1><p>{tx(route.lang,config[1])}</p>{screen==='login'&&<><div className="connection-status"><CheckCircle weight="fill"/><span><b>{tx(route.lang,'连接正常')}</b><small>{tx(route.lang,'弱网会安全重试，不会跳过身份验证')}</small></span></div><div className="demo-account-panel"><span>{tx(route.lang,'原型演示账号')}</span><div><button className={loginRole==='worker'?'active':''} onClick={()=>setLoginRole('worker')}><User/><b>{tx(route.lang,'工人师傅')}</b><small>{tx(route.lang,'进入现场任务')}</small></button><button className={loginRole==='office'?'active':''} onClick={()=>setLoginRole('office')}><Table/><b>{tx(route.lang,'维修部')}</b><small>{tx(route.lang,'进入办公室工作台')}</small></button></div><small>{tx(route.lang,'正式系统不显示账号选择；系统会根据实际输入的账号权限自动判断。')}</small></div><Field key={`${loginRole}-account`} label={tx(route.lang,'手机号码／电邮')} value={loginAccount}/><Field label={tx(route.lang,'密码')} type="password" value="12345678"/><Button onClick={()=>route.go('mfa',loginRole)}>{tx(route.lang,'登录并验证')}</Button><button className="text-button" onClick={()=>route.go('forgot-password',loginRole)}>{tx(route.lang,'忘记密码')}</button></>}{screen==='forgot-password'&&<><Field label={tx(route.lang,'手机号码／电邮')} value={route.role==='office'?'sammi@chittat.hk':'worker@chittat.hk'}/><Button onClick={()=>route.go('reset-sent')}>发送重设指引</Button><button className="text-button" onClick={()=>route.go('login')}>返回登录</button><div className="info-strip">为避免泄露账号是否存在，系统会统一显示发送结果。</div></>}{screen==='reset-sent'&&<><div className="auth-icon"><CheckCircle/></div><div className="info-strip">链接 15 分钟内有效。弱网时可以再次发送，但系统只保留最后一条有效链接。</div><Button onClick={()=>route.go('login')}>返回登录</Button></>}{screen==='mfa'&&<><div className="otp"><input defaultValue="8"/><input defaultValue="1"/><input/><input/><input/><input/></div><Button onClick={()=>route.go(roles[route.role].home)}>{tx(route.lang,mfaButton)}</Button><button className="text-button">{tx(route.lang,'重新发送（38秒）')}</button><div className="info-strip">{tx(route.lang,'验证码可在弱网下接收；服务器验证失败时保留输入并提示重试。已登录设备离线时，只能继续编辑本机草稿。')}</div></>}{screen==='access-denied'&&<><div className="auth-icon"><ShieldCheck/></div><Button variant="secondary" onClick={()=>route.go('login')}>返回登录</Button></>}{screen==='session-expired'&&<><div className="auth-icon"><Clock/></div><Button onClick={()=>route.go('login')}>重新登录</Button></>}<small className="security-note"><ShieldCheck/> {tx(route.lang,'岗位权限由服务器签发，前端不能自行切换')}</small></div></div>
}

function WorkerTasks({route}) { const [tab,setTab]=useState('今日'); return <WorkerShell route={route}><div className="worker-page-head"><div><small>{route.lang==='en'?'Friday · 04 Sep':'星期五 · 04 Sep'}</small><h1>{tx(route.lang,'早晨，楊师傅')}</h1><p>{tx(route.lang,'今天有 2 个现场任务')}</p></div><div className="sync-ok"><CheckCircle weight="fill"/>{tx(route.lang,'已同步')}</div></div><div className="segmented">{['今日','待补资料','已提交'].map(x=><button key={x} className={tab===x?'active':''} onClick={()=>setTab(x)}>{tx(route.lang,x)}</button>)}</div><div className="task-stack">{taskData.filter(t=>tab==='今日'||(tab==='待补资料'&&t.status==='待补资料')||(tab==='已提交'&&t.status==='办公室处理中')).map((t,i)=><button className={`task-note note-${t.tone}`} key={t.id} onClick={()=>route.go(t.status==='待补资料'?'worker-needs-info':t.status==='办公室处理中'?'worker-timeline':'worker-task-detail')}><div><Badge kind={i===0?'dark':'neutral'}>{tx(route.lang,t.status)}</Badge><small>{t.id}</small></div><h2>{t.title}</h2><p><MapPin/>{t.meta}</p><span className="task-progress">{tx(route.lang,t.status==='处理中'?'资料 1/4 已完成':t.status==='待开始'?'尚未填写':t.status==='待补资料'?'缺少 1 张照片':'查看办公室进度')}<ArrowRight/></span></button>)}</div><Button icon={<Plus/>} onClick={()=>route.go('worker-basic')}>{tx(route.lang,'新增报价资料')}</Button></WorkerShell> }
function MobileBack({title,onBack}) { return <div className="mobile-back"><IconButton label="返回" onClick={onBack}><ArrowLeft/></IconButton><b>{title}</b><span/></div> }
function StepDots({current}) { return <div className="step-dots">{[1,2,3,4].map(n=><span className={n<=current?'active':''} key={n}>{n}</span>)}</div> }
function StepRow({n,label,state,onClick}) { return <button className="step-row" onClick={onClick}><span>{n}</span><b>{label}</b>{state&&<small>{state}</small>}<CaretRight/></button> }
function WorkerTaskDetail({route}) { return <WorkerShell route={route}><MobileBack title={tx(route.lang,'任务详情')} onBack={()=>route.go('worker-tasks')}/><section className="mobile-summary"><Badge kind="dark">{tx(route.lang,'处理中')}</Badge><h1>黄竹坑5期｜空调不制冷</h1><p><MapPin/>黄竹坑5期 Tower 2 / 18F / A室</p><dl><div><dt>{tx(route.lang,'客户')}</dt><dd>物业 · 王太 / 住户 18A</dd></div><div><dt>{tx(route.lang,'联络电话')}</dt><dd>9123 4567</dd></div><div><dt>{tx(route.lang,'到场时间')}</dt><dd>{tx(route.lang,'今日')} 14:30</dd></div></dl></section><p className="step-guidance">{tx(route.lang,'点任一步骤即可查看或修改；底部按钮只负责快速继续当前未完成步骤。')}</p><section className="step-overview"><StepRow n="01" label={tx(route.lang,'基本资料')} state={tx(route.lang,'已完成 · 可修改')} onClick={()=>route.go('worker-basic')}/><StepRow n="02" label={tx(route.lang,'工作内容')} state={tx(route.lang,'进行中')} onClick={()=>route.go('worker-work')}/><StepRow n="03" label={tx(route.lang,'照片与描述')} state={tx(route.lang,'未开始')} onClick={()=>route.go('worker-photo')}/><StepRow n="04" label={tx(route.lang,'确认提交')} state={tx(route.lang,'等待前面完成')} onClick={()=>route.go('worker-review')}/></section><div className="sticky-cta"><Button onClick={()=>route.go('worker-work')}>{tx(route.lang,'继续第 02 步 · 工作内容')}<ArrowRight/></Button></div></WorkerShell> }

function WorkerForm({screen,route}) {
  const map={'worker-basic':[1,'基本资料','填写日期、地点与客户信息'],'worker-work':[2,'工作内容','选择项目并补充数量、型号与价钱'],'worker-photo':[3,'照片与描述','最少上传 1 张现场照片'],'worker-review':[4,'确认提交','办公室可直接整理，无需逐项来回确认']}; const [step,title,desc]=map[screen]
  const newlyAdded = !['检查室外机','清洗室内机连尘网'].includes(route.item)
  return <WorkerShell route={route}><MobileBack title="新报价资料" onBack={()=>route.go(step===1?'worker-tasks':step===2?'worker-basic':step===3?'worker-work':'worker-photo')}/><StepDots current={step}/><div className="form-head"><small>步骤 {step}/4</small><h1>{title}</h1><p>{desc}</p></div>{screen==='worker-basic'&&<div className="mobile-form"><Field label="日期" value="03/09/2026" required/><Field label="地址／单位" value="黄竹坑5期 Tower 2 / 18F / A室" required/><SelectField label="客户类型" value="物业" required/><Field label="物业／业主名称" value="Hero Brave Property Services Limited" required/><Field label="住户信息" value="王太 · 18A"/><Field label="客户联络电话" value="9123 4567" required/><SelectField label="维修负责人" value="楊师傅（当前账号）"/></div>}{screen==='worker-work'&&<div className="line-card-list"><LineCard title="检查室外机" model="—" qty="1" price="HK$ 1,800" onClick={()=>route.go('worker-item-edit')}/><LineCard title="清洗室内机连尘网" model="MXY-18" qty="2" price="待办公室定价" onClick={()=>route.go('worker-item-edit')}/><button className="add-line" onClick={()=>route.go('worker-item-picker')}><Plus/>添加工作项目</button><div className="info-strip">现场价钱可留空，由维修部根据价格库决定。</div></div>}{screen==='worker-photo'&&<div className="photo-step"><button className="camera-cta"><Camera/><b>拍摄现场照片</b><small>照片会自动压缩并保留原图</small></button><div className="photo-grid"><div><Camera/><span>室外机正面</span></div><div><Camera/><span>铭牌型号</span></div><button><Plus/><span>继续添加</span></button></div><Field label="现场描述" wide><textarea defaultValue="检查发现室外机不启动，电制有烧蚀痕迹；建议更换电制后再测试。"/></Field></div>}{screen==='worker-review'&&<div className="review-stack"><ReviewCard title="基本资料" onEdit={()=>route.go('worker-basic')} rows={[['地点','黄竹坑5期 Tower 2 / 18F / A室'],['客户','Hero Brave Property · 王太'],['电话','9123 4567']]}/><ReviewCard title="工作内容" onEdit={()=>route.go('worker-work')} rows={[['检查室外机','1 · HK$1,800'],['清洗室内机连尘网','2 · 待定价']]}/><ReviewCard title="照片与描述" onEdit={()=>route.go('worker-photo')} rows={[['附件','2 张照片'],['描述','已填写']]}/><label className="confirm-check"><input type="checkbox" defaultChecked/><span>以上资料来自现场检查，允许维修部按标准格式整理并定价。</span></label></div>}<div className="sticky-cta"><Button variant="secondary" onClick={()=>route.go('worker-offline')}>保存草稿</Button><Button onClick={()=>route.go(step===1?'worker-work':step===2?'worker-photo':step===3?'worker-review':'worker-success')}>{step===4?'提交资料':'下一步'}<ArrowRight/></Button></div></WorkerShell>
}

function WorkerFormV2({screen,route}) {
  const map={
    'worker-basic':[1,'基本资料','填写日期、地点与客户信息'],
    'worker-work':[2,'工作内容','每个项目都要完成数量、型号及现场说明'],
    'worker-photo':[3,'照片与描述','最少上传 1 张现场照片'],
    'worker-review':[4,'确认提交','办公室可直接整理，无需逐项来回确认']
  }
  const [step,title,desc]=map[screen]
  const newlyAdded=!['检查室外机','清洗室内机连尘网'].includes(route.item)
  const backScreen=step===1?'worker-task-detail':step===2?'worker-task-detail':step===3?'worker-work':'worker-photo'
  const nextScreen=step===1?'worker-work':step===2?'worker-photo':step===3?'worker-review':'worker-success'
  return <WorkerShell route={route}>
    <MobileBack title={tx(route.lang,'新增报价资料')} onBack={()=>route.go(backScreen)}/>
    <StepDots current={step}/>
    <div className="form-head"><small>{tx(route.lang,'步骤')} {step}/4</small><h1>{tx(route.lang,title)}</h1><p>{tx(route.lang,desc)}</p></div>
    {screen==='worker-basic'&&<div className="mobile-form">
      <Field label={tx(route.lang,'日期')} value="04/09/2026" required/>
      <Field label={tx(route.lang,'地址／单位')} value="黄竹坑5期 Tower 2 / 18F / A室" required/>
      <SelectField label={tx(route.lang,'客户类型')} value={tx(route.lang,'物业')} required/>
      <Field label={tx(route.lang,'物业／业主名称')} value="Hero Brave Property Services Limited" required/>
      <Field label={tx(route.lang,'住户信息')} value="王太 · 18A"/>
      <Field label={tx(route.lang,'客户联络电话')} value="9123 4567" required/>
      <SelectField label={tx(route.lang,'维修负责人')} value="楊师傅"/>
    </div>}
    {screen==='worker-work'&&<div className="line-card-list">
      <p className="step-guidance">{tx(route.lang,'点项目卡即可编辑；新增项目会先填写详情，再回到这里汇总。')}</p>
      <LineCard lang={route.lang} title={tx(route.lang,'检查室外机')} model="—" qty="1" price="HK$ 1,800" onClick={()=>route.go('worker-item-edit',undefined,{item:'检查室外机'})}/>
      <LineCard lang={route.lang} title={tx(route.lang,'清洗室内机连尘网')} model="MXY-18" qty="2" price={tx(route.lang,'待办公室定价')} onClick={()=>route.go('worker-item-edit',undefined,{item:'清洗室内机连尘网'})}/>
      {newlyAdded&&<LineCard lang={route.lang} title={tx(route.lang,route.item)} model={tx(route.lang,'未填写')} qty="1" price={tx(route.lang,'待办公室定价')} onClick={()=>route.go('worker-item-edit',undefined,{item:route.item})}/>}
      <button className="add-line" onClick={()=>route.go('worker-item-picker')}><Plus/>{tx(route.lang,'添加工作项目')}</button>
      <div className="info-strip">{tx(route.lang,'现场价钱可留空，由维修部根据价格库决定。')}</div>
    </div>}
    {screen==='worker-photo'&&<div className="photo-step">
      <button className="camera-cta"><Camera/><b>拍摄现场照片</b><small>照片会自动压缩并保留原图</small></button>
      <div className="photo-grid"><div><Camera/><span>室外机正面</span></div><div><Camera/><span>铭牌型号</span></div><button><Plus/><span>继续添加</span></button></div>
      <Field label="现场描述" wide><textarea defaultValue="检查发现室外机不启动，电制有烧蚀痕迹；建议更换电制后再测试。"/></Field>
    </div>}
    {screen==='worker-review'&&<div className="review-stack">
      <ReviewCard title="基本资料" onEdit={()=>route.go('worker-basic')} rows={[["地点","黄竹坑5期 Tower 2 / 18F / A室"],["客户","Hero Brave Property · 王太"],["电话","9123 4567"]]}/>
      <ReviewCard title="工作内容" onEdit={()=>route.go('worker-work')} rows={[["检查室外机","1 · HK$1,800"],["清洗室内机连尘网","2 · 待定价"]]}/>
      <ReviewCard title="照片与描述" onEdit={()=>route.go('worker-photo')} rows={[["附件","2 张照片"],["描述","已填写"]]}/>
      <label className="confirm-check"><input type="checkbox" defaultChecked/><span>以上资料来自现场检查，允许维修部按标准格式整理并定价。</span></label>
    </div>}
    <div className="sticky-cta"><Button variant="secondary" onClick={()=>route.go('worker-offline')}>{tx(route.lang,'保存草稿')}</Button><Button onClick={()=>route.go(nextScreen)}>{tx(route.lang,step===4?'提交资料':'下一步')}<ArrowRight/></Button></div>
  </WorkerShell>
}

function LineCard({title,model,qty,price,onClick,lang='zh-CN'}) { return <button className="line-card" onClick={onClick}><div><b>{title}</b><small>{tx(lang,'型号')}：{model}</small></div><div><span>{tx(lang,'数量')} {qty}</span><strong>{price}</strong></div><PencilSimple/></button> }
function ReviewCard({title,rows,onEdit}) { return <section className="review-card"><header><b>{title}</b><button onClick={onEdit}>编辑</button></header>{rows.map(r=><div key={r[0]}><span>{r[0]}</span><strong>{r[1]}</strong></div>)}</section> }
function WorkerItemPicker({route}) { const [selected,setSelected]=useState(['检查室外机']); return <WorkerShell route={route}><MobileBack title="选择工作项目" onBack={()=>route.go('worker-work')}/><div className="mobile-search"><MagnifyingGlass/><input placeholder="搜索项目名称"/></div><div className="chips"><button className="active">常用</button><button>检查</button><button>更换</button><button>购买</button><button>清洗</button></div><div className="picker-list">{workItems.map(item=><button key={item} className={selected.includes(item)?'selected':''} onClick={()=>setSelected(s=>s.includes(item)?s.filter(x=>x!==item):[...s,item])}><span className="check-box">{selected.includes(item)&&<Check/>}</span><b>{item}</b></button>)}</div><div className="sticky-cta"><Button onClick={()=>route.go('worker-work')}>加入 {selected.length} 个项目</Button></div></WorkerShell> }
function WorkerItemEdit({route}) { return <WorkerShell route={route}><MobileBack title="编辑项目" onBack={()=>route.go('worker-work')}/><div className="form-head"><Badge>工作项目</Badge><h1>检查室外机</h1></div><div className="mobile-form"><Field label="数量" value="1" required/><Field label="型号" placeholder="可扫描或手动输入"/><Field label="现场参考价" value="1800" type="number"/><Field label="说明" wide><textarea defaultValue="室外机不启动，建议办公室确认更换电制报价。"/></Field></div><div className="sticky-cta"><Button variant="danger">删除</Button><Button onClick={()=>route.go('worker-work')}>保存项目</Button></div></WorkerShell> }
const workGroups={常用:['检查室外机','检查室内机','更换室内机','更换室外机'],检查:['检查室外机','检查室内机'],更换:['更换室内机','更换室外机','更换电制','更换控制线','更换保温棉','代购更换室内机电子板','代购更换室外机电子板'],购买:['购买室内机','购买室外机'],清洗:['清洗室内机连尘网','清洗室内机去水喉','清洗室内机去水泵及水盘'],其他:['其他']}
function WorkerItemPickerV2({route}) { const [group,setGroup]=useState('常用'); return <WorkerShell route={route}><MobileBack title={tx(route.lang,'添加工作项目')} onBack={()=>route.go('worker-work')}/><div className="form-head compact"><small>{tx(route.lang,'第一步')}</small><h1>{tx(route.lang,'先选分类，再选一个项目')}</h1><p>{tx(route.lang,'项目数量不多，取消搜索可减少现场输入和误选。')}</p></div><div className="chips category-chips">{Object.keys(workGroups).map(x=><button key={x} className={group===x?'active':''} onClick={()=>setGroup(x)}>{tx(route.lang,x)}</button>)}</div><div className="picker-list single-pick">{workGroups[group].map(item=><button key={item} onClick={()=>route.go('worker-item-edit',undefined,{item})}><b>{tx(route.lang,item)}</b><span>{tx(route.lang,'添加并填写详情')}<CaretRight/></span></button>)}</div><div className="info-strip picker-help">{tx(route.lang,'一次添加一个项目，保存详情后再决定是否继续添加，避免遗漏型号或数量。')}</div></WorkerShell> }
function WorkerItemEditV2({route}) { const title=route.item||'检查室外机'; const existing=['检查室外机','清洗室内机连尘网'].includes(title); return <WorkerShell route={route}><MobileBack title={tx(route.lang,existing?'编辑工作项目':'填写新增项目')} onBack={()=>route.go(existing?'worker-work':'worker-item-picker')}/><div className="form-head"><Badge>{tx(route.lang,existing?'已添加项目':'第二步 · 项目详情')}</Badge><h1>{tx(route.lang,title)}</h1><p>{tx(route.lang,'完成本项目后返回工作内容汇总。')}</p></div><div className="mobile-form"><Field label={tx(route.lang,'数量')} value="1" required/><Field label={tx(route.lang,'型号')} placeholder={tx(route.lang,'手动输入机身铭牌型号；没有可留空')}/><Field label={tx(route.lang,'现场参考价')} value={title==='检查室外机'?'1800':''} placeholder={tx(route.lang,'可留空，由维修部定价')} type="number"/><Field label={tx(route.lang,'说明')} wide><textarea defaultValue={title==='检查室外机'?'室外机不启动，建议办公室确认更换电制报价。':''} placeholder={tx(route.lang,'现场情况、故障位置或特别要求')}/></Field></div><div className="sticky-cta">{existing&&<Button variant="danger">{tx(route.lang,'删除')}</Button>}<Button onClick={()=>route.go('worker-work')}>{tx(route.lang,'保存并返回工作内容')}</Button></div></WorkerShell> }
function WorkerState({screen,route}) { const c={'worker-offline':{icon:<CloudSlash/>,title:'已离线，资料仍可填写',body:'3 项更改保存在本机；恢复网络后自动同步。',action:'返回草稿',next:'worker-basic'},'worker-success':{icon:<CheckCircle/>,title:'资料提交成功',body:'提交编号 CT-MNA26-Q-S-0420。维修部可直接整理、定价及生成报价单。',action:'查看进度',next:'worker-timeline'},'worker-needs-info':{icon:<Camera/>,title:'需要补 1 张铭牌照片',body:'办公室已继续整理其他资料，只需补充可清晰看到型号的照片。',action:'拍照补充',next:'worker-photo'}}[screen]; return <WorkerShell route={route} active={screen==='worker-offline'?'drafts':'tasks'}><MobileBack title={screen==='worker-offline'?'离线草稿':'提交状态'} onBack={()=>route.go('worker-tasks')}/><div className="state-hero"><div>{c.icon}</div><h1>{c.title}</h1><p>{c.body}</p><Button onClick={()=>route.go(c.next)}>{c.action}</Button></div>{screen==='worker-offline'&&<div className="draft-list"><LineCard title="黄竹坑5期｜空调不制冷" model="2 张照片待同步" qty="步骤 3/4" price="刚刚保存" onClick={()=>route.go('worker-photo')}/><LineCard title="启德6554｜室外机检查" model="尚未提交" qty="步骤 1/4" price="昨天保存" onClick={()=>route.go('worker-basic')}/></div>}</WorkerShell> }
function WorkerTimeline({route}) { return <WorkerShell route={route}><MobileBack title="处理进度" onBack={()=>route.go('worker-tasks')}/><div className="timeline-head"><Badge>CT-MNA26-Q-S-0406</Badge><h1>Miami Quay T6-7G</h1><p>办公室处理中</p></div><div className="timeline"><TimelineItem done title="现场资料已提交" time="02 Sep · 17:42"/><TimelineItem done title="维修部已整理" time="03 Sep · 09:18"/><TimelineItem active title="报价单准备中" time="预计今日完成"/><TimelineItem title="发送客户"/></div><div className="info-strip">仅在资料确实缺失时通知你；价格与正式文本由维修部处理。</div></WorkerShell> }
function TimelineItem({done,active,title,time}) { return <div className={`timeline-item ${done?'done':''} ${active?'active':''}`}><span>{done?<Check/>:''}</span><div><b>{title}</b>{time&&<small>{time}</small>}</div></div> }

function WorkerNotifications({route}) { return <WorkerShell route={route} active="tasks"><MobileBack title={tx(route.lang,'我的通知')} onBack={()=>route.go('worker-tasks')}/><div className="notification-scope"><ShieldCheck/><div><b>{tx(route.lang,'只显示与你有关的消息')}</b><p>{tx(route.lang,'自己的任务、补资料要求和提交进度；不会出现办公室审批、库存或财务信息。')}</p></div></div><div className="notification-list mobile-notices"><Notice kind="warning" title="S-0412 需要补铭牌照片" body="请补一张可清晰看到型号的照片。"/><Notice title="S-0406 已由维修部接收" body="资料正在整理，无需再次确认。"/><Notice title="今日任务时间有更新" body="启德6554 调整至今日 16:00。"/></div></WorkerShell> }
function WorkerProfile({route}) { return <WorkerShell route={route} active="profile"><MobileBack title={tx(route.lang,'我的')} onBack={()=>route.go('worker-tasks')}/><section className="profile-card"><div className="profile-avatar">楊</div><div><h1>楊师傅</h1><p>worker@chittat.hk</p><Badge>{tx(route.lang,'工人师傅')}</Badge></div></section><section className="profile-scope"><h3>{tx(route.lang,'我的权限')}</h3><p><ShieldCheck/>{tx(route.lang,'只能查看自己的任务、草稿、通知与提交进度。')}</p><p>{tx(route.lang,'岗位由管理员配置；此账号没有办公室、主管、仓库或财务入口。')}</p></section><section className="profile-actions"><button><span><b>{tx(route.lang,'账号与验证')}</b><small>密码、双重验证、已登录设备</small></span><CaretRight/></button><button><span><b>{tx(route.lang,'使用帮助')}</b><small>联系维修部或报告问题</small></span><CaretRight/></button><button onClick={()=>route.go('login')}><span><b>{tx(route.lang,'退出登录')}</b><small>本机未同步草稿会继续保留</small></span><SignOut/></button></section></WorkerShell> }

function PageHead({eyebrow,title,desc,actions}) { return <div className="page-head"><div><small>{eyebrow}</small><h1>{title}</h1><p>{desc}</p></div><div className="page-actions">{actions}</div></div> }
function Filterbar({placeholder='搜索编号、客户、地址或项目',extras=true}) { return <div className="filterbar"><label><MagnifyingGlass/><input placeholder={placeholder}/></label>{extras&&<><Button variant="secondary" icon={<Funnel/>}>筛选</Button><Button variant="secondary">储存视图</Button></>}</div> }
function DataTable({headers,rows,onRow,selectable=true}) { return <div className="table-wrap"><table><thead><tr>{selectable&&<th><input type="checkbox"/></th>}{headers.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i} onClick={()=>onRow?.(r)}>{selectable&&<td><input type="checkbox" onClick={e=>e.stopPropagation()}/></td>}{r.map((c,j)=><td key={j}>{j===r.length-1?<Badge kind={String(c).includes('已')?'soft':String(c).includes('待')||String(c).includes('警告')?'warning':'neutral'}>{c}</Badge>:c}</td>)}</tr>)}</tbody></table></div> }
function CardHead({title,action}) { return <header className="card-head"><h3>{title}</h3>{action&&<button>{action}<PencilSimple/></button>}</header> }
function Detail({label,value}) { return <div className="detail"><span>{label}</span><b>{value}</b></div> }

function OfficeInbox({route}) { return <DesktopShell route={route}><PageHead eyebrow={tx(route.lang,'工人资料')} title={tx(route.lang,'待整理收件箱')} desc={tx(route.lang,'维修部拥有整理、补全和定价自主权；只在关键资料缺失时退回。')} actions={<><Button variant="secondary" icon={<FileArrowUp/>} onClick={()=>route.go('office-import')}>Excel Import</Button><Button icon={<Plus/>} onClick={()=>route.go('office-new')}>{tx(route.lang,'办公室新建')}</Button></>}/><div className="stats"><Stat label={tx(route.lang,'待整理')} value="8" hint="2 项今日到期"/><Stat label={tx(route.lang,'待签发')} value="5" hint="HK$ 86,400"/><Stat label={tx(route.lang,'待客户决定')} value="12" hint="3 项将到期"/><Stat label={tx(route.lang,'待补资料')} value="2" hint="已减少来回确认"/></div><Filterbar/><div className="split-panel"><DataTable headers={['提交编号','项目／地址','工人','提交时间','完整度','状态']} rows={[["S-0418","黄竹坑5期 · Tower 2 18A","楊师傅","10分钟前","96%",tx(route.lang,'待整理')],["S-0419","启德6554 · 03室","陳师傅","28分钟前","82%",tx(route.lang,'待整理')],["S-0412","御景湾北N1","李师傅","昨天","68%",tx(route.lang,'待补资料')],["S-0406","Miami Quay T6-7G","楊师傅","02 Sep","100%","已整理"]]} onRow={()=>route.go('office-case')}/><aside className="insight-panel"><h3>{tx(route.lang,'处理建议')}</h3><div><Badge kind="dark">{tx(route.lang,'优先')}</Badge><b>S-0418 资料完整</b><p>可直接整理并生成报价草稿。</p></div><div><Badge kind="warning">{tx(route.lang,'缺照片')}</Badge><b>S-0412 铭牌型号不清</b><p>只要求补 1 张照片，其他字段继续处理。</p></div></aside></div></DesktopShell> }
function OfficeIndex({route}) { return <DesktopShell route={route}><PageHead eyebrow="办公室 / INDEX" title="维修报价与业务总表" desc="默认复刻现有 33 列顺序；横向滚动、冻结关键列、批量粘贴。" actions={<><Button variant="secondary" icon={<UploadSimple/>} onClick={()=>route.go('office-import')}>导入 Excel</Button><Button variant="secondary" icon={<DownloadSimple/>}>导出</Button><Button icon={<Plus/>} onClick={()=>route.go('office-new')}>新增</Button></>}/><Filterbar/><div className="index-tabs"><button className="active">全部 128</button><button>工人来源 46</button><button>办公室来源 82</button><button>待处理 13</button></div><div className="wide-table"><DataTable headers={['QUO Ref. No.','来源','Project','客户／住户','工作内容','数量','型号','报价','状态']} rows={indexRows} onRow={()=>route.go('office-case')}/><div className="scroll-hint"><ArrowRight/> 右侧还有 24 列：日期、电话、负责人、Remark、SUM、发票、收款、库存、会计状态…</div></div></DesktopShell> }
function OfficeCase({route}) { return <DesktopShell route={route}><PageHead eyebrow="案件 / CT-MNA26-Q-S-0418" title="黄竹坑5期｜空调不制冷" desc="工人来源 · 维修部整理中 · 最后更新 10:42" actions={<><Button variant="secondary" onClick={()=>route.go('office-inbox')}>返回收件箱</Button><Button onClick={()=>route.go('office-quote')}>建立报价草稿</Button></>}/><div className="case-layout"><div className="case-main"><section className="section-card"><CardHead title="客户与地点"/><div className="detail-grid"><Detail label="日期" value="03/09/2026"/><Detail label="地址／单位" value="黄竹坑5期 Tower 2 / 18F / A室"/><Detail label="客户" value="Hero Brave Property Services Limited"/><Detail label="住户" value="王太 · 18A"/><Detail label="电话" value="9123 4567"/><Detail label="维修负责人" value="楊师傅"/></div></section><section className="section-card"><CardHead title="工作内容" action="编辑项目"/><DataTable selectable={false} headers={['项目','数量','型号','现场参考','办公室报价']} rows={[["检查室外机","1","—","HK$1,800","HK$1,800"],["清洗室内机连尘网","2","MXY-18","—","待定价"]]}/></section><section className="section-card"><CardHead title="照片与描述"/><div className="evidence-row"><div className="evidence"><Camera/><span>室外机正面</span></div><div className="evidence"><Camera/><span>铭牌型号</span></div><p>检查发现室外机不启动，电制有烧蚀痕迹；建议更换电制后再测试。</p></div></section></div><aside className="case-side"><section><h3>资料完整度</h3><div className="score">96%</div><p>可继续整理，不需要退回工人。</p></section><section><h3>编号关系</h3><p><b>提交编号</b><br/>CT-MNA26-Q-S-0418</p><p><b>正式报价编号</b><br/>签发时产生</p></section><section><h3>记录</h3><p>10:42 办公室打开</p><p>10:31 工人提交</p></section></aside></div></DesktopShell> }
function OfficeNew({route}) { return <DesktopShell route={route}><PageHead eyebrow="办公室新建" title="建立报价案件" desc="办公室来源将使用 CT-MNA26-Q-递增数字，不带 S。" actions={<><Button variant="secondary" onClick={()=>route.go('office-index')}>取消</Button><Button onClick={()=>route.go('office-quote')}>保存并编辑报价</Button></>}/><div className="module-form"><section className="section-card"><CardHead title="01 客户与项目"/><div className="form-grid"><Field label="日期" value="03/09/2026" required/><Field label="Project／地址" value="會德豐6563" required/><SelectField label="客户类型" value="物业"/><Field label="客户名称" value="會德豐物業管理有限公司"/><Field label="住户资料" value="謝生 · 15B"/><Field label="联络电话" value="9876 1234"/></div></section><section className="section-card"><CardHead title="02 工作内容" action="从资料库加入"/><DataTable selectable={false} headers={['项目','数量','型号','单价','金额']} rows={[["更换室外机","1","R410A-2HP","HK$9,800","HK$9,800"],["更换保温棉","2","1/2 inch","HK$600","HK$1,200"]]}/><button className="add-row"><Plus/>新增一行</button></section><section className="section-card"><CardHead title="03 Remark 与内部资料"/><div className="form-grid"><Field label="客户报价备注" wide><textarea defaultValue="报价有效期 30 天；不包括第三者责任保险。"/></Field><Field label="内部备注" wide><textarea placeholder="不会显示在客户报价单"/></Field></div></section></div></DesktopShell> }
function OfficePaste({route}) { return <DesktopShell route={route}><PageHead eyebrow="效率工具" title="批量粘贴工作项目" desc="从 Excel 复制多行，系统自动识别项目、数量、型号与价钱。" actions={<Button onClick={()=>route.go('office-quote')}>确认加入 8 行</Button>}/><div className="paste-layout"><section className="section-card"><CardHead title="从 Excel 粘贴"/><textarea className="paste-area" defaultValue={'检查室外机\t1\t\t1800\n更换室外机\t1\tR410A-2HP\t9800\n更换保温棉\t2\t1/2 inch\t600'}/><div className="paste-tips"><span><CheckCircle/>已识别 3 行</span><span><Warning/>第 1 行型号为空（允许）</span></div></section><section className="section-card"><CardHead title="预览与映射"/><DataTable selectable={false} headers={['项目','数量','型号','单价','结果']} rows={[["检查室外机","1","—","1,800","可加入"],["更换室外机","1","R410A-2HP","9,800","可加入"],["更换保温棉","2","1/2 inch","600","可加入"]]}/></section></div></DesktopShell> }
function StepRowDesktop({n,title,state,done,active}) { return <div className={`import-step ${done?'done':''} ${active?'active':''}`}><span>{done?<Check/>:n}</span><div><b>{title}</b><small>{state}</small></div></div> }
function OfficeImport({route}) { return <DesktopShell route={route}><PageHead eyebrow="Excel 迁移" title="导入、映射与冲突处理" desc="Excel 只作为输入输出工具，PostgreSQL 是唯一正式数据源。" actions={<Button onClick={()=>route.go('office-index')}>确认导入 126 行</Button>}/><div className="import-steps"><StepRowDesktop n="1" title="选择文件" state="2026_INDEX_维修單_fixed.xlsx" done/><StepRowDesktop n="2" title="映射字段" state="33/33 已匹配" done/><StepRowDesktop n="3" title="校验数据" state="126 行通过 · 2 行警告" active/><StepRowDesktop n="4" title="冲突处理" state="2 个重复编号待确认"/><StepRowDesktop n="5" title="写入数据库" state="尚未执行"/></div><div className="split-panel"><DataTable headers={['行','QUO Ref. No.','问题','建议处理','状态']} rows={[["46","CT-MNA26-Q-0319","系统已有相同编号","保留系统版本","警告"],["88","—","电话号码格式不一致","自动标准化","警告"],["91","CT-MNA26-Q-0320","通过校验","直接导入","可导入"]]}/><aside className="insight-panel"><h3>保护规则</h3><p>不会覆盖已签发 PDF、财务流水、库存流水或审计记录。</p><p>每次导入都有批次编号，可回滚尚未产生后续业务的新增记录。</p></aside></div></DesktopShell> }

function OfficeQuote({route}) { const [toast,setToast]=useState(''); return <DesktopShell route={route}><PageHead eyebrow="报价草稿 / 新建" title="CT-MNA26-Q-0322" desc="来源：办公室 · 未签发 · 自动保存于 11:18" actions={<><Button variant="secondary" onClick={()=>route.go('office-paste')}>批量粘贴</Button><Button variant="secondary" onClick={()=>route.go('office-pdf')}>预览 PDF</Button><Button onClick={()=>route.go('office-issue')}>签发报价</Button></>}/><div className="quote-layout"><div className="quote-sheet"><section className="quote-meta"><div><Field label="To 客户名称" value="Hero Brave Property Services Limited"/><Field label="Attn 联系人" value="Mr. Frankie Cheong"/><Field label="Project 地点" value="Miami Quay T6-7G 單位"/></div><div><Field label="QUO Ref. No." value="CT-MNA26-Q-0322"/><Field label="From" value="Ms. Sammi Cheng / Ms. Naomi Tong"/><Field label="Date" value="03-Sep-2026"/></div></section><section className="section-card"><CardHead title="Quotation 项目" action="编辑列"/><DataTable selectable={false} headers={['Item','Description','Quantity','Unit Price','Amount']} rows={[["1","检查冷气不制冷及室外机不运作","1 no.","HK$ 1,800","HK$ 1,800"],["2","更换电制并测试","1 no.","HK$ 1,200","HK$ 1,200"]]}/><button className="add-row" onClick={()=>route.go('office-items')}><Plus/>从项目资料库加入</button><div className="quote-total"><span>Total Amount</span><b>HK$ 3,000.00</b></div></section><section className="section-card"><CardHead title="Remark"/><textarea defaultValue={'1. 上述报价不包括第三者责任保险\n2. 报价有效期由发出日起计 30 天\n3. 工程完成后结清所有款项'}/></section></div><aside className="quote-tools"><section><h3>报价工具</h3><button onClick={()=>route.go('office-prices')}><Database/><span><b>历史价格建议</b><small>相似项目 8 条</small></span><CaretRight/></button><button><FilePdf/><span><b>套用 Remark 模板</b><small>标准空调工程</small></span><CaretRight/></button><button onClick={()=>setToast('草稿已保存')}><CheckCircle/><span><b>检查完整度</b><small>通过 12/12</small></span><CaretRight/></button></section><section><h3>金额摘要</h3><Detail label="小计" value="HK$3,000"/><Detail label="折扣" value="HK$0"/><Detail label="总额" value="HK$3,000"/></section></aside></div>{toast&&<Toast message={toast} onClose={()=>setToast('')}/>}</DesktopShell> }
function LibraryPage({type,route}) { const isPrice=type==='price'; return <DesktopShell route={route}><PageHead eyebrow="报价工具" title={isPrice?'历史价格建议':'工作项目资料库'} desc={isPrice?'只提供参考，不自动覆盖本次报价。':'统一项目名称、默认单位与可选字段。'} actions={<><Button variant="secondary">导出</Button><Button icon={<Plus/>}>{isPrice?'新增价格记录':'新增项目'}</Button></>}/><Filterbar placeholder={isPrice?'搜索 Project、项目、型号':'搜索项目名称或分类'}/><DataTable headers={isPrice?['Project','项目','型号','数量','单价','日期','采用']:['分类','项目名称','默认单位','需型号','参考价','状态']} rows={isPrice?[["會德豐6563","更换室外机","R410A-2HP","1","HK$9,800","18 Aug 2026","采用"],["KOKO Hill Parts","更换电子板","P.C.B.-A12","3","HK$2,400","04 Jul 2026","采用"],["Miami Quay","检查室外机","—","1","HK$1,800","02 Jun 2026","采用"]]:[["检查","检查室外机","no.","否","HK$1,800","已启用"],["更换","更换室外机","no.","是","按型号","已启用"],["清洗","清洗室内机连尘网","no.","可选","HK$750","已启用"],["配件","代购更换室外机电子板","pc.","是","按型号","已启用"]]} onRow={()=>isPrice&&route.go('office-quote')}/></DesktopShell> }

function OfficePdf({route}) { return <DesktopShell route={route}><PageHead eyebrow="报价预览" title="CT-MNA26-Q-0322.pdf" desc="A4 版式严格依据现有正式报价单；签发前不会成为正式文件。" actions={<><Button variant="secondary" onClick={()=>route.go('office-quote')}>返回编辑</Button><Button onClick={()=>route.go('office-issue')}>确认并签发</Button></>}/><div className="pdf-stage"><article className="pdf-page"><header><div className="pdf-logo">CT</div><div><h2>捷達機電工程有限公司</h2><span>CHIT TAT ELECTRICAL ENGINEERING LTD.</span></div></header><div className="pdf-meta"><p><span>To</span>Hero Brave Property Services Limited</p><p><span>QUO Ref. No.</span>CT-MNA26-Q-0322</p><p><span>Attn</span>Mr. Frankie Cheong</p><p><span>From</span>Ms. Sammi Cheng / Ms. Naomi Tong</p><p><span>Project</span>Miami Quay T6-7G 單位</p><p><span>Date</span>03-Sep-2026</p></div><h1>Quotation</h1><table><thead><tr><th>Item</th><th>Description</th><th>Quantity</th><th>Unit Price</th><th>Amount</th></tr></thead><tbody><tr><td>1.</td><td>检查冷气不制冷及室外机不运作</td><td>1 no.</td><td>HK$ 1,800</td><td>HK$ 1,800</td></tr><tr><td>2.</td><td>更换电制并测试</td><td>1 no.</td><td>HK$ 1,200</td><td>HK$ 1,200</td></tr></tbody></table><div className="pdf-total">Total Amount：<b>HK$ 3,000.00</b></div><div className="pdf-remark"><b>Remark：</b><p>1. 上述报价不包括第三者责任保险</p><p>2. 报价有效期由发出日起计30天</p><p>3. 工程完成后结清所有款项</p></div><footer><div><span>For and on behalf of</span><b>CHIT TAT ELECTRICAL ENG. LTD.</b><div className="signature-line">Manager</div></div><div><span>Confirmed and Accepted by</span><div className="signature-line">Authorized Signature</div></div></footer></article><aside><Badge kind="soft">版式检查通过</Badge><p>1 页 · A4 · 可打印</p><p>编号、金额与数据库草稿一致</p></aside></div></DesktopShell> }
function OfficeIssue({route}) { return <DesktopShell route={route}><PageHead eyebrow="高风险操作" title="确认签发正式报价单" desc="签发后会冻结这一版内容并生成不可覆盖的 PDF。" actions={<Button variant="secondary" onClick={()=>route.go('office-quote')}>返回编辑</Button>}/><div className="confirm-layout"><section className="confirm-card"><div className="confirm-icon"><FilePdf/></div><h2>CT-MNA26-Q-0322</h2><p>Miami Quay T6-7G · HK$3,000.00</p><div className="confirm-rules"><p><Check/>产生正式报价版本 v1</p><p><Check/>保留签发人、时间与内容快照</p><p><Check/>客户修改时才建立 Rev 1；原版仍可查</p></div><Field label="签发备注" placeholder="选填，只供内部审计"/><label className="confirm-check"><input type="checkbox"/><span>我已核对客户、项目、金额与 Remark。</span></label><Button onClick={()=>route.go('office-send')}>验证身份并签发</Button></section></div></DesktopShell> }
function Version({title,meta,active,muted}) { return <div className={`version ${active?'active':''} ${muted?'muted':''}`}><span>{active?<CheckCircle/>:<Clock/>}</span><div><b>{title}</b><small>{meta}</small></div><Button variant="secondary">查看快照</Button></div> }
function OfficeVersions({route}) { return <DesktopShell route={route}><PageHead eyebrow="版本记录" title="CT-MNA26-Q-0319" desc="日常草稿直接编辑；只有已签发内容被正式修改时才产生 Rev。" actions={<Button onClick={()=>route.go('office-quote')}>从当前版建立修订</Button>}/><div className="version-list"><Version title="当前有效 · Rev 1" meta="07 Aug 2026 · HK$2,100 · Ms. Sammi Cheng" active/><Version title="原签发版 · v1" meta="04 Aug 2026 · HK$1,800 · Ms. Naomi Tong"/><Version title="草稿编辑记录" meta="03–04 Aug · 自动保存 9 次" muted/></div><aside className="version-rule"><h3>什么时候需要 Rev？</h3><p>只用于“已经对外签发”后的正式内容变更，例如客户要求增加工程或修改金额。</p><p>错字在签发前修改、内部备注更新、发送方式变化，都不建立 Rev。</p></aside></DesktopShell> }
function OfficeSend({route}) { return <DesktopShell route={route}><PageHead eyebrow="正式报价已生成" title="CT-MNA26-Q-0322" desc="PDF 已冻结；下一步可发送客户或先下载核对。"/><div className="send-grid"><section className="send-success"><CheckCircle weight="fill"/><h2>签发成功</h2><p>03 Sep 2026 · 11:26 · Ms. Sammi Cheng</p><div><Button icon={<DownloadSimple/>}>下载 PDF</Button><Button variant="secondary" onClick={()=>route.go('office-versions')}>查看版本</Button></div></section><section className="send-options"><h3>发送给客户</h3><Field label="电邮" value="frankie@herobrave.hk"/><Field label="WhatsApp／SMS" value="9123 4567"/><Field label="信息" wide><textarea defaultValue="Frankie 先生您好，附件为 Miami Quay T6-7G 维修报价，请查收。"/></Field><Button>发送报价链接与 PDF</Button></section></div></DesktopShell> }

const pageConfigs={
  supervisor:{
    'supervisor-approvals':['审批队列','只显示超过金额阈值、价格异常或权限要求的报价。',['编号','Project','金额','触发原因','提交人','状态'],[["Q-0325","會德豐6563","HK$48,600","超过 HK$30,000","Sammi","待审批"],["Q-0324","KOKO Hill","HK$12,800","价格偏离 34%","Naomi","待审批"]]],
    'supervisor-workorders':['工单看板','客户接受报价后自动建立工单，信息不重复录入。',['工单','来源报价','Project','负责人','预约','状态'],[["WO-0261","Q-0319","Miami Quay","楊师傅","05 Sep 10:00","待派工"],["WO-0260","Q-0318","启德6554","陳师傅","04 Sep 14:00","进行中"],["WO-0259","Q-0316","黄竹坑5期","李师傅","03 Sep 09:00","已完成"]]],
    'supervisor-schedule':['派工排期','桌面显示时间轴；窄屏自动转换为按日卡片。',['时间','楊师傅','陳师傅','李师傅','未分配'],[["09:00","黄竹坑5期","—","御景湾北N1","WO-0261"],["11:00","—","启德6554","御景湾北N1","—"],["14:00","會德豐6563","KOKO Hill","—","—"]]],
    'supervisor-exceptions':['异常中心','跨报价、工单、库存、财务与系统运行的行动清单。',['等级','对象','异常','负责人','时限','状态'],[["高","INV-0182","付款金额不匹配","财务","30分钟","处理中"],["中","WO-0261","物料不足 1 件","仓库","今日","待处理"],["低","Q-0318","客户 5 日未回应","维修部","明日","待跟进"]]]
  },
  warehouse:{
    'warehouse-stock':['库存列表','按物料、型号、仓位与可用量快速查询。',['物料编号','物料／型号','仓位','账面','预留','可用','状态'],[["AC-PCB-012","室外机电子板 P.C.B.-A12","A-03-02","8","3","5","正常"],["AC-CON-020","电制 20A","B-01-04","3","2","1","低库存"],["INS-050","保温棉 1/2 inch","C-02-01","24","6","18","正常"]]],
    'warehouse-item':['物料台账','每次入库、预留、领料、退料与调整都形成不可覆盖流水。',['时间','业务','关联单据','入','出','结余','操作人'],[["03 Sep 10:18","工单预留","WO-0261","—","2","6","Wing"],["02 Sep 16:40","采购入库","PO-0108","10","—","8","May"],["01 Sep 09:12","工单领料","WO-0257","—","2","-2","Wing"]]],
    'warehouse-reserve':['预留物料','接受报价后按项目建议物料，仓库确认才扣减可用量。',['工单','Project','物料','需求','可用','建议','状态'],[["WO-0261","Miami Quay","电制 20A","1","1","全部预留","待确认"],["WO-0262","會德豐6563","室外机 R410A-2HP","2","1","部分预留","缺货"]]],
    'warehouse-pick':['领料／退料','扫描工单或输入编号，核对后一次提交流水。',['动作','工单','物料','数量','领取人','时间','状态'],[["领料","WO-0260","保温棉 1/2 inch","2","陳师傅","09:10","已完成"],["退料","WO-0258","电制 20A","1","李师傅","昨天","待确认"]]],
    'warehouse-adjust':['库存调整','盘点差异必须填写原因；高价值物料需要主管审批。',['物料','账面','实点','差异','原因','审批','状态'],[["AC-PCB-012","8","7","-1","盘点短缺","主管","待审批"],["INS-050","24","25","+1","上期漏录","免审批","可提交"]]]
  },
  finance:{
    'finance-invoices':['发票列表','工单完成后建立发票草稿，核对后正式签发。',['发票编号','客户','来源工单','金额','到期日','收款','状态'],[["INV-0184","Hero Brave Property","WO-0260","HK$9,800","30 Sep","HK$0","待签发"],["INV-0183","會德豐物業","WO-0259","HK$18,600","28 Sep","HK$8,600","部分收款"],["INV-0182","KOKO Hill","WO-0258","HK$7,200","25 Sep","HK$7,200","已收款"]]],
    'finance-invoice':['发票详情','项目来自已完成工单，可补充付款条款，不重新录入客户资料。',['项目','数量','单价','金额','来源'],[["更换室外机","1","HK$9,800","HK$9,800","WO-0260"],["折扣","—","—","HK$0","—"],["应收总额","—","—","HK$9,800","—"]]],
    'finance-payments':['收款登记','支持银行转账、支票、现金与其他方式，附件作为凭证。',['收款编号','客户','金额','方式','日期','未核销','状态'],[["PAY-0148","會德豐物業","HK$10,000","银行转账","03 Sep","HK$1,400","部分核销"],["PAY-0147","Hero Brave Property","HK$7,200","支票","02 Sep","HK$0","已核销"]]],
    'finance-allocation':['款项核销','一笔收款可分配至多张发票；不能超过未核销金额。',['发票','应收','已收','本次分配','余额','结果'],[["INV-0183","HK$18,600","HK$8,600","HK$1,400","HK$8,600","可核销"],["INV-0181","HK$8,600","HK$0","HK$8,600","HK$0","可核销"]]],
    'finance-accounting':['会计交接','批次发送、失败重试与对账结果可追踪；不依赖 OneDrive。',['批次','期间','发票','收款','系统','结果','状态'],[["ACC-0091","Sep 2026","18","12","Xero/API","17 成功 · 1 失败","需处理"],["ACC-0090","Aug 2026","126","98","Excel 导出","全部成功","已完成"]]]
  },
  admin:{
    'admin-users':['用户管理','账号、所属角色、状态与最近登录。',['姓名','账号','角色','项目范围','MFA','最近登录','状态'],[["楊师傅","worker@chittat.hk","工人","已分配任务","已启用","10:31","已启用"],["Sammi Cheng","sammi@chittat.hk","维修部","全部 Project","已启用","11:26","已启用"],["Wing","wing@chittat.hk","仓库","全部仓位","已启用","10:18","已启用"]]],
    'admin-roles':['角色权限','默认最小权限；高风险动作需 Step-up 验证。',['角色','查看','编辑','签发／审批','财务／库存','用户数','状态'],[["工人","自己的任务","自己的草稿","提交资料","无","18","已启用"],["维修部","报价与客户","报价草稿","签发报价","只读状态","6","已启用"],["主管","全部业务","审批与派工","审批高金额","只读","2","已启用"]]],
    'admin-dictionaries':['项目字典','维护工作项目、默认单位、型号要求与归类。',['编码','分类','项目名称','默认单位','型号','参考价','状态'],[["WI-001","检查","检查室外机","no.","可选","HK$1,800","已启用"],["WI-004","更换","更换室外机","no.","必填","按型号","已启用"]]],
    'admin-templates':['文档模板','报价、发票与工单模板分开版本化；发布后回滚有记录。',['模板','类型','当前版本','更新时间','发布人','适用范围','状态'],[["CT 标准报价单","报价","v12","03 Sep","Sammi","全部","已发布"],["维修工单","工单","v4","22 Aug","Admin","全部","已发布"],["税务发票","发票","v7","18 Aug","Finance","全部","已发布"]]],
    'admin-audit':['审计日志','记录查看敏感资料、编辑、签发、权限与导出。',['时间','人员','动作','对象','IP／设备','结果','风险'],[["11:26","Sammi","签发报价","Q-0322","Office-PC-03","成功","正常"],["11:02","Admin","修改角色","ROLE-OFFICE","Office-PC-01","成功","需复核"],["10:31","楊师傅","提交资料","S-0418","iPhone Safari","成功","正常"]]],
    'admin-security':['安全中心','WAF、MFA、异常登录、备份与漏洞处理概览。',['控制项','当前状态','目标','最近检查','负责人','行动','状态'],[["MFA 覆盖","94%","100%","今日","管理员","2 人待启用","需处理"],["WAF／限流","启用","启用","5 分钟前","运维","无","正常"],["备份恢复演练","通过","季度","30 Aug","运维","下次 30 Nov","正常"]]],
    'admin-operations':['运行监控','可用性、队列、PDF、导入、备份与通知均可观察。',['指标','当前','SLO','趋势','告警','Owner','状态'],[["页面可用性","99.99%","99.9%","稳定","无","DevOps","正常"],["API P95","320ms","<500ms","稳定","无","后端","正常"],["PDF 队列","3","<20","上升","无","Worker","正常"],["会计发送失败","1","0","—","已告警","财务","需处理"]]]
  }
}
function ConfigPage({kind,screen,route}) { const c=pageConfigs[kind][screen]; return <DesktopShell route={route}><PageHead eyebrow={`${roles[kind]?.label||kind}工作台`} title={c[0]} desc={c[1]} actions={<><Button variant="secondary" icon={<Funnel/>}>筛选</Button><Button icon={<Plus/>}>新增／处理</Button></>}/>{['supervisor','finance'].includes(kind)&&<div className="stats"><Stat label="待行动" value="7" hint="2 项高优先"/><Stat label="今日处理" value="12" hint="9 已完成"/><Stat label="本月金额" value="HK$428k" hint="趋势稳定"/></div>}<Filterbar/><DataTable headers={c[2]} rows={c[3]} onRow={()=>kind==='warehouse'&&screen==='warehouse-stock'?route.go('warehouse-item'):kind==='finance'&&screen==='finance-invoices'?route.go('finance-invoice'):kind==='supervisor'&&screen==='supervisor-workorders'?route.go('supervisor-schedule'):null}/></DesktopShell> }

function GlobalPage({screen,route}) { if(screen==='sync-conflict')return <DesktopShell route={route}><PageHead eyebrow="同步保护" title="发现 1 处并发修改" desc="不会静默覆盖；请比较后选择保留内容。"/><div className="diff-layout"><section><Badge>你的版本 · 11:24</Badge><h3>项目说明</h3><p>更换电制并测试室外机。</p><Button variant="secondary">采用这个版本</Button></section><section><Badge kind="warning">Sammi 的版本 · 11:25</Badge><h3>项目说明</h3><p>更换 20A 电制，并完成运行测试。</p><Button>采用这个版本</Button></section></div></DesktopShell>; const isSearch=screen==='global-search'; return <DesktopShell route={route}><PageHead eyebrow="全局" title={isSearch?'搜索':'通知中心'} desc={isSearch?'权限范围内搜索编号、客户、地址、项目、发票与工单。':'只显示需要行动的通知，普通状态更新合并展示。'}/>{isSearch?<><Filterbar extras={false}/><div className="search-groups"><SearchGroup title="报价" items={['CT-MNA26-Q-0319 · Miami Quay T6-7G','CT-MNA26-Q-S-0418 · 黄竹坑5期']}/><SearchGroup title="工单" items={['WO-0261 · 等待派工 · Miami Quay']}/><SearchGroup title="客户" items={['Hero Brave Property Services Limited']}/></div></>:<div className="notification-list"><Notice kind="warning" title="报价 Q-0325 等待审批" body="金额 HK$48,600，超过审批阈值。"/><Notice title="工人资料 S-0418 已提交" body="完整度 96%，可以直接整理。"/><Notice title="库存 AC-CON-020 低于安全量" body="可用 1 件，已有 2 个工单需求。"/></div>}</DesktopShell> }
function SearchGroup({title,items}) { return <section className="search-group"><h3>{title}<span>{items.length}</span></h3>{items.map(i=><button key={i}>{i}<CaretRight/></button>)}</section> }
function Notice({kind='neutral',title,body}) { return <button className="notice"><span className={`notice-dot ${kind}`}/><div><b>{title}</b><p>{body}</p><small>10 分钟前</small></div><CaretRight/></button> }

const diagramSources={
  logic:`flowchart TB
    A([开始：打开同一网址]) --> A1{忘记密码?}
    A1 -->|是| A2[统一结果的重设流程]
    A2 --> A
    A1 -->|否| A3[账号密码 + 风险式 MFA]
    A3 --> A4{网络可验证?}
    A4 -->|否| A5[保留输入并安全重试\n已登录设备仅开放本机草稿]
    A5 --> A4
    A4 -->|是| B{服务器签发岗位权限}
    B -->|工人：只见自己范围| C[今日任务便利贴]
    B -->|维修部：只见维修范围| D[收件箱 / INDEX]
    B -->|其他岗位| AB[进入各自唯一工作台]
    C --> C1[整卡进入任务详情]
    C1 --> C2{选择步骤或快速继续}
    C2 --> E[四步现场资料]
    E --> E1[工作项目：分类直选]
    E1 --> E2[逐项填写详情并回到汇总]
    E2 --> E
    E --> F{网络可用?}
    F -->|否| G[本机草稿\n显示离线状态]
    G --> F
    F -->|是| H{关键字段完整?}
    H -->|否| E
    H -->|是| I[生成 S 提交编号\nCT-MNA26-Q-S-递增数字]
    I --> D
    D --> J{资料是否足够整理?}
    J -->|是| K[维修部自主整理、定价]
    J -->|仅关键资料缺失| L[精确补资料请求]
    L --> C
    D --> M[办公室直接新建]
    M --> N[生成不带 S 正式编号\nCT-MNA26-Q-递增数字]
    K --> O[报价草稿]
    N --> O
    O --> P{签发校验通过?}
    P -->|否| O
    P -->|是| Q[冻结版本 + 生成 PDF]
    Q --> R{客户决定}
    R -->|要求修改| S[建立 Rev n\n保留原签发版]
    S --> O
    R -->|拒绝/过期| T([关闭并保留历史])
    R -->|接受| U[自动建立工单]
    U --> V[库存预留 / 派工]
    V --> W[完工]
    W --> X[发票]
    X --> Y[收款与核销]
    Y --> Z[会计交接]
    Z --> AA([结束：可审计、可查询])`,
  user:`flowchart TB
    subgraph W[工人师傅 · 手机现场]
      W0[登录与验证\n信息：连接/MFA/权限\nTrigger：登录\nFeedback：只进工人工作台]
      W1[任务便利贴\n信息：地点/时间/进度\nTrigger：点整张卡\nFeedback：打开任务详情]
      W2[可点击四步资料\n信息：客户/项目/照片\nTrigger：点步骤或快速继续\nFeedback：自动保存]
      W21[项目分类直选\n信息：分类/预设项目\nTrigger：点一个项目\nFeedback：进入该项目详情]
      W3[确认提交\n信息：摘要/缺失项\nTrigger：提交\nFeedback：S 编号+进度]
      W0 --> W1 --> W2 --> W21 --> W3
      W4[工人通知与我的\n信息：仅本人范围\nTrigger：铃铛/底栏\nFeedback：不跨岗位]
      W1 --> W4
    end
    subgraph O[维修部 · 电脑网页]
      O1[资料收件箱\n信息：完整度/时效/来源\nTrigger：点一行\nFeedback：案件汇总]
      O2[案件整理\n信息：客户/项目/证据\nTrigger：建立报价\nFeedback：预填草稿]
      O3[报价编辑器\n信息：项目/价格/Remark\nTrigger：预览\nFeedback：A4 PDF]
      O4[签发与发送\n信息：冻结规则/渠道\nTrigger：身份验证\nFeedback：正式编号]
      O1 --> O2 --> O3 --> O4
    end
    subgraph S[主管 / 仓库 / 财务]
      S1[工单与审批\nTrigger：报价接受\nFeedback：派工任务]
      S2[库存流水\nTrigger：预留/领退料\nFeedback：可用量更新]
      S3[发票与收款\nTrigger：完工/到账\nFeedback：核销余额]
      S4[会计与审计\nTrigger：批次发送\nFeedback：成功/重试]
      S1 --> S2 --> S3 --> S4
    end
    W3 --> O1
    O4 --> S1`
}
function DiagramScreen({type}) {
  const ref=useRef(null)
  useEffect(()=>{mermaid.initialize({startOnLoad:false,theme:'neutral',securityLevel:'loose',flowchart:{curve:'basis',htmlLabels:true}}); mermaid.render(`ct-${type}`,diagramSources[type]).then(({svg})=>{if(ref.current)ref.current.innerHTML=svg})},[type])
  return <div className="diagram-page"><header><div><small>产品逻辑推导</small><h1>{type==='logic'?'核心功能逻辑判断分支':'跨角色 User Flow'}</h1><p>{type==='logic'?'涵盖身份、权限、弱网、动作、条件与状态':'每个关键节点标明信息层级、Trigger 与 Feedback'}</p></div><Badge>PRD v10 · UX v2</Badge></header><main ref={ref}/></div>
}

export function App() {
  const route=usePrototypeRoute()
  useEffect(()=>{document.documentElement.lang=route.lang},[route.lang])
  if(route.screen==='design-logic')return <DiagramScreen type="logic"/>
  if(route.screen==='design-userflow')return <DiagramScreen type="user"/>
  if(['login','forgot-password','reset-sent','mfa','access-denied','session-expired'].includes(route.screen))return <AuthScreen screen={route.screen} route={route}/>
  const requiredRole=route.screen.startsWith('worker-')?'worker':route.screen.startsWith('office-')?'office':route.screen.startsWith('supervisor-')?'supervisor':route.screen.startsWith('warehouse-')?'warehouse':route.screen.startsWith('finance-')?'finance':route.screen.startsWith('admin-')?'admin':null
  if(requiredRole&&route.role!==requiredRole)return <AuthScreen screen="access-denied" route={route}/>
  if(route.role==='worker'&&['global-search','notifications','sync-conflict'].includes(route.screen))return <AuthScreen screen="access-denied" route={route}/>
  if(['global-search','notifications','sync-conflict'].includes(route.screen))return <GlobalPage screen={route.screen} route={route}/>
  if(route.screen==='worker-tasks')return <WorkerTasks route={route}/>
  if(route.screen==='worker-task-detail')return <WorkerTaskDetail route={route}/>
  if(['worker-basic','worker-work','worker-photo','worker-review'].includes(route.screen))return <WorkerFormV2 screen={route.screen} route={route}/>
  if(route.screen==='worker-item-picker')return <WorkerItemPickerV2 route={route}/>
  if(route.screen==='worker-item-edit')return <WorkerItemEditV2 route={route}/>
  if(['worker-offline','worker-success','worker-needs-info'].includes(route.screen))return <WorkerState screen={route.screen} route={route}/>
  if(route.screen==='worker-timeline')return <WorkerTimeline route={route}/>
  if(route.screen==='worker-notifications')return <WorkerNotifications route={route}/>
  if(route.screen==='worker-profile')return <WorkerProfile route={route}/>
  const office={ 'office-inbox':OfficeInbox,'office-index':OfficeIndex,'office-case':OfficeCase,'office-new':OfficeNew,'office-paste':OfficePaste,'office-import':OfficeImport,'office-quote':OfficeQuote,'office-pdf':OfficePdf,'office-issue':OfficeIssue,'office-versions':OfficeVersions,'office-send':OfficeSend }
  if(office[route.screen]){const C=office[route.screen];return <C route={route}/>}
  if(route.screen==='office-items')return <LibraryPage type="items" route={route}/>
  if(route.screen==='office-prices')return <LibraryPage type="price" route={route}/>
  if(route.screen.startsWith('supervisor-'))return <ConfigPage kind="supervisor" screen={route.screen} route={route}/>
  if(route.screen.startsWith('warehouse-'))return <ConfigPage kind="warehouse" screen={route.screen} route={route}/>
  if(route.screen.startsWith('finance-'))return <ConfigPage kind="finance" screen={route.screen} route={route}/>
  if(route.screen.startsWith('admin-'))return <ConfigPage kind="admin" screen={route.screen} route={route}/>
  return <AuthScreen screen="login" route={route}/>
}
