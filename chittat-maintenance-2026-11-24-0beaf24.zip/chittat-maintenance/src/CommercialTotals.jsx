import React from "react";
import {subtotal, discount, netTotal, validDiscount} from "./commercial-totals.js";

export default function CommercialTotals({record, money}) {
  return <dl className="commercial-totals">
    <dt>Sub Total</dt><dd>{money(subtotal(record))}</dd>
    <dt className="commercial-discount">Less discount :</dt><dd className="commercial-discount">({money(discount(record))})</dd>
    <dt className="commercial-net">Total Net Amount</dt><dd className="commercial-net">{validDiscount(record) ? money(netTotal(record)) : "—"}</dd>
  </dl>;
}
