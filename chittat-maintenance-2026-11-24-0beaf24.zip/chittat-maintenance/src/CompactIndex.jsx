import { MagnifyingGlass } from "@phosphor-icons/react";
import OperationFeedback from "./OperationFeedback";
import {sessionFetch,sessionToken} from "./session-fetch";
import React,{useState,useEffect,useRef} from "react";
import {INDEX_COLUMNS} from "./service-model";
import {total,itemName,today} from "./workspace-model";
import {currentQuotes} from "./office-tools-model";
export const compactRow=(q,n,lang)=>[n+1,q.date,q.ref,q.rev||0,q.tower,q.floor,q.flat,q.address,q.items.map(i=>itemName(i,lang)).join("; "),total(q),q.customer,q.contact];
const pageCache=new Map();
export default function CompactIndex({records,t,lang,open,generate,exportExcel,busy}) {
 const [query,setQuery]=useState(""),[source,setSource]=useState("all"),[ids,setIds]=useState([]),[year,setYear]=useState("");
 const [from,setFrom]=useState(""),[to,setTo]=useState(""),[project,setProject]=useState(""),[reference,setReference]=useState(""),[state,setState]=useState("");
 const all=currentQuotes(records.filter(r=>!r.deletedAt&&r.ref&&(r.approvedSnapshot||["approved","issued"].includes(r.status)))).map(({record,quote})=>({...quote,id:record.id,status:record.status==="issued"?"issued":"approved",pendingRevision:record.status==="revision"}));
 const [page,setPage]=useState(1);
 const [pageSize,setPageSize]=useState(()=>[6,20,50,100].includes(Number(new URLSearchParams(location.search).get("indexPageSize")))?Number(new URLSearchParams(location.search).get("indexPageSize")):6),[result,setResult]=useState(()=>pageCache.get(sessionToken()+":"+JSON.stringify({query:"",source:"all",year:"",from:"",to:"",project:"",reference:"",state:""})+":1:"+([6,20,50,100].includes(Number(new URLSearchParams(location.search).get("indexPageSize")))?Number(new URLSearchParams(location.search).get("indexPageSize")):6))||{data:[],total:0}),[loading,setLoading]=useState(false),[error,setError]=useState("");
 const [selectionRecords,setSelected]=useState([]),[allSelected,setAllSelected]=useState(false);
 const selected=selectionRecords.filter(r=>ids.includes(r.id)).filter(r=>!records.find(current=>current.id===r.id)?.deletedAt).map(r=>all.find(current=>current.id===r.id)||r);
 const filters=JSON.stringify({query,source,year,from,to,project,reference,state});
 const fetchPage=async(number,size=pageSize)=>{
  const response=await sessionFetch("/api/index?"+new URLSearchParams({...JSON.parse(filters),page:number,pageSize:size}),{cache:"no-store"});
  if(!response.ok)throw new Error("index-unavailable");return response.json();
 };
 // Workspace polling changes the array identity even when no task changed.
 // Only invalidate a request when actual record versions change.
 const recordVersions=all.map(r=>r.id+":"+r.rev+":"+r.status+":"+r.pendingRevision).sort().join("|");
 const priorFilters=useRef(filters);
 useEffect(()=>{if(priorFilters.current===filters)return;priorFilters.current=filters;setPage(1);setIds([]);setSelected([]);setAllSelected(false);},[filters]);
 useEffect(()=>{
  let cancelled=false;setError("");
  const key=sessionToken()+":"+filters+":"+page+":"+pageSize;
  const cached=pageCache.get(key);
  if(cached){setResult(cached);if(cached.fingerprint===recordVersions){setLoading(false);return;}}
  setLoading(true);
  const timer=setTimeout(()=>fetchPage(page).then(data=>{if(!cancelled){if(pageCache.size>40)pageCache.delete(pageCache.keys().next().value);pageCache.set(key,{...data,fingerprint:recordVersions});setResult(data);if(data.page!==page)setPage(data.page);}}).catch(()=>{if(!cancelled)setError(t("未能載入 INDEX，請重試。","Could not load INDEX. Please retry."));}).finally(()=>{if(!cancelled)setLoading(false);}),query?200:0);
  return ()=>{cancelled=true;clearTimeout(timer);};
 },[filters,page,pageSize,recordVersions]);
 useEffect(()=>{const q=new URLSearchParams(location.search);q.set("indexPage",page);q.set("indexPageSize",pageSize);history.replaceState(null,"","?"+q);},[page,pageSize]);
 const rows=result.data.filter(q=>!records.find(r=>r.id===q.id)?.deletedAt).map(q=>{const current=records.find(r=>r.id===q.id);return current&&Number(current.rev)===Number(q.rev)?{...q,status:current.status==="issued"?"issued":q.status,pendingRevision:current.status==="revision"}:q;});
 const everyResult=async()=>{const first=await fetchPage(1,100);let output=first.data;for(let n=2;n<=Math.ceil(first.total/100);n++)output.push(...(await fetchPage(n,100)).data);return output;};
 const toggle=async()=>{
  if(allSelected){setIds([]);setSelected([]);setAllSelected(false);return;}
  setLoading(true);try{const all=await everyResult();setSelected(all);setIds(all.map(r=>r.id));setAllSelected(true);}catch{setError(t("未能全選，請重試。","Could not select all. Retry."));}finally{setLoading(false);}
 };
const formatHkd = (n) => new Intl.NumberFormat("en-HK", { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(n || 0));
  return <>
  <OperationFeedback busy={loading&&!rows.length} message={error} important={!!error} t={t}/>
  <div className="ux-heading"><div><small>02 / INDEX</small><h1>INDEX</h1><p>{t("已確認資料集中於此。每份報價只顯示最新確認版本；修改中的內容確認後才會更新。","Confirmed records in one place. Each quotation shows its latest confirmed version; pending edits take effect only after confirmation.")}</p></div><button className="ux-btn" disabled={busy} onClick={async()=>{try{await exportExcel(await everyResult(),year);}catch{setError(t("未能匯出。","Export failed."));}}}>↑ {t("匯出 Excel","Export Excel")}</button></div>
  <div className="ux-filters"><label className="ux-field"><span>{t("搜尋編號、地點、客戶或工作內容","Search reference, location, customer or work")}</span><div className="ux-search-control"><MagnifyingGlass aria-hidden="true" /><input type="search" aria-label={t("搜尋 INDEX","Search INDEX")} value={query} onChange={e=>{setQuery(e.target.value);setIds([])}}/></div></label><label className="ux-field"><span>{t("來源","Source")}</span><select aria-label={t("來源","Source")} value={source} onChange={e=>{setSource(e.target.value);setIds([])}}><option value="all">{t("全部","All")}</option><option value="worker">{t("維修人員","Maintenance personnel")}</option><option value="office">{t("維修部","Office")}</option></select></label><label className="ux-field"><span>{t("年份","Year")}</span><select aria-label={t("年份","Year")} value={year} onChange={e=>{setYear(e.target.value);setIds([])}}><option value="">{t("全部年份","All years")}</option>{[...new Set([today().slice(0,4),...all.map(q=>q.date?.slice(0,4)).filter(Boolean)])].sort().reverse().map(v=><option key={v}>{v}</option>)}</select></label></div>
  <details className="index-filters"><summary>{t("更多篩選：日期、編號、地盤及狀態","More filters: date, reference, project and status")}</summary><div className="ux-fields">
   <label className="ux-field"><span>{t("開始日期","From date")}</span><input type="date" aria-label={t("開始日期","From date")} value={from} max={to||undefined} onChange={e=>{setFrom(e.target.value);setYear("");setIds([])}}/></label>
   <label className="ux-field"><span>{t("結束日期","To date")}</span><input type="date" aria-label={t("結束日期","To date")} value={to} min={from||undefined} onChange={e=>{setTo(e.target.value);setYear("");setIds([])}}/></label>
   <label className="ux-field"><span>{t("服務單／報價／發票編號","Service / quote / invoice number")}</span><input aria-label={t("服務單／報價／發票編號","Service / quote / invoice number")} value={reference} onChange={e=>{setReference(e.target.value);setIds([])}}/></label>
   <label className="ux-field"><span>{t("地盤／項目代碼","Project / code")}</span><select aria-label={t("地盤／項目代碼","Project / code")} value={project} onChange={e=>{setProject(e.target.value);setIds([])}}><option value="">{t("全部地盤","All projects")}</option>{[...new Map(all.filter(q=>q.projectCode).map(q=>[q.projectCode,q])).values()].map(q=><option key={q.projectCode} value={q.projectCode}>{q.projectName||q.address} · {q.projectCode}</option>)}</select></label>
   <label className="ux-field"><span>{t("狀態","Status")}</span><select aria-label={t("狀態","Status")} value={state} onChange={e=>{setState(e.target.value);setIds([])}}><option value="">{t("全部狀態","All statuses")}</option><option value="approved">{t("已確認 · 待生成","Confirmed · Ready to generate")}</option><option value="issued">{t("已簽發","Issued")}</option><option value="revision">{t("修訂版本","Revision")}</option></select></label>
  </div>{from&&to&&from>to&&<p role="alert">{t("結束日期不能早於開始日期。","To date cannot be before From date.")}</p>}<button className="ux-btn" onClick={()=>{setQuery("");setReference("");setSource("all");setState("");setProject("");setFrom("");setTo("");setYear("");setIds([])}}>{t("清除所有篩選","Clear all filters")}</button></details>
  <div className="ux-actions task-bulk-actions"><button className={"ux-btn selection-toggle"+(allSelected?" selected":"")} disabled={!result.total||loading} aria-pressed={allSelected} onClick={toggle}>{allSelected?t("✓ 取消全選","✓ Deselect all"):t("全選搜尋結果","Select all results")}</button><button className="ux-btn primary" disabled={!selected.length||busy||selected.some(r=>r.pendingRevision)} onClick={()=>generate(selected,"both")}>{t("生成服務單、報價單＆發票","Generate quotation & invoice")} ({selected.length})</button></div>
  <p role="status">{t("搜尋結果","Results")}: {result.total} · {t("已選","Selected")}: {selected.length} · {t("本頁報價總額","This page total")}: HK$ {formatHkd(rows.reduce((s,q)=>s+Math.round(total(q)*100),0)/100)}</p>
  {loading&&rows.length>0&&<p role="status">{t("正在更新列表…","Updating list…")}</p>}
  <div className="ux-grid-scroll" aria-busy={loading} tabIndex="0" aria-label={t("INDEX 表格，可向右捲動查看全部 12 欄","INDEX table, scroll right to view all 12 columns")}><table className="ux-grid compact-index"><thead><tr><th>{t("選取","Select")}</th>{INDEX_COLUMNS.map(c=><th key={c}>{c}</th>)}</tr></thead><tbody>{rows.map((q,n)=><tr key={q.id}><td><input type="checkbox" aria-label={t("選取 ","Select ")+q.ref} checked={ids.includes(q.id)} onChange={e=>{setAllSelected(false);setIds(e.target.checked?[...ids,q.id]:ids.filter(id=>id!==q.id));setSelected(e.target.checked?[...selected,q]:selected.filter(r=>r.id!==q.id));}}/></td>{compactRow(q,(page-1)*pageSize+n,lang).map((value,c)=><td key={c} className={c===9?"col-num":[0,1,3,4,5,6].includes(c)?"col-nowrap":""}>{c===2?<><button className="ux-link" onClick={()=>open(q)}>{value}</button><small>{q.invoiceRef||q.ref.replace("-Q-","-I-")}<br/>{q.projectCode||"—"}</small><small className={"ux-status state-"+q.status}>{q.source==="worker"?t("維修人員","Maintenance personnel"):t("維修部","Office")} · {q.pendingRevision?t("修改中（顯示上次確認）","Editing (last confirmed shown)"):q.status==="issued"?t("已簽發","Issued"):t("已確認 · 待生成","Confirmed · Ready to generate")}</small></>:c===3?<span className={q.rev>0?"ux-status state-revision":""}>{q.rev>0?"Rev "+q.rev:String(value)}</span>:c===9?formatHkd(value):String(value??"")}</td>)}</tr>)}</tbody></table></div>
  {error&&<p role="alert">{error}</p>}
  <nav className="index-pagination" aria-label="INDEX pagination"><label>{t("每頁","Per page")} <select aria-label={t("每頁筆數","Rows per page")} value={pageSize} onChange={e=>{setPageSize(Number(e.target.value));setPage(1);}}>{[6,20,50,100].map(n=><option key={n}>{n}</option>)}</select></label><button className="ux-btn" disabled={loading||page<=1} onClick={()=>setPage(page-1)}>{t("上一頁","Previous")}</button><span>{page} / {Math.max(1,Math.ceil(result.total/pageSize))}</span><button className="ux-btn" disabled={loading||page*pageSize>=result.total} onClick={()=>setPage(page+1)}>{t("下一頁","Next")}</button></nav>
  {!loading&&!rows.length&&<p className="ux-empty">{t("沒有符合條件的已確認資料。請先在任務完成覆核，或調整搜尋條件。","No matching confirmed records. Confirm a task or change your filters.")}</p>}
 </>;
}
