import React from "react";
import PdfPreview from "./PdfPreview";
export default function DocumentHistory({record,t}) {
  const versions=[...(record.approvalHistory||[])].sort((a,b)=>b.rev-a.rev);
  return <section className="ux-panel"><h2>{t("歷史版本","Version history")}</h2>
    {versions.map(v=><details key={v.rev} className="document-version"><summary>{record.ref} · Rev {v.rev} · {v.at?.slice(0,10)}</summary>
      {[["confirmed-service","維修服務單","Service order"],["quotation","報價單","Quotation"],["invoice","發票","Invoice"]].map(([kind,hk,en])=><details key={kind}><summary>{t(hk,en)} · PDF</summary><PdfPreview record={record} kind={kind} revision={v.rev} t={t}/></details>)}
    </details>)}
    {!versions.length&&<p>{t("尚未有確認版本。","No confirmed versions yet.")}</p>}
  </section>;
}
