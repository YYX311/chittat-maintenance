import React, { useCallback, useEffect, useRef, useState } from "react";
import { sessionFetch, sessionToken } from "./session-fetch";
import { uid } from "./workspace-model";
import { fieldStudyFields, fieldStudyScreens, phaseWorkloadItems, participantProfile, studyField } from "./field-study-catalog";
import { assistantSuggestions, fieldQueueKey, readFieldQueue, updateFieldQueue } from "./field-study";
import "./field-study.css";

const path="/api/research/field";
const cacheKey=id=>`ct-field-study-config-v1:${id}`;

async function studyRequest(body,caseId) {
  const response=await sessionFetch(caseId?`${path}?case=${encodeURIComponent(caseId)}`:path,body?{
    method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),signal:AbortSignal.timeout(5000),
  }:{signal:AbortSignal.timeout(5000)});
  if (!response.ok) throw Object.assign(Error("research-unavailable"),{status:response.status});
  return response.json();
}

export function useFieldStudy(account,record,screen,officeStep,editable) {
  const user=account?.id;
  const token=user?sessionToken():null;
  const id=record?.localOnly?null:record?.id;
  const [scope,setScope]=useState(null);
  const [pulse,setPulse]=useState(null);
  const config=user&&scope?.user===user?scope:null;
  const key=config?.studyId?fieldQueueKey(user,config.studyId):null;
  const assigned=Boolean(config?.joined&&config.caseId&&config.caseId===id);
  const surface=editable && Object.hasOwn(fieldStudyScreens,screen)?screen:
    editable && ["office-case","office-quote"].includes(screen)?`office-${officeStep}`:null;
  const refreshing=useRef(0);
  const flushing=useRef(false);
  const refresh=useCallback(async()=>{
    if (!user||!token||sessionToken()!==token) return;
    const sequence=++refreshing.current;
    try {
      const next={...await studyRequest(null,id),user};
      if (sequence!==refreshing.current) return;
      setScope(next);
      try {
        const prior=JSON.parse(localStorage.getItem(cacheKey(user))||"null");
        if (prior?.studyId&&(!next.joined||prior.studyId!==next.studyId)) localStorage.removeItem(fieldQueueKey(user,prior.studyId));
        const cachedCases=prior?.studyId===next.studyId?prior.cases||{}:{};
        if (id && next.caseId===id) cachedCases[id]={caseId:id,assignment:next.assignment,assistant:next.assistant,hints:next.hints,pulse:next.pulse};
        if (id && next.caseId!==id) delete cachedCases[id];
        const cases=Object.fromEntries(Object.entries(cachedCases).slice(-24));
        localStorage.setItem(cacheKey(user),JSON.stringify({...next,cases,expires:Date.now()+86400000}));
      } catch {}
    } catch {
      if (sequence!==refreshing.current || navigator.onLine) return;
      try {
        const cached=JSON.parse(localStorage.getItem(cacheKey(user))||"null");
        if (cached?.expires>Date.now()) setScope({...cached,caseId:null,assistant:false,...cached.cases?.[id]});
      } catch {}
    }
  },[id,user,token]);
  useEffect(()=>{
    if (!user) {setScope(null);setPulse(null);return;}
    void refresh();
    const onFocus=()=>{if (document.visibilityState==="visible") void refresh();};
    window.addEventListener("online",refresh);
    document.addEventListener("visibilitychange",onFocus);
    return ()=>{refreshing.current++;window.removeEventListener("online",refresh);document.removeEventListener("visibilitychange",onFocus);};
  },[user,refresh]);
  const flush=useCallback(async()=>{
    if (!key||!config?.joined||!navigator.onLine||flushing.current||!token||sessionToken()!==token) return;
    flushing.current=true;
    try {
      const queue=readFieldQueue(localStorage,key).slice(0,40);
      if (!queue.length) return;
      try { await studyRequest({action:"events",studyId:config.studyId,events:queue}); }
      catch (error) {
        if (![400,403,404].includes(error.status)) return;
      }
      updateFieldQueue(localStorage,key,[],queue.map(e=>e.id));
    } finally {flushing.current=false;}
  },[key,config?.joined,config?.studyId,token]);
  useEffect(()=>{
    if (!key||!config?.joined) return;
    void flush();
    const timer=setInterval(flush,12000);
    window.addEventListener("online",flush);
    window.addEventListener("pagehide",flush);
    return ()=>{clearInterval(timer);window.removeEventListener("online",flush);window.removeEventListener("pagehide",flush);};
  },[key,config?.joined,flush]);

  const track=useCallback((kind,field,durationMs)=>{
    if (!key||!assigned||!surface) return;
    const allowedField=studyField(field);
    if (kind==="field_clear"&&!allowedField) return;
    try {updateFieldQueue(localStorage,key,[{id:uid(),caseId:id,kind,surface,field:allowedField,durationMs,at:Date.now()}]);} catch {}
  },[key,assigned,surface,id]);
  const activeClock=useRef(null);
  useEffect(()=>{
    if (!assigned||!surface) return;
    let last=performance.now(),lastActivity=last,active=0,recentTarget=null,recentClicks=[],reportSlow=false;
    let visible=document.visibilityState==="visible";
    const emptyBefore=new WeakMap();
    const isFormControl=target=>target.matches?.("input:not([type=file]):not([type=password]),textarea")&&
      target.closest(".ux-main,dialog[open]");
    const tick=()=>{
      const now=performance.now();
      if (visible) active+=Math.max(0,Math.min(now,lastActivity+30000)-last);
      last=now;
    };
    const activity=()=>{tick();lastActivity=last;};
    const commitTime=()=>{
      tick();
      if (active>=1000) track("screen_active",null,Math.min(300000,Math.round(active)));
      active=0;
    };
    activeClock.current=commitTime;
    const visibility=()=>{commitTime();visible=document.visibilityState==="visible";if(visible)lastActivity=last;};
    const focus=e=>{
      if (isFormControl(e.target)) emptyBefore.set(e.target,!e.target.value.trim());
    };
    const input=e=>{
      if (!e.target.closest?.(".ux-main,dialog[open]")) return;
      activity();
      if (!isFormControl(e.target)) return;
      const empty=!e.target.value.trim();
      const field=e.target.closest("[data-feedback-target]")?.dataset.feedbackTarget;
      if (empty&&emptyBefore.get(e.target)===false&&field) track("field_clear",field);
      emptyBefore.set(e.target,empty);
    };
    const click=e=>{
      const target=e.target.closest?.("button,input,select,textarea");
      if (!target?.closest(".ux-main,dialog[open]")) return;
      if (!target) return;
      activity();
      if (recentTarget!==target) {recentTarget=target;recentClicks=[];}
      recentClicks=recentClicks.filter(at=>at>performance.now()-1000);
      recentClicks.push(performance.now());
      if (recentClicks.length>=3) {track("rage_click",target.closest("[data-feedback-target]")?.dataset.feedbackTarget);recentClicks=[];}
    };
    const offline=()=>track("offline");
    const online=()=>track("reconnect");
    const slow=e=>{
      if (e.detail!==id||reportSlow) return;
      reportSlow=true;track("slow_network");setTimeout(()=>{reportSlow=false;},5000);
    };
    const timer=setInterval(commitTime,120000);
    document.addEventListener("visibilitychange",visibility);
    document.addEventListener("focusin",focus);
    document.addEventListener("input",input,true);
    document.addEventListener("click",click,true);
    window.addEventListener("offline",offline);
    window.addEventListener("online",online);
    window.addEventListener("pagehide",commitTime);
    window.addEventListener("field-study-slow",slow);
    return ()=>{
      commitTime();activeClock.current=null;clearInterval(timer);
      document.removeEventListener("visibilitychange",visibility);
      document.removeEventListener("focusin",focus);
      document.removeEventListener("input",input,true);
      document.removeEventListener("click",click,true);
      window.removeEventListener("offline",offline);
      window.removeEventListener("online",online);
      window.removeEventListener("pagehide",commitTime);
      window.removeEventListener("field-study-slow",slow);
    };
  },[assigned,surface,id,track]);
  const ask=(caseId)=>{
    if (config?.joined&&config.caseId===caseId&&config.pulse) setPulse({caseId,studyId:config.studyId,user});
  };
  // Keep a prompt alive as the editor returns to its list.
  const prompt=pulse?.studyId===config?.studyId&&pulse?.user===user&&config?.joined?pulse:null;
  return {config,assigned,surface,track,flush,refresh,prompt,ask,
    finishTime:()=>activeClock.current?.(),dismiss:()=>setPulse(null)};
}

export function FieldStudyLayer({study,record,worker,issues,t,onFocus,settings}) {
  const {config,assigned,surface,track,refresh,prompt,dismiss}=study;
  const shown=useRef("");
  const [status,setStatus]=useState("");
  const [busy,setBusy]=useState(false);
  const recoveryScreen=config?.recovery&&["worker-basic","office-0"].includes(surface);
  const suggestions=assigned&&config?.assistant&&surface&&!recoveryScreen?assistantSuggestions(record,worker,issues,config.hints):null;
  const exposure=suggestions?.items.length?`${config.studyId}:${record.id}:${surface}`:"";
  useEffect(()=>{
    if (exposure&&shown.current!==exposure) {shown.current=exposure;track("assistant_shown");}
  },[exposure,track]);
  if (!config?.studyId) return null;
  async function save(body,done) {
    setBusy(true);setStatus("");
    try {
      await studyRequest({studyId:config.studyId,...body});
      done?.();
      await refresh();
      setStatus(t("已儲存。","Saved."));
    } catch { setStatus(t("暫時未能儲存，請重試。","Could not save. Please retry.")); }
    finally { setBusy(false); }
  }
  function submitProfile(event) {
    event.preventDefault();
    const data=new FormData(event.currentTarget);
    void save({action:"profile",tenure:data.get("tenure"),specialty:data.get("specialty"),
      licensed:data.get("licensed")===""?null:data.get("licensed")==="yes",workArea:data.get("work_area")});
  }
  const profile=config.profile||{};
  return <>
    {suggestions&&<section className="field-study-card field-study-hints" aria-label={t("退回風險提示","Return-risk hints")}>
      <div><h2>{t("AI 防錯助手","AI form assistant")}</h2><span>{suggestions.missing>0?t(`尚有 ${suggestions.missing} 項必填資料待核對`,`${suggestions.missing} required checks remain`):
        suggestions.items.length?t("提交前核對","Review before submitting"):t("目前未發現需核對的欄位。","No fields flagged by the current checks.")}</span></div>
      <ul>{suggestions.items.map(issue=><li key={issue.field}><span>{t(issue.hk,issue.en)}</span>
        <button type="button" onClick={()=>{track("assistant_accept",issue.field);onFocus(issue);}}>{t("前往","Go to")} <span className="field-study-sr">{t(fieldStudyFields[studyField(issue.field)],issue.en)}</span><span aria-hidden="true"> →</span></button></li>)}</ul>
    </section>}
    {prompt&&<section className="field-study-card" aria-label={t("這次填寫感受","How did this task feel?")}>
      <h2>{t("這次操作感受如何？","How did this task feel?")}</h2>
      <form className="field-study-form" onSubmit={event=>{
        event.preventDefault();const data=new FormData(event.currentTarget);
        void save({action:"pulse",caseId:prompt.caseId,ease:Number(data.get("ease")),strain:Number(data.get("strain"))},dismiss);
      }}>
        {[["ease",t("操作順手嗎？","How easy was this task?"),t("非常不順手","Very difficult"),t("非常順手","Very easy")],
          ["strain",t("有多心累或煩躁？","How mentally tiring or frustrating?"),t("完全沒有","None"),t("非常強烈","Very high")]].map(([name,label,low,high])=>
          <label key={name}>{label}<select name={name} required defaultValue=""><option value="">{t("請選擇","Select")}</option>
            {[1,2,3,4,5,6,7].map(value=><option key={value} value={value}>{value}{value===1?` · ${low}`:value===7?` · ${high}`:""}</option>)}</select></label>)}
        <button disabled={busy}>{t("送出回報","Send ratings")}</button><button type="button" onClick={dismiss}>{t("略過","Skip")}</button>
      </form>
    </section>}
    {settings&&<section className="field-study-card" aria-label={t("使用體驗研究","Workflow study")}>
      <h2>{t("使用體驗研究","Workflow study")}</h2>
      {config.joined?<><p>{t("已參與。你可以隨時停止新的收集。","You are participating. You can stop new collection at any time.")}</p>
        <button disabled={busy} onClick={()=>void save({action:"leave"})}>{t("停止參與","Stop participating")}</button>
        <form className="field-study-form" key={JSON.stringify(profile)} onSubmit={submitProfile}>
          {Object.entries(participantProfile).map(([name,choices])=><label key={name}>{({tenure:t("年資","Experience"),specialty:t("工種","Specialty"),work_area:t("常駐區域","Work area")})[name]}
            <select name={name} defaultValue={profile[name]??""}><option value="">{t("選填","Optional")}</option>
              {Object.entries(choices).map(([value,label])=><option key={value} value={value}>{t(label,value.replaceAll("_"," "))}</option>)}</select></label>)}
          <label>{t("持牌","Licensed")}<select name="licensed" defaultValue={profile.licensed==null?"":profile.licensed?"yes":"no"}>
            <option value="">{t("選填","Optional")}</option><option value="yes">{t("是","Yes")}</option><option value="no">{t("否","No")}</option></select></label>
          <button disabled={busy}>{t("儲存背景資料","Save optional background")}</button>
        </form>
        {config.workload?.length>0&&<form className="field-study-form" onSubmit={event=>{
          event.preventDefault();const data=new FormData(event.currentTarget);
          void save({action:"workload",period:data.get("period"),ratings:phaseWorkloadItems.map(([name])=>Number(data.get(name)))});
        }}><h3>{t("階段工作負荷 · NASA-TLX 六項評分（選填）","Period workload · six NASA-TLX ratings (optional)")}</h3>
          <label>{t("期別","Period")}<select name="period">{config.workload.map(p=><option key={p}>{p}</option>)}</select></label>
          {phaseWorkloadItems.map(([name,hk,en])=><label key={name}>{t(hk,en)} (0–100)<input name={name} required type="number" min="0" max="100" step="5"/></label>)}
          <button disabled={busy}>{t("儲存階段回報","Save period ratings")}</button>
        </form>}
      </>:<><p>{t("自願參與。系統只記錄案件的操作類型、連線與選填評分，不收集輸入文字、照片或定位。研究員使用代號查看結果。","Participation is optional. The study collects action categories, connectivity and optional ratings, without typed text, photos or location. Researchers see study codes.")}</p>
        <button disabled={busy} onClick={()=>void save({action:"join",agreed:true})}>{t("同意參與研究","Agree to participate")}</button></>}
    </section>}
    {status&&(settings||prompt)&&<p role="status">{status}</p>}
  </>;
}
