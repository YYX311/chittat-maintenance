import React from "react";
import {HEADERS} from "./workspace-model";
export function OfficeLedgerFields({record,update,t,disabled}) {
 const rows=record.ledger.length?record.ledger:[Array(33).fill("")];
 const label=k=>t(({12:"原表標記",13:"簽署日期",14:"發票日期",15:"發票編號",16:"發票版本",17:"分期編號",18:"發票金額",19:"收款日期",20:"收款金額",21:"付款方式",23:"項目代碼",24:"舊報價／發票參考",26:"零件備註"})[k]+" · "+HEADERS[k],k===24?"Previous QUO / INV.":HEADERS[k]);
 const change=(n,k,v)=>update({ledger:rows.map((r,i)=>i===n?Array.from({length:33},(_,j)=>j===k?v:r[j]??""):r)});
 return <section className="ux-panel"><h2>{t("04 跟進、發票及收款（如適用）","04 Follow-up, invoices and receipts (if applicable)")}</h2><p>{t("保留 INDEX 原欄位；尚未開發票可留空，不需虛構日期或金額。報價額不等於分期發票加總。","Original INDEX fields are retained. Leave blank until invoiced; do not invent dates or amounts. Quote value is separate from instalment invoices.")}</p>
 {rows.map((r,n)=><details key={n} open={n===0}><summary>{t("明細行","Detail row")} {n+1} · {r[15]||t("未填發票號碼","No invoice reference")}</summary>
 {[[t("跟進及分類","Follow-up and classification"),[12,13,23,24,26]],[t("發票","Invoice"),[14,15,16,17,18]],[t("收款","Receipt"),[19,20,21]]].map(([name,cols])=><div key={name}><h3>{name}</h3><div className="ux-fields">{cols.map(k=><label className="ux-field" key={k}><span>{label(k)}</span><input aria-label={label(k)+" "+(n+1)} disabled={disabled} type={[13,14,19].includes(k)?"date":[18,20].includes(k)?"number":"text"} min={[18,20].includes(k)?"0":undefined} step={[18,20].includes(k)?".01":undefined} value={r[k]??""} onChange={e=>change(n,k,e.target.value)}/></label>)}</div></div>)}
 <p>{t("未收款（自動）","Outstanding (automatic)")}: HK$ {((r[12]==="X"?0:Number(r[18]||0)-Number(r[20]||0))).toFixed(2)}</p></details>)}
 {!disabled&&<button className="ux-btn" onClick={()=>update({ledger:[...rows,Array(33).fill("")]})}>{t("新增分期／明細行","Add instalment / detail row")}</button>}
 <p>{t("No.、報價編號、Q-rev. 及報價額自動帶入；AB–AG 是原表摘要／日期區，不是逐張必填資料。","No., quote reference, revision and quote amount are automatic. AB–AG are workbook summary/date cells, not mandatory record fields.")}</p></section>;
}
