import React, { useState, useEffect } from "react";
import GroupedSummary from "./GroupedSummary";
import {
  uid,
  makeRecord,
  today,
  total,
  HEADERS,
  toIndexRows,
  SHEETS,
} from "./workspace-model";
import {
  summarize,
  currentQuotes,
  effectiveQuote,
  parseItemPaste,
  parseLedgerPaste,
  projectRows,
} from "./office-tools-model";
const money = (v) =>
  new Intl.NumberFormat("en-HK", { style: "currency", currency: "HKD" }).format(
    Number(v || 0),
  );
const B = ({ children, primary, ...props }) => (
  <button className={"ux-btn" + (primary ? " primary" : "")} {...props}>
    {children}
  </button>
);
const F = ({ label, value, onChange, options, ...props }) => (
  <label className="ux-field">
    <span>{label}</span>
    {options ? (
      <select
        aria-label={label}
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
      >
        {options.map(([v, n]) => (
          <option key={v} value={v}>
            {n}
          </option>
        ))}
      </select>
    ) : (
      <input
        aria-label={label}
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value)}
        {...props}
      />
    )}
  </label>
);
export function OriginalSheet({ db, index, t }) {
  const s = db.sheets.find((s) => s.name.trim() === SHEETS[index].trim());
  if (!s) return null;
  return (
    <details className="ux-panel">
      <summary>
        {t(
          "查看匯入原表（參考快照，不參與即時加總）",
          "View imported source (reference snapshot, excluded from live totals)",
        )}
      </summary>
      <div className="ux-grid-scroll">
        <table className="ux-grid">
          <tbody>
            {s.rows.map((row, r) => (
              <tr key={r}>
                {row.map((v, c) => (
                  <td key={c}>{String(v ?? "")}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </details>
  );
}
export function SummaryView({ db, t, open }) {
  const [blank, setBlank] = useState(false);
  const rows = summarize(db.records, blank);
  return (
    <>
      <GroupedSummary records={db.records} t={t} blank={blank}/>
      <div className="ux-heading">
        <div>
          <h2>{t("即時金額彙總", "Live financial summary")}</h2>
          <p>
            {t(
              "每宗只計目前有效報價一次；未簽發改動及歷史修改版本不重複加總。分期發票及實際收款分開計算。",
              "Count each current issued quote once. Pending changes and historical versions are excluded. Instalment invoices and receipts are totalled separately.",
            )}
          </p>
        </div>
        <label>
          <input
            type="checkbox"
            checked={blank}
            onChange={(e) => setBlank(e.target.checked)}
          />
          {t(
            "只限 X 空白（原範例篩選）",
            "X blank only (original sample filter)",
          )}
        </label>
      </div>
      <div className="ux-grid-scroll">
        <table className="ux-grid">
          <thead>
            <tr>
              {[
                "QUO ref. no.",
                "QUO. Amount",
                "INV. Amount",
                "Received Amount",
                "Outstanding Amount",
                t("提示", "Checks"),
              ].map((h) => (
                <th key={h}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td>
                  <button className="ux-link" onClick={() => open(r.record)}>
                    {r.ref}
                  </button>
                </td>
                {["quote", "invoice", "received", "outstanding"].map((k) => (
                  <td key={k}>{money(r[k])}</td>
                ))}
                <td>
                  {r.invoice > r.quote
                    ? t(
                        "發票高於報價，請核對分期或變更",
                        "Invoices exceed quote; check instalments or scope",
                      )
                    : r.outstanding < 0
                      ? t(
                          "收款高於發票，請核對",
                          "Receipts exceed invoices; check entries",
                        )
                      : t("—", "—")}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <th>{t("總計", "Total")}</th>
              {["quote", "invoice", "received", "outstanding"].map((k) => (
                <th key={k}>{money(rows.reduce((s, r) => s + r[k], 0))}</th>
              ))}
              <th>
                {rows.length} {t("宗", "cases")}
              </th>
            </tr>
          </tfoot>
        </table>
      </div>
      <OriginalSheet db={db} index={4} t={t} />
    </>
  );
}
export function LedgerView({ db, commit, t, onDirty }) {
  const [draft, setDraft] = useState(() => structuredClone(db.records)),
    [selected, setSelected] = useState([]),
    [query, setQuery] = useState(""),
    [msg, setMsg] = useState(""),
    [paste, setPaste] = useState(""),
    [showPaste, setShowPaste] = useState(false);
  useEffect(() => setDraft(structuredClone(db.records)), [db.records]);
  useEffect(() => {
    onDirty(
      JSON.stringify(draft.map((r) => r.ledger)) !==
        JSON.stringify(db.records.map((r) => r.ledger)),
    );
  }, [draft, db.records, onDirty]);
  useEffect(() => () => onDirty(false), [onDirty]);
  const records = currentQuotes(draft)
    .map((v) => v.record)
    .filter((r) =>
      [r.ref, r.address, r.customer]
        .join(" ")
        .toLowerCase()
        .includes(query.toLowerCase()),
    );
  const parsed = parseLedgerPaste(paste, draft);
  const change = (id, i, c, value) =>
    setDraft((prev) =>
      prev.map((r) =>
        r.id !== id
          ? r
          : {
              ...r,
              ledger: r.ledger.map((row, n) =>
                n !== i ? row : row.map((v, k) => (k === c ? value : v)),
              ),
            },
      ),
    );
  const add = () => {
    if (!selected.length) {
      setMsg(
        t(
          "請先選擇至少一宗已簽發報價。",
          "Select at least one issued quotation first.",
        ),
      );
      return;
    }
    setDraft((prev) =>
      prev.map((r) => {
        if (!selected.includes(r.id)) return r;
        const row = Array(33).fill("");
        Object.assign(row, {
          14: today(),
          18: total(effectiveQuote(r)),
          17: r.ledger.filter((v) => v[15] || v[18]).length + 1,
        });
        return { ...r, ledger: [...r.ledger, row] };
      }),
    );
    setMsg(
      t(
        "已按報價金額預填新行。請核對金額、填寫發票編號後儲存；此時尚未計入正式彙總。",
        "New rows prefilled from quote totals. Check amounts and enter invoice references, then save. They are not included in totals yet.",
      ),
    );
  };
  const save = () => {
    const seen = new Set();
    for (const r of draft) {
      for (const row of r.ledger) {
        if (!row[15] && !row[18]) continue;
        const date = String(row[14] || "");
        if (
          !row[15] ||
          !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
          !Number.isFinite(Number(row[18])) ||
          Number(row[18]) < 0 ||
          !Number.isFinite(Number(row[20] || 0)) ||
          Number(row[20] || 0) < 0
        ) {
          setMsg(
            t(
              "請核對發票編號、日期及有效金額，尚未儲存。",
              "Check invoice reference, date and valid amounts. Nothing saved.",
            ),
          );
          return;
        }
        const existing = db.records
          .find((v) => v.id === r.id)
          ?.ledger.some((v) => JSON.stringify(v) === JSON.stringify(row));
        if (seen.has(row[15]) && !existing) {
          setMsg(
            t(
              "新增的發票編號重複，請核對。",
              "A new invoice reference is duplicated. Please check.",
            ),
          );
          return;
        }
        seen.add(row[15]);
      }
    }
    if (
      commit({
        ...db,
        records: db.records.map((r) => ({
          ...r,
          ledger: draft.find((d) => d.id === r.id)?.ledger || r.ledger,
        })),
      })
    )
      setMsg(
        t(
          "已儲存發票及收款，總表與彙總已更新；報價版本不變。",
          "Invoices and receipts saved. Register and summary updated; quotation version unchanged.",
        ),
      );
  };
  return (
    <>
      <div className="ux-heading">
        <div>
          <h2>{t("發票及收款明細", "Invoice and receipt details")}</h2>
          <p>
            {t(
              "報價資料自動帶入。只在確實開票或收款時登記，覆核工人資料時不需要填寫這些欄位。",
              "Quotation details are carried over. Record invoices and receipts only when needed, not while reviewing worker submissions.",
            )}
          </p>
        </div>
        <B primary onClick={save}>
          {t("儲存發票及收款", "Save invoices and receipts")}
        </B>
      </div>
      {msg && (
        <div className="ux-message" role="status">
          {msg}
        </div>
      )}
      <div className="ux-filters">
        <F
          label={t("搜尋報價或物業", "Search quote or property")}
          value={query}
          onChange={setQuery}
        />
        <B onClick={add}>
          {t("按報價預填發票行", "Prefill invoice rows from quotes")}
        </B>
        <B onClick={() => setShowPaste(!showPaste)}>
          {t("批量貼上發票／收款", "Paste invoice / receipt rows")}
        </B>
      </div>
      <div className="office-select-list">
        {records.map((r) => (
          <label key={r.id}>
            <input
              type="checkbox"
              checked={selected.includes(r.id)}
              onChange={(e) =>
                setSelected(
                  e.target.checked
                    ? [...selected, r.id]
                    : selected.filter((id) => id !== r.id),
                )
              }
            />
            {r.ref} · {r.address}
          </label>
        ))}
      </div>
      {showPaste && (
        <section className="ux-panel">
          <h3>
            {t(
              "從 Excel 複製以下七欄（最多一百行）",
              "Copy these seven columns from Excel (up to 100 rows)",
            )}
          </h3>
          <p>
            QUO ref. no. → INV ref. no. → INV. Date (YYYY-MM-DD) → INV. Amount →
            Received Date → Received Amount → Paid by
          </p>
          <textarea
            className="office-paste"
            aria-label={t("批量發票資料", "Bulk invoice data")}
            value={paste}
            onChange={(e) => setPaste(e.target.value)}
          />
          <p>
            {t("可加入", "Ready to add")}: {parsed.changes.length} ·{" "}
            {t("錯誤行", "Error rows")}: {parsed.errors.join(", ") || "—"}
          </p>
          <B
            disabled={!paste.trim() || !!parsed.errors.length}
            onClick={() => {
              setDraft((prev) =>
                prev.map((r) => ({
                  ...r,
                  ledger: [
                    ...r.ledger,
                    ...parsed.changes
                      .filter((c) => c.recordId === r.id)
                      .map((c) => c.row),
                  ],
                })),
              );
              setPaste("");
              setShowPaste(false);
              setMsg(
                t(
                  "已加入待儲存明細。請核對後按「儲存發票及收款」。",
                  "Rows added for review. Select Save invoices and receipts when ready.",
                ),
              );
            }}
          >
            {t("加入待儲存明細", "Add rows for review")}
          </B>
        </section>
      )}
      <div className="ux-grid-scroll">
        <table className="ux-grid office-ledger">
          <thead>
            <tr>
              <th>QUO ref. no.</th>
              {[12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 26].map(
                (c) => (
                  <th key={c}>
                    {c === 24
                      ? t("舊QUO / INV.", "Previous QUO / INV.")
                      : HEADERS[c]}
                  </th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {records.flatMap((r) =>
              r.ledger.map((row, i) => (
                <tr key={r.id + "-" + i}>
                  <td>{r.ref}</td>
                  {[12, 13, 14, 15, 16, 17, 18, 19, 20, 21].map((c) => (
                    <td key={c}>
                      <input
                        aria-label={`${r.ref} ${HEADERS[c]} ${i + 1}`}
                        type={
                          [13, 14, 19].includes(c)
                            ? "date"
                            : [18, 20].includes(c)
                              ? "number"
                              : "text"
                        }
                        min={[18, 20].includes(c) ? 0 : undefined}
                        step="0.01"
                        value={row[c] ?? ""}
                        onChange={(e) => change(r.id, i, c, e.target.value)}
                      />
                    </td>
                  ))}
                  <td>
                    {row[12] === "X"
                      ? "—"
                      : money(Number(row[18] || 0) - Number(row[20] || 0))}
                  </td>
                  {[23, 24, 26].map((c) => (
                    <td key={c}>
                      <input
                        aria-label={`${r.ref} ${HEADERS[c]} ${i + 1}`}
                        value={row[c] ?? ""}
                        onChange={(e) => change(r.id, i, c, e.target.value)}
                      />
                    </td>
                  ))}
                </tr>
              )),
            )}
          </tbody>
        </table>
      </div>
      <p>
        {t(
          "金額超過報價時會在彙總提示，不會把差額解釋為修改版本的金額。未儲存的明細離開此分頁前請先儲存。",
          "Summary flags invoices above the quote, rather than treating differences as revision totals. Save edited rows before leaving this tab.",
        )}
      </p>
      <OriginalSheet db={db} index={2} t={t} />
    </>
  );
}
export function ProjectsView({ db, commit, t, onCreate, onDirty }) {
  const [editing, setEditing] = useState(null),
    [selected, setSelected] = useState([]),
    [message, setMessage] = useState(""),
    [paste, setPaste] = useState("");
  const projects = db.projects || [];
  useEffect(() => {
    onDirty(Boolean(editing));
  }, [editing, onDirty]);
  useEffect(() => () => onDirty(false), [onDirty]);
  const fresh = () => ({
    id: uid(),
    name: "",
    property: "",
    contractRef: "",
    coverage: "unknown",
    coverageNotes: "",
    brand: "",
    itemTerms: "",
    references: [],
  });
  const put = (key, v) => setEditing({ ...editing, [key]: v });
  const pasteRows = paste
    .trim()
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line) => {
      const [description, price = "", remark = ""] = line.split("\t");
      return { id: uid(), description, price, remark };
    });
  const bad =
    pasteRows.some(
      (r) =>
        !r.description ||
        (r.price !== "" &&
          (!Number.isFinite(Number(r.price)) || Number(r.price) < 0)),
    ) || pasteRows.length > 100;
  if (editing)
    return (
      <section className="ux-panel">
        <div className="ux-heading">
          <h2>{t("編輯項目參考", "Edit project reference")}</h2>
          <B
            onClick={() => {
              setEditing(null);
              setPaste("");
            }}
          >
            {t("返回項目列表", "Back to project list")}
          </B>
        </div>
        <p>
          {t(
            "「Project」原欄其實混合了合約參考及服務條件。以下分開儲存；項目名稱及合約編號均可留空。",
            "The original Project header mixes contract references and service conditions. Store them separately below; project name and contract reference are optional.",
          )}
        </p>
        {message && (
          <div role="status" className="ux-message">
            {message}
          </div>
        )}
        <div className="ux-fields">
          <F
            label={t("項目名稱（可留空）", "Project name (optional)")}
            value={editing.name}
            onChange={(v) => put("name", v)}
          />
          <F
            label={t("物業／屋苑", "Property / Estate")}
            value={editing.property}
            onChange={(v) => put("property", v)}
          />
          <F
            label={t("合約／報價參考編號", "Contract / quote reference")}
            value={editing.contractRef}
            onChange={(v) => put("contractRef", v)}
          />
          <F
            label={t("保養狀態", "Maintenance coverage")}
            value={editing.coverage}
            onChange={(v) => put("coverage", v)}
            options={[
              ["unknown", t("未指定", "Unspecified")],
              ["contract", t("有合約／保養", "Under contract / maintenance")],
              ["none", t("無保養", "No maintenance")],
              ["expired", t("合約已完", "Contract expired")],
            ]}
          />
          <F
            label={t("品牌", "Brand")}
            value={editing.brand}
            onChange={(v) => put("brand", v)}
          />
          <F
            label={t("服務條件／選項說明", "Coverage / option notes")}
            value={editing.coverageNotes}
            onChange={(v) => put("coverageNotes", v)}
          />
          <F
            label={t("項目共用備註／保養期", "Item terms / warranty period")}
            value={editing.itemTerms}
            onChange={(v) => put("itemTerms", v)}
          />
        </div>
        <h3>{t("參考報價項目", "Reference quotation items")}</h3>
        <div className="ux-grid-scroll">
          <table className="ux-grid office-ledger">
            <thead>
              <tr>
                <th>{t("報價項目", "Quotation item")}</th>
                <th>{t("參考價錢", "Reference price")}</th>
                <th>Remark / {t("原報價編號", "Source quote reference")}</th>
              </tr>
            </thead>
            <tbody>
              {editing.references.map((r, i) => (
                <tr key={r.id}>
                  {["description", "price", "remark"].map((k) => (
                    <td key={k}>
                      <input
                        aria-label={`${k} ${i + 1}`}
                        value={r[k]}
                        onChange={(e) =>
                          put(
                            "references",
                            editing.references.map((v) =>
                              v.id === r.id ? { ...v, [k]: e.target.value } : v,
                            ),
                          )
                        }
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="ux-actions">
          <B
            onClick={() =>
              put("references", [
                ...editing.references,
                { id: uid(), description: "", price: "", remark: "" },
              ])
            }
          >
            {t("新增參考項目", "Add reference item")}
          </B>
        </div>
        <details>
          <summary>
            {t("從 Excel 批量貼上參考項目", "Paste reference items from Excel")}
          </summary>
          <p>
            {t(
              "順序：報價項目、價錢、Remark／原報價編號。空白價錢不會當成零。",
              "Column order: quotation item, price, Remark / source quote. Blank prices remain blank, not zero.",
            )}
          </p>
          <textarea
            className="office-paste"
            aria-label={t("參考項目批量資料", "Reference item paste")}
            value={paste}
            onChange={(e) => setPaste(e.target.value)}
          />
          <B
            disabled={!paste.trim() || bad}
            onClick={() => {
              put("references", [...editing.references, ...pasteRows]);
              setPaste("");
            }}
          >
            {t("加入參考項目", "Add reference rows")} ({pasteRows.length})
          </B>
          {bad && (
            <p role="alert">
              {t(
                "請檢查價錢及行數（最多一百行）。",
                "Check prices and row limit (100).",
              )}
            </p>
          )}
        </details>
        <B
          primary
          onClick={() => {
            if (
              !editing.property.trim() ||
              editing.references.some(
                (r) =>
                  !r.description.trim() ||
                  (r.price !== "" &&
                    (!Number.isFinite(Number(r.price)) || Number(r.price) < 0)),
              )
            ) {
              setMessage(
                t(
                  "請填寫物業，並檢查項目描述及價錢。",
                  "Enter a property and check item descriptions and prices.",
                ),
              );
              return;
            }
            const updated = projects.some((p) => p.id === editing.id)
              ? projects.map((p) => (p.id === editing.id ? editing : p))
              : [...projects, editing];
            if (commit({ ...db, projects: updated })) {
              setEditing(null);
              setMessage("");
            }
          }}
        >
          {t("儲存項目參考", "Save project reference")}
        </B>
      </section>
    );
  return (
    <>
      <div className="ux-heading">
        <div>
          <h2>{t("項目及零件參考", "Projects and parts references")}</h2>
          <p>
            {t(
              "不同項目各自記錄物業、合約參考、保養、品牌及報價項目。工作表名稱不再固定為某個物業。",
              "Each project has its own property, contract reference, maintenance coverage, brand and quotation items. The worksheet is not named after a fixed property.",
            )}
          </p>
        </div>
        <B
          primary
          onClick={() => {
            setEditing(fresh());
            setMessage("");
          }}
        >
          {t("新增項目參考", "New project reference")}
        </B>
      </div>
      {!projects.length && (
        <p className="ux-empty">
          {t(
            "可新增項目，或匯入原 Excel 自動整理項目、品牌及參考項目。",
            "Create a project or import the original Excel to extract properties, brands and reference items.",
          )}
        </p>
      )}
      {projects.map((p) => (
        <section className="ux-panel" key={p.id}>
          <div className="ux-heading">
            <div>
              <h2>{p.name || p.property}</h2>
              <p>
                {t("物業", "Property")}: {p.property} · {t("品牌", "Brand")}:{" "}
                {p.brand || "—"}
              </p>
              <p>
                {t("合約／參考", "Contract / Reference")}:{" "}
                {p.contractRef || "—"} · {t("服務條件", "Coverage notes")}:{" "}
                {p.coverageNotes || "—"}
              </p>
              <p>{p.itemTerms}</p>
            </div>
            <B
              onClick={() => {
                setEditing(structuredClone(p));
                setMessage("");
              }}
            >
              {t("編輯項目參考", "Edit project reference")}
            </B>
          </div>
          <div className="ux-grid-scroll">
            <table className="ux-grid">
              <thead>
                <tr>
                  <th>{t("選取", "Select")}</th>
                  <th>{t("報價項目", "Quotation item")}</th>
                  <th>{t("參考價", "Reference price")}</th>
                  <th>Remark</th>
                </tr>
              </thead>
              <tbody>
                {p.references.map((r) => (
                  <tr key={r.id}>
                    <td>
                      <input
                        aria-label={r.description}
                        type="checkbox"
                        checked={selected.includes(r.id)}
                        onChange={(e) =>
                          setSelected(
                            e.target.checked
                              ? [...selected, r.id]
                              : selected.filter((id) => id !== r.id),
                          )
                        }
                      />
                    </td>
                    <td>{r.description}</td>
                    <td>{r.price === "" ? "—" : money(r.price)}</td>
                    <td>{r.remark}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <B
            onClick={() =>
              onCreate(
                p,
                p.references.filter((r) => selected.includes(r.id)),
              )
            }
          >
            {t("套用至新任務", "Use in a new task")} (
            {p.references.filter((r) => selected.includes(r.id)).length})
          </B>
          <small>
            {" "}
            {t(
              "物業及品牌自動帶入；參考價請核對後才簽發。",
              "Property and brand are prefilled. Verify reference prices before issuing.",
            )}
          </small>
        </section>
      ))}
    </>
  );
}
export function SampleGuide({ db, t }) {
  const groups = [
    ["報價識別", "Quote identity", [0, 1, 2, 3]],
    ["地點及工作內容", "Location and work", [4, 5, 6, 7, 8, 9, 26]],
    ["客戶及簽署", "Customer and acceptance", [10, 11, 12, 13]],
    ["發票及分期", "Invoices and instalments", [14, 15, 16, 17, 18]],
    ["收款及結欠", "Receipts and balance", [19, 20, 21, 22]],
    ["項目及歷史參考", "Project and historical references", [23, 24, 25]],
  ];
  return (
    <>
      <h2>
        {t("原表欄位分類及自動化", "Original field groups and automation")}
      </h2>
      <p>
        {t(
          "(SAMPLE) 是範例，不是每宗任務要填的另一張表。年份、RECEIVED 及 Today 屬工作表摘要，不需要逐宗輸入。",
          "(SAMPLE) is a reference, not another form per task. Year, RECEIVED and Today are sheet summaries, not per-case inputs.",
        )}
      </p>
      <div className="office-guide-grid">
        {groups.map(([h, e, cols]) => (
          <section className="ux-panel" key={e}>
            <h3>{t(h, e)}</h3>
            <p>
              {cols
                .map((c) =>
                  HEADERS[c] === "負責人"
                    ? t("負責人", "Person in charge")
                    : HEADERS[c] === "舊QUO / INV."
                      ? t("舊QUO / INV.", "Previous QUO / INV.")
                      : HEADERS[c],
                )
                .join(" · ")}
            </p>
          </section>
        ))}
      </div>
      <p>
        {t(
          "金額自動計算：工作項目數量 × 單價 → 報價總額；發票金額 − 已收款 → 未收款。修改版本保留歷史，不疊加至報價總額。",
          "Automatic calculations: quantity × unit price → quote total; invoice less receipts → outstanding. Historical quote versions are retained, not added to quote totals.",
        )}
      </p>
      <OriginalSheet db={db} index={1} t={t} />
    </>
  );
}
export async function downloadOfficeWorkbook(db, lang) {
  const { default: ExcelJS } = await import("exceljs");
  const wb = new ExcelJS.Workbook();
  const idx = wb.addWorksheet("INDEX_2026");
  idx.addRow(HEADERS.map((h, i) => (i === 32 ? new Date() : h)));
  currentQuotes(db.records)
    .flatMap(({ record, quote }, n) =>
      toIndexRows({ ...quote, ledger: record.ledger }, lang, n + 1),
    )
    .forEach((r) => idx.addRow(r));
  idx.views = [{ state: "frozen", xSplit: 3, ySplit: 1 }];
  idx.autoFilter = "A1:AA1";
  const sample = wb.addWorksheet("(SAMPLE)");
  const original = db.sheets.find((s) => s.name === "(SAMPLE)");
  (original?.rows || [[...HEADERS.slice(0, 23), ...HEADERS.slice(26)]]).forEach(
    (r) => sample.addRow(r),
  );
  const detail = wb.addWorksheet("詳細資料1");
  detail.addRow(HEADERS);
  currentQuotes(db.records)
    .flatMap(({ record, quote }, n) =>
      toIndexRows({ ...quote, ledger: record.ledger }, lang, n + 1),
    )
    .filter((r) => r[15] || r[18])
    .forEach((r) => detail.addRow(r));
  const parts = wb.addWorksheet("項目及零件參考");
  projectRows(db.projects || []).forEach((r) => parts.addRow(r));
  const summary = wb.addWorksheet("SUM (SAMPLE)");
  summary.addRow([
    "QUO ref. no.",
    "QUO. Amount",
    "INV. Amount",
    "Received Amount",
    "Outstanding Amount",
  ]);
  const sums = summarize(db.records);
  sums.forEach((r) =>
    summary.addRow([r.ref, r.quote, r.invoice, r.received, r.outstanding]),
  );
  summary.addRow([
    "TOTAL",
    ...["quote", "invoice", "received", "outstanding"].map((k) =>
      sums.reduce((s, r) => s + r[k], 0),
    ),
  ]);
  wb.worksheets.forEach((s) => {
    s.columns.forEach((c) => (c.width = 23));
    s.getRow(1).font = { bold: true };
  });
  const blob = new Blob([await wb.xlsx.writeBuffer()], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "CT_INDEX_current.xlsx";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
