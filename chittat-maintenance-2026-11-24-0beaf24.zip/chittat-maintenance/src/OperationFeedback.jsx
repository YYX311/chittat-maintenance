import React, {useEffect, useRef, useState} from "react";
import {createPortal} from "react-dom";
// Non-modal popover is in the top layer, including above open document dialogs.
export default function OperationFeedback({busy, message, important=false, t}) {
  const ref=useRef(null),[visible,setVisible]=useState(false);
  useEffect(()=>{
    setVisible(false);
    const timer=setTimeout(()=>setVisible(true),busy?180:0);
    const dismiss=!busy?setTimeout(()=>setVisible(false),important?4500:2200):null;
    return()=>{clearTimeout(timer);clearTimeout(dismiss)};
  },[busy,message,important]);
  useEffect(()=>{
    if(!ref.current)return;
    if(visible&&(busy||message))ref.current.showPopover?.();
    else ref.current.hidePopover?.();
  },[visible,busy,message]);
  return createPortal(<div ref={ref} popover="manual" className={"operation-feedback "+(important?"is-error":"")} role="status" aria-live="polite" aria-atomic="true">
    {busy?<span className="operation-spinner" aria-hidden="true"/>:<span aria-hidden="true">{important?"!":"✓"}</span>}
    <span>{busy?t("正在處理，請稍候…","Working, please wait…"):message}</span>
  </div>,document.body);
}
