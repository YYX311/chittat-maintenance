import OperationFeedback from "./OperationFeedback";
import React,{useState,useEffect} from "react";
import {sessionFetch} from "./session-fetch";
export default function PdfPreview({record,kind="quotation",revision,t}) {
 const [blobUrl,setBlobUrl]=useState(""),[failed,setFailed]=useState(false),[opened,setOpened]=useState(false);
 const [attempt,setAttempt]=useState(0);
 const params=new URLSearchParams({kind});
 if(revision!==undefined)params.set("revision",revision);
 else params.set("version",record.serverVersion||0);
 const url=`/api/cases/${encodeURIComponent(record.id)}/preview?${params}`;
 useEffect(()=>{if(record.localOnly||!opened)return;let cancelled=false,objectUrl;
  setBlobUrl("");setFailed(false);
  sessionFetch(url).then(async r=>{if(!r.ok)throw Error("preview-failed");const bytes=await r.arrayBuffer();if(new TextDecoder().decode(bytes.slice(0,5))!=="%PDF-")throw Error("invalid-pdf");const blob=new Blob([bytes],{type:"application/pdf"});if(!cancelled){objectUrl=URL.createObjectURL(blob);setBlobUrl(objectUrl)}}).catch(()=>{if(!cancelled)setFailed(true)});
  return()=>{cancelled=true;if(objectUrl)URL.revokeObjectURL(objectUrl)};
 },[url,record.localOnly,opened,attempt]);
 if(record.localOnly)return <p>{t("填寫資料後即可預覽 PDF。","Enter details to preview the PDF.")}</p>;
 if(!opened)return <button type="button" className="ux-btn" onClick={()=>setOpened(true)}>{t("顯示 PDF 預覽","Show PDF preview")}</button>;
 if(failed)return <div role="alert"><p>{t("預覽暫時無法載入，資料仍已保留。","Preview unavailable. Your data is retained.")}</p><button className="ux-btn" onClick={()=>{setFailed(false);setAttempt(n=>n+1)}}>{t("重新載入預覽","Retry preview")}</button></div>;
 if(!blobUrl)return <><OperationFeedback busy t={t}/><p role="status">{t("正在載入預覽…","Loading preview…")}</p></>;
 return <section className="document-preview"><OperationFeedback message={t("PDF 預覽已載入。","PDF preview loaded.")} t={t}/><p>{t("以下直接顯示 PDF，與下載文件使用相同排版。","This is the PDF itself, using the same layout as the download.")}</p><iframe className="pdf-preview" title={kind+" PDF"} src={blobUrl}/><a href={blobUrl} target="_blank" rel="noreferrer">{t("另開視窗檢視 PDF","Open PDF in a new window")}</a></section>;
}
