import React,{useState} from "react";
import {clearPriceDraft,confirmedPrice,priceDraftValue,updatePriceDraft} from "./pricing-model";
export default function PricingPanel({record,update,t,editAllowed,displayItem,money,issues=[],onEdit,onRemove,expandedId}) {
 const [errors,setErrors]=useState({});
 const drafts=record.priceDrafts||{};
 const setDrafts=change=>update({priceDrafts:change(drafts)});
 const change=(id,patch)=>update({items:record.items.map(i=>i.id===id?{...i,...patch}:i)});
 const confirm=(i)=>{
  const price=confirmedPrice(priceDraftValue(i,drafts));
  if(price===null){setErrors({...errors,[i.id]:t("請輸入零或以上的金額，最多兩位小數。","Enter an amount of zero or more, with at most two decimal places.")});return;}
  if(update({items:record.items.map(item=>item.id===i.id?{...item,price}:item),priceDrafts:clearPriceDraft(drafts,i.id)})){setErrors({...errors,[i.id]:""});}
 };
 const selected=record.items.find(i=>i.id===expandedId);
 if(!selected)return null;
 const n=record.items.findIndex(i=>i.id===selected.id);
 return <fieldset className="office-pricing" disabled={!editAllowed}><legend className="sr-only">{t("維修部定價","Office pricing")}</legend>
 { [selected].map((i)=>{const editing=Object.hasOwn(drafts,i.id)||i.price===""||i.price==null;const issue=issues.find(e=>e.field==="price-"+i.id);const error=errors[i.id]||(issue?t(issue.hk,issue.en):"");
 return <div className={"pricing-row"+(editing?" pricing-pending":"")+(error?" field-invalid":"")} data-feedback-target={"price-"+i.id} key={i.id}><div><b>{n+1}. {displayItem(i)}</b><p>{t("數量","Quantity")}: {i.qty} · {i.model||"—"}</p><div className="ux-actions"><button type="button" className="ux-btn" onClick={()=>onEdit(i)}>{t("編輯此行","Edit row")}</button><button type="button" className="ux-btn danger-text" onClick={()=>onRemove(i)}>{t("刪除此行","Delete row")}</button></div></div>
 <div>{editing?<><label className="ux-field"><span>{t("單價（港元）","Unit price (HKD)")}</span><input aria-label={t("單價：","Unit price: ")+displayItem(i)} aria-invalid={!!error} aria-describedby={error?"price-error-"+i.id:undefined} type="text" inputMode="decimal" value={priceDraftValue(i,drafts)} onChange={e=>{setErrors({...errors,[i.id]:""});setDrafts(current=>updatePriceDraft(current,i.id,e.target.value))}}/></label><button className="ux-btn primary" onClick={()=>confirm(i)}>{t("確定定價","Confirm price")}</button></>:<><strong className="fixed-price">{money(i.price)}</strong><small>{t("已確定單價","Confirmed unit price")}</small><button className="ux-btn" onClick={()=>setDrafts(current=>updatePriceDraft(current,i.id,String(i.price))) }>{t("修改定價","Edit price")}</button></>}{error&&<p id={"price-error-"+i.id} className="field-error" role="alert">{error}</p>}</div><strong>{editing?t("待確定","To confirm"):money(Number(i.qty)*Number(i.price||0))}</strong></div>})}
 </fieldset>;
}
