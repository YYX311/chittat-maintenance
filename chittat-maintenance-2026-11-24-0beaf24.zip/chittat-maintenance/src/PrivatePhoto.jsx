import React,{useState,useEffect} from "react";
import {photoBlob} from "./attachments";
import {rememberedPhoto} from "./photo-preview-cache";
export default function PrivatePhoto({photo}) {
 const [url,setUrl]=useState(""),[failed,setFailed]=useState(false),[retry,setRetry]=useState(0);
 useEffect(()=>{let gone=false,objectUrl;
  setFailed(false);setUrl("");
  const local=rememberedPhoto(photo.assetKey);
  const show=blob=>{if(!gone){objectUrl=URL.createObjectURL(blob);setUrl(objectUrl)}};
  if(local)show(local);
  else photoBlob(photo).then(show).catch(()=>{if(!gone)setFailed(true)});
  return()=>{gone=true;if(objectUrl)URL.revokeObjectURL(objectUrl)};
 },[photo.assetKey,photo.url,retry]);
 return url?<img src={url} alt={photo.name}/>:failed?<span onClick={e=>{e.stopPropagation();setRetry(n=>n+1)}}>未能載入，點擊重試 · {photo.name}</span>:<span role="status">正在載入相片… {photo.name}</span>;
}
