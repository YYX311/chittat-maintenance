import React,{useEffect,useId,useState} from "react";
import {projectRegistry} from "./task-guidance";
import {readStore} from "./workspace-model";
import {createProject,deleteProject,updateProject} from "./server-api";

export default function ProjectPicker({db,record,update,commit,t,disabled,error:externalError="",onSelected,children}) {
 const projects=projectRegistry(db).filter(p=>p.active!==false);
 const current=projects.find(p=>p.id===record.projectId);
 const [selectedId,setSelectedId]=useState(current?.id||"");
 const [code,setCode]=useState(current?.code||record.projectCode||"");
 const [error,setError]=useState(""),[busy,setBusy]=useState(false),[message,setMessage]=useState("");
 const errorId=useId();
 useEffect(()=>{
  const linked=projectRegistry(db).find(p=>p.id===record.projectId&&p.active!==false);
  setSelectedId(linked?.id||"");setCode(linked?.code||"");setError("");
 },[record.id]);
 const choose=id=>{
  const project=projects.find(p=>p.id===id);
  setSelectedId(project?.id||"");setCode(project?.code||"");setError("");setMessage("");
  update(project?{projectId:project.id,projectCode:project.code,projectName:project.name}:{projectId:"",projectCode:"",projectName:""});
  if(project)onSelected?.();
 };
 const putProject=project=>{
  const latest=readStore();
  const replace=items=>[...(items||[]).filter(p=>p.id!==project.id),project];
  commit({...latest,projectRegistry:replace(latest.projectRegistry),projects:replace(latest.projects)});
 };
 const save=async()=>{
  const clean=code.trim();setError("");setMessage("");
  if(!record.address?.trim())return setError(t("請先填寫工作地點。","Enter the work location first."));
  if(!/^[A-Za-z0-9][A-Za-z0-9._-]{0,39}$/.test(clean))return setError(t("Project Code 須為 1–40 位英文字母、數字、短橫線、底線或句點。","Use 1–40 letters, digits, hyphens, underscores or dots."));
  setBusy(true);
  try {
   const selected=projects.find(p=>p.id===selectedId);
   const same=projects.find(p=>p.code.toLowerCase()===clean.toLowerCase());
   if(selected&&same&&same.id!==selected.id)throw new Error("duplicate-project");
   const project=selected
    ? selected.code===clean?selected:await updateProject({id:selected.id,code:clean,expectedCode:selected.code})
    : same||await createProject({name:record.address,property:record.address,code:clean});
   putProject(project);
   setSelectedId(project.id);setCode(project.code);
   update({projectId:project.id,projectCode:project.code,projectName:project.name});onSelected?.();
   setMessage(t("Project Code 已儲存。","Project Code saved."));
  }catch(e){setError(e.message==="duplicate-project"||e.status===409?t("此代碼已存在或已被其他人更改，請重新選擇。","This code already exists or was changed elsewhere. Select it again."):t("未能儲存代碼，請重試。","Could not save the code. Retry."));}
  finally{setBusy(false);}
 };
 const remove=async()=>{
  const selected=projects.find(p=>p.id===selectedId);
  if(!selected||!window.confirm(t(`確認從已儲存清單刪除「${selected.code}」？已有任務和文件會保留。`,`Remove ${selected.code} from saved codes? Existing tasks and documents will remain.`)))return;
  setBusy(true);setError("");setMessage("");
  try{
   const removed=await deleteProject({id:selected.id,expectedCode:selected.code});
   putProject(removed);
   setSelectedId("");setCode("");
   if(record.projectId===selected.id)update({projectId:"",projectCode:"",projectName:""});
   setMessage(t("已從代碼清單刪除。","Code removed from saved list."));
  }catch(e){setError(e.status===409?t("此代碼已被其他人更改，請重新選擇。","This code changed elsewhere. Select it again."):t("未能刪除代碼，請重試。","Could not remove the code. Retry."));}
  finally{setBusy(false);}
 };
 const noticeError=error||externalError;
 const unsaved=code.trim()&&(code.trim()!==(current?.code||"")||!record.projectId);
 return <section className="project-picker">
  <h3>{t("工作地點及項目代碼","Work location and Project Code")}</h3>
  {children}
  <div className="project-code-row">
   <label className="ux-field" data-feedback-target="project">
    <span>Project Code</span>
    <input aria-label="Project Code" disabled={disabled||busy} value={code} onChange={e=>{setCode(e.target.value);setError("");setMessage("");}} aria-invalid={!!noticeError} aria-describedby={noticeError?errorId:undefined}/>
   </label>
   {!disabled&&<button type="button" className="ux-btn" disabled={busy||!code.trim()} onClick={save}>{t("儲存 Project Code","Save Project Code")}</button>}
  </div>
  {noticeError&&<p id={errorId} className="project-code-feedback field-error" role="alert">{noticeError}</p>}
  <div className="project-code-feedback" role="status">
   {busy?t("正在處理代碼…","Updating the code…"):!noticeError&&(message||(unsaved?t("儲存後才會套用到此任務。","Save to apply this code to the task."):""))}
  </div>
  <div className="project-code-actions"><label className="ux-field"><span>{t("已儲存的 Project Code","Saved Project Codes")}</span><select aria-label={t("已儲存的 Project Code","Saved Project Codes")} disabled={disabled||busy} value={selectedId} onChange={e=>choose(e.target.value)}><option value="">{t("輸入新代碼","Enter a new code")}</option>{projects.map(p=><option key={p.id} value={p.id}>{p.code} · {p.name}</option>)}</select></label>
   {!disabled&&selectedId&&<button className="ux-btn danger" disabled={busy} onClick={remove}>{t("刪除所選代碼","Remove selected code")}</button>}
  </div>
  <p className="project-picker-hint">{t("可選擇已儲存的代碼再修改。移除代碼不影響已有文件。","You can edit a saved code. Removing it does not affect existing documents.")}</p>
 </section>;
}
