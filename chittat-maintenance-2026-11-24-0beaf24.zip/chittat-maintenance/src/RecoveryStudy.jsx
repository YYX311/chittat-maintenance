import {useCallback,useEffect,useRef,useState} from 'react';
import {uid} from './workspace-model';
import {sessionFetch,sessionToken} from './session-fetch';
import {readFieldQueue,updateFieldQueue} from './field-study';

export function useRecovery(study,record,issues){
 const current=useRef(null),[state,setState]=useState(null),inflight=useRef(new Set());
 const config=study.config;
 const key=config?.joined&&config?.user&&config?.studyId?`ct-recovery-v1:${config.user}:${config.studyId}`:null;
 const token=sessionToken();
 const flush=useCallback(async()=>{
  if(!key||!token||sessionToken()!==token||!navigator.onLine||inflight.current.has(key))return;
  const batch=readFieldQueue(sessionStorage,key).slice(0,40);if(!batch.length)return;
  inflight.current.add(key);
  try{const r=await sessionFetch('/api/research/recovery',{method:'POST',headers:{'Content-Type':'application/json'},
   body:JSON.stringify({studyId:config.studyId,events:batch}),signal:AbortSignal.timeout(6000)});
   if(r.ok||[400,403,404].includes(r.status))updateFieldQueue(sessionStorage,key,[],batch.map(e=>e.id));
  }catch{}finally{inflight.current.delete(key);}
 },[key,token,config?.studyId]);
 const emit=useCallback((kind,extra={})=>{
  const r=current.current;if(!r||r.key!==key||sessionToken()!==token||r.sent.has(kind))return;
  r.sent.add(kind);
  updateFieldQueue(sessionStorage,key,[{id:uid(),episode:r.episode,caseId:r.caseId,kind,at:Date.now(),...extra}]);
  void flush();
 },[key,token,flush]);
 const tick=useCallback(()=>{const r=current.current;if(!r||r.resolved||!r.shown)return;
  const now=performance.now();if(r.visible)r.active+=Math.max(0,Math.min(now,r.activity+30000)-r.last);r.last=now;
 },[]);
 useEffect(()=>{current.current=null;setState(null);void flush();const timer=setInterval(flush,4000);
  window.addEventListener('online',flush);return()=>{clearInterval(timer);window.removeEventListener('online',flush);};
 },[key,token,flush]);
 function begin(issue){
  // Restrict the intervention to the existing contact phone check.
  if(!config?.recovery||issue.field!=='phone'||!study.assigned||!key)return false;
  const previous=current.current;if(previous?.caseId===record.id&&!previous.resolved)return true;
  const next={episode:uid(),key,caseId:record.id,issue,variant:config.assignment?.startsWith('B')?'B':'A',start:Date.now(),
   active:0,last:performance.now(),activity:performance.now(),visible:document.visibilityState==='visible',resolved:false,shown:false,sent:new Set()};
  current.current=next;setState({...next});return true;
 }
 // Measurement begins only after the prompt has rendered.
 useEffect(()=>{const r=current.current;if(!state||!r||r.shown||r.key!==key)return;
  r.shown=true;r.start=Date.now();r.last=r.activity=performance.now();emit('shown');
  document.querySelector('[aria-label="補填助手"],[aria-label="Correction assistant"]')?.scrollIntoView({block:'nearest',behavior:'auto'});
 },[state?.episode,key,emit]);
 useEffect(()=>{
  const activity=e=>{if(!e.target?.closest?.('.ux-main'))return;tick();if(current.current)current.current.activity=performance.now();};
  const focus=e=>{if(e.target?.closest?.('[data-feedback-target="phone"]'))emit('focus');};
  const visibility=()=>{tick();if(current.current){current.current.visible=document.visibilityState==='visible';current.current.last=performance.now();}};
  const offline=()=>emit('offline'),online=()=>emit('reconnect');
  const leave=()=>{tick();if(current.current&&!current.current.resolved){emit('left');current.current=null;}};
  const timer=setInterval(tick,1000);
  document.addEventListener('input',activity);document.addEventListener('click',activity);document.addEventListener('focusin',focus);document.addEventListener('visibilitychange',visibility);
  window.addEventListener('offline',offline);window.addEventListener('online',online);window.addEventListener('pagehide',leave);
  return()=>{clearInterval(timer);document.removeEventListener('input',activity);document.removeEventListener('click',activity);document.removeEventListener('focusin',focus);document.removeEventListener('visibilitychange',visibility);window.removeEventListener('offline',offline);window.removeEventListener('online',online);window.removeEventListener('pagehide',leave);};
 },[key,emit,tick]);
 const phoneInvalid=issues.some(i=>i.field==='phone');
 useEffect(()=>{const r=current.current;if(!r||r.key!==key)return;
  if(record?.id!==r.caseId){if(!r.resolved)emit('left');current.current=null;setState(null);return;}
  if(r.shown&&!r.resolved&&!phoneInvalid){tick();emit('resolved',{activeMs:Math.max(0,Math.min(Date.now()-r.start,Math.round(r.active)))});r.resolved=true;setState({...r});}
 },[record?.id,phoneInvalid,key,emit,tick]);
 return {state:state?.key===key?state:null,begin,
  submitted:id=>{if(current.current?.caseId!==id||!current.current.resolved)return false;emit('submitted');return true;},
  rate:n=>{emit(n===null?'skip':'rating',n===null?{}:{rating:n});setState(null);}};
}
export function RecoveryPrompt({recovery,t,onFocus}){
 const r=recovery.state;if(!r)return null;
 return <section className="field-study-card recovery-prompt" aria-label={t('補填助手','Correction assistant')}>
 {!r.resolved?<><h2>{t('補填提示','Correction hint')}</h2>
 <p>{r.variant==='B'?t('請核對聯絡電話，辦公室需要用它聯絡客戶。已填內容會保留。','Check the contact phone so the office can contact the client. Existing entries are retained.'):t('資料有待核對，請檢查。','Please check the entered information.')}</p>
 {r.variant==='B'&&<button type="button" onClick={()=>onFocus(r.issue)}>{t('前往補填','Go to field')}</button>}</>:
 <><h2>{t('剛才補填這一步，讓你有多煩躁？','How frustrating was that correction?')}</h2>
 <p>{t('1 完全不煩躁 · 7 非常煩躁（可略過）','1 Not at all · 7 Very frustrating (optional)')}</p>
 <div className="recovery-ratings" role="group" aria-label={t('補填煩躁評分','Correction frustration rating')}>
 {[1,2,3,4,5,6,7].map(n=><button type="button" key={n} onClick={()=>recovery.rate(n)}>{n}</button>)}
 <button type="button" onClick={()=>recovery.rate(null)}>{t('略過','Skip')}</button></div></>}
 </section>;
}
