import OperationFeedback from "./OperationFeedback";
import { ArrowCounterClockwise, Trash } from "@phosphor-icons/react";
import React,{useState,useEffect,useRef} from "react";
import {updateTrash} from "./server-api";
export default function RecycleBin({records,t,lang,onChanged}) {
 const [intent,setIntent]=useState(null),[busy,setBusy]=useState(false),[error,setError]=useState(""),[message,setMessage]=useState("");
 const dialog=useRef(null);
 useEffect(()=>{if(intent&&!dialog.current?.open)dialog.current?.showModal();},[intent]);
 const ask=(action,items)=>{setError("");setIntent({action,items});};
 const confirm=async()=>{
  setBusy(true);setError("");
  try{await updateTrash(intent.action,intent.items);setIntent(null);await onChanged();setMessage(t("回收站操作已完成。","Recycle bin updated."));}
  catch{setError(t("操作未完成，請重新整理後重試。","Could not complete. Refresh and retry."));}
  finally{setBusy(false);}
 };
 return <details className="ux-panel recycle-panel"><OperationFeedback busy={busy} message={error||message} important={!!error} t={t}/><summary>{t("回收站","Recycle bin")} ({records.length})</summary>
  {records.length>0?<><div className="ux-actions"><button className="ux-btn" onClick={()=>ask("restore",records)}>{t("全部復原","Restore all")}</button><button className="ux-btn" onClick={()=>ask("permanent-delete",records)}>{t("清空回收站","Empty recycle bin")}</button></div>
  <div className="recycle-list">{records.map(r=><article key={r.id}><div><b>{r.address||r.customer||t("未命名草稿","Untitled draft")}</b><small>{r.entryNo} · {new Date(r.deletedAt).toLocaleString(lang)}</small></div><div className="ux-actions"><button className="ux-btn" onClick={()=>ask("restore",[r])}>{t("復原","Restore")}</button><button className="ux-btn" onClick={()=>ask("permanent-delete",[r])}>{t("徹底刪除","Permanently delete")}</button></div></article>)}</div></>:<p>{t("沒有已刪除的草稿。","No deleted drafts.")}</p>}
  {intent && (
    <dialog ref={dialog} className="ux-modal confirm-modal" role="alertdialog"
      aria-label={t("確認回收站操作", "Confirm recycle bin action")}
      onCancel={e => { e.preventDefault(); if (!busy) setIntent(null); }}>
      <header>
        <span className={intent.action === "restore" ? "confirm-icon confirm-icon-restore" : "confirm-icon"}>
          {intent.action === "restore" ? <ArrowCounterClockwise aria-hidden="true" /> : <Trash aria-hidden="true" />}
        </span>
        <h2>{intent.action === "restore" ? t("確認復原所選草稿？", "Restore selected drafts?") : t("確認徹底刪除？", "Permanently delete selected drafts?")}</h2>
      </header>
      <p>{intent.action === "restore"
        ? t(`將 ${intent.items.length} 份草稿復原到任務列表。`, `Drafts to restore to the task list: ${intent.items.length}.`)
        : t(`將徹底刪除 ${intent.items.length} 份草稿，此操作無法復原。`, `Drafts to delete permanently: ${intent.items.length}. This cannot be undone.`)}</p>
      {error && <p role="alert">{error}</p>}
      <div className="ux-actions confirm-actions">
        <button autoFocus className="ux-btn" disabled={busy} onClick={() => setIntent(null)}>{t("取消", "Cancel")}</button>
        <button className={intent.action === "restore" ? "ux-btn primary" : "ux-btn danger-action"} disabled={busy} onClick={confirm}>
          {busy ? t("處理中…", "Working…") : t("確認", "Confirm")}
        </button>
      </div>
    </dialog>
  )}
  {error&&<p role="alert">{error}</p>}
 </details>;
}
