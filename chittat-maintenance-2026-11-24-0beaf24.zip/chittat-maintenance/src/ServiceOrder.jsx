import React from "react";
import {serviceDescription} from "./service-model";
export default function ServiceOrder({record:r,t,displayItem,office=false}) {
 const cell=(h,e,v)=><div className="service-cell"><small>{t(h,e)}{t(h,e)!==e&&<><br/>{e}</>}</small><p>{v||"—"}</p></div>;
 return <article className="service-order">
  <header><h2>{t("捷達機電工程有限公司","CHIT TAT ELECTRICAL ENGINEERING LTD.")}</h2><p>CHIT TAT ELECTRICAL ENGINEERING LTD.</p><h3>{t("工程／維修服務單","PROJECT / SERVICE ORDER")}</h3><b>PROJECT / SERVICE ORDER</b><p>{t("編號","Order No.")}: {r.serviceNo||t("提交時自動編號","Assigned on submission")}</p></header>
  <div className="service-row">{cell("客戶名稱","Client's Name",r.customer)}{cell("客戶聯絡電話","Client's Telephone No.",r.phone)}</div>
  {cell("工作地點","Job Location",[r.address,r.tower,r.floor,r.flat].filter(Boolean).join(" · "))}
  {cell("工作內容","Description",serviceDescription(r,displayItem)+(r.notes?"\n"+r.notes:""))}
  <div className="service-row"><div>{cell("工程經手人","Executed by",r.technician)}{cell("開工時間／日期","Commencement Time / Date",r.startedAt?.replace("T"," "))}{cell("完工時間／日期","Completion Time / Date",r.completedAt?.replace("T"," ")||t("尚未完工","Not completed"))}{cell("工程收費","Charge Amount (HK$)",office&&r.chargeAmount!==""&&r.chargeAmount!=null?r.chargeAmount:t("由維修部填寫","Office to complete"))}{cell("合約／報價編號","Contract / Quotation No.",r.contractRef)}</div><div>{cell("客戶簽收工程妥當","Certify Acceptance By (w/ Co. Chop)",t("客戶簽署／蓋章位置（未簽收）","Customer signature / company chop (not signed)"))}</div></div>
  {cell("材料","Material",r.material)}
  {cell("備註一","Remarks 1",r.serviceRemark1)}{cell("備註二","Remarks 2",r.serviceRemark2)}{cell("備註三","Remarks 3",r.serviceRemark3)}
  <footer>{t("此單並非收據","This is not a receipt.")}</footer>
 </article>;
}
