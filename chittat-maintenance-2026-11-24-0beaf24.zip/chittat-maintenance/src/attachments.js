import {sessionFetch} from "./session-fetch";
export async function getAsset(key) {
 if(!/^[0-9a-f-]{36}$/.test(key||""))throw Error("Invalid asset key");
 const response=await sessionFetch(`/api/assets/${encodeURIComponent(key)}`);
 if(!response.ok)throw Error("Asset unavailable");
 const blob=await response.blob();
 if(!blob.size)throw Error("Empty asset");
 if(blob.type.includes("pdf")&&await blob.slice(0,5).text()!=="%PDF-")throw Error("Invalid PDF");
 return blob;
}
export function downloadBlob(blob,name) {
 if(!blob.size)throw Error("Empty download");
 const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
export async function photoBlob(photo) {
 const original=photo.assetKey && await getAsset(photo.assetKey);
 if(original)return original;
 if(photo.assetKey)throw Error("Original photo unavailable");
 return (await fetch(photo.url)).blob();
}
export async function photoArchive(r,group) {
 const {default:JSZip}=await import("jszip");const zip=new JSZip(),folder=zip.folder(group);
 for(let n=0;n<r.photos.length;n++){
  const p=r.photos[n],blob=await photoBlob(p);
  const ext=(p.name?.match(/\.([a-z0-9]+)$/i)?.[1]||"jpg");
  folder.file(String(n+1).padStart(2,"0")+"_"+p.id.slice(0,8)+"."+ext,new Uint8Array(await blob.arrayBuffer()));
 }
 folder.file("相片說明.txt",r.photos.map((p,n)=>`${n+1}. ${p.name}\n${p.caption||""}`).join("\n\n"));
 return zip.generateAsync({type:"blob",compression:"STORE"});
}

// Invoke synchronously from the click handler, before generating or fetching files.
export async function chooseSaveTarget(name) {
 if(typeof window!=="undefined" && typeof window.showSaveFilePicker==="function") {
  try{return await window.showSaveFilePicker({suggestedName:name});}
  catch(error){if(error.name==="AbortError")throw error;if(!["SecurityError","NotAllowedError","NotSupportedError"].includes(error.name))throw error;}
 }
 return null;
}
export async function saveBlob(blob,name,target) {
 if(!blob.size)throw Error("Empty download");
 if(!target){downloadBlob(blob,name);return;}
 const stream=await target.createWritable();
 try{await stream.write(blob);await stream.close();}
 catch(error){await stream.abort().catch(()=>{});throw error;}
}
