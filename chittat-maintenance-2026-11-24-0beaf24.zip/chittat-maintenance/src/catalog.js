export const workItems = [
  '检查室外机', '检查室内机', '更换室内机', '更换室外机', '购买室内机', '购买室外机',
  '清洗室内机连尘网', '清洗室内机去水喉', '清洗室内机去水泵及水盘',
  '代购更换室内机电子板', '代购更换室外机电子板', '更换电制', '更换控制线', '更换保温棉', '其他'
]

export const roles = {
  worker: { label: '工人师傅', hint: '手机现场填报', home: 'worker-tasks', scope: '仅自己的任务与草稿' },
  office: { label: '维修部', hint: 'INDEX 与报价', home: 'office-inbox', scope: '维修部报价与客户资料' },
  supervisor: { label: '主管', hint: '审批与调度', home: 'supervisor-approvals', scope: '审批、派工与异常' },
  warehouse: { label: '仓库', hint: '库存与领退料', home: 'warehouse-stock', scope: '库存与领退料' },
  finance: { label: '财务', hint: '发票与收款', home: 'finance-invoices', scope: '发票、收款与会计' },
  admin: { label: '管理员', hint: '权限与安全', home: 'admin-users', scope: '账号、权限与运维' }
}

export const screenGroups = [
  { label: '登录与共用状态', screens: [
    ['login','登录'],['forgot-password','忘记密码'],['reset-sent','重设指引已发送'],['mfa','双重验证'],['access-denied','无权限'],['session-expired','登录过期'],['global-search','全局搜索'],['notifications','岗位通知中心'],['sync-conflict','同步冲突']
  ]},
  { label: '工人手机端', role: 'worker', screens: [
    ['worker-tasks','任务便利贴'],['worker-task-detail','任务详情'],['worker-basic','01 基本资料'],['worker-work','02 工作内容'],['worker-item-picker','按分类选择项目'],['worker-item-edit','新增／编辑项目'],['worker-photo','03 照片描述'],['worker-review','04 确认提交'],['worker-offline','离线草稿'],['worker-success','提交成功'],['worker-needs-info','待补资料'],['worker-timeline','进度记录'],['worker-notifications','工人通知'],['worker-profile','我的账号']
  ]},
  { label: '维修部办公室端', role: 'office', screens: [
    ['office-inbox','工人资料收件箱'],['office-index','INDEX 33列总表'],['office-case','案件汇总详情'],['office-new','办公室新建'],['office-paste','批量粘贴'],['office-import','Excel 导入校验'],['office-quote','报价编辑器'],['office-items','项目资料库'],['office-prices','历史价格'],['office-pdf','报价单 PDF 预览'],['office-issue','签发确认'],['office-versions','修订历史'],['office-send','发送结果']
  ]},
  { label: '主管端', role: 'supervisor', screens: [
    ['supervisor-approvals','审批队列'],['supervisor-workorders','工单看板'],['supervisor-schedule','派工排期'],['supervisor-exceptions','异常中心']
  ]},
  { label: '仓库端', role: 'warehouse', screens: [
    ['warehouse-stock','库存列表'],['warehouse-item','物料台账'],['warehouse-reserve','预留物料'],['warehouse-pick','领料／退料'],['warehouse-adjust','库存调整']
  ]},
  { label: '财务端', role: 'finance', screens: [
    ['finance-invoices','发票列表'],['finance-invoice','发票详情'],['finance-payments','收款登记'],['finance-allocation','款项核销'],['finance-accounting','会计交接']
  ]},
  { label: '管理与运维端', role: 'admin', screens: [
    ['admin-users','用户管理'],['admin-roles','角色权限'],['admin-dictionaries','项目字典'],['admin-templates','文档模板'],['admin-audit','审计日志'],['admin-security','安全中心'],['admin-operations','运行监控']
  ]}
]

export const taskData = [
  { id:'S-0418', title:'黄竹坑5期｜空调不制冷', meta:'今日 14:30 · 王太', status:'处理中', tone:'dark', next:'继续填写' },
  { id:'S-0419', title:'启德6554｜室外机检查', meta:'今日 16:00 · 陈先生', status:'待开始', tone:'mid', next:'开始填报' },
  { id:'S-0412', title:'御景湾北N1｜更换控制线', meta:'昨天 · 已离场', status:'待补资料', tone:'line', next:'补充照片' },
  { id:'S-0406', title:'Miami Quay T6-7G｜检查', meta:'02 Sep · 已提交', status:'办公室处理中', tone:'soft', next:'查看进度' }
]

export const indexRows = [
  ['CT-MNA26-Q-S-0418','S','黄竹坑5期','王太','检查室外机','1','—','1,800','待整理'],
  ['CT-MNA26-Q-S-0419','S','启德6554','陈先生','更换室外机','1','R410A-2HP','9,800','待整理'],
  ['CT-MNA26-Q-0321','办公室','會德豐6563','謝生','购买室内机','2','MSY-GR18','18,600','草稿'],
  ['CT-MNA26-Q-0320','办公室','KOKO Hill Parts','物业','更换电子板','3','P.C.B.-A12','7,200','待签发'],
  ['CT-MNA26-Q-0319','办公室','Miami Quay T6-7G','Frankie Cheong','检查冷气不制冷','1','—','1,800','已发送']
]
