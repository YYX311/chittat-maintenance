import { validMoney } from "./numeric-rules.js";

// Round each line to cents once, then subtract the negotiated monetary discount.
export const subtotalCents = record => (record.items || []).reduce((sum, item) =>
  sum + Math.round(Number(item.qty || 0) * Number(item.price || 0) * 100), 0);
export const subtotal = record => subtotalCents(record) / 100;
export const discount = record => Number(record.discountAmount || 0);
export const validDiscount = record =>
  (record.discountAmount === "" || record.discountAmount == null || validMoney(record.discountAmount)) &&
  Math.round(discount(record) * 100) <= subtotalCents(record);
export const netTotal = record => (subtotalCents(record) - Math.round(discount(record) * 100)) / 100;
