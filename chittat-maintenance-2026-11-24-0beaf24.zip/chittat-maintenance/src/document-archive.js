export async function documentArchive(files) {
 if(!Array.isArray(files)||!files.length)throw Error("Empty package");
 const {default:JSZip}=await import("jszip");
 const zip=new JSZip(),names=new Set();
 for(const file of files){
  if(names.has(file.name))throw Error("Duplicate document name");
  names.add(file.name);
  const bytes=new Uint8Array(await file.blob.arrayBuffer());
  if(!bytes.length||new TextDecoder().decode(bytes.slice(0,5))!=="%PDF-")throw Error("Invalid PDF");
  zip.file(file.name,bytes);
 }
 return zip.generateAsync({type:"blob"});
}
