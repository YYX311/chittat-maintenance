const PREFIX = "ct-emergency-drafts-v2:";

const storage = () => {
  try { return globalThis.localStorage; } catch { return null; }
};

const accountKey = (account) => PREFIX + String(account?.id || account?.email || "anonymous");

export function readDraftCache(account) {
  const store = storage();
  if (!store || !account) return [];
  try {
    const parsed = JSON.parse(store.getItem(accountKey(account)) || "[]");
    return Array.isArray(parsed) ? parsed.filter(entry => entry?.record?.id) : [];
  } catch { return []; }
}

export function cacheDraft(account, record, baseVersion) {
  const store = storage();
  if (!store || !account || !record?.id) return;
  const entries = readDraftCache(account).filter(entry => entry.record.id !== record.id);
  entries.push({ savedAt: new Date().toISOString(), baseVersion, record });
  try { store.setItem(accountKey(account), JSON.stringify(entries)); } catch {}
}

export function clearDraftCache(account, recordId) {
  const store = storage();
  if (!store || !account) return;
  const entries = readDraftCache(account).filter(entry => entry.record.id !== recordId);
  try {
    if (entries.length) store.setItem(accountKey(account), JSON.stringify(entries));
    else store.removeItem(accountKey(account));
  } catch {}
}

export function mergeDraftCache(workspace, account) {
  const cached = readDraftCache(account);
  const recovered = [];
  const byId = new Map(cached.map(entry => [entry.record.id, entry]));
  const records = workspace.records.map(serverRecord => {
    const entry = byId.get(serverRecord.id);
    if (!entry || serverRecord.deletedAt || !["editing", "draft", "needsInfo", "revision"].includes(serverRecord.status)) return serverRecord;
    if (Number(entry.baseVersion) !== Number(serverRecord.serverVersion)) return serverRecord;
    const record = { ...serverRecord, ...entry.record, serverVersion: serverRecord.serverVersion };
    recovered.push(record);
    return record;
  });
  for (const entry of cached) {
    if (entry.record.localOnly && !records.some(r=>r.id===entry.record.id)) {
      records.unshift(entry.record); recovered.push(entry.record);
    }
  }
  return { workspace: { ...workspace, records }, recovered };
}
