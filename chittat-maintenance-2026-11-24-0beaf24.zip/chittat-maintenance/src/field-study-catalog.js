export const fieldStudyScreens = {
  "worker-basic": "基本資料",
  "worker-work": "工作項目",
  "worker-photo": "相片與時間",
  "worker-review": "核對及提交",
  "office-0": "客戶及物業",
  "office-1": "工作項目及定價",
  "office-2": "相片及現場描述",
  "office-3": "服務資料及備註",
  "office-4": "核對及確認",
};

export const fieldStudyFields = {
  date: "日期", address: "工作地點", tower: "座數", floor: "樓層", flat: "單位",
  customer: "客戶名稱", contact: "聯絡人", occupant: "住戶資料", phone: "聯絡電話", items: "工作項目",
  qty: "數量", model: "型號", brand: "品牌", startedAt: "開工時間", completedAt: "完工時間",
  notes: "現場描述", photo: "現場相片", project: "Project Code", price: "定價",
  discountAmount: "優惠金額", chargeAmount: "工程收費", description: "項目說明", feedback: "退回標註",
};

export function studyField(value) {
  const field = typeof value === "string" && value.startsWith("price-") ? "price" : value;
  return typeof field === "string" && Object.hasOwn(fieldStudyFields, field) ? field : null;
}

export const fieldEventLabels = {
  screen_active: "畫面活動", validation_error: "欄位檢查攔截", field_clear: "清空欄位",
  rage_click: "快速連點", offline: "斷線", reconnect: "恢復連線", slow_network: "請求較慢",
  assistant_shown: "顯示防錯提示", assistant_accept: "點擊前往核對",
};

export const phaseWorkloadItems = [
  ["mental", "腦力需求", "Mental demand"],
  ["physical", "體力需求", "Physical demand"],
  ["temporal", "時間壓力", "Temporal demand"],
  ["performance", "對表現不滿意的程度", "Dissatisfaction with performance"],
  ["effort", "所需努力", "Effort"],
  ["frustration", "挫折感", "Frustration"],
];

export const participantProfile = {
  tenure: {under_1:"少於 1 年","1_to_3":"1–3 年","3_to_5":"3–5 年",over_5:"多於 5 年"},
  specialty: {hvac:"冷氣通風",electrical:"電力",plumbing:"水務",administration:"行政",other:"其他"},
  work_area: {hong_kong:"香港島",kowloon:"九龍",new_territories:"新界",mixed:"多區",office:"辦公室"},
};
