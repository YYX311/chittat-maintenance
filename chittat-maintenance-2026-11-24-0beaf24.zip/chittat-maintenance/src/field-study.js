import { fieldStudyFields, studyField } from "./field-study-catalog";

const steps = ["worker-basic", "worker-work", "worker-photo"];
const fieldSteps = {
  date:0,address:0,tower:0,floor:0,flat:0,customer:0,contact:0,occupant:0,phone:0,project:0,
  items:1,qty:1,model:1,brand:1,price:1,notes:2,photo:2,startedAt:2,completedAt:2,feedback:4,
};

export function assistantSuggestions(record, worker, issues, hints) {
  if (!record) return [];
  const suggestions = [];
  const add = (issue, kind) => {
    const field=studyField(issue.field);
    if (!field || suggestions.some(s=>studyField(s.field)===field)) return;
    suggestions.push({...issue,kind});
  };
  for (const issue of issues) add(issue,"missing");
  const risk=(field,hk,en,step,itemId)=>add({field,hk,en,step,itemId},"check");
  if (worker) {
    const phone=record.phone?.replace(/[\s()-]/g,"");
    if (phone && !/^(?:\+?852)?\d{8}$/.test(phone) && !/^\+\d{8,15}$/.test(phone)) {
      risk("phone","請核對聯絡電話格式。","Check the phone number format.",0);
    }
    for (const hint of hints) {
      const field=studyField(hint.field);
      if (field && Object.hasOwn(fieldSteps,field)) risk(field,
        `較早期曾有 ${hint.count} 次退回涉及「${fieldStudyFields[field]}」，請核對。`,
        `Earlier periods recorded ${hint.count} returns for this field. Check it before submitting.`,fieldSteps[field],
        ["qty","brand","model"].includes(field)?record.items?.[0]?.id:undefined);
    }
  } else {
    const largeItem=record.items?.find(i=>Number(i.qty)>50);
    if (largeItem) risk("qty","有工作項目數量多於 50，請核對。","An item has a quantity above 50. Verify it.",1,largeItem.id);
    if (record.startedAt && record.completedAt && record.completedAt.slice(0,10)<record.startedAt.slice(0,10))
      risk("completedAt","完工時間早於開工時間。","Completion precedes commencement.",3);
    if (record.feedback?.some(f=>!f.resolved))
      risk("feedback","仍有退回標註未獲回覆。","Some requests are still open.",4);
  }
  return {missing:suggestions.filter(s=>s.kind==="missing").length,
    items:suggestions.slice(0,3).map(s=>({...s,screen:steps[s.step]||"worker-review"}))};
}

const week = 7 * 86400000;
export const fieldQueueKey=(account,study)=>`ct-field-study-events-v1:${account}:${study}`;
export function readFieldQueue(storage,key,now=Date.now()) {
  try {
    const items=JSON.parse(storage.getItem(key)||"[]");
    return Array.isArray(items)?items.filter(x=>x?.at>=now-week&&x.at<=now+60000).slice(-240):[];
  } catch { return []; }
}

export function updateFieldQueue(storage,key,added=[],removed=[]) {
  try {
    const done=new Set(removed);
    const queue=[...readFieldQueue(storage,key).filter(x=>!done.has(x.id)),...added].slice(-240);
    if (queue.length) storage.setItem(key,JSON.stringify(queue));
    else storage.removeItem(key);
  } catch { /* Research storage cannot block business edits. */ }
}
