import {validQuantity,validMoney} from "./numeric-rules.js";
import {requiredIssues} from "./required-fields.js";
import {validDiscount} from "./commercial-totals.js";

// Match the rendered field order, rather than the order validation rules run in.
const fieldOrder=["date","address","project","tower","floor","flat","customer","contact","occupant","phone",
 "items","brand","qty","model","price","description","discountAmount","notes","startedAt","completedAt","chargeAmount"];
const rank=field=>{const n=fieldOrder.indexOf(field.startsWith("price-")?"price":field);return n<0?fieldOrder.length:n;};
export function orderedIssues(issues,items=[]) {
 const itemRank=issue=>issue.itemId?items.findIndex(item=>item.id===issue.itemId):items.length;
 return [...issues].sort((a,b)=>a.step-b.step || (a.step===1&&a.itemId&&b.itemId?itemRank(a)-itemRank(b):0) || rank(a.field)-rank(b.field));
}
export function firstFormIssue(issues,currentStep) {
 return issues.find(issue=>issue.step===currentStep)||issues[0];
}
export function firstItemIssue(item,worker,fallbackBrand="") {
 if(!item)return null;
 const add=(field,hk,en)=>({field,step:1,itemId:item.id,hk,en});
 if(!(item.brand||fallbackBrand)?.trim())return add("brand","請填寫空調品牌；不適用請填「不適用」。","Enter the AC brand, or N/A.");
 if(!validQuantity(item.qty))return add("qty","數量須為零或以上整數。","Enter a non-negative integer quantity.");
 if(!item.model?.trim())return add("model","請填寫型號；不適用請填「不適用」。","Enter the model, or N/A.");
 if(!worker&&item.price!==""&&!validMoney(item.price))return add("price","請填寫有效的非負單價。","Enter a valid non-negative unit price.");
 if(item.preset===14&&!item.description?.trim())return add("description","請填寫「其他」項目的說明。","Enter a description for Other.");
 return null;
}
export function formIssues(r,worker,projects=[]) {
 if(!r)return [];
 const out=requiredIssues(r,worker),add=(field,step,hk,en,itemId)=>{if(!out.some(e=>e.field===field&&e.itemId===itemId))out.push({field,step,hk,en,itemId});};
 if(!worker&&!projects.some(p=>p.active!==false&&p.id===r.projectId&&(p.code===r.projectCode||p.previousCodes?.includes(r.projectCode))))add("project",0,"請填寫並儲存 Project Code。","Enter and save Project Code.");
 if(!/^\d{4}-\d{2}-\d{2}$/.test(r.date||"")||!Number.isFinite(Date.parse(r.date)))add("date",0,"請填寫有效日期。","Enter a valid date.");
 if(!r.address?.trim())add("address",0,"請填寫工作地址／屋苑。","Enter the work address / property.");
 if(!r.customer?.trim())add("customer",0,"請填寫客戶名稱。","Enter the customer name.");
 if(worker&&!r.phone?.trim())add("phone",0,"請填寫客戶聯絡電話。","Enter the customer's phone number.");
 else if(r.phone&&!/^\+?[0-9 ()-]{7,24}$/.test(r.phone.trim()))add("phone",0,"電話格式不正確，請輸入數字，可包含國際區號、空格或短橫線。","Enter a valid phone number using digits, optional country code, spaces or hyphens.");
 if(!r.items.length)add("items",1,"請至少新增一個工作項目。","Add at least one work item.");
 r.items.forEach(i=>{
  if(!validQuantity(i.qty))add("qty",1,"數量須為零或以上整數，請修改此工作項目。","Quantity must be a non-negative integer. Edit this item.",i.id);
  if(i.preset===14&&!i.description?.trim())add("items",1,"「其他」項目須填寫工作說明。","Enter a description for Other.",i.id);
  if(!worker&&(i.price===""||i.price==null||!Number.isFinite(Number(i.price))||Number(i.price)<0||i.priceConfirmed===false||Object.hasOwn(r.priceDrafts||{},i.id)))add("price-"+i.id,1,"請輸入有效單價，並按「確定定價」。","Enter a valid unit price, then select Confirm price.",i.id);
 });
 const serviceStep=worker?2:3;
 if(!worker&&!validDiscount(r))add("discountAmount",1,"優惠金額須為零或以上、最多兩位小數，並且不可超過小計。","Discount must be non-negative, have at most two decimals and not exceed Sub Total.");
 if(!worker&&r.chargeAmount&&!/^\d+(?:\.\d{1,2})?$/.test(String(r.chargeAmount)))add("chargeAmount",3,"工程收費須為零或以上，最多兩位小數。","Enter a non-negative service charge with up to two decimals.");
 if(worker&&!r.photos?.length&&!r.notes?.trim())add("notes",2,"請填寫現場描述或加入相片。","Add site notes or a photo.");
 if(worker&&!r.startedAt)add("startedAt",serviceStep,"請填寫開工時間／日期。","Enter the commencement time / date.");
 if(r.completedAt&&(!r.startedAt||r.completedAt.slice(0,10)<r.startedAt.slice(0,10)))add("completedAt",serviceStep,"完工時間不能早於開工時間，請先填寫有效開工時間。","Completion must not precede commencement. Enter a valid start time first.");
 return orderedIssues(out,r.items);
}
