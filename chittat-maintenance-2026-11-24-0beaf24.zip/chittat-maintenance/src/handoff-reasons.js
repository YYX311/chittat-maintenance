export const handoffReasons = [
  ["photos", "相片", "Photos"],
  ["equipment", "設備資料", "Equipment details"],
  ["description", "工作說明", "Work description"],
  ["time", "時間資料", "Timing"],
  ["location", "工作地點", "Location"],
  ["changed_request", "要求變更", "Changed request"],
  ["other", "其他", "Other"],
  ["unknown", "尚未分類", "Unclassified"],
];

export function handoffReason(value) {
  return handoffReasons.some(([code]) => code === value) ? value : "unknown";
}
