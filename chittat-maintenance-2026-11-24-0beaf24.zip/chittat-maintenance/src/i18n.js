export const locales = [
  ['zh-HK','繁體中文'],
  ['zh-CN','简体中文'],
  ['en','English']
]

const hk = {
  '维修业务系统':'維修業務系統','现场助手':'現場助手','搜索':'搜尋','通知':'通知',
  '手机现场填报':'手機現場填報','仅自己的任务与草稿':'只限自己的任務及草稿','INDEX 与报价':'INDEX 與報價','维修部报价与客户资料':'維修部報價及客戶資料',
  '主管':'主管','仓库':'倉庫','财务':'財務','管理员':'管理員','审批':'審批','工单':'工作單','排期':'排期','异常':'異常','库存':'庫存','领退料':'領／退料','调整':'調整','发票':'發票','收款':'收款','核销':'核銷','会计':'會計','用户':'用戶','权限':'權限','模板':'範本','运维':'維運','退出登录':'登出',
  '任务':'任務','草稿':'草稿','进度':'進度','我的':'我的','离线草稿':'離線草稿','工人通知':'工人通知',
  '收件箱':'收件箱','报价':'報價','资料库':'資料庫','登录维修业务系统':'登入維修業務系統',
  '同一个网址，系统按账号权限进入唯一工作台':'同一個網址，系統按帳戶權限進入唯一工作台',
  '验证身份':'驗證身分','请输入验证器或短信中的 6 位验证码':'請輸入驗證器或短訊中的 6 位驗證碼',
  '忘记密码':'忘記密碼','输入账号，我们会发送安全的重设指引':'輸入帳戶，我們會發送安全的重設指引',
  '连接正常':'連線正常','弱网会安全重试，不会跳过身份验证':'網絡較弱時會安全重試，不會略過身分驗證',
  '原型演示账号':'原型示範帳戶','工人师傅':'工人師傅','进入现场任务':'進入現場任務',
  '维修部':'維修部','进入办公室工作台':'進入辦公室工作台',
  '正式系统不显示账号选择；系统会根据实际输入的账号权限自动判断。':'正式系統不會顯示帳戶選擇；系統會按實際輸入帳戶的權限自動判斷。',
  '手机号码／电邮':'手提電話／電郵','密码':'密碼','登录并验证':'登入並驗證',
  '岗位权限由服务器签发，前端不能自行切换':'崗位權限由伺服器簽發，前端不能自行切換',
  '验证并进入工人师傅工作台':'驗證並進入工人師傅工作台','验证并进入维修部工作台':'驗證並進入維修部工作台',
  '重新发送（38秒）':'重新發送（38秒）','验证码可在弱网下接收；服务器验证失败时保留输入并提示重试。已登录设备离线时，只能继续编辑本机草稿。':'驗證碼可在網絡較弱時接收；伺服器驗證失敗時會保留輸入並提示重試。已登入裝置離線時，只能繼續編輯本機草稿。',
  '早晨，楊师傅':'早晨，楊師傅','今天有 2 个现场任务':'今日有 2 個現場任務','已同步':'已同步',
  '今日':'今日','待补资料':'待補資料','已提交':'已提交','处理中':'處理中','待开始':'待開始','办公室处理中':'維修部處理中',
  '资料 1/4 已完成':'資料 1/4 已完成','尚未填写':'尚未填寫','缺少 1 张照片':'欠缺 1 張相片','查看办公室进度':'查看維修部進度','新增报价资料':'新增報價資料',
  '任务详情':'任務詳情','客户':'客戶','联络电话':'聯絡電話','到场时间':'到場時間',
  '点任一步骤即可查看或修改；底部按钮只负责快速继续当前未完成步骤。':'點選任何步驟均可查看或修改；底部按鈕只用作快速繼續目前未完成的步驟。',
  '基本资料':'基本資料','工作内容':'工作內容','照片与描述':'相片與描述','确认提交':'確認提交',
  '步骤':'步驟','填写日期、地点与客户信息':'填寫日期、地點及客戶資料','每个项目都要完成数量、型号及现场说明':'每個項目均須填寫數量、型號及現場說明','最少上传 1 张现场照片':'最少上載 1 張現場相片','办公室可直接整理，无需逐项来回确认':'維修部可直接整理，毋須逐項來回確認',
  '日期':'日期','地址／单位':'地址／單位','客户类型':'客戶類型','物业':'物業','物业／业主名称':'物業／業主名稱','住户信息':'住戶資料','客户联络电话':'客戶聯絡電話','维修负责人':'維修負責人',
  '点项目卡即可编辑；新增项目会先填写详情，再回到这里汇总。':'點選項目卡即可編輯；新增項目會先填寫詳情，再返回此頁總覽。','待办公室定价':'待維修部定價','未填写':'未填寫','现场价钱可留空，由维修部根据价格库决定。':'現場價錢可留空，由維修部按價格庫決定。','保存草稿':'儲存草稿','提交资料':'提交資料','下一步':'下一步',
  '检查室外机':'檢查室外機','检查室内机':'檢查室內機','更换室内机':'更換室內機','更换室外机':'更換室外機','购买室内机':'購買室內機','购买室外机':'購買室外機','清洗室内机连尘网':'清洗室內機連塵網','清洗室内机去水喉':'清洗室內機去水喉','清洗室内机去水泵及水盘':'清洗室內機去水泵及水盤','代购更换室内机电子板':'代購更換室內機電子板','代购更换室外机电子板':'代購更換室外機電子板','更换电制':'更換電掣','更换控制线':'更換控制線','更换保温棉':'更換保溫棉',
  '已完成 · 可修改':'已完成 · 可修改','进行中':'進行中','未开始':'未開始','等待前面完成':'等待前面完成','继续第 02 步 · 工作内容':'繼續第 02 步 · 工作內容',
  '添加工作项目':'新增工作項目','第一步':'第一步','先选分类，再选一个项目':'先選分類，再選一個項目','项目数量不多，取消搜索可减少现场输入和误选。':'項目數量不多，取消搜尋可減少現場輸入及誤選。',
  '常用':'常用','检查':'檢查','更换':'更換','购买':'購買','清洗':'清洗','其他':'其他','添加并填写详情':'新增並填寫詳情','一次添加一个项目，保存详情后再决定是否继续添加，避免遗漏型号或数量。':'每次新增一個項目，儲存詳情後再決定是否繼續新增，避免遺漏型號或數量。',
  '编辑工作项目':'編輯工作項目','填写新增项目':'填寫新增項目','已添加项目':'已新增項目','第二步 · 项目详情':'第二步 · 項目詳情','完成本项目后返回工作内容汇总。':'完成本項目後返回工作內容總覽。',
  '数量':'數量','型号':'型號','手动输入机身铭牌型号；没有可留空':'手動輸入機身銘牌型號；如沒有可留空','现场参考价':'現場參考價','可留空，由维修部定价':'可留空，由維修部定價','说明':'說明','删除':'刪除','保存并返回工作内容':'儲存並返回工作內容',
  '我的通知':'我的通知','只显示与你有关的消息':'只顯示與你有關的訊息','自己的任务、补资料要求和提交进度；不会出现办公室审批、库存或财务信息。':'自己的任務、補資料要求和提交進度；不會顯示維修部審批、庫存或財務資料。',
  '我的权限':'我的權限','只能查看自己的任务、草稿、通知与提交进度。':'只可查看自己的任務、草稿、通知及提交進度。','岗位由管理员配置；此账号没有办公室、主管、仓库或财务入口。':'崗位由管理員設定；此帳戶沒有維修部、主管、倉庫或財務入口。','账号与验证':'帳戶與驗證','使用帮助':'使用協助','退出登录':'登出',
  '工人资料':'工人資料','待整理收件箱':'待整理收件箱','维修部拥有整理、补全和定价自主权；只在关键资料缺失时退回。':'維修部可自行整理、補全及定價；只有關鍵資料缺失時才退回。','办公室新建':'維修部新增','待整理':'待整理','待签发':'待簽發','待客户决定':'待客戶決定','处理建议':'處理建議','优先':'優先','缺照片':'欠相片'
}

const en = {
  '维修业务系统':'Maintenance Operations','现场助手':'Field Assistant','搜索':'Search','通知':'Notifications',
  '手机现场填报':'Mobile field reporting','仅自己的任务与草稿':'Own tasks and drafts only','INDEX 与报价':'INDEX and quotations','维修部报价与客户资料':'Office quotations and customer data',
  '主管':'Supervisor','仓库':'Warehouse','财务':'Finance','管理员':'Administrator','审批':'Approvals','工单':'Work orders','排期':'Schedule','异常':'Exceptions','库存':'Stock','领退料':'Issue / Return','调整':'Adjustments','发票':'Invoices','收款':'Payments','核销':'Allocation','会计':'Accounting','用户':'Users','权限':'Permissions','模板':'Templates','运维':'Operations','退出登录':'Sign out',
  '任务':'Tasks','草稿':'Drafts','进度':'Progress','我的':'Me','离线草稿':'Offline drafts','工人通知':'Worker notifications',
  '收件箱':'Inbox','报价':'Quotations','资料库':'Library','登录维修业务系统':'Sign in to Maintenance Operations',
  '同一个网址，系统按账号权限进入唯一工作台':'One URL. Your account permissions determine your workspace.',
  '验证身份':'Verify your identity','请输入验证器或短信中的 6 位验证码':'Enter the 6-digit code from your authenticator or SMS.',
  '忘记密码':'Forgot password','输入账号，我们会发送安全的重设指引':'Enter your account to receive secure reset instructions.',
  '连接正常':'Connected','弱网会安全重试，不会跳过身份验证':'On a weak connection, sign-in retries safely without bypassing verification.',
  '原型演示账号':'Prototype demo accounts','工人师傅':'Field worker','进入现场任务':'Open field tasks',
  '维修部':'Maintenance office','进入办公室工作台':'Open office workspace',
  '正式系统不显示账号选择；系统会根据实际输入的账号权限自动判断。':'The live system will not show this selector. It routes users from their verified account permissions.',
  '手机号码／电邮':'Mobile number / Email','密码':'Password','登录并验证':'Sign in and verify',
  '岗位权限由服务器签发，前端不能自行切换':'Roles are issued by the server and cannot be changed in the interface.',
  '验证并进入工人师傅工作台':'Verify and open Field Worker','验证并进入维修部工作台':'Verify and open Maintenance Office',
  '重新发送（38秒）':'Resend (38s)','验证码可在弱网下接收；服务器验证失败时保留输入并提示重试。已登录设备离线时，只能继续编辑本机草稿。':'Codes can arrive on weak networks. Failed verification preserves input for retry. Offline signed-in devices can only edit local drafts.',
  '早晨，楊师傅':'Good morning, Mr. Yeung','今天有 2 个现场任务':'You have 2 field tasks today','已同步':'Synced',
  '今日':'Today','待补资料':'Needs information','已提交':'Submitted','处理中':'In progress','待开始':'Not started','办公室处理中':'Office processing',
  '资料 1/4 已完成':'1 of 4 sections complete','尚未填写':'Not started','缺少 1 张照片':'1 photo missing','查看办公室进度':'View office progress','新增报价资料':'New quotation details',
  '任务详情':'Task details','客户':'Customer','联络电话':'Contact number','到场时间':'Arrival time',
  '点任一步骤即可查看或修改；底部按钮只负责快速继续当前未完成步骤。':'Open any step to review or edit it. The bottom button resumes the current incomplete step.',
  '基本资料':'Basic details','工作内容':'Work items','照片与描述':'Photos and notes','确认提交':'Review and submit',
  '步骤':'Step','填写日期、地点与客户信息':'Enter the date, location and customer details','每个项目都要完成数量、型号及现场说明':'Complete quantity, model and site notes for every item','最少上传 1 张现场照片':'Upload at least one site photo','办公室可直接整理，无需逐项来回确认':'The office can prepare the quotation without repeated confirmations',
  '日期':'Date','地址／单位':'Address / Unit','客户类型':'Customer type','物业':'Property management','物业／业主名称':'Property / Owner name','住户信息':'Occupant details','客户联络电话':'Customer contact','维修负责人':'Technician in charge',
  '点项目卡即可编辑；新增项目会先填写详情，再回到这里汇总。':'Open an item card to edit it. New items return here after details are saved.','待办公室定价':'Office to price','未填写':'Not entered','现场价钱可留空，由维修部根据价格库决定。':'The field price is optional; the office can use the price library.','保存草稿':'Save draft','提交资料':'Submit details','下一步':'Next',
  '检查室外机':'Inspect outdoor unit','检查室内机':'Inspect indoor unit','更换室内机':'Replace indoor unit','更换室外机':'Replace outdoor unit','购买室内机':'Purchase indoor unit','购买室外机':'Purchase outdoor unit','清洗室内机连尘网':'Clean indoor unit and filter','清洗室内机去水喉':'Clean indoor unit drain pipe','清洗室内机去水泵及水盘':'Clean indoor unit pump and drain pan','代购更换室内机电子板':'Purchase and replace indoor control board','代购更换室外机电子板':'Purchase and replace outdoor control board','更换电制':'Replace electrical switch','更换控制线':'Replace control cable','更换保温棉':'Replace insulation',
  '已完成 · 可修改':'Complete · Editable','进行中':'In progress','未开始':'Not started','等待前面完成':'Waiting for prior steps','继续第 02 步 · 工作内容':'Continue step 02 · Work items',
  '添加工作项目':'Add work item','第一步':'Step one','先选分类，再选一个项目':'Choose a category, then one item','项目数量不多，取消搜索可减少现场输入和误选。':'The short preset list uses categories instead of search to reduce field input and mistakes.',
  '常用':'Common','检查':'Inspect','更换':'Replace','购买':'Purchase','清洗':'Clean','其他':'Other','添加并填写详情':'Add and complete details','一次添加一个项目，保存详情后再决定是否继续添加，避免遗漏型号或数量。':'Add one item at a time. Save its details before adding another to avoid missing model or quantity.',
  '编辑工作项目':'Edit work item','填写新增项目':'Complete new item','已添加项目':'Added item','第二步 · 项目详情':'Step two · Item details','完成本项目后返回工作内容汇总。':'Complete this item, then return to the work summary.',
  '数量':'Quantity','型号':'Model','手动输入机身铭牌型号；没有可留空':'Enter the nameplate model manually; leave blank if unavailable','现场参考价':'Field reference price','可留空，由维修部定价':'Optional; the maintenance office can price it','说明':'Notes','删除':'Delete','保存并返回工作内容':'Save and return to work items',
  '我的通知':'My notifications','只显示与你有关的消息':'Only messages relevant to you','自己的任务、补资料要求和提交进度；不会出现办公室审批、库存或财务信息。':'Your tasks, information requests and submission progress only. Office approvals, stock and finance are excluded.',
  '我的权限':'My permissions','只能查看自己的任务、草稿、通知与提交进度。':'You can only view your tasks, drafts, notifications and submission progress.','岗位由管理员配置；此账号没有办公室、主管、仓库或财务入口。':'Roles are managed by an administrator. This account has no office, supervisor, warehouse or finance access.','账号与验证':'Account and verification','使用帮助':'Help','退出登录':'Sign out',
  '工人资料':'Worker submissions','待整理收件箱':'Submission inbox','维修部拥有整理、补全和定价自主权；只在关键资料缺失时退回。':'The maintenance office can complete and price submissions. Return only when critical information is missing.','办公室新建':'Create in office','待整理':'To process','待签发':'To issue','待客户决定':'Awaiting customer','处理建议':'Suggested actions','优先':'Priority','缺照片':'Photo missing'
}

export function tx(lang,text){
  if(lang==='zh-CN') return text
  return (lang==='en'?en:hk)[text] || text
}
