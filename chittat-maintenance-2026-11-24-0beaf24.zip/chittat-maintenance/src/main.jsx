import { createRoot } from "react-dom/client";
import Workspace from "./Workspace.jsx";
import "./styles.css";

createRoot(document.getElementById("root")).render(<Workspace />);
