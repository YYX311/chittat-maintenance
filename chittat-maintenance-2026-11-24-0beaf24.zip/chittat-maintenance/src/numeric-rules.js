export const quantityInput = value => /^\d{0,5}$/.test(String(value));
export const validQuantity = value => /^\d+$/.test(String(value)) && Number.isSafeInteger(Number(value)) && Number(value) >= 0 && Number(value) <= 10000;
export const moneyInput = value => /^\d{0,9}(?:\.\d{0,2})?$/.test(String(value));
export const validMoney = value => /^\d+(?:\.\d{1,2})?$/.test(String(value)) && Number(value) <= 100000000;
