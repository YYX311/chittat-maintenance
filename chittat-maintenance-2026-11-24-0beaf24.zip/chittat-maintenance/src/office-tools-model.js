import {validQuantity} from "./numeric-rules.js";
import { uid, total } from "./workspace-model.js";

export const familyOf = (ref) => String(ref).replace(/(?:R\d+|[A-Za-z])$/, "");
export function effectiveQuote(r) {
  if (["revision","draft"].includes(r.status) && r.approvedSnapshot) return {...r,...r.approvedSnapshot,discountAmount:r.approvedSnapshot.discountAmount??"0",ledger:r.ledger,history:r.history,id:r.id};
  if (r.status === "revision" && r.history?.length) {
    return {
      ...r,
      ...r.history.at(-1).snapshot,
      discountAmount:r.history.at(-1).snapshot.discountAmount??"0",
      ledger: r.ledger,
      history: r.history,
      id: r.id,
    };
  }
  return r;
}
export function currentQuotes(records) {
  const map = new Map();
  records
    .filter((r) => r.ref)
    .forEach((r) => {
      const q = effectiveQuote(r),
        key = familyOf(q.ref);
      const rank = Number(q.ref.match(/R(\d+)$/)?.[1] || q.rev || 0);
      const old = map.get(key);
      if (!old || rank >= old.rank) map.set(key, { record: r, quote: q, rank });
    });
  return [...map.values()];
}
export function summarize(records, blankX = false) {
  return currentQuotes(records)
    .map(({ record, quote }) => {
      const ledger = (record.ledger || []).filter((row) => !blankX || !row[12]);
      const invoices = new Map();
      ledger.forEach((row, n) => {
        if (!row[15] && !Number(row[18])) return;
        const key = String(row[15] || `${record.id}-${n}`);
        if (!invoices.has(key))
          invoices.set(key, {
            amount: Number(row[18] || 0),
            paid: 0,
            payments: new Set(),
            excluded: row[12] === "X",
          });
        const inv = invoices.get(key);
        inv.amount = Math.max(inv.amount, Number(row[18] || 0));
        const payment = JSON.stringify([row[19], row[20], row[21]]);
        if (!inv.payments.has(payment)) {
          inv.paid += Number(row[20] || 0);
          inv.payments.add(payment);
        }
      });
      const list = [...invoices.values()];
      return {
        id: record.id,
        ref: quote.ref,
        address: quote.address,
        quote: total(quote),
        invoice: list.reduce((s, i) => s + Math.round(i.amount*100), 0)/100,
        received: list.reduce((s, i) => s + Math.round(i.paid*100), 0)/100,
        outstanding: list.reduce(
          (s, i) => s + (i.excluded ? 0 : Math.round(i.amount*100) - Math.round(i.paid*100)),
          0,
        )/100,
        versions: record.history?.length || 1,
        record,
      };
    })
    .filter(
      (v) =>
        !blankX ||
        !v.record.ledger.length ||
        v.record.ledger.some((r) => !r[12]),
    );
}
export function extractProjects(sheets) {
  const projects = [];
  for (const sheet of sheets) {
    // Detect structure, not a hard-coded project or worksheet name.
    const rows = sheet.rows || [];
    if (rows[0]?.[0] === "Project name" && rows[0]?.[1] === "Property") {
      const groups = new Map();
      rows.slice(1).forEach((row) => {
        if (!row[1]) return;
        const key = JSON.stringify(row.slice(0, 7));
        if (!groups.has(key))
          groups.set(key, {
            id: uid(),
            name: row[0] || "",
            property: row[1],
            contractRef: row[2] || "",
            coverage: row[3] || "unknown",
            coverageNotes: row[4] || "",
            brand: row[5] || "",
            itemTerms: row[6] || "",
            references: [],
          });
        if (row[7])
          groups
            .get(key)
            .references.push({
              id: uid(),
              description: row[7],
              price: row[8] ?? "",
              remark: row[9] || "",
            });
      });
      projects.push(...groups.values());
      continue;
    }
    for (let r = 0; r < rows.length - 3; r++) {
      if (!rows[r].some((v) => String(v).trim() === "Project")) continue;
      const starts = [];
      for (let c = 0; c < (rows[r + 2] || []).length; c++)
        if (/^Brand\s*:/i.test(String(rows[r + 2][c] || "")) && /^(價錢|价钱|Price)$/i.test(String(rows[r+3]?.[c+1]||'').trim())) starts.push(c);
      for (const c of starts) {
        const property = String(rows[r + 1]?.[c] || "").trim();
        if (!property) continue;
        const context = String(rows[r]?.[c] || "").trim();
        const project = {
          id: uid(),
          name: "",
          property,
          contractRef: context.match(/CT[A-Z0-9-]+/i)?.[0] || "",
          coverage: /無保養/.test(context)
            ? "none"
            : /已完/.test(context)
              ? "expired"
              : context
                ? "contract"
                : "unknown",
          coverageNotes: context,
          brand: String(rows[r + 2]?.[c] || "").replace(/^Brand\s*:\s*/i, ""),
          itemTerms: String(rows[r + 3]?.[c] || ""),
          references: [],
        };
        for (let j = r + 4; j < rows.length; j++) {
          if (rows[j]?.some((v) => String(v).trim() === "Project")) break;
          const description = String(rows[j]?.[c] || "").trim();
          if (!description) continue;
          project.references.push({
            id: uid(),
            description,
            price: rows[j]?.[c + 1] ?? "",
            remark: String(rows[j]?.[c + 2] || ""),
          });
        }
        projects.push(project);
      }
    }
  }
  return projects;
}
export function projectRows(projects) {
  return [
    [
      "Project name",
      "Property",
      "Contract / quotation reference",
      "Coverage",
      "Coverage notes",
      "Brand",
      "Item terms",
      "Quotation item",
      "Price",
      "Remark",
    ],
    ...projects.flatMap((p) =>
      (p.references.length ? p.references : [{}]).map((i) => [
        p.name,
        p.property,
        p.contractRef,
        p.coverage,
        p.coverageNotes,
        p.brand,
        p.itemTerms,
        i.description || "",
        i.price ?? "",
        i.remark || "",
      ]),
    ),
  ];
}
export function parseItemPaste(text) {
  const errors = [];
  const items = text
    .trim()
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line, n) => {
      const [description, qty, model = "", price = "", brand = ""] =
        line.split("\t");
      if (
        !description ||
        !(validQuantity(qty)) ||
        (price !== "" && (!Number.isFinite(Number(price)) || Number(price) < 0))
      )
        errors.push(n + 1);
      return {
        id: uid(),
        preset: 14,
        description,
        qty: Number(qty),
        model,
        price,
        brand,
      };
    });
  if (items.length > 100) errors.push("limit");
  return { items, errors };
}
export function parseLedgerPaste(text, records) {
  const errors = [],
    changes = [];
  text
    .trim()
    .split(/\r?\n/)
    .filter(Boolean)
    .forEach((line, n) => {
      const [
        ref,
        invoiceRef,
        date,
        amount,
        receivedDate = "",
        received = "",
        paidBy = "",
      ] = line.split("\t");
      const record = records.find(
        (r) => r.ref === ref && r.status === "issued",
      );
      const validDate = (v) =>
        !v || (/^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v)));
      if (
        !record ||
        !invoiceRef ||
        !date ||
        !validDate(date) ||
        !validDate(receivedDate) ||
        !Number.isFinite(Number(amount)) ||
        Number(amount) < 0 ||
        amount === "" ||
        (received !== "" &&
          (!Number.isFinite(Number(received)) || Number(received) < 0))
      ) {
        errors.push(n + 1);
        return;
      }
      const row = Array(33).fill("");
      Object.assign(row, {
        14: date,
        15: invoiceRef,
        18: Number(amount),
        19: receivedDate,
        20: received === "" ? "" : Number(received),
        21: paidBy,
      });
      changes.push({ recordId: record.id, row });
    });
  if (changes.length > 100) errors.push("limit");
  const keys = new Set(
    records.flatMap((r) => r.ledger.map((row) => row[15]).filter(Boolean)),
  );
  changes.forEach((c, i) => {
    if (keys.has(c.row[15])) errors.push(i + 1);
    keys.add(c.row[15]);
  });
  return { changes, errors: [...new Set(errors)] };
}
