export function normalizeLoginPhone(input) {
  const compact = String(input || "").trim().replace(/[\s()-]/g, "");
  const normalized = /^\d{8}$/.test(compact) ? `+852${compact}` : compact;
  if (!/^\+[1-9]\d{7,14}$/.test(normalized)) throw new Error("invalid-phone");
  return normalized;
}
