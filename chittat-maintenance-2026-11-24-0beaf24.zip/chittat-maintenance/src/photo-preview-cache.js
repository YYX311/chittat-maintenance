import {sessionToken} from "./session-fetch.js";
let owner=null;
const photos=new Map();
function current(){const token=sessionToken();if(owner!==token){photos.clear();owner=token;}return photos;}
export function rememberPhoto(key,blob){const cache=current();cache.set(key,blob);while(cache.size>20)cache.delete(cache.keys().next().value);}
export function rememberedPhoto(key){return current().get(key);}
