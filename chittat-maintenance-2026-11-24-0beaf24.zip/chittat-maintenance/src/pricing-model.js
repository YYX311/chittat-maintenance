import {moneyInput,validMoney} from "./numeric-rules.js";
export function priceDraftValue(item, drafts) {
  return Object.hasOwn(drafts, item.id) ? drafts[item.id] : String(item.price ?? "");
}

export function updatePriceDraft(drafts, id, value) {
  return moneyInput(value) ? { ...drafts, [id]: value } : drafts;
}

export function clearPriceDraft(drafts, id) {
  const next = { ...drafts };
  delete next[id];
  return next;
}

export function confirmedPrice(value) {
  const text = String(value).trim();
  if (!validMoney(text)) return null;
  const price = Number(text);
  return Number.isFinite(price) ? price : null;
}
