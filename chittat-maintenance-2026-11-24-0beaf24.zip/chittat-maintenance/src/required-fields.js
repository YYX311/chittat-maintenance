export const requiredFields = [
 ["date",0,"日期","Date"], ["address",0,"工作地點","Work location"],
 ["tower",0,"座數","Tower"], ["floor",0,"樓層","Floor"], ["flat",0,"單位","Flat"],
 ["customer",0,"客戶名稱","Customer"], ["contact",0,"聯絡人","Contact"],
 ["occupant",0,"住戶資料","Occupant"], ["phone",0,"聯絡電話","Phone"],
 ["notes",2,"現場描述","Site description"],
 ["startedAt",2,"開工時間","Commencement time"], ["completedAt",2,"完工時間","Completion time"],
];
const calendarFields = new Set(["date", "startedAt", "completedAt"]);
export function requiredIssues(record,worker) {
 const result=requiredFields.filter(([key])=>!String(record[key]??"").trim()).map(([field,step,hk,en])=>({
  field,
  step:!worker&&step===2&&field!=="notes"?3:step,
  hk:calendarFields.has(field)?`請選擇${hk}。`:`請填寫${hk}；不適用的資料請填「不適用」。`,
  en:calendarFields.has(field)?`Select ${en}.`:`Enter ${en}; enter N/A where not applicable.`,
 }));
 for(const item of record.items||[])for(const [field,hk,en] of [["model","型號","model"],["brand","品牌","brand"]]) {
  if(!String(item[field]||(field==="brand"?record.brand:"")||"").trim())result.push({field,itemId:item.id,step:1,hk:`請填寫工作項目的${hk}；不適用請填「不適用」。`,en:`Enter item ${en}, or N/A.`});
 }
 if(worker)for(const [field,label] of [["startedAt","開工時間"],["completedAt","完工時間"]]) {
  if(record[field]&&!record.timeConfirmed?.[field])result.push({field,step:2,hk:`請按「確認日期」確認${label}後繼續。`,en:"Confirm the selected date before continuing."});
 }
 return result;
}
