export const observationRelease='workflow-assistant-2026-11-06';
// Only known case operations are classified. Never transmit arbitrary URLs/bodies.
export function operationFor(path,options={}) {
  if(typeof path!=='string'||!['POST','PATCH','DELETE'].includes(String(options.method||'GET').toUpperCase()))return null;
  const m=/^\/api\/cases\/([\w-]{1,100})(?:\/(actions|assets|documents))?$/.exec(path);
  if(!m)return null;
  let operation=m[2]||'save';
  if(operation==='actions') {
    let action;try{action=JSON.parse(options.body).action;}catch{return null;}
    if(!['submit','return','confirm','reopen'].includes(action))return null;
    operation=action;
  }
  return {caseId:m[1],operation};
}
export function outcomeFor(status) {return status===0?'network':status===409?'conflict':status>=500?'server_error':status>=400?'rejected':'ok';}
export function recordRuntime(fetcher,token,operation,start,status) {
  if(!operation||!token)return;
  try {
    const id=globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(36).slice(2)}`;
    void fetcher('/api/research/runtime',{method:'POST',credentials:'omit',keepalive:true,signal:AbortSignal.timeout(5000),
      headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},
      body:JSON.stringify({...operation,id,outcome:outcomeFor(status),durationMs:Math.min(300000,Math.max(0,Math.round(performance.now()-start))),release:observationRelease})}).catch(()=>{});
  }catch{/* Diagnostics must never block a business operation. */}
}
