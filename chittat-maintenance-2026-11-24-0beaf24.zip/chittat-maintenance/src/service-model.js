// Current workflow: one confirmed row per quotation; documents are immutable snapshots.
export const INDEX_COLUMNS = ["No.","QUO. Date","QUO ref. no.","Q-rev.","Tower","Floor","Flat","Location","Description","QUO. Amount","CUS.","Attn."];
export const REMARK_TEMPLATES = [
 {id:"inspect",name:"檢查冷氣機",en:"AC inspection",text:"1. 上述報價不包第三者責任保險\n2. 上述工程只包括現場檢查, 零件/特別維持需另行報價\n3. 如需搭棚需另行報價\n4. 上述工程不包括開任何生口,開天花及油柒及批灰\n5. 上述工程不包括做任何保護牆身，地板及家具\n6. 需要確認報價才安排工作"},
 {id:"replace",name:"更換冷氣機",en:"AC replacement",text:"1. 上述報價不包第三者責任保險\n2. 上述工程只包括換機, 額外檢查, 零件/特別維持需另行報價\n3. 如需搭棚需另行報價\n4. 上述工程不包括開任何生口,開天花及油柒及批灰\n5. 上述工程不包括做任何保護牆身，地板及家具\n6. 如開機後有問題亦需要三菱檢查\n7. 訂機需要時, 需由本公司確認\n8. 需要確認報價才安排工作\n9. 此報價單由發出日起計30天內生效。"},
 {id:"clean",name:"清洗冷氣機",en:"AC cleaning",text:"1. 上述報價不包第三者責任保險\n2. 上述工程只包括洗機, 額外檢查, 零件/特別維持需另行報價\n3. 如需搭棚或吊船需另行報價\n4. 上述工程不包括做任何保護牆身及家具, 如需要另外收HK$3,000\n5. 需要確認報價才安排工作\n6. 上述工程不包括開任何生口, 開天花及油漆及批灰\n7. 上述工程不包括鎅除室内冷氣機側玻璃膠\n8. 清洗冷氣機不包括清通去水主喉及橫喉, 清洗需另行報價\n9. 清洗後保養只包滴水及漏水14天"},
 {id:"parts",name:"更換零件",en:"Parts replacement",text:"1. 上述報價不包第三者責任保險\n2. 上述工程不包括開任何生口,開天花及油柒及批灰\n3. 上述工程不包括做任何保護牆身，地板及家具, 如需要額外加$3000元\n4. 上述工程只包括更換零件\n5. 不包搭棚及工作台\n6. 需要確認報價才安排工作\n7. 此報價單由發出日起計30天內生效。\n8. 僅涵蓋安裝保養期為90天, 不包括機件保養"}
];
export const safeName = v => String(v || "task").replace(/[<>:"/\\|?*\x00-\x1f]/g,"_").slice(0,100);
export const packageTimestamp = (date = new Date()) => new Intl.DateTimeFormat("en-CA", {
 timeZone:"Asia/Hong_Kong",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"
}).formatToParts(date).reduce((parts,part)=>(parts[part.type]=part.value,parts),{});
export const documentPackageName = (records, date = new Date()) => {
 const p=packageTimestamp(date),stamp=`${p.year}${p.month}${p.day}_${p.hour}${p.minute}${p.second}`;
 return records.length===1?safeName(`${records[0].ref}_Rev${records[0].rev||0}_Q-I_${stamp}.zip`):`CT_QI_${stamp}_${records.length}records.zip`;
};
export const assetGroup = r => safeName((r.projectName||r.address||"工程")+"_"+(r.serviceNo||r.entryNo||r.id));
export const serviceDescription = (r,name) => r.items.map((i,n)=>`${n+1}. ${name(i)} × ${i.qty} ${i.unit||"no."}  ${i.brand||r.brand||""} ${i.model||""}`).join("\n");
export const serviceFields = [
 ["startedAt","開工時間／日期","Commencement time / date","date"],
 ["completedAt","完工時間／日期","Completion time / date","date"],
 ["contractRef","合約／報價編號（如有）","Contract / quotation no. (if any)","text"],
 ["material","材料（如有）","Materials (if any)","textarea"],
 ["serviceRemark1","備註一（補充）","Service remarks 1 (optional)","textarea"],
 ["serviceRemark2","備註二（補充）","Service remarks 2 (optional)","textarea"],
 ["serviceRemark3","備註三（補充）","Service remarks 3 (optional)","textarea"],
];
export function serviceError(r) {
 if(!r.phone?.trim()) return ["phone","請填寫客戶聯絡電話。","Enter the customer's phone number."];
 if(!r.startedAt) return ["startedAt","請填寫開工時間。","Enter commencement time."];
 if(r.completedAt && r.completedAt.slice(0,10)<r.startedAt.slice(0,10)) return ["completedAt","完工時間不能早於開工時間。","Completion cannot be before commencement."];
 return null;
}
