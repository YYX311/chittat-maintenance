import {operationFor,recordRuntime} from './runtime-observation';
function reportSlow(operation,start) {
  if (operation && performance.now()-start>=1500 && typeof window!=="undefined") {
    window.dispatchEvent(new CustomEvent("field-study-slow",{detail:operation.caseId}));
  }
}
const KEY = "ct-tab-session-v1";
const WORKSPACE_ROLE_KEY = "ct-workspace-role";
export function selectedWorkspaceRole() {
  return sessionStorage.getItem(WORKSPACE_ROLE_KEY);
}
export function setWorkspaceRole(role) {
  if (role) sessionStorage.setItem(WORKSPACE_ROLE_KEY, role);
  else sessionStorage.removeItem(WORKSPACE_ROLE_KEY);
}
export function sessionToken() {
  try { return sessionStorage.getItem(KEY); } catch { return null; }
}
export function setSessionToken(token) {
  if (token) sessionStorage.setItem(KEY, token);
  else sessionStorage.removeItem(KEY);
}
// Each tab owns its session. Never fall back to a different account's shared cookie.
export async function sessionFetch(path, options = {}) {
  const token = sessionToken();
  if (!token) throw Object.assign(new Error("unauthorized"), { status: 401 });
  const headers = new Headers(options.headers);
  headers.set("Authorization", `Bearer ${token}`);
  const selectedRole = selectedWorkspaceRole();
  if (selectedRole) headers.set("X-Workspace-Role", selectedRole);
  const operation=operationFor(path,options),start=performance.now();
  try {
    const response=await fetch(path, { ...options, headers, credentials: "omit", cache: "no-store",
      signal: options.signal || AbortSignal.timeout(30000) });
    reportSlow(operation,start);
    recordRuntime(fetch,token,operation,start,response.status);return response;
  }catch(error){reportSlow(operation,start);recordRuntime(fetch,token,operation,start,0);throw error;}
}
