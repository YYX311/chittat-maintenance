import {validQuantity} from "./numeric-rules.js";
export function missingDetails(r) {
 const list=[];
 const add=(field,h,e,screen,itemId)=>list.push({id:"missing-"+field+(itemId||""),field,text:h,en:e,screen,itemId,missing:true});
 if(!r.date)add("date","請填寫日期","Enter the date","worker-basic");
 if(!r.address?.trim())add("address","請填寫工作地點","Enter the work location","worker-basic");
 if(!r.customer?.trim())add("customer","請填寫客戶名稱","Enter the customer name","worker-basic");
 if(!r.phone?.trim())add("phone","請填寫客戶聯絡電話","Enter the customer phone number","worker-basic");
 if(!r.items?.length)add("items","請新增工作項目","Add a work item","worker-work");
 (r.items||[]).forEach((i,n)=>{if(!validQuantity(i.qty))add("qty","請填寫第 "+(n+1)+" 項的有效數量","Enter a valid quantity for item "+(n+1),"worker-work",i.id)});
 if(!r.startedAt)add("startedAt","請填寫開工時間","Enter the commencement time","worker-photo");
 if(r.startedAt&&r.completedAt&&r.completedAt.slice(0,10)<r.startedAt.slice(0,10))add("completedAt","完工時間不能早於開工時間","Completion cannot be before commencement","worker-photo");
 if(!r.photos?.length&&!r.notes?.trim())add("notes","請加入現場相片或描述","Add a site photo or description","worker-photo");
 return list;
}
export function statusTone(r) {
 // Urgent action always takes priority over a revision badge.
 if(["editing","needsInfo","draft"].includes(r.status))return r.status;
 if(r.status==="revision")return "revision";
 return r.status;
}
export function nextServiceNumber(state) {
 const used=state.records.map(r=>Number(r.serviceNo?.match(/^CT-MNA-(\d+)$/)?.[1]||0));
 return Math.max(Number(state.serviceCounter||0),0,...used)+1;
}
export function projectRegistry(state) {
 const map=new Map((state.projectRegistry||[]).map(p=>[p.id,p]));
 state.records.forEach(r=>{
  if(!r.projectCode||map.has(r.projectId))return;
  if([...map.values()].some(p=>p.code.toLowerCase()===r.projectCode.toLowerCase()))return;
  const id=r.projectId||"legacy-project-"+r.projectCode;
  map.set(id,{id,code:r.projectCode,name:r.projectName||r.address,property:r.address});
 });
 return [...map.values()];
}
