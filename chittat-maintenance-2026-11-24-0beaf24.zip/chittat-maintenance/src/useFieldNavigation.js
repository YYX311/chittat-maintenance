import {useEffect,useState} from "react";

// Focus controls keyboard mode; no scroll listener or per-keystroke global state.
export function useFieldNavigation(worker,screen,id) {
 const [typing,setTyping]=useState(false);
 useEffect(()=>{
  if(!worker)return;
  const editable=el=>el instanceof Element&&!!el.closest('input:not([type="checkbox"]):not([type="radio"]):not([type="file"]),textarea,select,[contenteditable="true"]');
  const focus=e=>setTyping(editable(e.target));
  const blur=()=>queueMicrotask(()=>setTyping(editable(document.activeElement)));
  const blank=e=>{
   if(e.target instanceof Element&&!e.target.closest('input,textarea,select,button,a,label,[role="button"],[contenteditable="true"]')){
    if(editable(document.activeElement))document.activeElement.blur();
    setTyping(false);
   }
  };
  document.addEventListener("focusin",focus);
  document.addEventListener("focusout",blur);
  document.addEventListener("pointerdown",blank);
  return()=>{document.removeEventListener("focusin",focus);document.removeEventListener("focusout",blur);document.removeEventListener("pointerdown",blank);};
 },[worker]);
 useEffect(()=>{setTyping(false);const frame=requestAnimationFrame(()=>window.scrollTo({top:0,behavior:"instant"}));return()=>cancelAnimationFrame(frame)},[screen,id]);
 return worker&&typing;
}
