import {validQuantity} from "./numeric-rules.js";
import {netTotal as total, discount, validDiscount} from "./commercial-totals.js";
// Shared presentation helpers. Business records are loaded from the server workspace API.
export const STORE = "ct-workspace-v4";
export const SHEETS = ["INDEX_"+new Date().toLocaleDateString("en-CA",{timeZone:"Asia/Hong_Kong"}).slice(0,4)];
export const HEADERS = [
  "No.",
  "QUO. Date",
  "QUO ref. no.",
  "Q-rev.",
  "Tower",
  "Floor",
  "Flat",
  "Location",
  "Description",
  "QUO. Amount",
  "CUS.",
  "Attn.",
  "X",
  "Signed Date",
  "INV. Date",
  "INV ref. no.",
  "I-rev.",
  "IP#",
  "INV. Amount",
  "Received Date",
  "Received Amount",
  "Paid by",
  "Outstanding Amount",
  "Project Code",
  "舊QUO / INV.",
  "負責人",
  "Parts",
  "2024",
  "RECEIVED:",
  "0.00",
  "",
  "Today =",
  "=TODAY()",
];
export const ADDRESSES = [
  "大埔仔 Mount Pavilia",
  "Park Mediterranean",
  "露輝路",
  "御半山TM515",
  "6574",
  "天寰",
  "西貢133 Portofino",
  "古洞",
  "6563",
  "6552",
  "鴨脷洲-凱玥",
  "山頂",
  "Koko Hill 1&2期",
  "Grand Napa",
  "K11 BMS",
  "星堤",
  "上鄉道",
  "維港匯",
  "司徒拔道松柏新村",
  "污水廠",
  "The Campton 營盤街",
  "柏傲山",
  "種植道保養",
  "6553",
  "6575",
  "亞皆老街",
  "太子道西Prince Central",
  "Oasis Kai Tak",
  "御海灣",
  "嘉享灣",
  "比華利山",
  "J&J",
  "大寶閣",
  "西洋菜北街 (曉栢峰)",
  "Wetland Seasons Bay (濕地33)",
  "翠濤閣",
  "瑧頤",
  "瑧蓺",
  "黃竹坑站四期",
  "6576",
  "醫局街",
  "瑧樺Timber House",
  "喜匯",
  "Koko Hill 3期",
  "溱柏",
  "LOHAS Park Phase 11凱柏峰",
  "連方1期",
  "維港匯GV3",
  "杏花邨",
  "瑧尚",
  "荃灣映日灣",
];
export const ITEMS = [
  ["inspect", "檢查室外機", "Inspect outdoor unit"],
  ["inspect", "檢查室內機", "Inspect indoor unit"],
  ["replace", "更換室內機", "Replace indoor unit"],
  ["replace", "更換室外機", "Replace outdoor unit"],
  ["purchase", "購買室內機", "Purchase indoor unit"],
  ["purchase", "購買室外機", "Purchase outdoor unit"],
  ["clean", "清洗室內機連塵網", "Clean indoor unit and filter"],
  ["clean", "清洗室內機去水喉", "Clean indoor drain pipe"],
  ["clean", "清洗室內機去水泵及水盤", "Clean indoor pump and drain pan"],
  [
    "replace",
    "代購更換室內機電子板",
    "Purchase and replace indoor control board",
  ],
  [
    "replace",
    "代購更換室外機電子板",
    "Purchase and replace outdoor control board",
  ],
  ["replace", "更換電掣", "Replace electrical switch"],
  ["replace", "更換控制線", "Replace control cable"],
  ["replace", "更換保溫棉", "Replace insulation"],
  ["other", "其他", "Other"],
];
export const uid = () => {
  const cryptoApi = globalThis.crypto;
  if (typeof cryptoApi?.randomUUID === "function") return cryptoApi.randomUUID();
  const bytes = new Uint8Array(16);
  if (typeof cryptoApi?.getRandomValues === "function") cryptoApi.getRandomValues(bytes);
  else for (let index = 0; index < bytes.length; index += 1) bytes[index] = Math.floor(Math.random() * 256);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = [...bytes].map((value) => value.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
};
export const today = () =>
  new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Hong_Kong" });
export function makeRecord(source = "office") {
  const id = uid();
  return {
    id,
    entryNo: source==="office" ? "" : "DRAFT-"+id.slice(0,8).toUpperCase(),
    source,
    owner: "worker@chittat.hk",
    status: source === "worker" ? "editing" : "draft",
    ref: "",
    rev: 0,
    date: today(),
    customerType: "property",
    projectName: "",
    contractRef: "",
    brand: "",
    coverage: "unknown",
    coverageNotes: "",
    customer: "",
    contact: "",
    phone: "",
    occupant: "",
    address: "",
    tower: "",
    floor: "",
    flat: "",
    technician: source === "worker" ? "Mr. Yeung" : "Sammi Cheng",
    items: [],
    discountAmount: "0",
    photos: [],
    notes: "",
    remark: "",
    startedAt: "",
    completedAt: "",
    material: "",
    serviceRemark1: "",
    serviceRemark2: "",
    serviceRemark3: "",
    serviceNo: "",
    invoiceHistory: [],
    feedback: [],
    history: [],
    ledger: [],
    createdAt: new Date().toISOString(),
  };
}
export function readStore() {
  return runtimeStore;
}
export const emptyWorkspace = () => ({
  version: 4, records: [], sheets: [], sampleRows: [], parts: [], projects: [],
  counters: { worker: 0, office: 0 }, entryCounter: 0, serviceCounter: 0,
});
let runtimeStore = emptyWorkspace();
export function setRuntimeStore(next) { runtimeStore = next; }
export function normalizeTaskNumbers(state) {
  let office=Math.max(0,Number(state.entryCounter||0),...state.records.map(r=>Number(r.entryNo?.match(/^REC-CT-MNA-(\d+)$/)?.[1]||0)));
  let service=Math.max(0,Number(state.serviceCounter||0),...state.records.map(r=>Number(r.serviceNo?.match(/^CT-MNA-(\d+)$/)?.[1]||0)));
  const records=state.records.map(r=>{
    if(r.source==="office"&&!/^REC-CT-MNA-\d+$/.test(r.entryNo||""))return {...r,legacyEntryNo:r.entryNo,entryNo:"REC-CT-MNA-"+String(++office).padStart(4,"0")};
    if(r.source==="worker"&&r.status!=="editing"&&!r.serviceNo)return {...r,serviceNo:"CT-MNA-"+String(++service).padStart(4,"0")};
    return r;
  });
  return {...state,records,entryCounter:office,serviceCounter:service};
}
export { netTotal as total } from "./commercial-totals.js";
export function itemName(item, lang = "en") {
  return item.description || ITEMS[item.preset]?.[lang === "en" ? 2 : 1] || "";
}
export function completeness(r) {
  const checks = [r.date, r.address.trim(), r.customer.trim(), r.technician.trim(),r.phone?.trim(),r.startedAt,
    r.items.length > 0, r.items.length > 0 && r.items.every(i => validQuantity(i.qty)),
    r.photos.length > 0, Boolean(r.notes.trim() || r.photos.some(p=>p.caption?.trim()))];
  const flags = [
    Boolean(r.date && r.address && r.customer && r.phone),
    r.items.length > 0 && r.items.every((i) => validQuantity(i.qty)),
    Boolean(r.startedAt && (r.photos.length > 0 || r.notes.trim())),
    r.status !== "editing",
  ];
  return { flags, percent: Math.round(checks.filter(Boolean).length/checks.length*100) };
}
export function formalSignature(r) {
  return JSON.stringify({
    discountAmount: discount(r),
    fields: [
      "date",
      "address",
      "tower",
      "floor",
      "flat",
      "customer",
      "contact",
      "technician",
      "remark",
      "brand",
      "projectName",
      "projectId",
      "projectCode",
      "contractRef",
      "paymentTerms",
      "phone",
    ].map((k) => String(r[k] ?? "")),
    items: r.items.map((i) => ({
      description: i.description || "",
      preset: i.preset,
      qty: Number(i.qty),
      price: i.price === "" ? null : Number(i.price),
      model: i.model || "",
      brand: i.brand || "",
    })),
  });
}
export function issueRecord(state, id) {
  const record = state.records.find((r) => r.id === id);
  if (!record || !["draft", "revision"].includes(record.status))
    throw new Error("invalid-state");
  if (!validDiscount(record)) throw new Error("invalid-discount");
  if (
    !record.customer.trim() ||
    !record.address.trim() ||
    !record.items.length ||
    record.items.some(
      (i) =>
        !itemName(i).trim() ||
        !(validQuantity(i.qty)) ||
        i.price === "" ||
        !Number.isFinite(Number(i.price)) ||
        Number(i.price) < 0,
    )
  )
    throw new Error("missing-fields");
  const prior = record.history?.at(-1)?.snapshot;
  if (
    record.status === "revision" &&
    prior &&
    formalSignature(record) === formalSignature(prior)
  )
    return {
      ...state,
      records: state.records.map((r) =>
        r.id === id ? { ...r, status: "issued", rev: prior.rev || 0 } : r,
      ),
    };
  const year = today().slice(2,4);
  const base = `CT-MNA${year}-Q-${record.source === "worker" ? "S-" : ""}`;
  const count = Math.max(Number(state.counters[record.source]||1),...state.records.filter(r=>r.ref?.startsWith(base)).map(r=>Number(r.ref.slice(base.length).match(/^\d+/)?.[0]||0)+1));
  const ref =
    record.ref ||
    base+String(count).padStart(3, "0");
  const issued = { ...record, ref, status: "issued" };
  issued.history = [
    ...record.history,
    {
      at: new Date().toISOString(),
      rev: record.rev,
      snapshot: structuredClone({ ...issued, history: [] }),
    },
  ];
  return {
    ...state,
    counters: record.ref
      ? state.counters
      : { ...state.counters, [record.source]: count + 1 },
    records: state.records.map((r) => (r.id === id ? issued : r)),
  };
}
export function beginRevision(record) {
  if (record.status !== "issued") return record;
  return { ...record, status: "revision", rev: record.rev + 1 };
}
export function toIndexRows(r, lang = "en", n = 1) {
  const rows = r.ledger.length ? r.ledger : [Array(33).fill("")];
  return rows.map((row, idx) => {
    const v = Array.from({ length: 33 }, (_, i) => row[i] ?? "");
    Object.assign(v, {
      0: v[0] || Number(r.ref?.match(/^CT-MNA\d{2}-Q-(?:S-)?(\d+)/)?.[1]) || n,
      1: idx ? "" : r.date,
      2: r.ref || "",
      3: r.rev || v[3] || "",
      4: r.tower,
      5: r.floor,
      6: r.flat,
      7: r.address,
      8: r.items.map((i) => itemName(i, lang)).join("; "),
      9: idx ? "" : total(r),
      10: r.customer,
      11: r.contact,
      25: r.technician,
      23: r.projectCode || v[23],
    });
    // Original W formula: excluded rows are blank; otherwise invoice minus receipts.
    v[22] = v[12] === "X" ? "" : Number(v[18] || 0) - Number(v[20] || 0);
    return v;
  });
}
export function normalizeCell(value) {
  if (value == null) return "";
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  if (typeof value === "object") {
    if ("formula" in value || "sharedFormula" in value)
      return normalizeCell(value.result);
    if (value.richText) return value.richText.map((t) => t.text).join("");
    return value.text || "";
  }
  return value;
}
export function parseIndex(sheet, existing = []) {
  const header = sheet.rows[0] || [];
  const errors = [];
  HEADERS.slice(0, 12).forEach((h, i) => {
    if (String(header[i] ?? "").trim() !== h)
      errors.push(`Column ${i + 1}: ${h}`);
  });
  if (errors.length) return { records: [], errors, duplicates: 0, rowCount: 0 };
  const groups = new Map();
  const seen = new Set(existing.map((r) => r.ref).filter(Boolean));
  let duplicates = 0,
    rowCount = 0;
  for (let ri = 1; ri < sheet.rows.length; ri++) {
    const row = sheet.rows[ri];
    if (!row?.[2]) continue;
    const ref = String(row[2]).trim();
    rowCount++;
    if (seen.has(ref)) {
      duplicates++;
      continue;
    }
    if (!/^CT-MNA\d{2}-Q-(?:S-)?\d+(?:[A-Za-z]\d*)?$/.test(ref)) {
      errors.push(`Row ${ri + 1}: QUO ref. no.`);
      continue;
    }
    if (
      [9].some(
        (i) =>
          row[i] !== "" &&
          row[i] != null &&
          (!Number.isFinite(Number(row[i])) || Number(row[i]) < 0),
      )
    ) {
      errors.push(`Row ${ri + 1}: Amount`);
      continue;
    }
    if (!String(row[1] || "").trim() || !String(row[7] || "").trim() ||
      !String(row[8] || "").trim() || !String(row[10] || "").trim()) {
      errors.push(`Row ${ri + 1}: Date, Location, Description and CUS. are required`);
      continue;
    }
    if (!groups.has(ref)) {
      const r = makeRecord(ref.includes("-S-") ? "worker" : "office");
      Object.assign(r, {
        ref,
        status: "issued",
        date: row[1] || "",
        legacyRev: row[3] || "",
        rev: Number(String(row[3]||"0").replace(/[^0-9]/g,""))||0,
        tower: row[4] || "",
        floor: row[5] || "",
        flat: row[6] || "",
        address: String(row[7] || ""),
        customer: String(row[10] || ""),
        contact: String(row[11] || ""),
        technician: String(row[25] || ""),
        items: [
          {
            id: uid(),
            preset: 14,
            description: String(row[8] || ""),
            qty: 1,
            model: "",
            price: Number(row[9] || 0),
          },
        ],
        imported: true,
      });
      groups.set(ref, r);
    }
    groups.get(ref).ledger = [];
  }
  const records = [...groups.values()];
  return { records, errors, duplicates, rowCount };
}
