// Keep canonical server versions separate from unsaved form values.
export function mergeWorkspace(remote, canonical, local, dirtyIds, requestedVersions = new Map()) {
  const records = remote.records.map(incoming => {
    const known = canonical.get(incoming.id);
    // A conditional list refresh may omit snapshots already loaded for this version.
    const current = known?.serverVersion >= incoming.serverVersion ? known : incoming;
    const draft = dirtyIds.has(current.id) && local.records.find(r => r.id === current.id);
    // A remote edit during local typing must still fail the optimistic lock.
    if (!draft || !known) canonical.set(current.id, current);
    return draft ? { ...draft, serverVersion: known?.serverVersion ?? current.serverVersion, localOnly: false } : current;
  });
  for (const draft of local.records) {
    if (draft.localOnly && !records.some(r => r.id === draft.id)) records.push(draft);
    else if (!records.some(r => r.id === draft.id) && canonical.has(draft.id) &&
      (!requestedVersions.has(draft.id) || canonical.get(draft.id).serverVersion > requestedVersions.get(draft.id))) records.push(draft);
  }
  return { ...remote, records };
}
