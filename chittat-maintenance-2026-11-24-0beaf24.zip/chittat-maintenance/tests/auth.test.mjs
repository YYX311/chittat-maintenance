import assert from "node:assert/strict";
import test from "node:test";
import { normalizeLoginPhone } from "../src/phone.js";

test("login phone normalizes eight-digit Hong Kong numbers", () => {
  assert.equal(normalizeLoginPhone("9123 4567"), "+85291234567");
  assert.equal(normalizeLoginPhone("+852 9123-4567"), "+85291234567");
  assert.throws(() => normalizeLoginPhone("000"), /invalid-phone/);
});

test("public sign-up and OTP entry points are unavailable", async () => {
  process.env.BETTER_AUTH_SECRET ||= "test-only-secret-more-than-32-characters";
  process.env.BETTER_AUTH_URL ||= "http://localhost:3000";
  const { auth } = await import("../lib/auth.ts");
  for (const path of ["sign-up/email", "phone-number/send-otp", "phone-number/verify"]) {
    const response = await auth.handler(new Request(`http://localhost:3000/api/auth/${path}`, {
      method: "POST", headers: { "content-type": "application/json" }, body: "{}",
    }));
    assert.equal(response.status, 404, path);
  }
});
