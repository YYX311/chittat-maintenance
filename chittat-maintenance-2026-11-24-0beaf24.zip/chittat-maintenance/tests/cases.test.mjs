import {completeFields,completeItem} from "./complete-fixture.mjs";
const createCase=(db,staff,data)=>rawCreateCase(db,staff,{...completeFields,...data,...(data.items?{items:data.items.map(i=>({...completeItem,...i}))}:{})});
const saveCase=(db,staff,id,data)=>rawSaveCase(db,staff,id,{...data,...((data.startedAt||data.completedAt)?{timeConfirmed:{startedAt:true,completedAt:true}}:{}),...(data.items?{items:data.items.map(i=>({...completeItem,...i}))}:{})});
import assert from "node:assert/strict";
import test from "node:test";
import { readFile, readdir } from "node:fs/promises";
import { PGlite } from "@electric-sql/pglite";
import { createCase as rawCreateCase, saveCase as rawSaveCase, actionCase, listCases } from "../lib/case-service.ts";
import { saveImage, readAsset } from "../lib/asset-service.ts";
import { generateCaseDocument } from "../lib/document-service.ts";
import { listStaff } from "../lib/access.ts";
import { createProject, deleteProject, listProjects, updateProject } from "../lib/project-service.ts";
import { listIndex } from "../lib/index-service.ts";

test("worker completion and remark template survive office review; INDEX orders by confirmation", async () => {
  const database=await fixture();
  try {
    const worker=staff("worker1","worker"),office=staff("office1","office");
    const project=await createProject(database,office,{name:"Site",code:"TIME",property:"Site"});
    let record=await createCase(database,worker,{customer:"First created",address:"Site",phone:"12345678",
      startedAt:"2026-09-20T09:00",completedAt:"2026-09-20T11:25",notes:"Inspected",items:[{id:"i",preset:0,qty:1}]});
    record=await actionCase(database,worker,record.id,"submit",record.serverVersion);
    let later=await createCase(database,office,{customer:"Later created",address:"Site",projectId:project.id,projectCode:project.code,items:[{id:"i",preset:0,qty:1,price:2}]});
    later=await actionCase(database,office,later.id,"confirm",later.serverVersion);
    record=await saveCase(database,office,record.id,{serverVersion:record.serverVersion,completedAt:"",remarkTemplate:"inspect",remark:"Inspection terms",projectId:project.id,projectCode:project.code,items:[{id:"i",preset:0,qty:1,price:3}]});
    assert.equal(record.completedAt,"2026-09-20T11:25");
    assert.equal(record.remarkTemplate,"inspect");
    record=await actionCase(database,office,record.id,"confirm",record.serverVersion);
    assert.equal(record.approvedSnapshot.completedAt,"2026-09-20T11:25");
    const index=await listIndex(database,office,new URLSearchParams());
    assert.equal(index.data[0].id,record.id);
    assert.equal(index.total,2);
    const saved=(await listCases(database,office)).find(r=>r.id===record.id);
    assert.equal(saved.remarkTemplate,"inspect");
  } finally {await database.close();}
});

async function fixture() {
  const database = new PGlite();
  for (const name of (await readdir(new URL("../migrations/", import.meta.url))).filter(file=>file.endsWith(".sql")&&!file.startsWith("006_")).sort()) {
    await database.exec(await readFile(new URL(`../migrations/${name}`, import.meta.url), "utf8"));
  }
  for (const [index, [id, role]] of [["worker1", "worker"], ["worker2", "worker"], ["office1", "office"]].entries()) {
    await database.query(`INSERT INTO "user"(id, name, email, "phoneNumber")
      VALUES ($1, $2, $3, $4)`, [id, id, `${id}@staff.invalid`, `+1555000000${index + 1}`]);
    await database.query(`INSERT INTO employees(user_id, staff_code, role) VALUES ($1, $2, $3)`, [id, id, role]);
  }
  return database;
}

const staff = (id, role) => ({ userId: id, staffCode: id, name: id,
  email: `${id}@staff.invalid`, phone: "+15550000001", role });

test("negotiation versions retain original prices and PDFs while INDEX uses confirmed net",async()=>{
 const db=await fixture();
 try{
  const {total}=await import('../src/workspace-model.js');
  const office=staff('office1','office');
  const project=await createProject(db,office,{name:'Discount',property:'Site',code:'DISC'});
  let r=await createCase(db,office,{customer:'Customer',address:'Site',projectId:project.id,projectCode:project.code,items:[{id:'i',preset:0,qty:1,price:14500}]});
  r=await actionCase(db,office,r.id,'confirm',r.serverVersion);
  const objects=new Map(),store={put:async(k,b)=>objects.set(k,b),get:async k=>objects.get(k)};
  const first=await generateCaseDocument(db,store,office,r.id,'quotation');r=first.record;
  const originalBytes=objects.get(first.assetKey);
  for(const [index,discountAmount] of ['1450','2000'].entries()){
   r=await actionCase(db,office,r.id,'start-revision',r.serverVersion);
   r=await saveCase(db,office,r.id,{serverVersion:r.serverVersion,discountAmount});
   const before=await listIndex(db,office,new URLSearchParams());
   assert.equal(total(before.data[0]),index===0?14500:13050);
   r=await actionCase(db,office,r.id,'confirm',r.serverVersion);
   assert.equal(r.rev,index+1);assert.equal(r.items[0].price,14500);
   assert.equal(total((await listIndex(db,office,new URLSearchParams())).data[0]),14500-Number(discountAmount));
   const quote=await generateCaseDocument(db,store,office,r.id,'quotation');
   const invoice=await generateCaseDocument(db,store,office,r.id,'invoice');r=invoice.record;
   assert.notEqual(quote.assetKey,first.assetKey);
  }
  const old=await generateCaseDocument(db,store,office,r.id,'quotation',0);
  assert.equal(old.assetKey,first.assetKey);assert.deepEqual(objects.get(old.assetKey),originalBytes);
  r=await actionCase(db,office,r.id,'start-revision',r.serverVersion);
  r=await saveCase(db,office,r.id,{serverVersion:r.serverVersion,discountAmount:'15000'});
  await assert.rejects(actionCase(db,office,r.id,'confirm',r.serverVersion),/invalid-discount/);
  r=await actionCase(db,office,r.id,'discard-revision',r.serverVersion);
  assert.equal(r.discountAmount,'2000');assert.equal(r.rev,2);
 }finally{await db.close();}
});

test("worker records are isolated, prices are server protected, and submission allocates one number", async () => {
  const database = await fixture();
  try {
    const worker1 = staff("worker1", "worker");
    const worker2 = staff("worker2", "worker");
    const created = await createCase(database, worker1, {});
    assert.equal(created.status, "editing");
    const saved = await saveCase(database, worker1, created.id, {
      serverVersion: created.serverVersion, customer: "Test customer", address: "Test site",
      phone: "12345678", startedAt: "2026-09-14T09:00", notes: "Inspected unit",
      items: [{ id: "i1", preset: 0, qty: 1, price: 999999, model: "TEST", description: "" }],
    });
    assert.equal(saved.items[0].price, "");
    assert.equal((await listCases(database, worker2)).length, 0);
    await assert.rejects(saveCase(database, worker2, created.id, { serverVersion: saved.serverVersion }), /not-found/);
    const submitted = await actionCase(database, worker1, created.id, "submit", saved.serverVersion);
    assert.equal(submitted.serviceNo, "CT-MNA-0001");
    assert.equal(submitted.status, "submitted");
    await assert.rejects(actionCase(database, worker1, created.id, "submit", saved.serverVersion), /conflict/);
    const version = await database.query("SELECT count(*)::int AS count FROM case_versions WHERE kind = 'service'");
    assert.equal(version.rows[0].count, 1);
  } finally { await database.close(); }
});

test("office return, review, confirmation and changed revision preserve the quote reference", async () => {
  const database = await fixture();
  try {
    const worker = staff("worker1", "worker");
    const office = staff("office1", "office");
    const project = await createProject(database, office, { name: "Test project", property: "Test site", code: "TEST-001" });
    let record = await createCase(database, worker, {});
    record = await saveCase(database, worker, record.id, {
      serverVersion: record.serverVersion, customer: "Test customer", address: "Test site",
      phone: "12345678", startedAt: "2026-09-14T09:00", notes: "Inspected unit",
      items: [{ id: "i1", preset: 0, qty: 1, model: "TEST", description: "" }],
    });
    record = await actionCase(database, worker, record.id, "submit", record.serverVersion);
    record = await actionCase(database, office, record.id, "return", record.serverVersion,
      { text: "Check model", field: "model", itemId: "i1" });
    assert.equal(record.status, "needsInfo");
    const feedbackId = record.feedback.at(-1).id;
    await assert.rejects(actionCase(database, worker, record.id, "submit", record.serverVersion), /unaddressed-feedback/);
    record = await saveCase(database, worker, record.id, { serverVersion: record.serverVersion,
      addressedFeedbackIds: [feedbackId], notes: "Checked the request at site; model label is unavailable." });
    assert.equal(record.feedback.at(-1).addressed, true);
    record = await actionCase(database, worker, record.id, "submit", record.serverVersion);
    assert.equal(record.feedback.at(-1).resolved, true);
    assert.equal(record.serviceNo, "CT-MNA-0001");
    record = await actionCase(database, office, record.id, "review", record.serverVersion);
    record = await saveCase(database, office, record.id, { serverVersion: record.serverVersion,
      projectId: project.id, projectCode: "TEST-001", items: [{ ...record.items[0], price: 100 }] });
    record = await actionCase(database, office, record.id, "confirm", record.serverVersion);
    const ref = record.ref;
    assert.match(ref, /^CT-MNA\d{2}-Q-S-001$/);
    assert.equal(record.rev, 0);
    record = await actionCase(database, office, record.id, "start-revision", record.serverVersion);
    record = await saveCase(database, office, record.id, { serverVersion: record.serverVersion,
      items: [{ ...record.items[0], price: 120 }] });
    record = await actionCase(database, office, record.id, "confirm", record.serverVersion);
    assert.equal(record.ref, ref);
    assert.equal(record.rev, 1);
    const versions = await database.query("SELECT revision FROM case_versions WHERE kind='confirmation' ORDER BY revision");
    assert.deepEqual(versions.rows.map((row) => row.revision), [0, 1]);
  } finally { await database.close(); }
});

test("draft deletion can be undone and discarding a revision restores approved content", async () => {
  const database = await fixture();
  try {
    const worker = staff("worker1", "worker");
    const office = staff("office1", "office");
    const project = await createProject(database, office, { name: "Test project", property: "Site", code: "TEST-001" });
    let draft = await createCase(database, worker, {});
    draft = await actionCase(database, worker, draft.id, "delete-draft", draft.serverVersion);
    assert.equal((await listCases(database, worker)).filter(item => !item.deletedAt).length, 0);
    assert.equal((await listCases(database, worker)).filter(item => item.deletedAt).length, 1);
    await assert.rejects(saveCase(database, worker, draft.id, { serverVersion: draft.serverVersion }), /not-found/);
    await assert.rejects(actionCase(database, office, draft.id, "restore-draft", draft.serverVersion), /forbidden/);
    draft = await actionCase(database, worker, draft.id, "restore-draft", draft.serverVersion);
    assert.equal((await listCases(database, worker)).length, 1);
    assert.equal(draft.deletedAt, undefined);

    let officeDraft = await createCase(database, office, {});
    officeDraft = await actionCase(database, office, officeDraft.id, "delete-draft", officeDraft.serverVersion);
    assert.ok(officeDraft.deletedAt);
    officeDraft = await actionCase(database, office, officeDraft.id, "restore-draft", officeDraft.serverVersion);
    assert.equal(officeDraft.deletedAt, undefined);

    let quote = await createCase(database, office, {});
    quote = await saveCase(database, office, quote.id, { serverVersion: quote.serverVersion,
      customer: "Customer", address: "Site", projectId: project.id, projectCode: "TEST-001",
      items: [{ id: "i1", preset: 0, qty: 1, model: "M", description: "Inspection", price: 100 }] });
    quote = await actionCase(database, office, quote.id, "confirm", quote.serverVersion);
    quote = await actionCase(database, office, quote.id, "start-revision", quote.serverVersion);
    quote = await saveCase(database, office, quote.id, { serverVersion: quote.serverVersion,
      items: [{ ...quote.items[0], price: 120 }] });
    quote = await actionCase(database, office, quote.id, "discard-revision", quote.serverVersion);
    assert.equal(quote.status, "approved");
    assert.equal(quote.items[0].price, 100);
    assert.equal(quote.rev, 0);
  } finally { await database.close(); }
});

test("private image assets reject invalid content and enforce case visibility", async () => {
  const database = await fixture();
  try {
    const worker = staff("worker1", "worker");
    const outsider = staff("worker2", "worker");
    const office = staff("office1", "office");
    const record = await createCase(database, worker, {});
    const objects = new Map();
    const store = { put: async (key, bytes) => { objects.set(key, bytes); }, get: async (key) => objects.get(key) };
    const image = Uint8Array.from([0xff, 0xd8, 0xff, 0xd9]);
    await assert.rejects(saveImage(database, store, worker, record.id, image, "image/png"), /invalid-image/);
    await assert.rejects(saveImage(database, store, outsider, record.id, image, "image\/jpeg"), /forbidden/);
    const asset = await saveImage(database, store, worker, record.id, image, "image/jpeg");
    await assert.rejects(saveCase(database, worker, record.id, { serverVersion: record.serverVersion,
      photos: [{ id: "p1", assetKey: "not-an-asset", name: "test.jpg", caption: "" }] }), /invalid-photo-asset/);
    const withPhoto = await saveCase(database, worker, record.id, { serverVersion: record.serverVersion,
      photos: [{ id: "p1", assetKey: asset.key, name: "test.jpg", caption: "" }] });
    assert.equal(withPhoto.photos[0].url, `/api/assets/${asset.key}`);
    assert.deepEqual((await readAsset(database, store, worker, asset.key)).bytes, image);
    assert.deepEqual((await readAsset(database, store, office, asset.key)).bytes, image);
    await assert.rejects(readAsset(database, store, outsider, asset.key), /not-found/);
  } finally { await database.close(); }
});

test("document generation is authorized, versioned and idempotent", async () => {
  const database = await fixture();
  try {
    const worker = staff("worker1", "worker");
    const office = staff("office1", "office");
    const project = await createProject(database, office, { name: "Test project", property: "Site", code: "TEST-001" });
    let record = await createCase(database, office, {});
    record = await saveCase(database, office, record.id, { serverVersion: record.serverVersion,
      customer: "Customer", address: "Site", projectId: project.id, projectCode: "TEST-001",
      items: [{ id: "i1", preset: 0, qty: 2, model: "M", description: "Inspection", price: 100 }] });
    record = await actionCase(database, office, record.id, "confirm", record.serverVersion);
    const objects = new Map();
    const store = { put: async (key, bytes) => { objects.set(key, bytes); }, get: async (key) => objects.get(key) };
    await assert.rejects(generateCaseDocument(database, store, worker, record.id, "quotation"), /not-found/);
    const quote = await generateCaseDocument(database, store, office, record.id, "quotation");
    assert.equal(quote.record.status, "issued");
    assert.equal(quote.record.history.length, 1);
    const repeated = await generateCaseDocument(database, store, office, record.id, "quotation");
    assert.equal(repeated.assetKey, quote.assetKey);
    assert.equal(repeated.record.serverVersion, quote.record.serverVersion);
    await database.query("UPDATE case_versions SET document_format_version=0 WHERE case_id=$1 AND kind='quotation'", [record.id]);
    const corrected = await generateCaseDocument(database, store, office, record.id, "quotation");
    assert.notEqual(corrected.assetKey, quote.assetKey);
    assert.equal(corrected.record.history.length, 1);
    assert.equal(corrected.record.serverVersion, quote.record.serverVersion);
    const correctedVersion = await database.query("SELECT asset_key,document_format_version FROM case_versions WHERE case_id=$1 AND kind='quotation'", [record.id]);
    assert.equal(correctedVersion.rows[0].asset_key, corrected.assetKey);
    assert.equal(correctedVersion.rows[0].document_format_version, 4);
    const correctedRepeat = await generateCaseDocument(database, store, office, record.id, "quotation");
    assert.equal(correctedRepeat.assetKey, corrected.assetKey);
    const invoice = await generateCaseDocument(database, store, office, corrected.record.id, "invoice");
    assert.equal(invoice.record.invoiceHistory.length, 1);
    assert.notEqual(invoice.assetKey, corrected.assetKey);
    assert.equal(objects.size, 3);
    const versions = await database.query("SELECT kind,revision FROM case_versions WHERE case_id=$1 ORDER BY kind", [record.id]);
    assert.deepEqual(versions.rows.map(v => v.kind), ["confirmation", "invoice", "quotation"]);
    // A reconfirmed unchanged revision reuses its files but must recover Issued.
    let unchanged=await actionCase(database,office,record.id,"start-revision",invoice.record.serverVersion);
    unchanged=await actionCase(database,office,record.id,"confirm",unchanged.serverVersion);
    const reissued=await generateCaseDocument(database,store,office,record.id,"quotation");
    assert.equal(reissued.record.status,"issued");
    assert.equal(reissued.assetKey,corrected.assetKey);
    const index=await listIndex(database,office,new URLSearchParams());
    assert.equal(index.data[0].status,"issued");

  } finally { await database.close(); }
});

test("INDEX service PDFs use the same confirmed snapshot for worker and office cases",async()=>{
 const database=await fixture();
 try {
  const office=staff("office1","office"),worker=staff("worker1","worker");
  const project=await createProject(database,office,{name:"Unified",property:"Unified",code:"UNIFIED"});
  const objects=new Map(),store={put:async(key,bytes)=>objects.set(key,bytes),get:async key=>objects.get(key)};
  for(const creator of [worker,office]){
   let r=await createCase(database,creator,{customer:"Original",address:"Site",phone:"12345678",startedAt:"2026-09-22T09:00",completedAt:"2026-09-22T12:00",notes:"Inspected",items:[{id:"i",preset:0,qty:1}]});
   if(creator.role==="worker")r=await actionCase(database,worker,r.id,"submit",r.serverVersion);
   r=await saveCase(database,office,r.id,{serverVersion:r.serverVersion,customer:"Confirmed customer",projectId:project.id,projectCode:project.code,items:[{id:"i",preset:0,qty:1,price:12}]});
   r=await actionCase(database,office,r.id,"confirm",r.serverVersion);
   const result=await generateCaseDocument(database,store,office,r.id,"confirmed-service",r.rev);
   assert.ok(objects.size);assert.equal(result.record.invoiceHistory.length,0);
   const version=(await database.query("SELECT snapshot FROM case_versions WHERE case_id=$1 AND kind='confirmed-service'",[r.id])).rows[0];
   assert.equal(version.snapshot.customer,"Confirmed customer");assert.equal(version.snapshot.source,creator.role);
   assert.equal((await generateCaseDocument(database,store,office,r.id,"confirmed-service",r.rev)).assetKey,result.assetKey);
  }
 }finally{await database.close()}
});

test("staff directory is available only to managers", async () => {
  const database = await fixture();
  try {
    await assert.rejects(listStaff(database, staff("office1", "office")), /forbidden/);
    const rows = await listStaff(database, staff("office1", "manager"));
    assert.equal(rows.length, 3);
    assert.ok(rows.every(row => row.phone && row.staff_code && !Object.hasOwn(row, "password")));
  } finally { await database.close(); }
});

test("project codes are unique and cannot be forged on cases", async () => {
  const database = await fixture();
  try {
    const office = staff("office1", "office");
    await assert.rejects(createProject(database, staff("worker1", "worker"),
      { name: "Site", property: "Site", code: "SITE-01" }), /forbidden/);
    const project = await createProject(database, office, { name: "Site", property: "Site", code: "SITE-01" });
    await assert.rejects(createProject(database, office, { name: "Duplicate", property: "Site", code: "site-01" }));
    assert.equal((await listProjects(database)).length, 1);
    const record = await createCase(database, office, {});
    await assert.rejects(saveCase(database, office, record.id, { serverVersion: record.serverVersion,
      projectId: project.id, projectCode: "FORGED" }), /invalid-project/);
    const linked = await saveCase(database, office, record.id, { serverVersion: record.serverVersion,
      projectId: project.id, projectCode: project.code });
    assert.equal(linked.projectId, project.id);
    const row = await database.query("SELECT project_id FROM cases WHERE id=$1", [record.id]);
    assert.equal(row.rows[0].project_id, project.id);
  } finally { await database.close(); }
});


test("trash bulk operations validate ownership and versions before restore or irreversible deletion", async()=>{
 const database=await fixture();
 const {updateTrash}=await import("../lib/trash-service.ts");
 try{
  const worker=staff("worker1","worker"),other=staff("worker2","worker"),office=staff("office1","office");
  let first=await createCase(database,worker,{}),second=await createCase(database,worker,{});
  await assert.rejects(updateTrash(database,worker,[{id:first.id,serverVersion:0}],"permanent-delete"),/not-found/);
  first=await actionCase(database,worker,first.id,"delete-draft",first.serverVersion);
  second=await actionCase(database,worker,second.id,"delete-draft",second.serverVersion);
  await assert.rejects(updateTrash(database,other,[first],"restore"),/not-found/);
  await assert.rejects(updateTrash(database,office,[first],"restore"),/forbidden/);
  await assert.rejects(updateTrash(database,worker,[first,{...second,serverVersion:999}],"restore"),/conflict/);
  assert.equal((await listCases(database,worker)).every(r=>r.deletedAt),true);
  assert.equal((await updateTrash(database,worker,[first,second],"restore")).count,2);
  const active=await listCases(database,worker);
  assert.equal(active.every(r=>!r.deletedAt),true);
  const deleted=[];for(const r of active)deleted.push(await actionCase(database,worker,r.id,"delete-draft",r.serverVersion));
  assert.equal((await updateTrash(database,worker,deleted,"permanent-delete")).count,2);
  assert.equal((await listCases(database,worker)).length,0);
  assert.equal((await database.query("SELECT count(*)::int AS n FROM audit_events WHERE action='permanent-delete'")).rows[0].n,2);
 }finally{await database.close();}
});

test("retrying a client draft creation does not duplicate it or allow another owner to claim it", async()=>{
 const database=await fixture();
 try{
  const clientId=crypto.randomUUID(),worker=staff("worker1","worker");
  const a=await createCase(database,worker,{clientId,customer:"Saved input"});
  const b=await createCase(database,worker,{clientId,customer:"Retry"});
  assert.equal(a.id,b.id);assert.equal(b.customer,"Saved input");
  assert.equal((await listCases(database,worker)).length,1);
  await assert.rejects(createCase(database,staff("worker2","worker"),{clientId}),/not-found/);
 }finally{await database.close();}
});

test("INDEX paginates confirmed snapshots only, clamps pages and rejects worker access",async()=>{
 const database=await fixture();const {listIndex}=await import("../lib/index-service.ts");
 try{
  const office=staff("office1","office");
  const project=await createProject(database,office,{name:"Pagination",property:"Test site",code:"PAGE"});
  const ids=[];
  for(let i=0;i<5;i++){
   let r=await createCase(database,office,{customer:"Confirmed "+i,address:"Test site",projectId:project.id,projectCode:project.code,items:[{id:"i",preset:0,qty:1,price:10}]});
   r=await actionCase(database,office,r.id,"confirm",r.serverVersion);ids.push(r.id);
  }
  await createCase(database,office,{customer:"Unconfirmed"});
  const a=await listIndex(database,office,new URLSearchParams({page:"1",pageSize:"2"}));
  const b=await listIndex(database,office,new URLSearchParams({page:"2",pageSize:"2"}));
  assert.equal(a.total,5);assert.equal(a.data.length,2);assert.equal(new Set([...a.data,...b.data].map(r=>r.id)).size,4);
  const last=await listIndex(database,office,new URLSearchParams({page:"99",pageSize:"2"}));assert.equal(last.page,3);assert.equal(last.data.length,1);
  let r=(await listCases(database,office)).find(r=>r.id===ids[0]);r=await actionCase(database,office,r.id,"start-revision",r.serverVersion);
  await saveCase(database,office,r.id,{serverVersion:r.serverVersion,customer:"Unconfirmed replacement"});
  const found=await listIndex(database,office,new URLSearchParams({query:"Unconfirmed replacement"}));assert.equal(found.total,0);
  await assert.rejects(listIndex(database,staff("worker1","worker"),new URLSearchParams()),/forbidden/);
 }finally{await database.close();}
});


test("task numbers use one sequence for both sources and migrate old drafts without renumbering issued services",async()=>{
 const database=await fixture();
 try {
  const worker=staff("worker1","worker"),office=staff("office1","office");
  const a=await rawCreateCase(database,worker,{}),b=await rawCreateCase(database,office,{});
  assert.equal(a.serviceNo,"CT-MNA-0001");assert.equal(b.serviceNo,"CT-MNA-0002");
  assert.equal(a.entryNo,a.serviceNo);assert.equal(b.entryNo,b.serviceNo);
  await database.query("UPDATE cases SET service_no=NULL,data=data-'serviceNo' WHERE id=$1",[b.id]);
  await database.exec(await readFile(new URL('../migrations/006_task_numbers.sql',import.meta.url),'utf8'));
  const rows=await listCases(database,office);
  assert.equal(rows.find(r=>r.id===a.id).serviceNo,a.serviceNo);
  assert.match(rows.find(r=>r.id===b.id).serviceNo,/^CT-MNA-\d{4,}$/);
  assert.notEqual(rows.find(r=>r.id===b.id).serviceNo,a.serviceNo);
  const c=await rawCreateCase(database,office,{});
  assert.notEqual(c.serviceNo,rows.find(r=>r.id===b.id).serviceNo);
 }finally{await database.close();}
});


test("editing a saved project replaces its code and preserves old case references",async()=>{
 const db=await fixture();try{
  const office=staff("office1","office"),worker=staff("worker1","worker");
  const project=await createProject(db,office,{name:"Site",property:"Worker address",code:"OLD"});
  let r=await createCase(db,office,{customer:"Client",address:"Original location",projectId:project.id,projectCode:"OLD",items:[{id:"i",preset:0,qty:1,price:1}]});
  await assert.rejects(updateProject(db,worker,{id:project.id,code:"NEW",expectedCode:"OLD"}),/forbidden/);
  const changed=await updateProject(db,office,{id:project.id,code:"NEW",expectedCode:"OLD"});
  assert.equal(changed.id,project.id);assert.equal(changed.code,"NEW");assert.ok(changed.previousCodes.includes("OLD"));
  assert.equal((await listProjects(db)).length,1);
  r=await saveCase(db,office,r.id,{serverVersion:r.serverVersion,notes:"Still editable"});
  assert.equal(r.address,"Original location");
  await assert.rejects(updateProject(db,office,{id:project.id,code:"RACE",expectedCode:"OLD"}),/conflict/);
 }finally{await db.close();}
});

test("removing one saved Project Code hides it without deleting linked tasks",async()=>{
 const db=await fixture();try{
  const office=staff("office1","office"),worker=staff("worker1","worker");
  const first=await createProject(db,office,{name:"A",property:"A",code:"KEEP-HISTORY"});
  const second=await createProject(db,office,{name:"B",property:"B",code:"STILL-SAVED"});
  const record=await createCase(db,office,{customer:"Customer",address:"A",projectId:first.id,projectCode:first.code});
  await assert.rejects(deleteProject(db,worker,{id:first.id,expectedCode:first.code}),/forbidden/);
  await assert.rejects(deleteProject(db,office,{id:first.id,expectedCode:"stale"}),/conflict/);
  const removed=await deleteProject(db,office,{id:first.id,expectedCode:first.code});
  assert.equal(removed.active,false);
  const registry=await listProjects(db);
  assert.deepEqual(registry.filter(p=>p.active).map(p=>p.id),[second.id]);
  const saved=await saveCase(db,office,record.id,{serverVersion:record.serverVersion,notes:"Historical case still editable"});
  assert.equal(saved.projectId,first.id);
  await assert.rejects(createCase(db,office,{customer:"New",address:"A",projectId:first.id,projectCode:first.code}),/invalid-project/);
  await assert.rejects(deleteProject(db,office,{id:first.id,expectedCode:first.code}),/conflict/);
 }finally{await db.close();}
});
