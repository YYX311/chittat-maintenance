import assert from "node:assert/strict";
import test from "node:test";
import { parseOptions } from "../scripts/cli-options.mjs";

test("staff provisioning accepts spaced and equals-style options", () => {
  assert.deepEqual(parseOptions(["--phone", "+85291234567", "--role=worker"]), {
    phone: "+85291234567",
    role: "worker",
  });
});

test("staff provisioning rejects missing option values", () => {
  assert.throws(() => parseOptions(["--phone", "--role=worker"]), /Invalid argument: --phone/);
  assert.throws(() => parseOptions(["phone=123"]), /Invalid argument: phone=123/);
});
