export const completeFields={timeConfirmed:{startedAt:true,completedAt:true},date:"2026-09-20",tower:"A",floor:"1",flat:"101",contact:"Test contact",occupant:"Test occupant",phone:"12345678",startedAt:"2026-09-20T09:00",completedAt:"2026-09-20T12:00",notes:"Inspected"};
export const completeItem={brand:"Test brand",model:"Test model"};
