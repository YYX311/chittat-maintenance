import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { PGlite } from "@electric-sql/pglite";

test("PostgreSQL migrations enforce staff, case and version integrity", async () => {
  const db = new PGlite();
  try {
    for (const name of ["000_auth.sql", "001_business.sql", "002_projects.sql", "003_document_format.sql"]) {
      await db.exec(await readFile(new URL(`../migrations/${name}`, import.meta.url), "utf8"));
    }
    await db.query(`INSERT INTO "user"(id, name, email, "phoneNumber")
      VALUES ('u1', 'Worker', 'u1@staff.invalid', '+85212345678')`);
    await db.query(`INSERT INTO employees(user_id, staff_code, role) VALUES ('u1', 'EMP-W001', 'worker')`);
    await db.query(`INSERT INTO cases(id, owner_user_id, source, status, data)
      VALUES ('c1', 'u1', 'worker', 'editing', '{}'::jsonb)`);
    await db.query(`INSERT INTO case_versions(id, case_id, kind, revision, snapshot, created_by)
      VALUES ('v1', 'c1', 'confirmation', 0, '{}'::jsonb, 'u1')`);
    await assert.rejects(db.query(`INSERT INTO case_versions(id, case_id, kind, revision, snapshot, created_by)
      VALUES ('v2', 'c1', 'confirmation', 0, '{}'::jsonb, 'u1')`));
    await assert.rejects(db.query(`INSERT INTO employees(user_id, staff_code, role) VALUES ('u1', 'x', 'owner')`));
    const result = await db.query("SELECT count(*)::int AS count FROM cases");
    assert.equal(result.rows[0].count, 1);
    const version = await db.query("SELECT document_format_version FROM case_versions WHERE id='v1'");
    assert.equal(version.rows[0].document_format_version, 0);
  } finally {
    await db.close();
  }
});
