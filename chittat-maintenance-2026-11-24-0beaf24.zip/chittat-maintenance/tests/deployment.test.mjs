import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);
const read = (path) => readFile(new URL(path, root), "utf8");

test("production container runs migrations and the standalone server as a non-root user", async () => {
  const dockerfile = await read("Dockerfile");
  assert.match(dockerfile, /USER nextjs/);
  assert.match(dockerfile, /node scripts\/migrate\.mjs && node server\.js/);
  assert.match(dockerfile, /\.next\/standalone/);
});

test("migration runner serializes concurrent deploys", async () => {
  const migrate = await read("scripts/migrate.mjs");
  assert.match(migrate, /pg_advisory_lock/);
  assert.match(migrate, /pg_advisory_unlock/);
  assert.match(migrate, /Applied migration changed/);
});

test("development indicator is hidden while document fonts are traced", async () => {
  const config = await read("next.config.mjs");
  assert.match(config, /devIndicators:\s*false/);
  assert.match(config, /output:\s*"standalone"/);
  assert.match(config, /assets\/fonts\/\*\*\/\*/);
});

test("root layout tolerates attributes injected by browser extensions before hydration", async () => {
  const layout = await read("app/layout.tsx");
  assert.match(layout, /<html lang="zh-HK" suppressHydrationWarning>/);
  assert.match(layout, /<body suppressHydrationWarning>/);
});

test("local acceptance guide explains how to keep both roles signed in", async () => {
  const readme = await read("README.md");
  assert.match(readme, /普通窗口/);
  assert.match(readme, /无痕／InPrivate 窗口/);
  assert.match(readme, /独立的 Cookie/);
});

test("rendered PDF verification files stay outside version control", async () => {
  const ignore = await read(".gitignore");
  assert.match(ignore, /^output\/$/m);
  assert.match(ignore, /^tmp\/$/m);
});
