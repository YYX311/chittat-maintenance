import test from "node:test";
import assert from "node:assert/strict";
import {subtotal, discount, netTotal, validDiscount} from "../src/commercial-totals.js";
import {total, toIndexRows} from "../src/workspace-model.js";
import {editableCopy, formalContent, validateConfirmation} from "../lib/case-rules.ts";
import {formIssues} from "../src/form-validation.js";
import {effectiveQuote} from "../src/office-tools-model.js";

const record={id:"q",source:"office",owner:"worker",status:"draft",items:[{qty:1,price:6800},{qty:1,price:7700}],photos:[]};
test("commercial amounts use one shared net total and legacy quotes default to no discount",()=>{
 assert.equal(subtotal(record),14500); assert.equal(discount(record),0);
 assert.equal(total(record),14500);
 const negotiated={...record,discountAmount:"1450.00"};
 assert.equal(netTotal(negotiated),13050);assert.equal(total(negotiated),13050);
 assert.equal(netTotal({...record,items:[{qty:3,price:.1}],discountAmount:"0.10"}),.2);
 assert.equal(netTotal({...record,discountAmount:"14500"}),0);
 assert.equal(formalContent(record),formalContent({...record,discountAmount:"0"}));
 assert.notEqual(formalContent(record),formalContent(negotiated));
 assert.equal(total(effectiveQuote({...negotiated,status:"revision",approvedSnapshot:record})),14500);
 assert.equal(toIndexRows({...negotiated,ledger:[]})[0][9],13050);
});
test("discount validation rejects negative, excessive, nonfinite and malformed amounts",()=>{
 for(const value of ["-1","14500.01","NaN","Infinity","1e3","0.001","."]){
  const r={...record,discountAmount:value};
  assert.equal(validDiscount(r),false,value);
  assert.throws(()=>validateConfirmation(r),/invalid-discount/);
  assert.ok(formIssues(r,false).some(i=>i.field==="discountAmount"));
 }
});
test("only office can change a discount; draft decimals survive autosave",()=>{
 const r={...record,source:"worker",status:"needsInfo",discountAmount:"100"};
 assert.equal(editableCopy(r,{discountAmount:"50"},{role:"worker",email:"worker"}).discountAmount,"100");
 assert.equal(editableCopy(r,{discountAmount:"1450."},{role:"office"}).discountAmount,"1450.");
 assert.throws(()=>editableCopy(r,{discountAmount:"-1"},{role:"office"}),/invalid-discount/);
});
