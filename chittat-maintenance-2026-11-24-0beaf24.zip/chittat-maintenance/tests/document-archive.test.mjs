import test from 'node:test';
import assert from 'node:assert/strict';
import JSZip from 'jszip';
import {documentArchive} from '../src/document-archive.js';
test('download archive contains all three nonempty PDFs with exact bytes',async()=>{
 const files=['服務單','報價單','發票'].map(name=>({name:`CT-MNA_Rev1/${name}.pdf`,blob:new Blob(['%PDF-1.7\n'+name])}));
 const blob=await documentArchive(files);
 const zip=await JSZip.loadAsync(await blob.arrayBuffer());
 assert.equal(Object.values(zip.files).filter(f=>!f.dir).length,3);
 for(const f of files)assert.equal(await zip.file(f.name).async('string'),await f.blob.text());
 await assert.rejects(documentArchive([]),/Empty/);
 await assert.rejects(documentArchive([{name:'bad.pdf',blob:new Blob(['error'])}]),/Invalid/);
 await assert.rejects(documentArchive([files[0],files[0]]),/Duplicate/);
});
