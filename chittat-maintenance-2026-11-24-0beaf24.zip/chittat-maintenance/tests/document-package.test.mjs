import assert from "node:assert/strict";
import test from "node:test";
import { documentPackageName } from "../src/service-model.js";

test("combined quotation and invoice packages use a database-friendly Hong Kong timestamp", () => {
  const at = new Date("2026-09-15T06:07:08Z");
  assert.equal(documentPackageName([{ ref:"CT-MNA26-Q-007", rev:2 }], at), "CT-MNA26-Q-007_Rev2_Q-I_20260915_140708.zip");
  assert.equal(documentPackageName([{ ref:"A", rev:0 }, { ref:"B", rev:0 }], at), "CT_QI_20260915_140708_2records.zip");
});
