import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { spawnSync } from "node:child_process";
import { PDFDocument } from "pdf-lib";
import { renderDocument } from "../lib/pdf-document.ts";

const record = {
  id: "test", source: "worker", status: "approved", owner: "test@staff.invalid",
  serviceNo: "CT-MNA-0001", ref: "CT-MNA26-Q-S-001", invoiceRef: "CT-MNA26-I-S-001",
  rev: 0, date: "2026-09-14", customer: "測試客戶", phone: "91234567", address: "測試大廈",
  technician: "維修員", startedAt: "2026-09-14T09:00", notes: "已檢查室外機",
  projectCode: "TEST-001", items: [{ id: "i1", preset: 0, description: "檢查室外機", qty: 2, price: 100 }], photos: [],
};

test("quotation and invoice include matching subtotal, negotiated discount and net on one page",async()=>{
 const r={...record,discountAmount:"1450",items:[{...record.items[0],qty:1,price:6800},{...record.items[0],qty:1,price:7700}]};
 for(const kind of ["quotation","invoice"]){
  const bytes=await renderDocument(r,kind);
  assert.equal((await PDFDocument.load(bytes)).getPageCount(),1);
  const extracted=spawnSync("pdftotext",["-layout","-","-"],{input:Buffer.from(bytes),encoding:"utf8"});
  assert.ifError(extracted.error);
  assert.equal(extracted.status,0,extracted.stderr);
  for(const text of ["Sub Total","Less discount","Total Net Amount","14,500.00","(1,450.00)","13,050.00"])assert.ok(extracted.stdout.includes(text),kind+": "+text);
 }
 await assert.rejects(renderDocument({...r,discountAmount:"14501"},"invoice"),/invalid-discount/);
});

test("PDF font is a static regular face", async () => {
  const bytes = await readFile(new URL("../assets/fonts/NotoSansHK.ttf", import.meta.url));
  const tableCount = bytes.readUInt16BE(4);
  const tables = new Set(Array.from({ length: tableCount }, (_, index) =>
    bytes.toString("ascii", 12 + index * 16, 16 + index * 16)));
  assert.equal(tables.has("fvar"), false, "variable fonts are not safe for PDF subsetting");
});

test("official CT logo is available to both the app and generated documents", async () => {
  const bytes = await readFile(new URL("../public/brand-logo.png", import.meta.url));
  assert.equal(bytes.subarray(1,4).toString("ascii"), "PNG");
  assert.ok(bytes.length > 10000);
});

test("service, quotation and invoice PDFs render from a version snapshot", async () => {
  for (const kind of ["service", "quotation", "invoice"]) {
    const bytes = await renderDocument(record, kind);
    assert.equal(Buffer.from(bytes).toString("ascii", 0, 5), "%PDF-");
    const pdf = await PDFDocument.load(bytes);
    assert.ok(pdf.getPageCount() >= 1);
    assert.ok(pdf.getTitle()?.includes(kind === "service" ? record.serviceNo : kind === "quotation" ? record.ref : record.invoiceRef));
    const extracted = spawnSync("pdftotext", ["-layout", "-", "-"], { input: Buffer.from(bytes), encoding: "utf8" });
    if (!extracted.error) {
      assert.equal(extracted.status, 0, extracted.stderr);
      assert.ok(extracted.stdout.includes(record.customer));
      assert.ok(extracted.stdout.includes(kind === "service" ? record.serviceNo : kind === "quotation" ? record.ref : record.invoiceRef));
      if (kind !== "service") assert.ok(extracted.stdout.includes("200.00"));
      if (kind === "service") assert.ok(extracted.stdout.includes("This is not a receipt"));
    }
    const fonts = spawnSync("pdffonts", ["-"], { input: Buffer.from(bytes), encoding: "utf8" });
    if (!fonts.error) {
      assert.equal(fonts.status, 0, fonts.stderr);
      assert.match(fonts.stdout, /[A-Z]{6}\+NotoSansHK-Regular\s+CID TrueType\s+Identity-H\s+yes\s+yes\s+yes/);
      assert.doesNotMatch(fonts.stdout, /NotoSansHK-Thin/);
    }
  }
});

test('commercial forms preserve workbook sections and paginate long content',async()=>{
 const template=JSON.parse(await readFile(new URL('../assets/commercial-template.json',import.meta.url),'utf8'));
 assert.equal(template.QUO.titleRow,8);assert.equal(template.INVOICE.titleRow,9);
 for(const kind of ['quotation','invoice']){
  const pdf=await PDFDocument.load(await renderDocument({...record,items:Array.from({length:9},(_,n)=>({...record.items[0],id:'item-'+n,description:'Work '+n}))},kind));
  assert.equal(pdf.getPageCount(),3);
 }
 const {REMARK_TEMPLATES}=await import('../src/service-model.js');
 for(const template of REMARK_TEMPLATES){
  const bytes=await renderDocument({...record,remark:template.text},'quotation');
  assert.equal((await PDFDocument.load(bytes)).getPageCount(),1,template.name);
 }
 await assert.rejects(renderDocument({...record,remark:'Long remark line\n'.repeat(100)},'quotation'),/quotation-remarks-too-long/);
});
