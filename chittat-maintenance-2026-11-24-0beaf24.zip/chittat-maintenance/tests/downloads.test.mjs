import test from 'node:test';
import assert from 'node:assert/strict';
import {saveBlob,getAsset} from '../src/attachments.js';
test('save writes all bytes and closes the chosen file',async()=>{
 const data=new Blob(['%PDF-1.7\ncomplete document']);const steps=[];
 const target={createWritable:async()=>({write:async b=>steps.push(await b.text()),close:async()=>steps.push('closed'),abort:async()=>steps.push('aborted')})};
 await saveBlob(data,'test.pdf',target);assert.deepEqual(steps,['%PDF-1.7\ncomplete document','closed']);
});
test('empty downloads are rejected before creating a file and failed writes are aborted',async()=>{
 let opened=false;await assert.rejects(saveBlob(new Blob([]),'test.pdf',{createWritable:async()=>{opened=true;}}),/Empty/);assert.equal(opened,false);
 let aborted=false;await assert.rejects(saveBlob(new Blob(['abc']),'test.pdf',{createWritable:async()=>({write:async()=>{throw Error('disk full')},abort:async()=>{aborted=true}})}),/disk full/);assert.equal(aborted,true);
});
test('download rejects empty and invalid PDF responses',async()=>{
 const original=globalThis.fetch;
 const originalStorage=globalThis.sessionStorage;
 globalThis.sessionStorage={getItem:()=>"signed-token"};
 try{for(const content of ['', 'error']){globalThis.fetch=async()=>new Response(content,{headers:{'Content-Type':'application/pdf'}});await assert.rejects(getAsset('12345678-1234-1234-1234-123456789abc'));}}
 finally{globalThis.fetch=original;globalThis.sessionStorage=originalStorage;}
});
