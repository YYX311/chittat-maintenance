import assert from "node:assert/strict";
import test from "node:test";
import { cacheDraft, clearDraftCache, mergeDraftCache, readDraftCache } from "../src/draft-cache.js";

const values = new Map();
globalThis.localStorage = {
  getItem: key => values.get(key) ?? null,
  setItem: (key, value) => values.set(key, value),
  removeItem: key => values.delete(key),
};

test("emergency drafts survive reload, merge only with the matching server version, and clear after sync", () => {
  values.clear();
  const account = { id: "worker-1" };
  const server = { id: "case-1", status: "editing", serverVersion: 4, notes: "server" };
  cacheDraft(account, { ...server, notes: "offline edit" }, 4);
  assert.equal(readDraftCache(account).length, 1);
  const recovered = mergeDraftCache({ records: [server] }, account);
  assert.equal(recovered.workspace.records[0].notes, "offline edit");
  assert.equal(recovered.recovered.length, 1);
  assert.equal(mergeDraftCache({ records: [{ ...server, serverVersion: 5 }] }, account).workspace.records[0].notes, "server");
  clearDraftCache(account, server.id);
  assert.equal(readDraftCache(account).length, 0);
});


test("a new offline draft survives a reload before it has a server record",()=>{
 values.clear();const account={id:"offline-worker"};
 cacheDraft(account,{id:"offline-id",localOnly:true,status:"editing",customer:"Offline input"},undefined);
 const merged=mergeDraftCache({records:[]},account);
 assert.equal(merged.workspace.records[0].customer,"Offline input");assert.equal(merged.recovered.length,1);
 assert.equal(mergeDraftCache({records:[]},{id:"other-worker"}).recovered.length,0);
});

test('an offline draft does not hide other users newly submitted tasks',()=>{
 values.clear();const account={id:'office'};
 const draft={id:'local',localOnly:true,status:'draft',customer:'Unsynced'};cacheDraft(account,draft,undefined);
 const fresh={id:'worker-new',status:'submitted',serverVersion:2,customer:'New worker submission'};
 const merged=mergeDraftCache({records:[fresh]},account).workspace;
 assert.deepEqual(merged.records.map(r=>r.id),['local','worker-new']);
 assert.equal(readDraftCache(account).length,1);
});
