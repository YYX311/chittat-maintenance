import {completeFields,completeItem} from "../complete-fixture.mjs";
import {test,expect} from "@playwright/test";
import {makeRecord} from "../../src/workspace-model.js";
const base=process.env.E2E_BASE_URL||"http://localhost:3100";
async function login(page:any,role:string){
 await page.goto("/?screen=login&lang=zh-HK");
 await page.getByRole("textbox",{name:"公司已登記的手機號碼"}).fill(role==="worker"?"91234567":"92345678");
 await page.getByRole("textbox",{name:"密碼",exact:true}).fill(process.env.E2E_PASSWORD!);
 const response=page.waitForResponse((r:any)=>r.url().includes("/sign-in/phone-number"));
 await page.getByRole("button",{name:"登入",exact:true}).click();
 const token=(await response).headers()["set-auth-token"];
 await expect(page.getByRole("button",{name:role==="worker"?/新增現場記錄/:/建立任務/}).first()).toBeVisible();
 return {Origin:base,Authorization:`Bearer ${token}`};
}
test("signing in again recovers an unsynchronized local draft instead of clearing it",async({page})=>{
 const headers=await login(page,"worker");
 const account=await (await page.request.get("/api/me",{headers})).json();
 const draft={...makeRecord("worker"),customer:"OFFLINE-RECOVERY",address:"Saved locally",owner:account.email,localOnly:true};
 await page.evaluate(({account,draft})=>{
  localStorage.setItem("ct-emergency-drafts-v2:"+account.id,JSON.stringify([{record:draft,savedAt:new Date().toISOString()}]));
  sessionStorage.removeItem("ct-tab-session-v1");
 },{account,draft});
 await page.reload();
 const signedIn=await login(page,"worker");
 await expect.poll(async()=>{
  const data=await (await page.request.get("/api/workspace",{headers:signedIn})).json();
  return data.records.some((r:any)=>r.id===draft.id&&r.customer==="OFFLINE-RECOVERY");
 }).toBeTruthy();
});
test("same-browser tabs retain separate roles; typing submits without PDF and survives relogin",async({page,context})=>{
 const workerHeaders=await login(page,"worker");
 const office=await context.newPage();const officeHeaders=await login(office,"office");
 const create=await page.request.post("/api/cases",{headers:workerHeaders,data:{...completeFields,customer:"TAB-SYNC",address:"Site",phone:"12345678",notes:"Initial",startedAt:"2026-09-22T09:00",completedAt:"2026-09-22T10:00",items:[{...completeItem,id:"i",preset:0,qty:1,description:"Inspect"}]}});
 expect(create.ok(),await create.text()).toBeTruthy();const record=await create.json();expect(record.source).toBe("worker");
 await page.goto(`/?screen=worker-photo&lang=zh-HK&id=${record.id}`);
 const notes=page.getByRole("textbox",{name:"現場描述",exact:true});await expect(notes).toBeEditable();
 let saves=0,pdfs=0;
 page.on("request",r=>{if(r.method()==="PATCH")saves++;if(r.url().includes("/documents")||r.url().includes("/preview"))pdfs++});
 await notes.fill("");await notes.pressSequentially("Inspected every part of the outdoor unit.",{delay:15});
 await page.getByRole("button",{name:"下一步：確認提交",exact:true}).click();
 await page.getByRole("button",{name:"確認服務單並提交",exact:true}).click();
 await expect(page.getByRole("heading",{name:"已提交至維修部",exact:true})).toBeVisible({timeout:15000});
 expect(saves).toBeLessThan(8);expect(pdfs).toBe(0);
 await expect(office.getByRole("row").filter({hasText:"TAB-SYNC"})).toBeVisible({timeout:15000});
 await page.reload();await expect(page.getByRole("heading",{name:"已提交至維修部",exact:true})).toBeVisible();
 await page.getByRole("button",{name:"帳戶選單",exact:true}).click();
 await page.getByRole("button",{name:"登出／切換帳戶",exact:true}).click();
 await login(page,"worker");await expect(page.getByText("TAB-SYNC",{exact:true})).toBeVisible();
 const saved=await (await page.request.get("/api/workspace",{headers:workerHeaders})).json();
 // The old worker token was signed out; the office session remains valid.
 expect(saved.error).toBe("unauthorized");
 expect((await office.request.get("/api/me",{headers:officeHeaders})).ok()).toBeTruthy();
 await office.reload();await expect(office.getByRole("button",{name:/建立任務/}).first()).toBeVisible();
});
