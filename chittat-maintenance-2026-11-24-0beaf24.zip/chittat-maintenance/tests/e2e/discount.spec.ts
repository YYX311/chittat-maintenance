import {test,expect} from '@playwright/test';
import {completeFields,completeItem} from '../complete-fixture.mjs';

test('office enters a negotiated discount, confirms it and sees the net in INDEX',async({page})=>{
 const base=process.env.E2E_BASE_URL||'http://localhost:3100';
 const headers={Origin:base};
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 const auth=await page.request.post('/api/auth/sign-in/phone-number',{headers,data:{phoneNumber:'+85292345678',password:process.env.E2E_PASSWORD}});
 expect(auth.ok(),await auth.text()).toBeTruthy();
 await page.addInitScript(token=>sessionStorage.setItem('ct-tab-session-v1',token),auth.headers()['set-auth-token']);
 const project=await (await page.request.post('/api/projects',{headers,data:{name:'Discount QA',property:'Site',code:'DISCOUNT-QA'}})).json();
 const response=await page.request.post('/api/cases',{headers,data:{...completeFields,customer:'Discount QA',address:'Site',projectId:project.id,projectCode:project.code,items:[{...completeItem,id:'discount-item',preset:0,qty:1,price:14500}]}});
 expect(response.ok(),await response.text()).toBeTruthy();
 const r=await response.json();
 await page.goto(`/?screen=office-case&lang=zh-HK&role=office&id=${r.id}`);
 await page.getByRole('button',{name:'下一步',exact:true}).click();
 const row=page.locator('.work-item-accordion').first();
 await expect(page.getByRole('heading',{name:'工作項目',exact:true})).toBeVisible();
 await expect(row.locator('.work-item-number')).toHaveText('01');
 await expect(row.locator('.work-item-price')).toContainText('14,500.00');
 await row.getByRole('button',{name:/查看定價/}).click();
 await expect(row.locator('.office-pricing')).toBeVisible();
 await row.getByRole('button',{name:/收起定價/}).click();
 await expect(row.locator('.office-pricing')).toHaveCount(0);
 const discount=page.getByRole('region',{name:'優惠金額',exact:true});
 const input=discount.getByRole('textbox',{name:'Less discount HK$'});
 await expect(input).toHaveCSS('font-size','18px');
 await expect(input).toHaveValue('0');
 await input.fill('1450');
 await expect(page.locator('.commercial-net').last()).toContainText('13,050.00');
 await expect.poll(async()=>{
  const w=await (await page.request.get('/api/workspace')).json();return w.records.find((x:any)=>x.id===r.id)?.discountAmount;
 }).toBe('1450');
 await page.screenshot({path:'test-results/discount-pricing.png',fullPage:true});
 await input.fill('15000');
 await page.getByRole('button',{name:'下一步',exact:true}).click();
 await expect(input).toBeVisible();
 await expect(discount.getByRole('alert')).toHaveText('優惠金額須為零或以上、最多兩位小數，並且不可超過小計。');
 await expect(input).toHaveAttribute('aria-invalid','true');
 await input.fill('1450');
 for(let i=0;i<3;i++)await page.getByRole('button',{name:'下一步',exact:true}).click();
 await page.getByRole('button',{name:'確認並更新 INDEX',exact:true}).click();
 await expect.poll(async()=>{
  const result=await (await page.request.get('/api/index')).json();
  return result.data?.find((x:any)=>x.id===r.id)?.discountAmount;
 }).toBe('1450');
 expect(errors).toEqual([]);
});
