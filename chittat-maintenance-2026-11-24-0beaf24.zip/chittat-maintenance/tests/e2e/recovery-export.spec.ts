import { expect, test } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

test('standalone research HTML works offline across both prompt and role views', async ({ page, context }) => {
  const errors: string[] = [];
  const networkRequests: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  page.on('request', request => {
    if (/^https?:/.test(request.url())) networkRequests.push(request.url());
  });
  await context.setOffline(true);
  await page.goto(pathToFileURL(resolve('docs/補填體驗研究.html')).href);
  await expect(page.getByRole('heading', { name: '補填體驗研究', exact: true })).toBeVisible();
  await expect(page.getByText('離線展示 · 虛構資料')).toBeVisible();
  await expect(page.locator('#rows tr')).toHaveCount(5);
  const method = resolve('docs/補填體驗研究-設計與流程.md');
  expect(await readFile(method, 'utf8')).toContain('從表單到研究工作台');

  await page.getByRole('button', { name: '試用員工介面' }).click();
  const demo = page.getByRole('dialog', { name: '員工介面試用' });
  const phone = demo.getByLabel('聯絡電話');
  const next = demo.getByRole('button', { name: '繼續', exact: true });
  await demo.getByRole('button', { name: 'A · 普通提示' }).click();
  await next.click();
  await expect(demo.getByText('資料有待核對，請檢查。')).toBeVisible();
  await expect(demo.getByRole('button', { name: '前往補填' })).toBeHidden();
  await demo.getByRole('button', { name: 'B · 具體解釋' }).click();
  await next.click();
  await demo.getByRole('button', { name: '前往補填' }).click();
  await expect(phone).toBeFocused();
  await phone.fill('12345678');
  await next.click();
  await demo.getByRole('button', { name: '略過', exact: true }).click();
  await expect(demo.getByText('已略過評分。試用完成。')).toBeVisible();
  await demo.getByRole('button', { name: '關閉', exact: true }).click();
  await expect(page.locator('#rows tr')).toHaveCount(5);

  await page.getByRole('button', { name: '維修部', exact: true }).click();
  await expect(page.locator('#rows tr')).toHaveCount(3);
  await expect(page.getByRole('cell', { name: '未完成', exact: true })).toBeVisible();
  await page.getByLabel('開始日期').fill('2026-11-11');
  await page.getByRole('button', { name: '套用日期' }).click();
  await expect(page.locator('#rows tr')).toHaveCount(1);
  const downloading = page.waitForEvent('download');
  await page.getByRole('button', { name: '下載示例 CSV' }).click();
  const download = await downloading;
  const csv = await readFile(await download.path(), 'utf8');
  expect(download.suggestedFilename()).toBe('補填體驗-虛構示例.csv');
  expect(csv).toContain('"2026-11-12","office","O-02","B","未完成","","",""');
  expect(csv).not.toContain('12345678');
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
  expect(errors).toEqual([]);
  expect(networkRequests).toEqual([]);
});
