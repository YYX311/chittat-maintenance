import {readFile} from 'node:fs/promises';
import {test,expect} from '@playwright/test';
import pg from 'pg';
import {completeFields,completeItem} from '../complete-fixture.mjs';
test('phone recovery captures real correction, offline rating and role-separated research results',async({page,context,request})=>{
 test.setTimeout(120000);
 const origin=process.env.E2E_BASE_URL!;
 async function login(phoneNumber:string){const r=await request.post('/api/auth/sign-in/phone-number',{headers:{Origin:origin},data:{phoneNumber,password:process.env.E2E_PASSWORD}});expect(r.ok()).toBeTruthy();return {Origin:origin,Authorization:`Bearer ${r.headers()['set-auth-token']}`};}
 const admin=await login('+85293456789'),worker=await login('+85291234567'),office=await login('+85292345678');
 async function post(path:string,headers:typeof admin,data:Record<string,unknown>){const r=await request.post(path,{headers,data});expect(r.ok(),await r.text()).toBeTruthy();return r.json();}
 const study=await post('/api/research',admin,{action:'create-study',title:'Recovery focused pilot',protocol:'Synthetic local acceptance, missing phone only.'});
 const rpost=(data:Record<string,unknown>)=>post('/api/research',admin,{studyId:study.id,...data});
 const today=new Date(Date.now()+8*3600000).toISOString().slice(0,10);
 const client=new pg.Client({connectionString:process.env.DATABASE_URL});await client.connect();
 try{
 await rpost({action:'study-status',status:'collecting'});
 await rpost({action:'auto-collection',consentReference:'TEST-RECOVERY-ONLY',permissionConfirmed:true});
 await rpost({action:'trial-plan',startsOn:today,weeks:1});
 await post('/api/research/field',worker,{action:'join',studyId:study.id,agreed:true});
 await post('/api/research/field',office,{action:'join',studyId:study.id,agreed:true});
 await post('/api/research/recovery',admin,{action:'configure',studyId:study.id,enabled:true});
 expect((await request.post('/api/research/recovery',{headers:admin,data:{action:'configure',studyId:crypto.randomUUID(),enabled:true}})).status()).toBe(400);
 expect((await request.post('/api/research/recovery',{headers:worker,data:{action:'configure',studyId:study.id,enabled:false}})).status()).toBe(403);
 expect((await request.get(`/api/research/recovery?study=${study.id}`,{headers:worker})).status()).toBe(403);
 expect((await request.get('/api/research/recovery?view=interface',{headers:worker})).status()).toBe(403);
 await page.addInitScript(token=>sessionStorage.setItem('ct-tab-session-v1',token),worker.Authorization.slice(7));
 const rows=async(role='worker')=>(await (await request.get(`/api/research/recovery?study=${study.id}&role=${role}`,{headers:admin})).json());
 for(const variant of ['A','B']){
  if(variant==='B')await client.query('UPDATE research_trial_plans SET starts_on=starts_on-7 WHERE study_id=$1',[study.id]);
  const task=await post('/api/cases',worker,{...completeFields,address:'Local recovery test',phone:'',customer:'Never export this customer',items:[{...completeItem,id:'item',preset:0,qty:1}]});
  await page.goto(`/?screen=worker-basic&lang=zh-HK&role=worker&id=${task.id}`);
  await expect.poll(()=>page.evaluate(id=>Object.keys(localStorage).some(key=>key.startsWith('ct-field-study-config-v1:')&&JSON.parse(localStorage.getItem(key)||'{}').caseId===id),task.id)).toBeTruthy();
  await page.getByRole('button',{name:'下一步：工作內容',exact:true}).click();
  const prompt=page.getByRole('region',{name:'補填助手'});
  await expect(prompt).toBeVisible();
  if(variant==='B'){await expect(prompt).toContainText('辦公室需要用它聯絡客戶');await prompt.getByRole('button',{name:'前往補填'}).click();await expect(page.getByLabel('客戶聯絡電話')).toBeFocused();}
  else await expect(prompt).toContainText('資料有待核對，請檢查');
  await context.setOffline(true);
  await page.getByLabel('客戶聯絡電話').fill('91234567');
  await expect(prompt.getByRole('heading',{name:'剛才補填這一步，讓你有多煩躁？'})).toBeVisible();
  await prompt.getByRole('button',{name:variant==='A'?'5':'2',exact:true}).click();
  await expect(prompt).toHaveCount(0);
  await context.setOffline(false);
  await expect.poll(async()=> (await rows()).conditions.find((r:any)=>r.variant===variant)?.rated,{timeout:20000}).toBe(1);
  if(variant==='B'){
   // Continue in the same mounted workspace so the terminal event is associated.
   await page.getByRole('button',{name:'下一步：工作內容',exact:true}).click();
   await page.getByRole('button',{name:'下一步：相片及描述',exact:true}).click();
   await page.getByRole('button',{name:'下一步：確認提交',exact:true}).click();
   await page.getByRole('button',{name:'確認服務單並提交',exact:true}).click();
   await expect.poll(async()=> (await rows()).total.submitted,{timeout:20000}).toBe(1);
  }
 }
 const summary=await rows();expect(summary.total).toMatchObject({n:2,resolved:2,rated:2});expect(summary.pairs).toHaveLength(1);expect((await rows('office')).total.n).toBe(0);
 expect(summary.episodes.find((r:any)=>r.variant==='B').focused).toBe(true);
 const csv=await request.get(`/api/research/recovery?study=${study.id}&csv=1`,{headers:admin});expect(csv.ok()).toBeTruthy();expect(await csv.text()).not.toContain('91234567');expect(await csv.text()).not.toContain('Never export');
 const officePage=await context.newPage();
 await officePage.addInitScript(token=>sessionStorage.setItem('ct-tab-session-v1',token),office.Authorization.slice(7));
 const project=await post('/api/projects',office,{name:'Recovery test',property:'Office recovery test',code:'RECOVERY-E2E'});
 const officeTask=await post('/api/cases',office,{...completeFields,address:project.property,customer:'Office recovery sample',phone:'12345678',projectId:project.id,projectCode:project.code});
 await officePage.goto(`/?screen=office-quote&lang=zh-HK&role=office&id=${officeTask.id}`);
 await expect.poll(()=>officePage.evaluate(id=>Object.keys(localStorage).some(key=>key.startsWith('ct-field-study-config-v1:')&&JSON.parse(localStorage.getItem(key)||'{}').caseId===id),officeTask.id)).toBeTruthy();
 await officePage.getByLabel('客戶聯絡電話').fill('123');
 await officePage.getByRole('button',{name:'下一步',exact:true}).click();
 const officePrompt=officePage.getByRole('region',{name:'補填助手'});await expect(officePrompt).toBeVisible();
 await officePrompt.getByRole('button',{name:'前往補填'}).click();
 await officePage.getByLabel('客戶聯絡電話').fill('12345678');
 await officePrompt.getByRole('button',{name:'略過',exact:true}).click();
 await expect.poll(async()=> (await rows('office')).episodes[0]?.skipped).toBe(true);
 await officePage.close();
 const adminPage=await context.newPage();await adminPage.addInitScript(token=>sessionStorage.setItem('ct-tab-session-v1',token),admin.Authorization.slice(7));
 const supplied = await request.get('/api/research/recovery?view=interface',{headers:admin});
 expect(supplied.ok()).toBeTruthy();
 const html = await supplied.text();
 // The frame's existing security metadata is the only addition to the supplied document.
 expect(html).toContain('http-equiv="Content-Security-Policy"');
 expect(html.replace(/<head><meta name="recovery-mode" content="system"><meta http-equiv="Content-Security-Policy" content="[^"]*">/, '<head>'))
  .toBe(await readFile('docs/recovery-study-supplied.html','utf8'));
 await adminPage.goto('/research?section=analysis&view=recovery');
 const suppliedFrame = adminPage.frameLocator('iframe[title="補填體驗研究"]');
 await expect(suppliedFrame.getByRole('heading',{name:'補填體驗研究',exact:true})).toBeVisible();
 await expect(suppliedFrame.getByText('Error Recovery UI: A Pilot Study on Field Completion')).toBeVisible();
 await suppliedFrame.getByText('樣本量估算（兩個獨立組）',{exact:true}).click();
 await expect(suppliedFrame.getByRole('button',{name:'計算樣本量'})).toBeVisible();

 await adminPage.goto('/research?section=analysis&view=recovery');
 const research = adminPage.frameLocator('iframe[title="補填體驗研究"]');
 await expect(research.getByText('維修表單採集記錄 · 員工介面試用不寫入資料。')).toBeVisible();
 await expect(research.getByText('樣本量估算（兩個獨立組）')).toBeVisible();
 await expect(research.getByRole('heading',{name:'受試者內變化 (Within-Subject Analysis)'})).toBeVisible();
 await expect(research.locator('#scope')).toContainText('2 筆記錄');
 await expect(research.locator('#readout')).toContainText('1 位有配對歷時');
 const filters = research.getByRole('group',{name:'記錄篩選'});
 await filters.getByRole('button',{name:'B · 具體解釋'}).click();
 await expect(research.locator('#rows tr')).toHaveCount(1);
 const downloading = adminPage.waitForEvent('download');
 await research.getByRole('button',{name:'下載補填資料 CSV'}).click();
 const csvText = await readFile(await (await downloading).path(),'utf8');
 expect(csvText.trim().split('\r\n')).toHaveLength(2);
 expect(csvText).toContain('"worker"');
 expect(csvText).toContain('"B"');
 expect(csvText).not.toContain('91234567');
 await filters.getByRole('button',{name:'全部',exact:true}).click();

 await research.getByRole('button',{name:'試用員工介面'}).click();
 const demo=research.getByRole('dialog',{name:'員工介面試用'});
 await expect(demo.getByRole('button',{name:'關閉對話框'})).toBeInViewport();
 await demo.getByRole('button',{name:'繼續',exact:true}).click();
 await demo.getByRole('button',{name:'前往補填'}).click();
 await expect(demo.getByLabel('聯絡電話')).toBeFocused();
 await demo.getByLabel('聯絡電話').fill('12345678');
 await demo.getByRole('button',{name:'繼續',exact:true}).click();
 await expect(demo.getByRole('button',{name:'7',exact:true})).toBeVisible();
 await demo.getByRole('button',{name:'略過',exact:true}).click();
 await expect(demo.locator('#done')).toContainText('已略過評分');
 await demo.getByRole('button',{name:'關閉對話框'}).click();
 expect((await rows()).total.n).toBe(2);

 await research.getByRole('group',{name:'採集端口'}).getByRole('button',{name:'維修部',exact:true}).click();
 await expect(research.getByRole('cell',{name:'已略過',exact:true})).toBeVisible();
 await research.getByRole('button',{name:'暫停新採集'}).click();
 await expect(research.getByRole('button',{name:'啟用補填採集'})).toBeEnabled();
 expect((await rows('office')).enabled).toBe(false);
 await adminPage.screenshot({path:'test-results/recovery-desktop.png',fullPage:true});
 await adminPage.setViewportSize({width:390,height:844});
 expect(await adminPage.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
 expect(await research.locator('body').evaluate(el=>el.scrollWidth<=window.innerWidth)).toBeTruthy();
 await adminPage.screenshot({path:'test-results/recovery-mobile.png',fullPage:true});
 await post('/api/research/recovery',admin,{action:'configure',studyId:study.id,enabled:false});
 const denied=await request.post('/api/research/recovery',{headers:worker,data:{studyId:study.id,events:[{id:crypto.randomUUID(),episode:crypto.randomUUID(),caseId:crypto.randomUUID(),kind:'shown',at:Date.now()}]}});expect(denied.status()).toBe(403);
 }finally{
  // Remove only this test's fixtures so the fresh-workbench test still starts empty.
  await context.setOffline(false);
  await Promise.all(context.pages().map(tab=>tab.close()));
  try{
   for(const table of ['research_recovery_events','research_field_events','research_task_pulse'])
    await client.query(`DELETE FROM ${table} WHERE study_case_id IN (SELECT id FROM research_cases WHERE study_id=$1)`,[study.id]);
   for(const table of ['research_cases','research_recovery_settings','research_participation','research_auto_collection','research_studies'])
    await client.query(`DELETE FROM ${table} WHERE ${table==='research_studies'?'id':'study_id'}=$1`,[study.id]);
  }finally{await client.end();}
 }
});

