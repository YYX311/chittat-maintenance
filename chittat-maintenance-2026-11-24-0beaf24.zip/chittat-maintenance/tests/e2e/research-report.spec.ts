import { readFile } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import { expect, test } from '@playwright/test';

test('the generated research report includes charts and stays readable offline', async ({ context, page, request, baseURL }, testInfo) => {
  const login = await request.post('/api/auth/sign-in/phone-number', {
    headers: { Origin: baseURL! },
    data: { phoneNumber: '+85293456789', password: process.env.E2E_PASSWORD },
  });
  expect(login.ok()).toBeTruthy();
  await page.addInitScript(token => sessionStorage.setItem('ct-tab-session-v1', token), login.headers()['set-auth-token']);
  await page.goto('/research?tab=report');
  await page.getByRole('button', { name: '報告', exact:true }).click();

  const preview = page.getByRole('article', { name: '研究報告預覽' });
  await expect(preview).toHaveCount(0);
  await page.getByRole('button', { name: '生成報告', exact: true }).click();
  await expect(preview.getByText('業務記錄 · 報告生成時的快照', { exact: true })).toBeVisible();
  await expect(preview.getByRole('img', { name: /研究模型/ })).toBeVisible();
  await expect(preview.getByRole('heading', { name: '心理測量與解讀' })).toBeVisible();
  await expect(preview.getByRole('heading', { name: '假設、實驗與回歸結果' })).toBeVisible();

  const fileReady = page.waitForEvent('download');
  await page.getByRole('button', { name: '下載 HTML 報告' }).click();
  const file = await fileReady;
  expect(file.suggestedFilename()).toMatch(/^research-report-\d{4}-\d{2}-\d{2}\.html$/);
  const path = testInfo.outputPath(file.suggestedFilename());
  await file.saveAs(path);
  const html = await readFile(path, 'utf8');
  expect(html).not.toContain('<script');
  expect(html).not.toContain('ct-tab-session-v1');
  expect(html).toContain('埋點事件及收集狀況');

  const offline = await context.newPage();
  await context.setOffline(true);
  try {
    await offline.goto(pathToFileURL(path).href);
    const report = offline.getByRole('article', { name: '研究報告預覽' });
    await expect(report).toHaveCSS('background-color', 'rgb(255, 255, 255)');
    await expect(report.getByRole('img', { name: /研究模型/ })).toBeVisible();
    await expect(report.getByRole('table', { name: '分析變量定義' })).toBeVisible();
    await expect(report.getByText('目前沒有可分解的時間記錄。')).toBeVisible();
  } finally {
    await context.setOffline(false);
    await offline.close();
  }
});
