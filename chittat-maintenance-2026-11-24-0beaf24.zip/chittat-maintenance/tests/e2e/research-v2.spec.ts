import { expect, test } from '@playwright/test';
import { completeFields, completeItem } from '../complete-fixture.mjs';

test('research keeps one live dataset across model, charts and CSV', async ({ page, request, baseURL }) => {
  const login = await request.post('/api/auth/sign-in/phone-number', {
    headers: { Origin: baseURL! },
    data: { phoneNumber: '+85293456789', password: process.env.E2E_PASSWORD },
  });
  expect(login.ok()).toBeTruthy();
  const token = login.headers()['set-auth-token'];
  await page.addInitScript((value) => sessionStorage.setItem('ct-tab-session-v1', value), token);
  await page.goto('/research');
  await expect(page.getByRole('heading',{name:'期間交接量'})).toBeVisible();
  await page.getByRole('button',{name:'退回原因',exact:true}).click();
  await expect(page.getByRole('heading',{name:'退回時需要解決甚麼？'})).toBeVisible();
  await expect(page.getByText('這段期間沒有退回記錄。')).toBeVisible();
  await page.getByRole('button', { name: '研究模型' }).click();
  await expect(page.getByRole('heading', { name: '交接概況' })).toBeVisible();
  await expect(page.getByText(/示例資料/)).toHaveCount(0);
  await expect(page.getByText('0 次提交 · 0 名維修人員')).toBeVisible();
  const tabs = page.getByRole('navigation', { name: '研究工作台' });
  await expect(tabs.getByRole('button')).toHaveCount(5);
  await expect(tabs).toHaveCSS('backdrop-filter', 'blur(18px) saturate(1.15)');
  await page.setViewportSize({ width: 390, height: 844 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBe(390);
  await expect(page.getByRole('img', { name: /研究模型/ })).toBeVisible();
  await expect(page.getByText('四個假設', { exact: true })).toHaveCount(0);
  const analysis = tabs.getByRole('button', { name: '圖表分析', exact: true });
  await analysis.click();
  const charts = page.getByRole('navigation', { name: '分析圖表' });
  await charts.getByRole('button', { name: '填單感受' }).click();
  await expect(analysis).toHaveAttribute('aria-current', 'page');
  await expect(page.getByRole('heading', { name: '操作受阻與退回率' })).toBeVisible();
  await expect(page).toHaveURL(/tab=psych/);
  await charts.getByRole('button', { name: '核對提示' }).click();
  await expect(page.getByRole('heading', { name: /有提示和沒提示/ })).toBeVisible();
  await expect(page.getByText('尚無可比較的核對提示分組資料。')).toBeVisible();
  await tabs.getByRole('button', { name: '資料記錄' }).click();
  await expect(page.getByRole('heading', { name: '資料記錄' })).toBeVisible();
  await expect(page.getByText('抽樣自填', { exact: true })).toBeVisible();
  const download = page.waitForEvent('download');
  await page.getByRole('button', { name: /匯出分析資料 CSV/ }).click();
  expect((await download).suggestedFilename()).toMatch(/^episodes-.*\.csv$/);
  await tabs.getByRole('button',{name:'交接觀察'}).click();
  await expect(page.getByRole('heading',{name:'退回時需要解決甚麼？'})).toBeVisible();
});


test('a fresh research tab offers sign in',async({page})=>{await page.goto('/research');await expect(page.getByLabel('手機號碼')).toBeVisible();await expect(page.getByText('unauthorized',{exact:true})).toHaveCount(0);});



test('the episode API requires research authorization', async ({ request, baseURL }) => {
  const url = '/api/research/v2/dataset?from=2026-11-12&to=2026-11-18';
  expect((await request.get(url)).status()).toBe(401);
  const login = await request.post('/api/auth/sign-in/phone-number', {
    headers: { Origin: baseURL! },
    data: { phoneNumber: '+85292345678', password: process.env.E2E_PASSWORD },
  });
  expect(login.ok()).toBeTruthy();
  const headers = { Authorization: 'Bearer ' + login.headers()['set-auth-token'] };
  expect((await request.get(url, { headers })).status()).toBe(403);
});

test('research returns to business sign-in with either kind of staff account', async ({ page }) => {
  async function signIn(phone: string) {
    await page.getByLabel('公司已登記的手機號碼').fill(phone);
    await page.getByLabel('密碼', { exact: true }).fill(process.env.E2E_PASSWORD!);
    await page.getByRole('button', { name: '登入', exact: true }).click();
  }

  await page.goto('/');
  await signIn('93456789');
  await expect(page.getByRole('heading', { name: '期間交接量' })).toBeVisible();
  await page.getByRole('link', { name: '返回業務系統' }).click();
  const phone = page.getByLabel('公司已登記的手機號碼');
  await expect(phone).toBeVisible();
  await page.reload();
  await expect(phone).toBeVisible();
  await page.goto('/');
  await expect(phone).toBeVisible();
  await page.goto('/research');
  await expect(page.getByRole('heading', { name: '期間交接量' })).toBeVisible();
  await page.getByRole('link', { name: '返回業務系統' }).click();
  await signIn('91234567');
  await expect(page).toHaveURL(/screen=worker-tasks/);
  await page.goto('/research');
  await expect(page.getByLabel('手機號碼', { exact: true })).toBeVisible();
  await page.getByRole('link', { name: '返回業務系統' }).click();
  await signIn('92345678');
  await expect(page).toHaveURL(/screen=office-inbox/);
  await expect(page).not.toHaveURL(/switchAccount/);
});

test('staff operations are collected automatically without a participation card', async ({ page, request, baseURL }) => {
  const path = '/api/research/v2/probe';
  const login = async (phoneNumber: string) => {
    const response = await request.post('/api/auth/sign-in/phone-number', {
      headers: { Origin: baseURL! }, data: { phoneNumber, password: process.env.E2E_PASSWORD },
    });
    expect(response.ok()).toBeTruthy();
    return { Authorization: 'Bearer ' + response.headers()['set-auth-token'], Origin: baseURL! };
  };
  const worker = await login('+85291234567');
  const admin = await login('+85293456789');
  const staff = await request.post('/api/cases', {
    headers: worker, data: { ...completeFields, customer: 'Probe test', address: 'Probe test site', phone: '',
      items: [{ ...completeItem, id: 'probe-item', preset: 0, qty: 1 }] },
  });
  expect(staff.ok(), await staff.text()).toBeTruthy();
  const task = await staff.json();
  await page.addInitScript(token => sessionStorage.setItem('ct-tab-session-v1', token), worker.Authorization.slice(7));
  await page.goto('/?screen=worker-profile&lang=zh-HK');
  await expect(page.getByRole('button', { name: '同意參與研究' })).toHaveCount(0);
  await expect(page.getByRole('heading', { name: '工作流程研究' })).toHaveCount(0);
  const configLoaded = page.waitForResponse(response => response.url().endsWith(path) && response.request().method() === 'GET');
  await page.goto('/?screen=worker-basic&lang=zh-HK&id=' + task.id);
  expect(await (await configLoaded).json()).toMatchObject({ joined: true });
  await expect(page.getByLabel('客戶聯絡電話')).toBeVisible();
  const eventUpload = page.waitForResponse(response => response.url().endsWith(path) && response.request().method() === 'POST');
  await page.getByRole('button', { name: '下一步：工作內容', exact: true }).click();
  const upload = await eventUpload;
  const original = upload.request().postDataJSON();
  expect(original.events).toContainEqual(expect.objectContaining({ name: 'form.validation_block', field: 'phone' }));
  expect((await upload.json()).recorded).toBeGreaterThanOrEqual(1);
  expect(await (await request.post(path, { headers: worker, data: original })).json()).toEqual({ recorded: 0 });
  const updated = await request.patch('/api/cases/' + task.id, { headers: worker, data: { serverVersion: task.serverVersion, phone: '91234567' } });
  expect(updated.ok(), await updated.text()).toBeTruthy();
  const submitted = await request.post('/api/cases/' + task.id + '/actions', {
    headers: worker, data: { action: 'submit', serverVersion: (await updated.json()).serverVersion },
  });
  expect(submitted.ok(), await submitted.text()).toBeTruthy();
  const version = (await submitted.json()).serverVersion;
  const surveyEvents = [
    { id: 'workload-shown', name: 'survey.shown' },
    { id: 'workload-effort', name: 'survey.effort', value: 6 },
    { id: 'workload-fatigue', name: 'survey.fatigue', value: 4 },
  ].map(event => ({ ...event, version, caseId: task.id, at: Date.now(), schema: 'workflow-fatigue-v2' }));
  expect(await (await request.post(path, { headers: worker, data: { ...original, events: surveyEvents } })).json()).toEqual({ recorded: 3 });
  const day = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Hong_Kong', dateStyle: 'short' }).format(new Date());
  const result = await request.get('/api/research/v2/dataset?from=' + day + '&to=' + day, { headers: admin });
  expect(result.ok(), await result.text()).toBeTruthy();
  const data = await result.json();
  expect(data.episodes).toContainEqual(expect.objectContaining({ validationBlocks: 1, effort: 6, fatigue: 4 }));
  expect(data.survey).toEqual({ shown: 1, answered: 1 });
  expect(JSON.stringify(data)).not.toContain('91234567');
});
