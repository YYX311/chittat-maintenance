import {test,expect} from '@playwright/test';
import {completeFields,completeItem} from '../complete-fixture.mjs';
test('service dates omit time and retain legacy timestamps visibly',async({page,request,baseURL})=>{
 const r=await request.post('/api/auth/sign-in/phone-number',{headers:{Origin:baseURL!},data:{phoneNumber:'+85291234567',password:process.env.E2E_PASSWORD}});
 const token=r.headers()['set-auth-token'];
 const task=await request.post('/api/cases',{headers:{Origin:baseURL!,Authorization:'Bearer '+token},data:{...completeFields,address:'Date test',customer:'Date test',items:[{...completeItem,id:'date-item',preset:0,qty:1}]}});
 expect(task.ok()).toBeTruthy();
 await page.addInitScript(t=>sessionStorage.setItem('ct-tab-session-v1',t),token);
 await page.goto('/?screen=worker-photo&lang=zh-HK&id='+(await task.json()).id);
 const start=page.getByLabel('開工時間／日期',{exact:true});
 await expect(start).toHaveAttribute('type','date');
 await expect(start).toHaveValue('2026-09-20');
 await page.getByLabel('完工時間／日期',{exact:true}).fill('2026-09-20');
 await expect(page.getByRole('button',{name:'✓ 確認日期',exact:true})).toBeVisible();
});
test('a worker may correct returned notes directly without opening the feedback shortcut',async({page,request,baseURL})=>{
 async function login(phoneNumber:string){
  const r=await request.post('/api/auth/sign-in/phone-number',{headers:{Origin:baseURL!},data:{phoneNumber,password:process.env.E2E_PASSWORD}});
  expect(r.ok()).toBeTruthy();return {Origin:baseURL!,Authorization:'Bearer '+r.headers()['set-auth-token']};
 }
 const worker=await login('+85291234567'),office=await login('+85292345678');
 let response=await request.post('/api/cases',{headers:worker,data:{...completeFields,address:'Direct edit test',customer:'Direct edit test',items:[{...completeItem,id:'direct-item',preset:0,qty:1}]}});
 let task=await response.json();
 response=await request.post('/api/cases/'+task.id+'/actions',{headers:worker,data:{action:'submit',serverVersion:task.serverVersion}});
 task=await response.json();
 response=await request.post('/api/cases/'+task.id+'/actions',{headers:office,data:{action:'return',serverVersion:task.serverVersion,payload:{field:'notes',reason:'description',text:'Please clarify inspection result'}}});
 expect(response.ok()).toBeTruthy();
 const compact=await request.get('/api/workspace',{headers:worker});
 const listed=(await compact.json()).records.find((r:any)=>r.id===task.id);
 expect(listed.serviceDocuments[0].snapshot).toBeUndefined();
 const detail=await request.get('/api/cases/'+task.id,{headers:worker});
 expect((await detail.json()).serviceDocuments[0].snapshot.notes).toBeTruthy();
 const cached=await request.get('/api/workspace',{headers:{...worker,'If-None-Match':compact.headers().etag}});
 expect(cached.status()).toBe(304);
 await page.addInitScript(t=>sessionStorage.setItem('ct-tab-session-v1',t),worker.Authorization.slice(7));
 await page.goto('/?screen=worker-photo&lang=zh-HK&id='+task.id);
 await page.getByRole('textbox',{name:'現場描述',exact:true}).fill('Inspection completed and result clarified');
 await page.getByRole('button',{name:'下一步：確認提交',exact:true}).click();
 await page.getByRole('button',{name:'確認修改並重新提交',exact:true}).click();
 await expect(page.getByRole('heading',{name:'已提交至維修部',exact:true})).toBeVisible();
});
