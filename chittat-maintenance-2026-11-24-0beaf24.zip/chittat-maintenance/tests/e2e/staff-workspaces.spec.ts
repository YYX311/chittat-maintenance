import {test,expect} from '@playwright/test';
import pg from 'pg';
test('dual-role staff choose a workspace per tab without granting research access',async({request})=>{
 const c=new pg.Client({connectionString:process.env.DATABASE_URL});await c.connect();
 try{
 await c.query("UPDATE employees SET can_work=true WHERE staff_code='office'");
 const login=await request.post('/api/auth/sign-in/phone-number',{headers:{Origin:process.env.E2E_BASE_URL!},data:{phoneNumber:'+85292345678',password:process.env.E2E_PASSWORD}});
 expect(login.ok()).toBeTruthy();
 const headers={Authorization:'Bearer '+login.headers()['set-auth-token']};
 const [office,worker]=await Promise.all(['office','worker'].map(role=>request.get('/api/me',{headers:{...headers,'X-Workspace-Role':role}})));
 expect(await office.json()).toMatchObject({role:'office',canWork:true,canResearch:false});
 expect(await worker.json()).toMatchObject({role:'worker',canWork:true,canResearch:false});
 expect((await request.get('/api/research',{headers})).status()).toBe(403);
 }finally{await c.query("UPDATE employees SET can_work=false WHERE staff_code='office'");await c.end();}
});

test('the sign-in page prompts for a workspace only after authenticating dual-role staff', async ({context, page}) => {
  const db = new pg.Client({connectionString:process.env.DATABASE_URL});
  await db.connect();
  async function signIn(tab: typeof page, phone: string) {
    await tab.goto('/?screen=login&lang=zh-HK');
    await expect(tab.locator('.ux-lang option[value="zh-HK"]')).toHaveText('繁體中文');
    const stages=tab.locator('.ux-login-stages');
    await expect(stages).toContainText('② 維修部：覆核及修正服務單，在 INDEX 處理報價及發票');
    await expect(stages).not.toContainText('③');
    await expect(tab.getByRole('dialog', {name:'選擇工作台'})).toHaveCount(0);
    await expect(tab.locator('form select')).toHaveCount(0);
    await tab.getByLabel('公司已登記的手機號碼').fill(phone);
    await tab.getByLabel('密碼', {exact:true}).fill(process.env.E2E_PASSWORD!);
    await tab.getByRole('button', {name:'登入', exact:true}).click();
  }
  const officeTab = await context.newPage();
  try {
    await signIn(page, '91234567');
    await expect(page).toHaveURL(/screen=worker-tasks/);
    await signIn(officeTab, '92345678');
    await expect(officeTab).toHaveURL(/screen=office-inbox/);
    await db.query("UPDATE employees SET can_work=true WHERE staff_code='office'");

    await page.close();
    await officeTab.close();
    const workerSide = await context.newPage();
    const officeSide = await context.newPage();
    await signIn(workerSide, '92345678');
    await workerSide.getByRole('dialog', {name:'選擇工作台'}).getByRole('button', {name:/^維修人員/}).click();
    await expect(workerSide).toHaveURL(/screen=worker-tasks/);
    await signIn(officeSide, '92345678');
    await officeSide.getByRole('dialog', {name:'選擇工作台'}).getByRole('button', {name:/^維修部/}).click();
    await expect(officeSide).toHaveURL(/screen=office-inbox/);
    await workerSide.reload();
    await expect(workerSide.getByRole('button', {name:/新增現場記錄/}).first()).toBeVisible();
    await expect(officeSide.getByRole('button', {name:/建立任務/}).first()).toBeVisible();
  } finally {
    await db.query("UPDATE employees SET can_work=false WHERE staff_code='office'");
    await db.end();
  }
});
