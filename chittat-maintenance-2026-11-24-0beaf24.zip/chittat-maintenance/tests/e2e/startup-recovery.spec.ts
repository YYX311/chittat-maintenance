import { expect, test } from '@playwright/test';

test('an unavailable account lookup stops waiting and offers the business login', async ({ page, request, baseURL }) => {
  const response = await request.post('/api/auth/sign-in/phone-number', {
    headers: { Origin: baseURL! },
    data: { phoneNumber: '+85292345678', password: process.env.E2E_PASSWORD },
  });
  expect(response.ok()).toBeTruthy();
  await page.addInitScript(token => sessionStorage.setItem('ct-tab-session-v1', token), response.headers()['set-auth-token']);
  await page.route('**/api/me', async route => {
    await new Promise(resolve => setTimeout(resolve, 18000));
    await route.fulfill({ json: {} }).catch(() => {});
  });
  await page.goto('/');
  await expect(page.getByLabel('公司已登記的手機號碼')).toBeVisible({ timeout: 15000 });
  await expect(page.getByRole('status').filter({ hasText: '正在載入' })).toHaveCount(0);
  await page.unrouteAll({ behavior: 'ignoreErrors' });
});

test('temporary gateway failures are retried while restoring a staff session', async ({ page, request, baseURL }) => {
  const response = await request.post('/api/auth/sign-in/phone-number', {
    headers: { Origin: baseURL! },
    data: { phoneNumber: '+85292345678', password: process.env.E2E_PASSWORD },
  });
  expect(response.ok()).toBeTruthy();
  await page.addInitScript(token => sessionStorage.setItem('ct-tab-session-v1', token), response.headers()['set-auth-token']);
  let attempts = 0;
  await page.route('**/api/me', async route => {
    attempts++;
    if (attempts === 1) await route.fulfill({ status: 503, json: { error: 'service-unavailable' } });
    else await route.continue();
  });
  await page.goto('/');
  await expect(page.getByRole('button', { name: /建立任務/ }).first()).toBeVisible();
  expect(attempts).toBe(2);
});
