import { expect, test } from "@playwright/test";
import pg from "pg";
import { completeFields, completeItem } from "../complete-fixture.mjs";

test("opt-in staff enter ABAB automatically and offline friction reaches anonymous analysis",async({page,context,request})=>{
  test.setTimeout(120000);
  const origin=process.env.E2E_BASE_URL!;
  const login=async(phoneNumber:string)=>{
    const response=await request.post("/api/auth/sign-in/phone-number",{headers:{Origin:origin},
      data:{phoneNumber,password:process.env.E2E_PASSWORD}});
    expect(response.ok()).toBeTruthy();
    return {Authorization:`Bearer ${response.headers()["set-auth-token"]}`,Origin:origin};
  };
  const admin=await login("+85293456789"), office=await login("+85292345678"), worker=await login("+85291234567");
  async function post(path:string,headers:typeof admin,data:Record<string,unknown>){
    const response=await request.post(path,{headers,data});
    expect(response.ok(),await response.text()).toBeTruthy();
    return response.json();
  }
  const study=await post("/api/research",admin,{action:"create-study",title:"Automatic pilot",protocol:"Four alternating weeks of the maintenance form."});
  const research=(data:Record<string,unknown>)=>post("/api/research",admin,{...data,studyId:study.id});
  const config=async(id:string)=>(await request.get(`/api/research/field?case=${id}`,{headers:worker})).json();
  const report=async()=>(await request.get(`/api/research?field=1&study=${study.id}`,{headers:admin})).json();
  const sample={...completeFields,address:"Synthetic only",customer:"Sensitive synthetic value",
    items:[{...completeItem,id:"item",preset:0,qty:1}]};
  const create=()=>post("/api/cases",worker,sample);

  await research({action:"study-status",status:"collecting"});
  const today=new Date(Date.now()+8*3600000).toISOString().slice(0,10);
  await research({action:"auto-collection",consentReference:"TEST-AUTHORIZATION",permissionConfirmed:true});
  const outside=await create();
  expect((await report()).trial.tasks).toBe(0);

  await page.addInitScript(token=>sessionStorage.setItem("ct-tab-session-v1",token),worker.Authorization.slice(7));
  await page.goto("/?screen=worker-profile&role=worker&lang=zh-HK");
  const participate=page.getByRole("region",{name:"使用體驗研究"});
  await expect(participate).toBeVisible();
  await participate.getByRole("button",{name:"同意參與研究"}).click();
  await expect(participate.getByRole("button",{name:"停止參與"})).toBeVisible();
  await participate.getByLabel("年資").selectOption("1_to_3");
  await participate.getByRole("button",{name:"儲存背景資料"}).click();
  await expect.poll(async()=> (await config("none")).profile?.tenure).toBe("1_to_3");
  const routine=await create();
  expect((await config(routine.id)).assignment).toBe("OBS");
  expect((await config(routine.id)).assistant).toBe(false);
  await post("/api/research/field",worker,{studyId:study.id,action:"events",events:[{
    id:crypto.randomUUID(),caseId:routine.id,kind:"validation_error",field:"phone",surface:"worker-basic",at:Date.now(),
  }]});
  expect((await report()).usage.backlog).toEqual(expect.arrayContaining([expect.objectContaining({action:"validation_error",target:"phone"})]));
  await research({action:"trial-plan",startsOn:today,weeks:1});
  const baseline=await create();
  expect((await config(baseline.id)).assignment).toBe("A1");
  expect((await config(baseline.id)).assistant).toBe(false);
  expect((await config(outside.id)).caseId).toBeNull();

  // Advance the isolated calendar fixture to B1 without editing a live plan.
  const client=new pg.Client({connectionString:process.env.DATABASE_URL});
  await client.connect();
  try {
    await client.query("UPDATE research_trial_plans SET starts_on=starts_on-7 WHERE study_id=$1",[study.id]);
    await client.query("UPDATE research_participation SET joined_at=joined_at-interval '7 days' WHERE study_id=$1",[study.id]);
  }
  finally {await client.end();}
  const task=await create();
  await post("/api/research/field",worker,{studyId:study.id,action:"workload",period:"A1",ratings:[30,40,50,60,70,80]});
  const workload=await request.get(`/api/research?field=1&study=${study.id}&csv=workload`,{headers:admin});
  expect(await workload.text()).toContain('"30","40","50","60","70","80","55"');
  expect((await config(task.id)).assignment).toBe("B1");
  expect((await config(baseline.id)).assistant).toBe(false);
  await page.setViewportSize({width:390,height:844});
  await page.goto(`/?screen=worker-basic&lang=zh-HK&role=worker&id=${task.id}`);
  const phone=page.getByLabel("客戶聯絡電話");
  await expect(phone).toHaveValue("12345678");
  await expect.poll(()=>page.evaluate(()=>Object.keys(localStorage).some(key=>key.startsWith("ct-field-study-config-v1:")&&localStorage.getItem(key)?.includes("B1")))).toBeTruthy();
  await context.setOffline(true);
  await phone.fill("");
  const hints=page.getByRole("region",{name:"退回風險提示"});
  await expect(hints.getByRole("heading",{name:"AI 防錯助手"})).toBeVisible();
  await expect(hints.getByText(/聯絡電話/).first()).toBeVisible();
  await page.screenshot({path:"test-results/field-offline-hints.png"});
  await hints.getByRole("button",{name:/前往.*聯絡電話/}).click();
  await expect(phone).toBeFocused();
  await expect(page.getByText("請填寫聯絡電話；不適用的資料請填「不適用」。",{exact:true})).toHaveCount(1);
  expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBeTruthy();
  await phone.fill("12345678");
  await context.setOffline(false);
  await expect.poll(async()=>{
    const result=await request.get(`/api/research?field=1&study=${study.id}&csv=events`,{headers:admin});
    return result.text();
  },{timeout:20000}).toContain("field_clear");

  const getLatest=async()=>{
    const workspace=await request.get("/api/workspace",{headers:worker});
    return (await workspace.json()).records.find((row:{id:string})=>row.id===task.id);
  };
  // Workspace saves the restored value before the worker submits.
  await expect.poll(async()=> (await getLatest())?.phone).toBe("12345678");
  await page.goto(`/?screen=worker-review&lang=zh-HK&role=worker&id=${task.id}`);
  await expect.poll(()=>page.evaluate(id=>Object.keys(localStorage).some(key=>key.startsWith("ct-field-study-config-v1:")&&
    JSON.parse(localStorage.getItem(key)||"{}").caseId===id),task.id)).toBeTruthy();
  await page.getByRole("button",{name:"確認服務單並提交"}).click();
  const pulse=page.getByRole("region",{name:"這次填寫感受"});
  await expect(pulse).toBeVisible();
  await pulse.getByLabel("操作順手嗎？").selectOption("5");
  await pulse.getByLabel("有多心累或煩躁？").selectOption("6");
  await pulse.getByRole("button",{name:"送出回報"}).click();
  await expect(pulse).toHaveCount(0);
  await post("/api/research/field",office,{studyId:study.id,action:"join",agreed:true});
  const officePage=await context.newPage();
  await officePage.addInitScript(token=>sessionStorage.setItem("ct-tab-session-v1",token),office.Authorization.slice(7));
  await officePage.goto(`/?screen=office-case&lang=zh-HK&role=office&id=${task.id}`);
  await expect(officePage.getByRole("heading",{name:"覆核提交資料"})).toBeVisible();
  await expect(officePage.getByRole("heading",{name:"AI 防錯助手"})).toBeVisible();
  const officePhone=officePage.getByLabel("客戶聯絡電話",{exact:true});
  await expect(officePhone).toHaveValue("12345678");
  await officePhone.fill("");
  await officePage.getByRole("button",{name:"下一步",exact:true}).click();
  await officePhone.fill("12345678");
  await expect.poll(async()=>{
    const result=await request.get(`/api/research?field=1&study=${study.id}&csv=events`,{headers:admin});
    return result.text();
  },{timeout:20000}).toMatch(/"office","improved","screen","validation_error","ok","","office-0","phone"/);
  const submitted=await getLatest();
  expect(submitted.phone).toBe("12345678");
  await post(`/api/cases/${task.id}/actions`,office,{action:"return",serverVersion:submitted.serverVersion,
    payload:{field:"phone",reason:"equipment",text:"Synthetic review evidence"}});
  const summary=await report();
  expect(summary.trialSummary.comparisons[1]).toMatchObject({n:1,returned:1,pulse:1,strain:6});
  expect(summary.usage.backlog.some((row:{target:string})=>row.target==="phone")).toBeTruthy();
  expect(summary.usage.backlog).toEqual(expect.arrayContaining([
    expect.objectContaining({role:"worker",target:"phone",action:"field_clear"}),
    expect.objectContaining({role:"office",target:"phone",action:"validation_error"}),
  ]));
  await officePage.close();
  expect(summary.trial.roster.find((row:{role:string})=>row.role==="worker").tenure).toBe("1_to_3");
  const csv=await request.get(`/api/research?field=1&study=${study.id}&csv=tasks`,{headers:admin});
  const contents=await csv.text();
  expect(contents).toContain("friction_score");
  expect(contents).toContain("strain");
  expect(contents).not.toContain("Sensitive synthetic value");
  expect(contents).not.toContain(task.id);
  expect(summary.assistant.evidence).toContain("B1");
  expect(summary.assistant.evidence).not.toContain("Sensitive synthetic value");
  expect(summary.assistant.evidence).not.toContain(task.id);
  const forbidden=await request.post("/api/research/diagnostics",{headers:worker,
    data:{studyId:study.id,fieldScope:{from:today,to:today}}});
  expect(forbidden.status()).toBe(403);
  const researchPage=await context.newPage();
  await researchPage.addInitScript(token=>sessionStorage.setItem("ct-tab-session-v1",token),admin.Authorization.slice(7));
  await researchPage.goto("/research");
  await researchPage.getByRole("button",{name:"分析",exact:true}).click();
  await researchPage.getByRole("navigation",{name:"分析頁面"}).getByRole("button",{name:"多因素分析",exact:true}).press("Enter");
  const comparison=researchPage.getByRole("region",{name:"四期試行比較"});
  const returnRates=comparison.getByRole("region",{name:"各期首次退回率"});
  await expect(returnRates.getByText("100.0% · 1 / 1 宗",{exact:true})).toBeVisible();
  await expect(returnRates.getByText("尚無覆核結果",{exact:true}).first()).toBeVisible();
  await expect(comparison.getByRole("region",{name:"員工自評對照"})).toContainText("55.0 / 100 · 1 份");
  await expect(researchPage.getByRole("region",{name:"回歸圖與資料準備"})).toContainText("基本資料門檻也未達到");
  await expect(comparison.getByRole("table")).toHaveCount(0);
  await comparison.getByText("查看四期明細",{exact:true}).click();
  await expect(comparison.getByRole("row").filter({hasText:"B1"})).toContainText("1 / 1");
  await researchPage.getByRole("navigation",{name:"分析頁面"}).getByRole("button",{name:"改進建議",exact:true}).click();
  await researchPage.getByRole("button",{name:"AI 改善助手",exact:true}).click();
  const assistant=researchPage.getByRole("region",{name:"AI 改善助手"});
  await expect(assistant.getByText(/此環境尚未啟用 Qwen/)).toBeVisible();
  const rules=assistant.getByRole("article",{name:"規則改善建議"});
  const choices=assistant.getByRole("group",{name:"選擇要核查的問題"});
  await choices.getByRole("button",{name:/退回 · 設備資料/}).click();
  await expect(rules).toContainText("抽查「設備資料」退回案件");
  const ruleDownload=researchPage.waitForEvent("download");
  await rules.getByRole("button",{name:"下載核查建議"}).click();
  expect((await ruleDownload).suggestedFilename()).toMatch(/^workflow-check-/);
  await researchPage.route("**/api/research?field=1&*",async route=>{
    const response=await route.fetch();
    const data=await response.json();
    await route.fulfill({response,json:{...data,assistant:{...data.assistant,available:true}}});
  });
  await researchPage.route("**/api/research/diagnostics",async route=>{
    const body=route.request().postDataJSON();
    expect(body.studyId).toBe(study.id);
    expect(body.fieldScope.to).toBe(today);
    const result=await request.get(`/api/research?field=1&study=${study.id}&from=${body.fieldScope.from}&to=${body.fieldScope.to}`,{headers:admin});
    const {assistant:snapshot}=await result.json();
    await route.fulfill({json:{evidence:snapshot.evidence,result:{finding:"聯絡電話值得優先核對。",
      action:"把聯絡電話提示移到欄位旁。",verification:"比較同類案件的欄位檢查與首次退回。",factIds:["signal_1"]}}});
  });
  await researchPage.getByRole("button",{name:"近 7 天",exact:true}).click();
  await assistant.getByRole("button",{name:"用 Qwen 3.8 生成改善建議"}).click();
  const resultPanel=assistant.getByRole("article",{name:"AI 改善建議"});
  await expect(resultPanel).toContainText("把聯絡電話提示移到欄位旁。");
  const download=researchPage.waitForEvent("download");
  await resultPanel.getByRole("button",{name:"下載 AI 改善建議"}).click();
  expect((await download).suggestedFilename()).toMatch(/^workflow-ai-/);
  await researchPage.close();
  const postTrialClient=new pg.Client({connectionString:process.env.DATABASE_URL});
  await postTrialClient.connect();
  try{await postTrialClient.query("UPDATE research_trial_plans SET starts_on=starts_on-28 WHERE study_id=$1",[study.id]);}
  finally{await postTrialClient.end();}
  const postTrial=await create();
  expect((await config(postTrial.id)).assignment).toBe("OBS");
  await post("/api/research/field",worker,{studyId:study.id,action:"leave"});
  const rejected=await request.post("/api/research/field",{headers:worker,data:{studyId:study.id,action:"events",events:[]}});
  expect(rejected.status()).toBe(403);
  await create();
  expect((await report()).trial.tasks).toBe(4);
  await research({action:"study-status",status:"closed"});
  expect((await config(task.id)).studyId).toBeNull();
  expect((await report()).trialSummary.comparisons[1].returned).toBe(1);
});
