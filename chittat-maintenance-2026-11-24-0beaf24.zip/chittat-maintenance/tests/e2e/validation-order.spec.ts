import {test,expect} from '@playwright/test';
import {completeFields,completeItem} from '../complete-fixture.mjs';

test('next checks the current page from top to bottom before returning to earlier missing fields',async({page,request,baseURL})=>{
 const login=await request.post('/api/auth/sign-in/phone-number',{headers:{Origin:baseURL!},data:{phoneNumber:'+85291234567',password:process.env.E2E_PASSWORD}});
 expect(login.ok()).toBeTruthy();
 const token=login.headers()['set-auth-token'],headers={Origin:baseURL!,Authorization:'Bearer '+token};
 const response=await request.post('/api/cases',{headers,data:{...completeFields,customer:'Validation order',address:'Test site',tower:'',notes:'',startedAt:'2026-11-23',completedAt:'2026-11-22',items:[{...completeItem,id:'i',preset:0,qty:1}]}});
 expect(response.ok()).toBeTruthy();const task=await response.json();
 await page.addInitScript(t=>sessionStorage.setItem('ct-tab-session-v1',t),token);
 await page.goto('/?screen=worker-photo&lang=zh-HK&id='+task.id);
 const next=page.getByRole('button',{name:'下一步：確認提交',exact:true});
 await next.click();
 const notes=page.getByRole('textbox',{name:'現場描述',exact:true});
 await expect(notes).toBeFocused();await notes.fill('Inspected');
 await next.click();
 const end=page.getByLabel('完工時間／日期',{exact:true});
 await expect(end).toBeFocused();await end.fill('2026-11-23');
 await next.click();
 await expect(page).toHaveURL(/screen=worker-basic/);
 await expect(page.getByRole('textbox',{name:'座數',exact:true})).toBeFocused();
});

test('item validation follows brand, quantity and model on each save attempt',async({page,request,baseURL})=>{
 const login=await request.post('/api/auth/sign-in/phone-number',{headers:{Origin:baseURL!},data:{phoneNumber:'+85291234567',password:process.env.E2E_PASSWORD}});
 const token=login.headers()['set-auth-token'];
 const response=await request.post('/api/cases',{headers:{Origin:baseURL!,Authorization:'Bearer '+token},data:{...completeFields,customer:'Item validation',address:'Test site',items:[{id:'i',preset:0,qty:1,brand:'',model:''}]}});
 expect(response.ok()).toBeTruthy();const task=await response.json();
 await page.addInitScript(t=>sessionStorage.setItem('ct-tab-session-v1',t),token);
 await page.goto('/?screen=worker-work&lang=zh-HK&id='+task.id);
 await page.locator('.ux-work-item').click();
 const dialog=page.getByRole('dialog',{name:'工作項目詳情'}),save=dialog.getByRole('button',{name:'儲存並返回工作內容',exact:true});
 const brand=dialog.getByRole('textbox',{name:'空調品牌',exact:true});
 const quantity=dialog.getByRole('textbox',{name:'數量',exact:true});
 const model=dialog.getByRole('textbox',{name:'型號（按銘牌填寫）',exact:true});
 await quantity.fill('');await save.click();await expect(brand).toBeFocused();await brand.fill('Daikin');
 await save.click();await expect(quantity).toBeFocused();await quantity.fill('1');
 await save.click();await expect(model).toBeFocused();await model.fill('RX');
 await save.click();await expect(dialog).toHaveCount(0);
});
