import {test,expect,type Page,type APIRequestContext} from '@playwright/test';

async function openWorker(page:Page,request:APIRequestContext,baseURL:string) {
 const login=await request.post('/api/auth/sign-in/phone-number',{
  headers:{Origin:baseURL},data:{phoneNumber:'+85291234567',password:process.env.E2E_PASSWORD},
 });
 expect(login.ok()).toBeTruthy();
 await page.addInitScript(token=>sessionStorage.setItem('ct-tab-session-v1',token),login.headers()['set-auth-token']);
 await page.goto('/?screen=worker-tasks&lang=zh-HK');
 await expect(page.getByRole('heading',{name:'我的任務',exact:true})).toBeVisible();
}

test.describe('touch navigation',()=>{
 test.use({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
 test('bottom tabs switch without browser tap overlays or sticky hover',async({page,request,baseURL})=>{
  const errors:string[]=[];page.on('pageerror',error=>errors.push(error.message));
  await openWorker(page,request,baseURL!);
  const nav=page.getByRole('navigation',{name:'主要導覽',exact:true});
  for(const [name,screen] of [['草稿','worker-drafts'],['我的','worker-profile'],['任務','worker-tasks']]){
   const button=nav.getByRole('button',{name,exact:true});
   // The icon and text must inherit the same transparent native tap highlight.
   for(const target of [button,button.locator('svg'),button.locator('span').first()])
    await expect(target).toHaveCSS('-webkit-tap-highlight-color','rgba(0, 0, 0, 0)');
   await button.tap();
   await expect(button).toHaveAttribute('aria-current','page');
   await expect(page).toHaveURL(new RegExp('screen='+screen));
   await expect(button).toHaveCSS('filter','none');
   await expect(button).toHaveCSS('outline-style','none');
  }
  expect(errors).toEqual([]);
 });
});

test('keyboard users retain a visible focus ring on bottom tabs',async({page,request,baseURL})=>{
 await openWorker(page,request,baseURL!);
 const nav=page.getByRole('navigation',{name:'主要導覽',exact:true});
 await nav.getByRole('button',{name:'任務',exact:true}).click();
 await page.keyboard.press('Tab');
 const drafts=nav.getByRole('button',{name:'草稿',exact:true});
 await expect(drafts).toBeFocused();
 await expect(drafts).toHaveCSS('outline-style','solid');
 await expect(drafts).toHaveCSS('outline-width','3px');
 await page.keyboard.press('Enter');
 await expect(drafts).toHaveAttribute('aria-current','page');
});
