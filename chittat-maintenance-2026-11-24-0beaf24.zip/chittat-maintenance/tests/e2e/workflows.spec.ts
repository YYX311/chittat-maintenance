import {completeFields,completeItem} from "../complete-fixture.mjs";
import {test,expect} from "@playwright/test";
const baseURL=process.env.E2E_BASE_URL || "http://localhost:3100";
const workerURL=baseURL.replace("localhost","127.0.0.1");

test('live correction and office confirmation synchronize two open editors',async({page,browser})=>{
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));
 await login(page,'worker');
 const ctx=await browser.newContext({baseURL:baseURL});
 const headers={Origin:baseURL};
 try {
  const office=await ctx.newPage();office.on('pageerror',e=>errors.push(e.message));await login(office,'office');
  const suffix=Date.now();
  const project=await (await office.request.post('/api/projects',{headers,data:{name:'Sync '+suffix,property:'Sync',code:'SYNC-'+suffix}})).json();
  let r=await (await page.request.post('/api/cases',{headers,data:{...completeFields,date:'2025-12-31',customer:'SYNC-'+suffix,address:'Sync',phone:'23456789',startedAt:'2026-09-20T09:00',completedAt:'2026-09-20T10:00',notes:'Initial inspection',items:[{...completeItem,id:'sync-item',preset:0,qty:0}]}})).json();
  r=await (await page.request.post(`/api/cases/${r.id}/actions`,{headers,data:{action:'submit',serverVersion:r.serverVersion}})).json();
  r=await (await office.request.patch(`/api/cases/${r.id}`,{headers,data:{serverVersion:r.serverVersion,projectId:project.id,projectCode:project.code,items:[{...r.items[0],price:100}]}})).json();
  await page.goto(`/?screen=worker-task-detail&lang=zh-HK&id=${r.id}`);
  await office.goto(`/?screen=office-case&lang=zh-HK&id=${r.id}`);
  const returned=await office.request.post(`/api/cases/${r.id}/actions`,{headers,data:{action:'return',serverVersion:r.serverVersion,payload:{field:'notes',text:'Confirm site description'}}});
  expect(returned.ok(),await returned.text()).toBeTruthy();
  const feedback=page.locator('.ux-feedback-link').filter({hasText:'Confirm site description'});
  await expect(feedback).toBeVisible({timeout:15000});
  await feedback.click();
  await expect(page.getByRole('textbox',{name:'現場描述',exact:true})).toBeEnabled({timeout:15000});
  await page.getByRole('textbox',{name:'現場描述',exact:true}).fill('Model unavailable; inspected unit instead.');
  await expect(page.locator('.feedback-addressed')).toContainText('Confirm site description');
  await page.getByLabel('完工時間／日期',{exact:true}).fill('2026-09-20T11:25');
  await expect(page.getByRole('button',{name:'下一步：確認提交',exact:true})).toBeDisabled();
  await page.getByRole('button',{name:'✓ 確認時間',exact:true}).click();
  await page.getByRole('button',{name:'下一步：確認提交',exact:true}).click();
  await expect(page.locator('.ux-feedback-link')).toHaveCount(0);
  await page.getByRole('button',{name:'確認修改並重新提交',exact:true}).click();
  await expect(page.getByRole('heading',{name:'已提交至維修部',exact:true})).toBeVisible({timeout:20000});
  await expect(page.getByRole('button',{name:/新增下一份現場記錄/})).toBeVisible();
  await expect(page.getByText('Confirm site description',{exact:true})).toHaveCount(0);
  await expect.poll(async()=>await office.locator('.ux-heading').innerText(),{timeout:15000}).not.toContain('待維修人員確認');
  for(let i=0;i<3;i++)await office.getByRole('button',{name:'下一步',exact:true}).click();
  await expect(office.getByLabel('完工時間／日期',{exact:true})).toHaveValue('2026-09-20T11:25');
  await expect(office.getByLabel('完工時間／日期',{exact:true})).toHaveAttribute('readonly','');
  await office.getByRole('combobox',{name:'報價備註範本',exact:true}).selectOption('inspect');
  await expect.poll(async()=>{
    const data=await (await office.request.get('/api/workspace')).json();return data.records.find((x:any)=>x.id===r.id).remarkTemplate;
  }).toBe('inspect');
  await expect(office.getByRole('combobox',{name:'報價備註範本',exact:true})).toHaveValue('inspect');
  for(let i=0;i<7;i++){
    let other=await (await office.request.post('/api/cases',{headers,data:{...completeFields,customer:'E2E-LATER-'+i,address:'Later',projectId:project.id,projectCode:project.code,items:[{...completeItem,id:'i',preset:0,qty:1,price:1}]}})).json();
    const response=await office.request.post(`/api/cases/${other.id}/actions`,{headers,data:{action:'confirm',serverVersion:other.serverVersion}});expect(response.ok()).toBeTruthy();
  }
  await office.getByRole('button',{name:'下一步',exact:true}).click();
  await office.getByRole('button',{name:'確認並更新 INDEX',exact:true}).click();
  await expect(office).toHaveURL(/screen=office-inbox/);
  const confirmedRow=office.getByRole('row').filter({hasText:'SYNC-'+suffix});
  await expect(confirmedRow).toHaveCount(0);
  await expect(office.getByRole('combobox',{name:'狀態',exact:true})).toHaveValue('pending');
  await office.getByRole('button',{name:'清除篩選',exact:true}).click();
  await expect(confirmedRow).toHaveCount(0);
  const index=await (await office.request.get('/api/index?query='+encodeURIComponent('SYNC-'+suffix))).json();expect(index.total).toBe(8);expect(index.data[0].id).toBe(r.id);
  await office.getByRole('navigation').getByRole('button',{name:/INDEX/}).click();
  await expect(office.locator('tbody tr').first()).toContainText('SYNC-'+suffix);
  await expect(office.locator('tbody tr')).toHaveCount(6);
  await office.getByRole('button',{name:'下一頁',exact:true}).click();
  await office.getByRole('navigation').getByRole('button',{name:/服務單覆核/}).click();
  await office.getByRole('navigation').getByRole('button',{name:/INDEX/}).click();
  await expect(office.locator('tbody tr').first()).toContainText('SYNC-'+suffix);
  expect((await page.request.get('/api/me')).ok()).toBeTruthy();expect((await office.request.get('/api/me')).ok()).toBeTruthy();
  await page.reload();expect((await page.request.get('/api/me')).ok()).toBeTruthy();
  await expect(page.getByRole('heading',{name:'已提交至維修部',exact:true})).toBeVisible();
  expect(errors).toEqual([]);
  const {tmpdir}=await import('node:os');const {join}=await import('node:path');
  await office.screenshot({path:join(tmpdir(),'maintenance-office-sync.png')});
  await page.setViewportSize({width:390,height:844});
  await page.screenshot({path:join(tmpdir(),'maintenance-worker-sync.png')});
 }finally{await ctx.close();}
});

const password=process.env.E2E_PASSWORD;
test.skip(!password,"Set E2E_PASSWORD for the dedicated local acceptance accounts.");
const sessions=new Map<string,any[]>();
const tokens=new Map<string,string>();
async function login(page:any,role:"worker"|"office") {
 if(sessions.has(role)){await page.context().addCookies(sessions.get(role)!);}else{
 const response=await page.request.post("/api/auth/sign-in/phone-number",{data:{phoneNumber:role==="worker"?"+85291234567":"+85292345678",password},headers:{Origin:baseURL}});
 expect(response.ok(),await response.text()).toBeTruthy();
 tokens.set(role,response.headers()["set-auth-token"]);
 sessions.set(role,await page.context().cookies());}
 await page.addInitScript((token:string)=>sessionStorage.setItem("ct-tab-session-v1",token),tokens.get(role)!);
 await page.goto(role==="office"?"/?screen=office-inbox&lang=zh-HK":"/?screen=worker-tasks&lang=zh-HK");
 await expect(page.getByRole("button",{name:role==="worker"?/新增現場記錄/:/建立任務/}).first()).toBeVisible();
}

for(const role of ["worker","office"] as const) {
 test(`${role}: opening and leaving an empty task never creates a server record`,async({page})=>{
  await page.addInitScript(()=>Object.defineProperty(globalThis.crypto,"randomUUID",{configurable:true,value:undefined}));
  await login(page,role);
  const before=(await (await page.request.get("/api/workspace")).json()).records.length;
  const creates:string[]=[];page.on("request",r=>{if(r.method()==="POST"&&new URL(r.url()).pathname==="/api/cases")creates.push(r.url());});
  await page.getByRole("button",{name:role==="worker"?/新增現場記錄/:/建立任務/}).first().click();
  await expect(page.getByRole("textbox",{name:"客戶名稱",exact:true})).toBeVisible();
  if(role==="worker"){
    await page.getByRole("list",{name:"填報進度"}).getByRole("button",{name:/確認提交/}).click();
    await expect(page).toHaveURL(/screen=worker-basic/);
    const missingField = page.locator("input[aria-invalid=true]:focus, textarea[aria-invalid=true]:focus, select[aria-invalid=true]:focus");
    await expect(missingField).toHaveCount(1);
    await missingField.blur();
  }else{
    await page.getByRole("list",{name:"填寫進度"}).getByRole("button",{name:/核對及確認/}).click();
    await expect(page.getByRole("heading",{name:"核對後提交"})).toBeHidden();
  }
  const {tmpdir}=await import("node:os");const {join}=await import("node:path");
  await page.screenshot({path:join(tmpdir(),`maintenance-${role}-create-fallback.png`)});
  if(role==="office")await page.getByRole("button",{name:"返回任務列表",exact:true}).click();
  else await page.getByRole("navigation").getByRole("button",{name:/任務/}).click();
  await expect(page.getByRole("button",{name:role==="worker"?/新增現場記錄/:/建立任務/}).first()).toBeVisible();
  expect(creates).toHaveLength(0);
  expect((await (await page.request.get("/api/workspace")).json()).records.length).toBe(before);
 });
}

test("office: incomplete input prompts on exit and is excluded from INDEX",async({page})=>{
 await login(page,"office");
 await page.getByRole("button",{name:/建立任務/}).first().click();
 const name="E2E-DRAFT-"+Date.now();
 await page.getByRole("textbox",{name:"客戶名稱",exact:true}).fill(name);
 const created=await page.waitForResponse(r=>r.request().method()==="POST"&&new URL(r.url()).pathname==="/api/cases");
 expect(created.ok()).toBeTruthy();
 page.once("dialog",d=>{expect(d.message()).toContain("草稿");void d.dismiss();});
 await page.getByRole("button",{name:"返回任務列表",exact:true}).click();
 await expect(page.getByRole("textbox",{name:"客戶名稱",exact:true})).toHaveValue(name);
 page.once("dialog",d=>void d.accept());
 await page.getByRole("button",{name:"返回任務列表",exact:true}).click();
 await expect(page.getByRole("row").filter({hasText:name})).toContainText("草稿");
 const drafts=page.getByRole("group",{name:"工作隊列"}).getByRole("button",{name:/草稿/});
 await drafts.click();
 await expect(drafts).toHaveAttribute("aria-pressed","true");
 await expect(page.getByRole("row").filter({hasText:name})).toBeVisible();
 const result=await (await page.request.get("/api/index?query="+name)).json();expect(result.total).toBe(0);
});

test("office: recycle bin restore requires confirmation; delete has a cancel path",async({page})=>{
 await login(page,"office");
 const headers={Origin:baseURL};
 const created=await (await page.request.post("/api/cases",{headers,data:{...completeFields,customer:"E2E-TRASH",address:"E2E-TRASH"}})).json();
 await page.request.post(`/api/cases/${created.id}/actions`,{headers,data:{action:"delete-draft",serverVersion:created.serverVersion}});
 await page.reload();await page.locator("summary").filter({hasText:"回收站"}).click();
 const row=page.locator(".recycle-list article").filter({hasText:"E2E-TRASH"});
 await row.getByRole("button",{name:"徹底刪除",exact:true}).click();
 await expect(page.getByRole("alertdialog")).toContainText("無法復原");
 await expect(page.locator("dialog[open]")).toBeInViewport();
 await page.getByRole("alertdialog").getByRole("button",{name:"取消",exact:true}).click();
 await expect(row).toBeVisible();
 await row.getByRole("button",{name:"復原",exact:true}).click();
 await expect(page.getByRole("alertdialog")).toContainText("確認復原");
 await page.getByRole("alertdialog").getByRole("button",{name:"確認",exact:true}).click();
 await expect(row).toHaveCount(0);
});

test("office: logout stays within a short desktop viewport and INDEX fits its work area",async({page})=>{
 await page.setViewportSize({width:1280,height:600});await login(page,"office");
 const badge = page.locator(".ux-brand > .brand-logo");
 const title = page.locator(".ux-brand > b");
 await expect(badge.getByRole("img",{name:"Chit Tat Electrical Engineering Ltd."})).toBeVisible();
 const [badgeBox,titleBox]=await Promise.all([badge.boundingBox(),title.boundingBox()]);
 expect(badgeBox!.width).toBeGreaterThan(170);
 expect(titleBox!.x).toBeGreaterThan(badgeBox!.x+badgeBox!.width);
 expect(Math.abs(titleBox!.y+titleBox!.height/2-badgeBox!.y-badgeBox!.height/2)).toBeLessThan(1);
 const [rightGap,toolbarDiff] = await page.evaluate(()=>{
  const main=document.querySelector('.ux-main')!;
  const bounds=main.getBoundingClientRect(),padding=getComputedStyle(main);
  const lang=document.querySelector('.ux-top .ux-lang')!.getBoundingClientRect();
  const avatar=document.querySelector('.ux-avatar')!.getBoundingClientRect();
  return [bounds.right-parseFloat(padding.paddingRight)-avatar.right,lang.top+lang.height/2-avatar.top-avatar.height/2];
 });
 expect(Math.abs(rightGap)).toBeLessThan(1);
 expect(Math.abs(toolbarDiff)).toBeLessThan(1);
 await expect(page.locator(".ux-lang")).toHaveCSS("text-align","center");
 const nav = page.getByRole("navigation",{name:"主要導覽"});
 const logout=nav.getByRole('button',{name:'登出帳戶',exact:true});
 await expect(logout).toHaveCSS('border-top-width','1px');
 const status=page.getByRole('combobox',{name:'狀態',exact:true});
 await expect(status).toHaveCSS('border-top-width','1px');
 if(await page.evaluate(()=>CSS.supports('appearance:base-select')&&CSS.supports('selector(select::picker(select))')))
  await expect(status).toHaveCSS('appearance','base-select');
 const review = nav.getByRole("button",{name:/服務單覆核/});
 const index = nav.getByRole("button",{name:/INDEX/});
 // The glass scene uses CSS gradients, so its rendering never depends on downloading a photo.
 const scene = await page.locator(".ux-office").evaluate(node=>getComputedStyle(node).backgroundImage);
 expect(scene).toMatch(/^radial-gradient\(/);
 expect(scene).not.toContain("url(");
 expect(scene).toContain("rgb(220, 234, 250)");
 await expect(nav).toHaveCSS("backdrop-filter","blur(18px) saturate(1.15)");
 const queue = page.getByRole("group",{name:"工作隊列"}).getByRole("button").first();
 await expect(queue).toHaveCSS("backdrop-filter","blur(26px) saturate(1.18)");
 await expect(queue).toHaveCSS("border-inline-start-color","rgba(75, 88, 105, 0.17)");
 await page.emulateMedia({reducedMotion:"reduce"});
 expect(await queue.evaluate(node=>getComputedStyle(node,"::after").animationName)).toBe("none");
 await expect(review.locator("svg[aria-hidden=true]")).toBeVisible();
 await expect(review).toHaveCSS("border-inline-start-color","rgb(73, 91, 116)");
 const avatar = page.getByRole("button",{name:"帳戶選單"});
 await expect(avatar).toHaveCSS("font-size","18px");
 await expect(avatar).toHaveCSS("background-color","rgb(255, 255, 255)");
 await avatar.click();
 await expect(avatar).toHaveAttribute("aria-expanded","true");
 const accountEntry=page.getByRole("button",{name:"我的帳戶",exact:true});
 const signOutEntry=page.getByRole("button",{name:"登出／切換帳戶",exact:true});
 await expect(accountEntry).toBeVisible();
 await expect(signOutEntry).toHaveCSS("background-color",await accountEntry.evaluate(el=>getComputedStyle(el).backgroundColor));
 await expect(signOutEntry).toHaveCSS("border-top-width",await accountEntry.evaluate(el=>getComputedStyle(el).borderTopWidth));
 await avatar.click();
 const [reviewBox,indexBox,navBox,mainBox] = await Promise.all([
   review.boundingBox(),index.boundingBox(),nav.boundingBox(),page.getByRole("main").boundingBox(),
 ]);
 expect(reviewBox!.y).toBeLessThan(indexBox!.y);
 expect(navBox!.x + navBox!.width).toBeLessThanOrEqual(mainBox!.x);
 expect(Math.abs(badgeBox!.x-navBox!.x)).toBeLessThan(1);
 await page.getByRole("button",{name:/INDEX/,exact:false}).first().click();
 await expect(page.getByRole("searchbox",{name:"搜尋 INDEX"})).toBeVisible();
 await expect(page.getByRole("navigation",{name:"INDEX pagination"})).toBeVisible();
 await expect(page.getByRole("main")).toHaveCSS("background-color","rgba(72, 98, 136, 0.04)");
 await expect(page.locator(".ux-grid-scroll").first()).toHaveCSS("background-color","rgb(255, 255, 255)");
 const box=await page.locator(".office-logout").boundingBox();expect(box!.y+box!.height).toBeLessThanOrEqual(600);
 const dimensions=await page.locator(".ux-main").evaluate(el=>({width:el.clientWidth,scroll:el.scrollWidth}));expect(dimensions.scroll).toBeLessThanOrEqual(dimensions.width);
 await page.goto("/?screen=office-index&lang=zh-HK&appearance=blue");
 await expect(avatar).toHaveCSS("background-color","rgb(220, 234, 254)");
 await nav.getByRole("button",{name:/服務單覆核/}).click();
 await expect(review).toHaveCSS("border-inline-start-color","rgb(33, 91, 158)");
 await page.goto("/?screen=office-inbox&lang=zh-HK&appearance=white");
 await expect(avatar).toHaveCSS("background-color","rgb(255, 255, 255)");
 await page.setViewportSize({width:390,height:844});
 const [mobileBadge,mobileTitle,mobileNav]=await Promise.all([badge.boundingBox(),title.boundingBox(),nav.boundingBox()]);
 expect(Math.abs(mobileBadge!.x-mobileNav!.x)).toBeLessThan(1);
 expect(mobileTitle!.x).toBeGreaterThan(mobileBadge!.x+mobileBadge!.width);
 expect(Math.abs(mobileTitle!.y+mobileTitle!.height/2-mobileBadge!.y-mobileBadge!.height/2)).toBeLessThan(1);
});


test("both local hostnames support independent role sessions",async({page,context})=>{
 await login(page,"office");
 const response=await page.request.post(workerURL+"/api/auth/sign-in/phone-number",{data:{phoneNumber:"+85291234567",password},headers:{Origin:workerURL}});
 expect(response.ok()).toBeTruthy();
 const worker=await context.newPage();await worker.addInitScript(token=>sessionStorage.setItem("ct-tab-session-v1",token),response.headers()["set-auth-token"]);await worker.goto(workerURL+"/?lang=zh-HK");
 await expect(worker.getByRole("heading",{name:"我的任務"})).toBeVisible();
 await worker.setViewportSize({width:390,height:844});
 const workerNav = worker.getByRole("navigation",{name:"主要導覽"});
 await expect(workerNav.getByRole("button",{name:/任務/})).toHaveCSS("background-color","rgb(232, 236, 242)");
 const navBox = await workerNav.boundingBox();
 expect(navBox!.y + navBox!.height).toBe(836);
 expect(await worker.evaluate(() => document.documentElement.scrollWidth)).toBe(390);
 await worker.setViewportSize({width:320,height:680});
 await expect(worker.locator('.ux-brand').getByText('現場助手',{exact:true})).toBeVisible();
 await expect(worker.getByRole('button',{name:'帳戶選單',exact:true})).toBeInViewport();
 expect(await worker.evaluate(()=>document.documentElement.scrollWidth)).toBe(320);
 await page.reload();await expect(page.getByRole("button",{name:/建立任務/}).first()).toBeVisible();
 await workerNav.getByRole("button",{name:"我的",exact:true}).click();
 await expect(worker.getByRole("heading",{name:"驗收 worker",exact:true})).toHaveCSS("font-weight","800");
 await page.getByRole("button",{name:"帳戶選單",exact:true}).click();
 await expect(page.locator(".ux-menu").getByText("驗收 office",{exact:true})).toHaveCSS("font-size","18px");
 await page.getByRole("button",{name:"我的帳戶",exact:true}).click();
 await expect(page.getByRole("heading",{name:"驗收 office",exact:true})).toHaveCSS("font-weight","800");
});

test("office review exposes missing-field anchors and uses the PDF preview endpoint",async({page,browser})=>{
 await login(page,"worker");const headers={Origin:baseURL};
 const created=await (await page.request.post("/api/cases",{headers,data:{...completeFields,customer:"E2E-ANCHOR",address:"E2E-ANCHOR",phone:"23456789",startedAt:"2026-09-16T09:00",notes:"Inspection",items:[{...completeItem,id:"e2e-item",preset:0,qty:1}]}})).json();
 const submitted=await (await page.request.post(`/api/cases/${created.id}/actions`,{headers,data:{action:"submit",serverVersion:created.serverVersion}})).json();
 const officeContext=await browser.newContext();await officeContext.addCookies(sessions.get("office")!);const office=await officeContext.newPage();
 await office.addInitScript(token=>sessionStorage.setItem("ct-tab-session-v1",token),tokens.get("office")!);
 await office.goto(`${baseURL}/?screen=office-case&lang=zh-HK&id=${created.id}`);
 await expect(office.getByRole("button",{name:/批量貼上/})).toHaveCount(0);
 await office.getByRole("button",{name:/⚠.*單價/}).click();
 await expect(office.locator('[data-feedback-target="price-e2e-item"]')).toBeVisible();
 const response=await page.request.get(`/api/cases/${created.id}/preview?kind=service&revision=0`);expect(response.status()).toBe(200);expect(response.headers()["content-type"]).toContain("application/pdf");
 expect((await response.body()).subarray(0,5).toString()).toBe("%PDF-");
 const generated=await (await page.request.post(`/api/cases/${created.id}/documents`,{headers,data:{kind:"service",revision:0}})).json();
 const pdf=await page.request.get(`/api/assets/${generated.assetKey}`);expect(pdf.status()).toBe(200);
 await officeContext.close();
});

test("office bulk selection, modal visibility and six-row pagination",async({page})=>{
 await login(page,"office");
 const draft=await page.request.post("/api/cases",{headers:{Origin:baseURL},data:{...completeFields,customer:"E2E-BULK",address:"E2E-BULK"}});
 expect(draft.ok(),await draft.text()).toBeTruthy();
 await page.reload();
 const select=page.getByRole("button",{name:"全選可刪除任務",exact:true});await select.click();
 await expect(page.getByRole("button",{name:"取消全選",exact:true})).toBeVisible();
 const [deselect,remove]=await Promise.all([
  page.getByRole("button",{name:"取消全選",exact:true}).boundingBox(),
  page.getByRole("button",{name:/刪除所選任務/}).boundingBox(),
 ]);
 expect(remove!.x-deselect!.x-deselect!.width).toBeGreaterThanOrEqual(20);
 await expect(page.getByRole("button",{name:/匯入 Excel/})).toHaveText("↓ 匯入 Excel");
  await page.setViewportSize({width:360,height:800});
  const [compactDeselect,compactRemove]=await Promise.all([
    page.getByRole("button",{name:"取消全選",exact:true}).boundingBox(),
    page.getByRole("button",{name:/刪除所選任務/}).boundingBox(),
  ]);
  expect(compactRemove!.y-compactDeselect!.y-compactDeselect!.height).toBeGreaterThanOrEqual(12);
 await page.getByRole("button",{name:/刪除所選任務/}).click();
  const prompt=page.getByRole("dialog",{name:"確認移至回收站？"});
  await expect(prompt).toContainText("移動後可在回收站復原");
  await expect(prompt.getByRole("button",{name:"保留草稿",exact:true})).toBeFocused();
  expect((await prompt.boundingBox())!.width).toBeLessThan(360);
  await prompt.getByRole("button",{name:"保留草稿",exact:true}).click();
 await page.goto('/?screen=office-index&lang=zh-HK');
 await expect(page.getByRole("button",{name:/匯出 Excel/})).toHaveText("↑ 匯出 Excel");
 await expect(page.getByRole('combobox',{name:'每頁筆數'})).toHaveValue('6');
 expect((await (await page.request.get('/api/index')).json()).pageSize).toBe(6);
});

test("generated package downloads nonempty PDFs and back-to-INDEX comes first",async({page})=>{
 await login(page,'office');const headers={Origin:baseURL};
 const suffix=Date.now();
 const project=await (await page.request.post('/api/projects',{headers,data:{name:'E2E-PDF-'+suffix,property:'E2E-PDF',code:'PDF-'+suffix}})).json();
 let record=await (await page.request.post('/api/cases',{headers,data:{...completeFields,customer:'E2E-PDF',address:'E2E-PDF',projectId:project.id,projectCode:project.code,items:[{...completeItem,id:'pdf-item',preset:0,qty:1,price:2000,description:'維修檢查'}]}})).json();
 const confirmed=await page.request.post(`/api/cases/${record.id}/actions`,{headers,data:{action:'confirm',serverVersion:record.serverVersion}});expect(confirmed.ok(),await confirmed.text()).toBeTruthy();record=await confirmed.json();
 await page.addInitScript(()=>{Object.defineProperty(window,'showSaveFilePicker',{value:undefined,configurable:true});});
 await page.goto(`/?screen=office-confirmed&lang=zh-HK&id=${record.id}`);
 await expect(page.getByRole('button',{name:'返回 INDEX',exact:true})).toHaveCount(1);
 const back=await page.getByRole('button',{name:'返回 INDEX',exact:true}).first().boundingBox();const section=await page.locator('.document-center').boundingBox();expect(back!.y).toBeLessThan(section!.y);
 const promise=page.waitForEvent('download');await page.getByRole('button',{name:'生成服務單、報價單＆發票',exact:true}).click();const download=await promise;
 const {readFile}=await import('node:fs/promises');const bytes=await readFile((await download.path())!);expect(bytes.length).toBeGreaterThan(1000);
 const {default:JSZip}=await import('jszip');const zip=await JSZip.loadAsync(bytes,{checkCRC32:true});const files=Object.values(zip.files).filter(f=>!f.dir);expect(files).toHaveLength(3);
 const {PDFDocument}=await import('pdf-lib');for(const f of files){const data=await f.async('nodebuffer');expect(data.subarray(0,5).toString()).toBe('%PDF-');expect((await PDFDocument.load(data)).getPageCount()).toBeGreaterThan(0);}
});

test('independent sessions can submit concurrently without invalidating one another',async({browser})=>{
 const contexts=await Promise.all(Array.from({length:4},()=>browser.newContext({baseURL:baseURL})));
 const headers={Origin:baseURL};
 try{
  const logins=await Promise.all(contexts.map((ctx,n)=>ctx.request.post('/api/auth/sign-in/phone-number',{headers,data:{phoneNumber:n<2?'+85291234567':'+85292345678',password}})));
  for(const response of logins)expect(response.ok(),await response.text()).toBeTruthy();
  const created=await Promise.all(contexts.map((ctx,n)=>ctx.request.post('/api/cases',{headers,data:{...completeFields,customer:'E2E-CONCURRENT-'+n,address:'E2E-CONCURRENT',phone:'23456789',startedAt:'2026-09-16T09:00',notes:'Inspection',items:[{...completeItem,id:'concurrent-item',preset:0,qty:1}]}})));
  const records=await Promise.all(created.map(async r=>{expect(r.ok(),await r.text()).toBeTruthy();return r.json();}));
  expect(new Set(records.map(r=>r.id)).size).toBe(4);
  const submitted=await Promise.all(contexts.slice(0,2).map((ctx,n)=>ctx.request.post(`/api/cases/${records[n].id}/actions`,{headers,data:{action:'submit',serverVersion:records[n].serverVersion}})));
  const results=await Promise.all(submitted.map(async r=>{expect(r.ok(),await r.text()).toBeTruthy();return r.json();}));expect(results[0].serviceNo).not.toBe(results[1].serviceNo);
  const offices=await Promise.all(contexts.slice(2).map(ctx=>ctx.request.get('/api/workspace')));for(const response of offices){const workspace=await response.json();for(const record of results)expect(workspace.records.some((r:any)=>r.id===record.id&&r.status==='submitted')).toBeTruthy();}
  const clash=await Promise.all(contexts.slice(2).map((ctx,n)=>ctx.request.patch(`/api/cases/${records[2].id}`,{headers,data:{serverVersion:records[2].serverVersion,customer:'E2E-CONFLICT-'+n}})));expect(clash.map(r=>r.status()).sort()).toEqual([200,409]);
  const logout=await contexts[0].request.post('/api/auth/sign-out',{headers,data:{}});expect(logout.ok()).toBeTruthy();expect((await contexts[0].request.get('/api/me')).status()).toBe(401);for(const ctx of contexts.slice(1))expect((await ctx.request.get('/api/me')).ok()).toBeTruthy();
 }finally{await Promise.all(contexts.map(ctx=>ctx.close()));}
});

test('worker deletes an opened draft and resolves returned feedback before resubmitting',async({page,browser})=>{
 await login(page,'worker');const headers={Origin:baseURL};
 let record=await (await page.request.post('/api/cases',{headers,data:{...completeFields,customer:'E2E-WORKER-DELETE',address:'E2E-WORKER-DELETE',phone:'23456789',startedAt:'2026-09-16T09:00',notes:'Initial inspection',items:[{...completeItem,id:'return-item',preset:0,qty:1}]}})).json();
 await page.goto(`/?screen=worker-basic&lang=zh-HK&id=${record.id}`);
 await page.getByRole('button',{name:'刪除此草稿',exact:true}).click();
 await page.getByRole('button',{name:'確認移至回收站',exact:true}).click();
 await expect(page).toHaveURL(/screen=worker-drafts/);
 const deleted=(await (await page.request.get('/api/workspace')).json()).records.find((r:any)=>r.id===record.id);expect(deleted.deletedAt).toBeTruthy();
 const returned=await (await page.request.post('/api/cases',{headers,data:{...completeFields,customer:'E2E-WORKER-RETURN',address:'E2E-WORKER-RETURN',phone:'23456789',startedAt:'2026-09-16T09:00',notes:'Initial inspection',items:[{...completeItem,id:'return-item',preset:0,qty:1}]}})).json();
 const submitted=await (await page.request.post(`/api/cases/${returned.id}/actions`,{headers,data:{action:'submit',serverVersion:returned.serverVersion}})).json();
 const officeContext=await browser.newContext();
 try {
  const office=await officeContext.newPage();await login(office,'office');
  const response=await office.request.post(`/api/cases/${returned.id}/actions`,{headers,data:{action:'return',serverVersion:submitted.serverVersion,payload:{field:'notes',text:'請確認現場描述'}}});
  expect(response.ok(),await response.text()).toBeTruthy();
 } finally { await officeContext.close(); }
 await page.goto(`/?screen=worker-task-detail&lang=zh-HK&id=${returned.id}`);
 await expect(page.locator('.ux-callout.important-change')).toHaveCount(0);
 const reminder=page.getByRole('button',{name:/請確認現場描述/});
 await expect(reminder).toHaveCSS('border-top-width','0px');
 await expect(reminder).toHaveCSS('border-inline-start-width','2px');
 await reminder.click();
 await page.getByRole('textbox',{name:'現場描述',exact:true}).fill('已再次確認現場描述');
 await expect(page.locator('.feedback-addressed')).toContainText('請確認現場描述');
 await page.locator('.feedback-addressed').click();
 await expect(page).toHaveURL(/screen=worker-review/);
});

test('office pricing keeps the inline progress state, edits service charge and removes a row',async({page})=>{
 await login(page,'office');const headers={Origin:baseURL};const suffix=Date.now();
 const project=await (await page.request.post('/api/projects',{headers,data:{name:'E2E-PRICE-'+suffix,property:'E2E-PRICE',code:'PRICE-'+suffix}})).json();
 const created=await (await page.request.post('/api/cases',{headers,data:{...completeFields,projectId:project.id,projectCode:project.code,customer:'E2E-PRICE',address:'E2E-PRICE',items:[{...completeItem,id:'price-one',preset:0,qty:1,price:100,description:'First row'},{...completeItem,id:'price-two',preset:1,qty:1,price:200,description:'Second row'}]}})).json();
 await page.goto(`/?screen=office-case&lang=zh-HK&id=${created.id}`);
 await page.getByRole('button',{name:'下一步',exact:true}).click();
 await expect(page.getByText('工作項目及定價正在填寫',{exact:true})).toHaveCount(0);
 await page.locator('.ux-work-item').first().click();
 await expect(page.getByText('工作項目及定價正在填寫',{exact:true})).toHaveCount(0);
 await expect(page.getByRole('button',{name:'編輯此行',exact:true})).toHaveCount(1);
 page.once('dialog',d=>d.accept());await page.getByRole('button',{name:'刪除此行',exact:true}).first().click();
 await expect(page.getByRole('button',{name:'編輯此行',exact:true})).toHaveCount(0);
 await page.locator('.ux-work-item').first().click();
 await expect(page.getByRole('button',{name:'編輯此行',exact:true})).toHaveCount(1);
 for(let n=0;n<2;n++)await page.getByRole('button',{name:'下一步',exact:true}).click();
 const charge=page.getByRole('textbox',{name:'工程收費 HK$（如適用）',exact:true});await charge.fill('1800.50');
 await expect.poll(async()=>{const workspace=await (await page.request.get('/api/workspace')).json();return workspace.records.find((r:any)=>r.id===created.id)?.chargeAmount;}).toBe('1800.50');
});


test('native save starts on generation click; history consolidates PDFs and issued INDEX stays cached',async({page})=>{
 await login(page,'office');const headers={Origin:baseURL};const suffix=Date.now();
 const project=await (await page.request.post('/api/projects',{headers,data:{name:'Native',property:'Native',code:'NATIVE-'+suffix}})).json();
 let record=await (await page.request.post('/api/cases',{headers,data:{...completeFields,customer:'NATIVE-'+suffix,address:'Native',projectId:project.id,projectCode:project.code,items:[{...completeItem,id:'native',preset:0,qty:1,price:1}]}})).json();
 record=await (await page.request.post(`/api/cases/${record.id}/actions`,{headers,data:{action:'confirm',serverVersion:record.serverVersion}})).json();
 await page.addInitScript(()=>{
  (window as any).saveLog=[];
  Object.defineProperty(window,'showSaveFilePicker',{configurable:true,value:async()=>{(window as any).saveLog.push('picker');return {createWritable:async()=>({write:async(blob:Blob)=>{(window as any).savedSize=blob.size;(window as any).saveLog.push('write')},close:async()=>{(window as any).saveLog.push('close')},abort:async()=>{}})}}});
 });
 await page.goto(`/?screen=office-confirmed&lang=zh-HK&id=${record.id}`);
 await expect(page.getByRole('button',{name:'返回 INDEX',exact:true})).toHaveCount(1);
 await expect(page.getByText('已生成文件',{exact:true})).toHaveCount(0);
 await page.route('**/documents',async route=>{await new Promise(resolve=>setTimeout(resolve,300));await route.continue()});
 await page.getByRole('button',{name:'生成服務單、報價單＆發票',exact:true}).click();
 await expect.poll(()=>page.evaluate(()=>(window as any).saveLog[0])).toBe('picker');
 await expect(page.locator('.operation-feedback:popover-open').filter({hasText:'正在處理'})).toBeVisible();
 await expect.poll(()=>page.evaluate(()=>(window as any).saveLog)).toEqual(['picker','write','close']);
 expect(await page.evaluate(()=>(window as any).savedSize)).toBeGreaterThan(1000);
 const savedFeedback=page.locator('.operation-feedback:popover-open').filter({hasText:'文件已儲存成功'});
 await expect(savedFeedback).toBeVisible();
 const feedbackBox=await savedFeedback.boundingBox();
 const viewport=page.viewportSize()!;
 expect(Math.abs(feedbackBox!.x+feedbackBox!.width/2-viewport.width/2)).toBeLessThan(2);
 expect(Math.abs(feedbackBox!.y+feedbackBox!.height/2-viewport.height/2)).toBeLessThan(2);
 await page.locator('.document-version>summary').first().click();
 const quote=page.locator('.document-version>details').filter({has:page.locator('summary',{hasText:'報價單'})});
 await quote.locator('summary').click();await quote.getByRole('button',{name:'顯示 PDF 預覽',exact:true}).click();
 await expect(quote.locator('iframe')).toBeVisible();
 await page.getByRole('button',{name:'返回 INDEX',exact:true}).click();
 await expect(page.getByRole('row').filter({hasText:record.ref})).toContainText('已簽發');
 await page.getByRole('navigation').getByRole('button',{name:/服務單覆核/}).click();
 let reloads=0;await page.route('**/api/index?**',async route=>{reloads++;await route.continue()});
 await page.getByRole('navigation').getByRole('button',{name:/INDEX/}).click();
 await expect(page.getByRole('row').filter({hasText:record.ref})).toBeVisible({timeout:500});
 await expect(page.locator('.operation-feedback:popover-open').filter({hasText:/切換|Switch/})).toHaveCount(0);
 await page.waitForTimeout(300);expect(reloads).toBe(0);
});

test('worker location survives office Project Code selection and required steps block empty fields',async({page})=>{
 await login(page,'office');const headers={Origin:baseURL};
 const r=await (await page.request.post('/api/cases',{headers,data:{...completeFields,customer:'Required',address:'Original worker location',items:[{...completeItem,id:'i',preset:0,qty:1,price:1}]}})).json();
 await page.goto(`/?screen=office-case&lang=zh-HK&id=${r.id}`);
 const picker=page.locator('.project-picker');
 const address=picker.getByRole('textbox',{name:'地址／屋苑',exact:true});
 await address.click();
 await expect(picker.locator('.ux-combo')).toHaveCSS('outline-color','rgb(105, 133, 169)');
 await expect(picker).toHaveCSS('outline-style','none');
 await expect(picker.locator('[data-feedback-target="address"]').first()).toHaveCSS('outline-style','none');
 await address.press('Tab');
 const suggestions=picker.getByRole('button',{name:'地址／屋苑 ▾',exact:true});
 await expect(suggestions).toBeFocused();
 await expect(suggestions).toHaveCSS('outline-width','2px');
 await expect(suggestions).toHaveCSS('outline-color','rgb(105, 133, 169)');
 await suggestions.press('Space');
 await expect(suggestions).toHaveAttribute('aria-expanded','true');
 const list=picker.getByRole('group',{name:'地址／屋苑',exact:true});
 await expect(list).toHaveCSS('border-radius','14px');
 await list.getByRole('button').first().press('Escape');
 await expect(list).toHaveCount(0);
 await expect(suggestions).toBeFocused();
 await page.getByRole('button',{name:'下一步',exact:true}).click();
 const code=picker.getByRole('textbox',{name:'Project Code',exact:true});
 await expect(code).toBeFocused();
 await expect(code).toHaveAccessibleDescription('請填寫並儲存 Project Code。');
 await expect(code).toHaveCSS('border-top-width','1px');
 await expect(code).toHaveCSS('border-top-color','rgb(184, 90, 84)');
 await expect(picker.getByRole('alert')).toHaveText('請填寫並儲存 Project Code。');
 await expect(picker).toHaveCSS('outline-style','none');
 await code.fill('NEW-'+Date.now());
 await page.getByRole('button',{name:'儲存 Project Code',exact:true}).click();
 await expect(picker.getByRole('status')).toHaveText('Project Code 已儲存。');
 await expect(picker.getByRole('alert')).toHaveCount(0);
 const savedCodes=picker.getByRole('combobox',{name:'已儲存的 Project Code',exact:true});
 if(await page.evaluate(()=>CSS.supports('appearance:base-select')&&CSS.supports('selector(select::picker(select))')))
  await expect(savedCodes).toHaveCSS('appearance','base-select');
 await expect(page.getByRole('textbox',{name:'地址／屋苑',exact:true})).toHaveValue('Original worker location');
 await page.getByRole('textbox',{name:'聯絡人',exact:true}).fill('');
 await page.getByRole('button',{name:'下一步',exact:true}).click();
 await expect(page.getByRole('textbox',{name:'聯絡人',exact:true})).toHaveAttribute('aria-invalid','true');
 await page.getByRole('textbox',{name:'聯絡人',exact:true}).fill('Contact');
 for(let i=0;i<3;i++)await page.getByRole('button',{name:'下一步',exact:true}).click();
 const startTime=page.getByLabel('開工時間／日期',{exact:true});
 await startTime.focus();
 const confirmTime=page.getByRole('button',{name:'✓ 確認時間',exact:true});
 await expect(confirmTime).toBeVisible();
 const [calendarBox,confirmBox]=await Promise.all([startTime.boundingBox(),confirmTime.boundingBox()]);
 expect(confirmBox!.x).toBeGreaterThan(calendarBox!.x);
 expect(Math.abs(confirmBox!.y+confirmBox!.height/2-calendarBox!.y-calendarBox!.height/2)).toBeLessThan(2);
 await confirmTime.click();
 await expect(page.getByRole('button',{name:'✓ 確認時間',exact:true})).toHaveCount(0);
});


test('first camera image appears immediately and persists without a second capture',async({page})=>{
 await login(page,'worker');const headers={Origin:baseURL};
 const r=await (await page.request.post('/api/cases',{headers,data:{...completeFields,customer:'CAMERA',address:'Camera site',items:[{...completeItem,id:'i',preset:0,qty:1}]}})).json();
 await page.goto(`/?screen=worker-photo&lang=zh-HK&id=${r.id}`);
 await page.route('**/assets',async route=>{if(route.request().method()==='POST')await new Promise(resolve=>setTimeout(resolve,600));await route.continue()});
 await page.getByLabel('Take photo',{exact:true}).setInputFiles('public/brand-logo.png');
 await expect(page.getByText('正在儲存相片…',{exact:true})).toBeVisible();
 await expect.poll(async()=>{
  const data=await (await page.request.get('/api/workspace')).json();return data.records.find((x:any)=>x.id===r.id).photos.length;
 }).toBe(1);
 await expect(page.locator('.photo-open img')).toHaveCount(1);
 await expect.poll(()=>page.locator('.photo-open img').evaluate((img:HTMLImageElement)=>img.complete&&img.naturalWidth>0)).toBeTruthy();
 await page.reload();await expect(page.locator('.photo-open img')).toHaveCount(1);
});

test('saved Project Code is replaced rather than duplicated and location is retained',async({page})=>{
 await login(page,'office');const headers={Origin:baseURL},suffix=Date.now();
 const p=await (await page.request.post('/api/projects',{headers,data:{name:'Code edit',property:'Registry address',code:'BEFORE-'+suffix}})).json();
 const r=await (await page.request.post('/api/cases',{headers,data:{...completeFields,customer:'CODE',address:'Worker original address',projectId:p.id,projectCode:p.code,items:[]}})).json();
 await page.goto(`/?screen=office-case&lang=zh-HK&id=${r.id}`);
 await page.getByRole('textbox',{name:'Project Code',exact:true}).fill('AFTER-'+suffix);
 await page.waitForTimeout(350);
 expect((await (await page.request.get('/api/workspace')).json()).records.find((x:any)=>x.id===r.id)?.projectId).toBe(p.id);
 await page.getByRole('button',{name:'儲存 Project Code',exact:true}).click();
 await expect.poll(async()=>{const data=await (await page.request.get('/api/workspace')).json();return data.projectRegistry.find((x:any)=>x.id===p.id)?.code}).toBe('AFTER-'+suffix);
 await expect(page.getByRole('textbox',{name:'地址／屋苑',exact:true})).toHaveValue('Worker original address');
 await expect(page.getByRole('combobox',{name:'已儲存的 Project Code',exact:true})).toContainText('AFTER-'+suffix);
 page.once('dialog',dialog=>dialog.dismiss());
 await page.getByRole('button',{name:'刪除所選代碼',exact:true}).click();
 await expect(page.getByRole('combobox',{name:'已儲存的 Project Code',exact:true})).toContainText('AFTER-'+suffix);
 page.once('dialog',dialog=>dialog.accept());
 await page.getByRole('button',{name:'刪除所選代碼',exact:true}).click();
 await expect.poll(async()=>{const data=await (await page.request.get('/api/workspace')).json();return data.projectRegistry.find((x:any)=>x.id===p.id)?.active}).toBe(false);
 await expect(page.getByRole('combobox',{name:'已儲存的 Project Code',exact:true})).not.toContainText('AFTER-'+suffix);
 await expect(page.getByRole('textbox',{name:'Project Code',exact:true})).toHaveValue('');
 await expect(page.getByRole('textbox',{name:'地址／屋苑',exact:true})).toHaveValue('Worker original address');
 await expect.poll(async()=>{const data=await (await page.request.get('/api/workspace')).json();return data.records.find((x:any)=>x.id===r.id)?.projectId}).toBeFalsy();
 await page.reload();
 await expect(page.getByRole('combobox',{name:'已儲存的 Project Code',exact:true})).not.toContainText('AFTER-'+suffix);
});
