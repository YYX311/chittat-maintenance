import assert from "node:assert/strict";
import test from "node:test";
import { productionConfigurationErrors } from "../lib/environment.ts";

const production = {
  NODE_ENV: "production",
  DATABASE_URL: "postgres://maintenance:secret@db.internal/maintenance",
  BETTER_AUTH_URL: "https://maintenance.example.com",
  BETTER_AUTH_SECRET: "a-random-production-secret-with-32-characters",
  OBJECT_STORAGE_MODE: "s3",
  S3_BUCKET: "maintenance-private",
  S3_REGION: "ap-east-1",
  COMPANY_NAME_HK: "公司",
  COMPANY_NAME_EN: "Company Limited",
  COMPANY_ADDRESS: "Hong Kong",
  COMPANY_PHONE: "+852 2000 0000",
  COMPANY_PAYMENT_DETAILS: "Bank transfer details",
};

test("development does not require production services", () => {
  assert.deepEqual(productionConfigurationErrors({ NODE_ENV: "development" }), []);
});

test("complete production configuration passes readiness validation", () => {
  assert.deepEqual(productionConfigurationErrors(production), []);
});

test("production rejects insecure or placeholder configuration", () => {
  const errors = productionConfigurationErrors({
    ...production,
    DATABASE_URL: "sqlite:data.db",
    BETTER_AUTH_URL: "http://maintenance.example.com",
    BETTER_AUTH_SECRET: "replace-with-at-least-32-random-characters",
    OBJECT_STORAGE_MODE: "local",
    S3_BUCKET: "",
    S3_ENDPOINT: "http://storage.internal",
    COMPANY_PAYMENT_DETAILS: "",
  });
  assert.deepEqual(errors, [
    "DATABASE_URL",
    "BETTER_AUTH_URL",
    "BETTER_AUTH_SECRET",
    "OBJECT_STORAGE_MODE",
    "S3_BUCKET",
    "S3_ENDPOINT",
    "COMPANY_PAYMENT_DETAILS",
  ]);
});
