import assert from "node:assert/strict";
import test from "node:test";
import { normalizeFieldEvents, periodFor } from "../lib/field-study-service.ts";
import { summarizeTrialTasks, taskMeasures } from "../lib/field-study-analysis.ts";
import { assistantSuggestions, readFieldQueue, updateFieldQueue } from "../src/field-study.js";

test("Hong Kong midnight switches new assignments across ABAB boundaries",()=>{
  const plan={starts_on:"2026-11-12",weeks_per_period:1};
  assert.equal(periodFor(plan,new Date("2026-11-18T15:59:59Z")).label,"A1");
  assert.equal(periodFor(plan,new Date("2026-11-18T16:00:00Z")).label,"B1");
  assert.equal(periodFor(plan,new Date("2026-11-25T16:00:00Z")).label,"A2");
  assert.equal(periodFor(plan,new Date("2026-12-02T16:00:00Z")).label,"B2");
  assert.equal(periodFor(plan,new Date("2026-12-09T16:00:00Z")),undefined);
});

test("field telemetry sanitizes targets and rejects arbitrary or expired data; queue removal preserves later offline events",()=>{
  const now=Date.now();
  const event={id:"test-123456",caseId:"example-id",kind:"field_clear",surface:"office-1",at:now,field:"price-hidden-item-id",text:"sensitive"};
  const [safe]=normalizeFieldEvents([event],now);
  assert.equal(safe.field,"price");
  assert.equal(safe.duration_ms,null);
  assert.ok(!Object.values(safe).includes("sensitive"));
  assert.throws(()=>normalizeFieldEvents([{...event,field:"Client Lee"}],now),/invalid-field-events/);
  assert.throws(()=>normalizeFieldEvents([{...event,at:now-8*86400000}],now),/invalid-field-events/);
  const map=new Map(),storage={getItem:key=>map.get(key),setItem:(key,value)=>map.set(key,value),removeItem:key=>map.delete(key)};
  updateFieldQueue(storage,"account-study",[event]);
  updateFieldQueue(storage,"account-study",[{...event,id:"reconnect-id",kind:"reconnect"}]);
  updateFieldQueue(storage,"account-study",[],[event.id]);
  assert.deepEqual(readFieldQueue(storage,"account-study").map(e=>e.id),["reconnect-id"]);
});

test("return-risk suggestions give concrete reasons and leave the business data intact",()=>{
  const record={phone:"77",items:[{id:"i",qty:51}],feedback:[{resolved:false}],startedAt:"2026-11-12T11:00",completedAt:"2026-11-11"};
  assert.deepEqual(assistantSuggestions(record,true,[],[{field:"photo",count:3}]).items.map(x=>[x.field,x.screen]),
    [["phone","worker-basic"],["photo","worker-photo"]]);
  assert.deepEqual(assistantSuggestions(record,false,[],[]).items.map(x=>x.field),["qty","completedAt","feedback"]);
  assert.equal(record.items[0].qty,51);
});

test("task analysis retains missing time and excludes ratings after first review from the mechanism",()=>{
  const row={alias:"R1",source:"worker",user_id:"worker",period:"B1",phase:"improved",difficulty:"medium",
    first_action:"2026-11-12T09:00:00Z",first_decision_at:"2026-11-12T09:01:00Z",pulse_at:"2026-11-12T09:02:00Z",
    time_ms:null,validations:0,clears:0,rapid_clicks:0,net_issues:0,assistant_shown:0,assistant_accepts:0,ease:4,strain:6};
  const task=taskMeasures(row,"study");
  assert.equal(task.after_17,1);
  assert.equal(task.active_minutes,null);
  assert.equal(task.friction_score,null);
  assert.equal(task.pulse_before_review,0);
  assert.equal(summarizeTrialTasks([task]).strain[1].n,0);
  assert.equal(summarizeTrialTasks([task]).comparisons[1].n,1);
});
