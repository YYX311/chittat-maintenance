import { completeFields, completeItem } from "./complete-fixture.mjs";

export async function seedHandoffs(call, studyId, count = 5) {
  const entryNos = [];
  const project = await call("office", "/api/projects", {
    name: "本地驗收項目", property: "本地測試", code: "PREVIEW-" + crypto.randomUUID().slice(0, 8),
  });
  const samples = [
    { phase: "baseline", reason: "equipment", confirm: true },
    { phase: "baseline", reason: "photos", confirm: false },
    { phase: "baseline", confirm: false },
    { phase: "improved", confirm: true },
    { phase: "improved", confirm: true },
  ];
  for (const [index, sample] of samples.slice(0, count).entries()) {
    let record = await call("worker", "/api/cases", {
      ...completeFields, address: "測試地址", customer: `本地驗收案件 ${index + 1}`,
      items: [{ ...completeItem, id: "item", preset: 0, qty: 1 }],
    });
    entryNos.push(record.entryNo);
    await call("research", "/api/research", {
      action: "enroll", studyId, entryNo: record.entryNo, phase: sample.phase,
      difficulty: "medium", permissionConfirmed: true, consentReference: "ISOLATED-TEST-FIXTURE",
    });
    const action = (side, action, payload) => call(side, `/api/cases/${record.id}/actions`, {
      action, payload, serverVersion: record.serverVersion,
    });
    record = await action("worker", "submit");
    if (sample.reason) {
      record = await action("office", "return", { field: "notes", reason: sample.reason, text: "測試覆核補充資料" });
      if (sample.confirm) {
        record = await call("worker", `/api/cases/${record.id}`, {
          serverVersion: record.serverVersion,
          notes: "已核對及補充測試資料",
          addressedFeedbackIds: record.feedback.map(item => item.id),
        }, "PATCH");
        record = await action("worker", "submit");
      }
    }
    if (sample.confirm) {
      record = await call("office", `/api/cases/${record.id}`, {
        serverVersion: record.serverVersion, projectId: project.id, projectCode: project.code,
        items: record.items.map(item => ({ ...item, price: 100 })),
      }, "PATCH");
      await action("office", "confirm");
    }
  }
  return entryNos;
}

export async function seedFieldContext(call, studyId, entryNos) {
  const reports = [
    { index: 0, factors: ["interruption"], load: 4 },
    { index: 1, factors: ["connection"], load: 5 },
    { index: 3, factors: ["interface"], load: 2 },
  ];
  for (const report of reports) {
    if (!entryNos[report.index]) continue;
    await call("research", "/api/research", {
      action: "context-review", studyId, entryNo: entryNos[report.index],
      role: "worker", stage: "submit", source: "self_report", factors: report.factors,
      load: report.load, safety: "not_asked", contextPermission: true, consentReference: "ISOLATED-TEST-FIXTURE",
    });
  }
}

export async function seedAutomaticPilot(call, db, studyId) {
  const today=new Date(Date.now()+8*3600000).toISOString().slice(0,10);
  const research=body=>call("research","/api/research",{...body,studyId});
  await research({action:"trial-plan",startsOn:today,weeks:1});
  await research({action:"auto-collection",consentReference:"LOCAL-SYNTHETIC-ONLY",permissionConfirmed:true});
  await call("worker","/api/research/field",{studyId,action:"join",agreed:true,tenure:"1_to_3",specialty:"hvac"});
  await call("office","/api/research/field",{studyId,action:"join",agreed:true});
  const project=await call("office","/api/projects",{name:"四期預覽",property:"測試大樓",code:"TRIAL-"+crypto.randomUUID().slice(0,8)});
  for(const [index,sample] of [{strain:6,returned:true},{strain:3,returned:false}].entries()){
    if(index===1)await db.query("UPDATE research_trial_plans SET starts_on=starts_on-7 WHERE study_id=$1",[studyId]);
    let record=await call("worker","/api/cases",{...completeFields,address:"測試大樓",customer:`四期預覽案例 ${index+1}`,
      items:[{...completeItem,id:"item",preset:0,qty:1}]});
    const event=(kind,surface,field,durationMs)=>({id:crypto.randomUUID(),caseId:record.id,kind,surface,field,durationMs,at:Date.now()});
    const events=[event("screen_active","worker-basic",null,18000+index*6000)];
    if(index===0)events.push(event("validation_error","worker-basic","phone"),event("offline","worker-photo"));
    else events.push(event("assistant_shown","worker-review"),event("assistant_accept","worker-review","phone"));
    await call("worker","/api/research/field",{action:"events",studyId,events});
    const action=(side,action,payload)=>call(side,`/api/cases/${record.id}/actions`,{action,payload,serverVersion:record.serverVersion});
    record=await action("worker","submit");
    await call("worker","/api/research/field",{action:"pulse",studyId,caseId:record.id,ease:8-sample.strain,strain:sample.strain});
    if(sample.returned)await action("office","return",{field:"phone",reason:"description",text:"本地示例：請核對聯絡電話。"});
    else{
      record=await call("office",`/api/cases/${record.id}`,{serverVersion:record.serverVersion,projectId:project.id,projectCode:project.code,
        items:record.items.map(item=>({...item,price:100}))},"PATCH");
      await action("office","confirm");
    }
  }
}
