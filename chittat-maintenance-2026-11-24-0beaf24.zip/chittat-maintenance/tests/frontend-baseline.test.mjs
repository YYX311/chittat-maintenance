import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);
const model = await import(new URL("src/service-model.js", root));
const workspaceModel = await import(new URL("src/workspace-model.js", root));
const guidance = await import(new URL("src/task-guidance.js", root));

test("confirmed INDEX keeps the twelve approved business columns", () => {
  assert.equal(model.INDEX_COLUMNS.length, 12);
  assert.deepEqual(model.INDEX_COLUMNS.slice(0, 4), [
    "No.",
    "QUO. Date",
    "QUO ref. no.",
    "Q-rev.",
  ]);
  assert.equal(model.INDEX_COLUMNS.at(-1), "Attn.");
});

test("service number advances beyond existing numbers", () => {
  const state = { serviceCounter: 3, records: [{ serviceNo: "CT-MNA-0007" }] };
  assert.equal(guidance.nextServiceNumber(state), 8);
});

test("service dates reject earlier days and accept legacy timestamps on the same day", () => {
  const record = { phone: "00000001", startedAt: "2026-09-14T10:00", completedAt: "2026-09-14T09:00" };
  assert.equal(model.serviceError(record), null);
  record.completedAt="2026-09-13";
  assert.equal(model.serviceError(record)?.[0], "completedAt");
});

test("client UUID generation works when randomUUID is unavailable", () => {
  const originalCrypto = globalThis.crypto;
  Object.defineProperty(globalThis, "crypto", {
    configurable: true,
    value: { getRandomValues: (bytes) => bytes.fill(0x2a) },
  });
  try {
    assert.match(workspaceModel.uid(), /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/);
  } finally {
    Object.defineProperty(globalThis, "crypto", { configurable: true, value: originalCrypto });
  }
});

test("workspace keeps a versioned emergency draft cache and does not expose the internal email alias", async () => {
  const source = await readFile(new URL("src/Workspace.jsx", root), "utf8");
  const cache = await readFile(new URL("src/draft-cache.js", root), "utf8");
  assert.match(cache, /ct-emergency-drafts-v2/);
  assert.match(source, /恢復連線後會自動同步/);
  assert.doesNotMatch(source, /<small>\{account\.email\}<\/small>/);
  assert.match(source, /<small>\{account\.phone\} · \{account\.id\}<\/small>/);
});

test("INDEX uses one toggling selection control and one combined document package action", async () => {
  const source = await readFile(new URL("src/CompactIndex.jsx", root), "utf8");
  assert.match(source, /generate\(selected,"both"\)/);
  assert.match(source, /生成服務單、報價單＆發票/);
  assert.equal(source.indexOf("清除所有篩選") < source.indexOf("</details>"), true);
  assert.match(source, /aria-pressed/);
});

test("the explicit worker save-and-return action exits without a second confirmation", async () => {
  const source = await readFile(new URL("src/Workspace.jsx", root), "utf8");
  assert.match(source, /go\("worker-drafts","",true\).*儲存並返回草稿/);
});

test("office pricing exposes integrated accordion and row controls while feedback is red", async () => {
  const source = await readFile(new URL("src/Workspace.jsx", root), "utf8");
  const styles = await readFile(new URL("src/workspace.css", root), "utf8");
  assert.match(source, /onRemove=\{i=>/);
  assert.match(source, /expandedId=\{pricingExpandedId\}/);
  assert.match(source, /disabled=\{worker&&!editAllowed\}/);
  assert.match(source, /issue\.field\.startsWith\("price-"\).*setPricingExpandedId/);
  assert.match(source, /important-feedback/);
  assert.match(source, /chargeAmount/);
  assert.match(source, /a\.status===\"needsInfo\"\?0:1/);
  assert.match(source, /needs-info-card/);
  assert.match(source, /feedback-addressed/);
  assert.match(source, /addressedFeedbackIds/);
  assert.doesNotMatch(source, /record\.status==="needsInfo"&&<div className="ux-callout important-change"/);
  assert.match(source, /!\["approved","issued"\]\.includes\(r\.status\)/);
  assert.match(source, /source-tag source-\"\+r\.source/);
  assert.match(styles, /\.ux-feedback\.important-feedback[^}]*color:var\(--workspace-warning-ink\)/);
  assert.match(styles, /\.source-worker[^}]*#eaf2ff/);
  assert.match(styles, /\.source-office[^}]*#fff6d9/);
});
