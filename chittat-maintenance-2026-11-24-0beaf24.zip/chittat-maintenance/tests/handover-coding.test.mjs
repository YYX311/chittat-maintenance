import assert from 'node:assert/strict';
import test from 'node:test';
import { dateRange } from '../lib/handover-coding.ts';
test('Hong Kong date windows accept one day and reject rollovers, inverted and oversized windows',()=>{
  assert.deepEqual(dateRange('2026-11-18','2026-11-18'),['2026-11-18','2026-11-18']);
  for(const [from,to] of [['2026-02-29','2026-03-01'],['2026-11-19','2026-11-18'],['2026-01-01','2026-04-04']])
    assert.throws(()=>dateRange(from,to));
});
