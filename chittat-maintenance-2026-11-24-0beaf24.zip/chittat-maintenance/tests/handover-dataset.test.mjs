import assert from 'node:assert/strict';
import { test } from 'node:test';
import { PGlite } from '@electric-sql/pglite';
import { loadHandoverDataset } from '../lib/handover-dataset.ts';
import { analyze, toCsv } from '../lib/research-model.ts';

test('live dataset follows Hong Kong dates, preserves rounds and leaves missing measures blank', async () => {
  const db = new PGlite();
  try {
    await db.exec(`
      CREATE TABLE audit_events(id bigint GENERATED ALWAYS AS IDENTITY, case_id text, actor_user_id text,
        action text, detail jsonb DEFAULT '{}', created_at timestamptz);
      CREATE TABLE case_versions(case_id text, kind text, revision int, snapshot jsonb,
        created_by text, created_at timestamptz);
      CREATE TABLE research_probe_events(id text, case_id text, actor_user_id text, role text, name text,
        at timestamptz, step text, active_ms int, rating int, case_version int);
      INSERT INTO audit_events(case_id,actor_user_id,action,created_at,detail) VALUES
        ('case-rework','worker-private','submit','2026-11-17 15:55Z','{}'),
        ('case-rework','office-private','return','2026-11-17 16:05Z','{"reason":"location","field":"address"}'),
        ('case-rework','worker-private','submit','2026-11-17 16:20Z','{"version":4}'),
        ('case-rework','office-private','review','2026-11-17 16:30Z','{}'),
        ('case-rework','office-private','confirm','2026-11-17 16:40Z','{}'),
        ('case-rework','office-private','confirm','2026-11-17 17:20Z','{}'),
        ('case-return','worker-private','submit','2026-11-17 17:00Z','{}'),
        ('case-return','office-private','return','2026-11-17 17:15Z','{"reason":"photos","field":"photo"}'),
        ('case-pending','worker-private','submit','2026-11-18 15:55Z','{}'),
        ('case-pending','office-private','confirm','2026-11-18 16:00Z','{}'),
        ('case-withdraw','worker-private','submit','2026-11-18 14:10Z','{}'),
        ('case-withdraw','worker-private','withdraw','2026-11-18 14:15Z','{}'),
        ('case-pass','worker-private','submit','2026-11-18 14:20Z','{}'),
        ('case-pass','office-private','confirm','2026-11-18 14:30Z','{}');
      INSERT INTO case_versions VALUES
        ('case-rework','service',1,'{"address":"private original","items":[{}],"submittedAt":"2026-11-17T16:19:59Z"}','worker-private','2026-11-17 16:19:59Z'),
        ('case-rework','confirmation',0,'{"address":"private correction","approvedAt":"2026-11-17T16:39:59Z"}','office-private','2026-11-17 16:39:59Z');
      INSERT INTO research_probe_events VALUES
        ('outside-round','case-rework','worker-private','worker','form.step_leave','2026-11-17 15:45Z','worker-basic',60000,null,null),
        ('fill','case-rework','worker-private','worker','form.step_leave','2026-11-17 16:10Z','worker-basic',60000,null,null),
        ('block','case-rework','worker-private','worker','form.validation_block','2026-11-17 16:12Z','worker-basic',null,null,null),
        ('prompt','case-rework','worker-private','worker','survey.shown','2026-11-17 16:20:01Z',null,null,null,4),
        ('effort','case-rework','worker-private','worker','survey.effort','2026-11-17 16:21Z',null,null,6,4),
        ('fatigue','case-rework','worker-private','worker','survey.fatigue','2026-11-17 16:21Z',null,null,4,4),
        ('review','case-rework','office-private','office','form.step_leave','2026-11-17 16:35Z','office-0',120000,null,null);
    `);
    const data = await loadHandoverDataset(db, '2026-11-18', '2026-11-18');
    const analysis = analyze(data);
    assert.equal(data.episodes.length, 5);
    assert.deepEqual(data.episodes.map(e => [e.round, e.returned, e.taskSeqToday]),
      [[2, false, 1], [1, true, 2], [1, null, 3], [1, false, 4], [1, null, 5]]);
    assert.deepEqual(data.episodes[0].correctedFields, ['address']);
    assert.equal(data.episodes[0].cycleMin, 20);
    assert.equal(data.episodes[0].reviewWaitMin, 10);
    assert.equal(data.episodes[0].fillActiveMin, 1);
    assert.equal(data.episodes[0].reviewActiveMin, 2);
    assert.equal(data.episodes[0].validationBlocks, 1);
    assert.equal(data.episodes[0].itemCount, 1);
    assert.equal(data.episodes[0].effort, 6);
    assert.equal(data.episodes[0].fatigue, 4);
    assert.equal(data.episodes[1].fillActiveMin, null);
    assert.equal(analysis.kpi.fpy, 0.5);
    assert.equal(analysis.kpi.firstDecided, 2);
    assert.equal(analysis.kpi.corrected, 1);
    assert.equal(analysis.kpi.cycle, 15);
    assert.equal(analysis.models.m1, null);
    assert.equal(analysis.kpi.surveyResponse, 1);
    assert.ok(!toCsv(analysis.rows).includes('NaN'));
    assert.doesNotMatch(JSON.stringify(data), /private|case-rework/);
  } finally {
    await db.close();
  }
});

test('v2 optimizations: photoCount, phase, check-card MRT, officeDocMin, excludeTest, compactCase, and recordReviewOpened', async () => {
  const { compactCase, recordReviewOpened, workspaceFingerprint } = await import('../lib/case-service.ts');
  const { normalizeProbeEvents } = await import('../lib/research-probe.ts');

  // 1. compactCase strips nested snapshots while keeping metadata
  const bloated = {
    id: 'c1',
    status: 'approved',
    serviceDocuments: [{ rev: 0, at: '2026-11-23T00:00:00Z', assetKey: 'k1', snapshot: { huge: 'x'.repeat(1000) } }],
    approvalHistory: [{ rev: 0, at: '2026-11-23T00:00:00Z', snapshot: { huge: 'y'.repeat(1000) } }],
    history: [{ rev: 0, at: '2026-11-23T00:00:00Z', assetKey: 'k2', snapshot: { huge: 'z'.repeat(1000) } }],
    invoiceHistory: [{ rev: 0, at: '2026-11-23T00:00:00Z', assetKey: 'k3', snapshot: { huge: 'w'.repeat(1000) } }],
  };
  const slim = compactCase(bloated);
  assert.equal(slim.serviceDocuments[0].snapshot, undefined);
  assert.equal(slim.serviceDocuments[0].assetKey, 'k1');
  assert.equal(slim.approvalHistory[0].snapshot, undefined);
  assert.equal(slim.history[0].snapshot, undefined);
  assert.equal(slim.invoiceHistory[0].snapshot, undefined);

  // 2. normalizeProbeEvents accepts check-card MRT events
  const now = Date.now();
  const normalized = normalizeProbeEvents([
    { schema: 'workflow-fatigue-v2', id: 'ev-1', caseId: 'case-1', name: 'check.assigned', arm: 'check', flags: 2, at: now },
    { schema: 'workflow-fatigue-v2', id: 'ev-2', caseId: 'case-1', name: 'check.shown', flags: 2, at: now },
    { schema: 'workflow-fatigue-v2', id: 'ev-3', caseId: 'case-1', name: 'check.go_field', field: 'notes', at: now },
    { schema: 'workflow-fatigue-v2', id: 'ev-4', caseId: 'case-1', name: 'check.confirmed', at: now },
  ], 'worker', now);
  assert.equal(normalized.length, 4);
  assert.equal(normalized[0].step, 'check');
  assert.equal(normalized[0].rating, 2);
  assert.equal(normalized[2].field, 'notes');

  // 3. Database test for photoCount, officeDocMin, checkAccepted, excludeTest, and recordReviewOpened
  const db = new PGlite();
  try {
    await db.exec(`
      CREATE TABLE cases(id text PRIMARY KEY, owner_user_id text, status text, row_version int DEFAULT 0,
        updated_at timestamptz DEFAULT now(), deleted_at timestamptz, data jsonb DEFAULT '{}');
      CREATE TABLE projects(id text PRIMARY KEY, code text, name text, details jsonb DEFAULT '{}', active boolean DEFAULT true);
      CREATE TABLE audit_events(id bigint GENERATED ALWAYS AS IDENTITY, case_id text, actor_user_id text,
        action text, detail jsonb DEFAULT '{}', created_at timestamptz);
      CREATE TABLE case_versions(case_id text, kind text, revision int, snapshot jsonb,
        created_by text, created_at timestamptz);
      CREATE TABLE research_probe_events(id text, case_id text, actor_user_id text, role text, name text,
        at timestamptz, step text, active_ms int, rating int, case_version int);

      INSERT INTO cases(id, owner_user_id, status, row_version, data) VALUES
        ('case-prod', 'w1', 'submitted', 1, '{"address":"太古城","customer":"陳生"}'),
        ('case-gray', 'w1', 'submitted', 1, '{"address":"灰度測試屋苑-A1","customer":"灰度客戶"}');

      INSERT INTO audit_events(case_id, actor_user_id, action, created_at, detail) VALUES
        ('case-prod', 'w1', 'submit', '2026-11-23 02:00:00Z', '{"version":1}'),
        ('case-gray', 'w1', 'submit', '2026-11-23 02:05:00Z', '{"version":1}');

      INSERT INTO case_versions VALUES
        ('case-prod', 'service', 0, '{"address":"太古城","items":[{},{}],"photos":[{},{},{}],"submittedAt":"2026-11-23T02:00:00Z"}', 'w1', '2026-11-23 02:00:00Z');

      INSERT INTO research_probe_events VALUES
        ('chk-1', 'case-prod', 'w1', 'worker', 'check.assigned', '2026-11-23 01:59:50Z', 'check', null, 2, null),
        ('chk-2', 'case-prod', 'w1', 'worker', 'check.go_field', '2026-11-23 01:59:55Z', null, null, null, null);
    `);

    const officeStaff = { userId: 'o1', id: '92025966', role: 'office', name: 'JJ', email: 'o1@staff.invalid', phone: '+85292025966', canWork: false, canManage: false, canResearch: false };
    // Idempotent review open: first open records 1 event, second open in same round is a no-op
    const firstOpen = await recordReviewOpened(db, officeStaff, 'case-prod');
    const secondOpen = await recordReviewOpened(db, officeStaff, 'case-prod');
    assert.equal(firstOpen, true);
    assert.equal(secondOpen, false);

    // Confirm and generate quotation document 5 minutes later
    await db.exec(`
      INSERT INTO audit_events(case_id, actor_user_id, action, created_at, detail) VALUES
        ('case-prod', 'o1', 'confirm', '2026-11-23 02:10:00Z', '{"version":2}'),
        ('case-prod', 'o1', 'generate-quotation', '2026-11-23 02:15:00Z', '{"revision":0}');
      INSERT INTO case_versions VALUES
        ('case-prod', 'confirmation', 0, '{"address":"太古城(已修正)","approvedAt":"2026-11-23T02:10:00Z"}', 'o1', '2026-11-23 02:10:00Z');
    `);

    const allData = await loadHandoverDataset(db, '2026-11-23', '2026-11-23', { excludeTest: false });
    assert.equal(allData.episodes.length, 2);

    const prodOnly = await loadHandoverDataset(db, '2026-11-23', '2026-11-23', { excludeTest: true });
    assert.equal(prodOnly.episodes.length, 1);
    const ep = prodOnly.episodes[0];
    assert.equal(ep.itemCount, 2);
    assert.equal(ep.photoCount, 3);
    assert.equal(ep.phase, 'mrt');
    assert.equal(ep.arm, 'check');
    assert.equal(ep.checkFlags, 2);
    assert.equal(ep.checkAccepted, true);
    assert.equal(ep.fieldsCorrected, 1);
    assert.equal(ep.officeDocMin, 5);
    assert.ok(prodOnly.events.some(e => e.name === 'case.review_opened' && e.count === 1));
    assert.ok(prodOnly.events.some(e => e.name === 'doc.generated' && e.count === 1));

    const etag = await workspaceFingerprint(db, officeStaff);
    assert.match(etag, /^W\/"ws-office-2-2-/);
    await db.exec("INSERT INTO projects(id,code,name) VALUES ('p1','A','Test')");
    const beforeProjectEdit=await workspaceFingerprint(db,officeStaff);
    await db.exec("UPDATE projects SET code='B' WHERE id='p1'");
    assert.notEqual(await workspaceFingerprint(db,officeStaff),beforeProjectEdit);
  } finally {
    await db.close();
  }
});
