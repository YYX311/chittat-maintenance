import test from 'node:test';
import assert from 'node:assert/strict';
import { sameOrigin } from '../lib/http.ts';

test('mutations accept the public origin when Next binds to 0.0.0.0 and reject foreign origins', () => {
  const prior = process.env.BETTER_AUTH_URL;
  const priorAllowed = process.env.DEV_ALLOWED_ORIGINS;
  process.env.BETTER_AUTH_URL = 'http://localhost:3000';
  process.env.DEV_ALLOWED_ORIGINS = 'http://192.168.20.194:3000';
  try {
    const request = origin => new Request('http://0.0.0.0:3000/api/cases', { method:'POST', headers: origin ? {origin} : {} });
    assert.equal(sameOrigin(request('http://localhost:3000')), true);
    assert.equal(sameOrigin(request('https://attacker.example')), false);
    assert.equal(sameOrigin(request('http://localhost:3001')), false);
    assert.equal(sameOrigin(request('http://192.168.20.194:3000')), true);
    assert.equal(sameOrigin(request('http://192.168.20.195:3000')), false);
    assert.equal(sameOrigin(request()), false);
  } finally { if (prior === undefined) delete process.env.BETTER_AUTH_URL; else process.env.BETTER_AUTH_URL = prior; if (priorAllowed === undefined) delete process.env.DEV_ALLOWED_ORIGINS; else process.env.DEV_ALLOWED_ORIGINS = priorAllowed; }
});
