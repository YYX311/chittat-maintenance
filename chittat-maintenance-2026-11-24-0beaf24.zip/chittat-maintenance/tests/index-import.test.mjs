import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import ExcelJS from "exceljs";
import { PGlite } from "@electric-sql/pglite";
import { HEADERS } from "../src/workspace-model.js";
import { importIndex, parseIndexWorkbook } from "../lib/index-import.ts";

async function workbook(rows) {
  const book = new ExcelJS.Workbook();
  const sheet = book.addWorksheet("INDEX_2026");
  sheet.addRow(HEADERS.slice(0, 12));
  rows.forEach(row => sheet.addRow(row));
  return new Uint8Array(await book.xlsx.writeBuffer());
}

async function fixture() {
  const database = new PGlite();
  for (const name of ["000_auth.sql", "001_business.sql", "002_projects.sql", "003_document_format.sql"]) {
    await database.exec(await readFile(new URL(`../migrations/${name}`, import.meta.url), "utf8"));
  }
  await database.query(`INSERT INTO "user"(id,name,email,"phoneNumber") VALUES ('office','Office','office@staff.invalid','+15550000001')`);
  await database.query(`INSERT INTO employees(user_id,staff_code,role) VALUES ('office','OFFICE','office')`);
  return database;
}

const staff = { userId: "office", staffCode: "OFFICE", name: "Office", email: "office@staff.invalid", phone: "+15550000001", role: "office" };
const row = [1, "2026-09-15", "CT-MNA26-Q-001", 0, "A", "10", "1", "Test site", "Inspection", 250, "Customer", "Attention"];

test("INDEX workbook validation requires the current twelve columns and business fields", async () => {
  const parsed = await parseIndexWorkbook(await workbook([row]));
  assert.equal(parsed.records.length, 1);
  assert.equal(parsed.records[0].items[0].price, 250);
  await assert.rejects(parseIndexWorkbook(await workbook([[1, "", "CT-MNA26-Q-002", 0, "", "", "", "", "", 0, "", ""]])), /invalid-index/);
});

test("INDEX import is transactional and repeat imports do not duplicate quotations", async () => {
  const database = await fixture();
  try {
    const bytes = await workbook([row]);
    const first = await importIndex(database, staff, bytes);
    const second = await importIndex(database, staff, bytes);
    assert.equal(first.count, 1);
    assert.equal(second.count, 0);
    assert.equal(second.duplicates, 1);
    const cases = await database.query("SELECT quote_ref,status,data FROM cases");
    assert.equal(cases.rows.length, 1);
    assert.equal(cases.rows[0].status, "approved");
    assert.equal(cases.rows[0].data.imported, true);
    const counter = await database.query("SELECT value FROM counters WHERE key='quotation-26-office'");
    assert.equal(Number(counter.rows[0].value), 1);
  } finally { await database.close(); }
});
