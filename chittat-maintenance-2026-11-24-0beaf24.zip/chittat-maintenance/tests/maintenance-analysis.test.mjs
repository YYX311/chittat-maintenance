import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {PGlite} from '@electric-sql/pglite';
import {analyzeMaintenance,diagnosticEvidence,maintenanceBrief} from '../lib/maintenance-analysis.ts';
import {storeRuntime} from '../lib/runtime-observation.ts';
import {maintenanceOverview,reserveDiagnosticAi,finishDiagnosticAi} from '../lib/maintenance-service.ts';
import {researchMutation,researchOverview,researchRuntimeExport} from '../lib/research-service.ts';
import {operationFor,outcomeFor,recordRuntime} from '../src/runtime-observation.js';
import {prioritizeSignals,recommendedSignal,signalScope,emptyGuidance} from '../lib/maintenance-presentation.ts';
import {managementSnapshot,validateManagementReport} from '../lib/management-analysis.ts';
import {fieldRange,hkDay} from '../lib/research-field.ts';
const admin={userId:'owner',phone:'+85259849530',role:'office'},worker={userId:'worker',phone:'+85211111111',role:'worker'},other={userId:'other',phone:'+85222222222',role:'worker'};
process.env.RESEARCH_ADMIN_PHONE=admin.phone;
async function fixture(){const db=new PGlite();for(const file of (await readdir('migrations')).filter(n=>n.endsWith('.sql')).sort())await db.exec(await readFile('migrations/'+file,'utf8'));
 for(const staff of [admin,worker,other]){await db.query('INSERT INTO "user"(id,name,email) VALUES($1,$1,$2)',[staff.userId,staff.userId+'@test.invalid']);await db.query('INSERT INTO employees(user_id,staff_code,role) VALUES($1,$1,$2)',[staff.userId,staff.role]);}
 await db.query(`INSERT INTO cases(id,owner_user_id,source,status,entry_no,data) VALUES('case1','worker','worker','editing','CT-MNA-1000','{"customer":"PRIVATE"}')`);
 const {id}=await researchMutation(db,admin,{action:'create-study',title:'Synthetic',protocol:'Synthetic consent study.'});await researchMutation(db,admin,{action:'study-status',studyId:id,status:'collecting'});return {db,studyId:id};}
const event={id:'request-123',caseId:'case1',operation:'submit',outcome:'server_error',durationMs:5000,release:'workflow-assistant-2026-11-06'};
test('field assistant sends only in-range aggregate facts and reuses the matching report',async()=>{
 const {db,studyId}=await fixture();
 try{
   await researchMutation(db,admin,{action:'enroll',studyId,entryNo:'CT-MNA-1000',phase:'baseline',difficulty:'low',permissionConfirmed:true,consentReference:'PRIVATE-REFERENCE'});
   const found=(await db.query('SELECT id FROM research_cases WHERE study_id=$1',[studyId])).rows[0];
   await db.query(`INSERT INTO research_field_events(study_case_id,actor_user_id,id,at,kind,surface,field)
     VALUES($1,'worker','private-event-id',now(),'validation_error','worker-basic','phone')`,[found.id]);
   const today=hkDay(),range=fieldRange(today,today);
   const run=await reserveDiagnosticAi(db,admin,studyId,undefined,undefined,range);
   assert.match(run.evidence,/聯絡電話 · 欄位檢查攔截：1 宗、1 次/);
   assert.ok(run.factIds.includes('signal_1'));
   for(const privateValue of ['PRIVATE','case1','private-event-id',found.id])assert.ok(!run.evidence.includes(privateValue));
   const generated=validateManagementReport(JSON.stringify({finding:'可優先核對聯絡電話。',factIds:['signal_1'],
     action:'把提示放到欄位旁。',verification:'比較有覆核紀錄的同類案件。'}),run.factIds);
   await finishDiagnosticAi(db,run.id,run.attempt,generated);
   assert.deepEqual((await reserveDiagnosticAi(db,admin,studyId,undefined,undefined,range)).cached,generated);
   await assert.rejects(reserveDiagnosticAi(db,admin,studyId,undefined,undefined,fieldRange('2026-01-01','2026-01-01')),/no-evidence/);
 }finally{await db.close();}
});
test('runtime classification excludes credentials, arbitrary URLs, read polling and request content',()=>{
 assert.equal(operationFor('/api/auth/sign-in',{method:'POST'}),null);assert.equal(operationFor('/api/cases/case1'),null);
 assert.equal(operationFor('/api/cases/case1?secret=hello',{method:'PATCH'}),null);
 assert.deepEqual(operationFor('/api/cases/case1/actions',{method:'POST',body:JSON.stringify({action:'submit',customer:'PRIVATE'})}),{caseId:'case1',operation:'submit'});
 assert.equal(outcomeFor(409),'conflict');assert.equal(outcomeFor(0),'network');
 assert.doesNotThrow(()=>recordRuntime(()=>{throw Error('offline');},'token',{caseId:'case1',operation:'save'},0,200));
});
test('signals count affected cases separately, preserve evidence and never fabricate empty results',()=>{
 const rows=[1,2].map(n=>({id:String(n),research_case_id:'r1',operation:'submit',outcome:'server_error',duration_ms:6000,role:'worker',release:'v1',created_at:'2026-11-06T00:00:00Z'}));
 const a=analyzeMaintenance(rows,[],3,true);assert.equal(a.signals[0].count,2);assert.equal(a.signals[0].cases,1);assert.equal(a.runtimeCases,1);assert.equal(a.partial,true);
 assert.ok(diagnosticEvidence(a).includes('資料截斷'));const brief=maintenanceBrief(a,a.signals[0]);assert.match(brief,/先閱讀倉庫/);assert.match(brief,/待人工復現/);assert.match(brief,/1, 2/);
 assert.deepEqual(analyzeMaintenance([],[],0).signals,[]);
});
test('progressive presentation distinguishes no data from no flags and prioritizes blocked operations without inventing risk scores',()=>{
 const base=analyzeMaintenance([],[],0);assert.equal(emptyGuidance(base,false).action,'加入案件');
 assert.equal(emptyGuidance({...base,enrolled:1},false).title,'等待第一筆使用記錄');
 assert.equal(emptyGuidance({...base,enrolled:1,runtimeCount:1},false).title,'目前沒有需要檢查的問題');
 const signals=[{key:'slow',cases:99,count:100},{key:'server_error',cases:1,count:1},{key:'conflict',cases:2,count:3}];
 assert.deepEqual(prioritizeSignals(signals).map(s=>s.key),['conflict','server_error','slow']);assert.equal(signals[0].key,'slow');
 assert.deepEqual(signalScope({...base,signals},'server_error').signals.map(s=>s.key),['server_error']);
});
test('collaboration baseline uses separate historical and recent completed handoffs, excluding open cases',()=>{
 const rows=[];
 for(let i=0;i<20;i++){
   const start=Date.UTC(2026,0,i+1);
   rows.push({id:String(i*2),research_case_id:`case-${i}`,action:'submit',created_at:new Date(start).toISOString()});
   rows.push({id:String(i*2+1),research_case_id:`case-${i}`,action:i<10?'return':'confirm',created_at:new Date(start+(i<10?60:10)*60000).toISOString()});
 }
 rows.push({id:'40',research_case_id:'pending',action:'submit',created_at:'2026-01-21T00:00:00.000Z'});
 rows.push({id:'41',research_case_id:'no-visible-submit',action:'return',created_at:'2026-01-22T00:00:00.000Z'});
 const a=analyzeMaintenance([],rows.reverse(),22);
 assert.deepEqual(a.collaboration,{submitted:21,reviewed:20,returned:10,medianWaitMinutes:35,waitBaseline:{priorCount:10,recentCount:10,priorMedian:60,recentMedian:10}});
 const snapshot=managementSnapshot(a,'waiting');assert.ok(snapshot.ready);assert.match(snapshot.evidence,/較早 10 宗：60 分鐘；最近 10 宗：10 分鐘/);
 assert.equal(managementSnapshot(analyzeMaintenance([],[],3),'rework').ready,false);
 const proposal={finding:'有可核查的等待記錄。',factIds:['baseline'],action:'試行交接提醒。',verification:'比較同難度案件的等候時間。'};
 assert.deepEqual(validateManagementReport(JSON.stringify(proposal),snapshot.facts.map(f=>f.id)),proposal);
 assert.throws(()=>validateManagementReport(JSON.stringify({...proposal,factIds:['invented']}),['baseline']),/ai-invalid-result/);
 assert.throws(()=>validateManagementReport(JSON.stringify({...proposal,finding:'節省 90%'}),['baseline']),/ai-invalid-result/);
});
test('runtime scope, ownership, deduplication, closed study and AI snapshot quota are enforced',async()=>{
 const {db,studyId}=await fixture();try{
   assert.equal((await storeRuntime(db,worker,event)).recorded,false);
   await researchMutation(db,admin,{action:'enroll',studyId,entryNo:'CT-MNA-1000',phase:'baseline',difficulty:'low',permissionConfirmed:true,consentReference:'TEST'});
   assert.equal((await storeRuntime(db,other,event)).recorded,false);
   assert.equal((await storeRuntime(db,worker,event)).recorded,true);
   const otherStudy=await researchMutation(db,admin,{action:'create-study',title:'Newer but empty',protocol:'Synthetic consent study.'});
   await researchMutation(db,admin,{action:'study-status',studyId:otherStudy.id,status:'collecting'});
   assert.equal((await researchOverview(db,admin,null)).suggestedStudyId,studyId);
   const exported=await researchRuntimeExport(db,admin,studyId);assert.equal(exported.rows.length,1);
   assert.deepEqual(Object.keys(exported.rows[0]).sort(),['alias','category','collection_version','difficulty','duration_ms','operation','outcome','phase','release','role','seconds_since_enrollment']);
   assert.equal(exported.rows[0].category,'field-handoff');assert.equal(exported.rows[0].collection_version,1);
   assert.equal((await researchRuntimeExport(db,admin,otherStudy.id)).rows.length,0);
   assert.equal((await storeRuntime(db,worker,event)).recorded,false);
   await assert.rejects(storeRuntime(db,worker,{...event,durationMs:-1}),/invalid/);
   await assert.rejects(maintenanceOverview(db,worker,studyId),/forbidden/);
   const a=await maintenanceOverview(db,admin,studyId);assert.equal(a.runtimeCount,1);assert.equal(a.signals[0].cases,1);assert.ok(!JSON.stringify(a).includes('PRIVATE'));
   assert.equal(a.activity.operation,'submit');assert.equal(recommendedSignal(a).key,'server_error');
   await assert.rejects(reserveDiagnosticAi(db,admin,studyId,undefined,'waiting'),/invalid-no-evidence/);
   const selected=await reserveDiagnosticAi(db,admin,studyId,'server_error');assert.ok(!selected.evidence.includes('操作等待較久'));
   await finishDiagnosticAi(db,selected.id,selected.attempt,{cause:'unknown',quote:'',explanation:'Need more evidence'});
   await assert.rejects(reserveDiagnosticAi(db,admin,studyId,'not-a-signal'),/no-evidence/);
   const reserved=await reserveDiagnosticAi(db,admin,studyId);assert.ok(!reserved.evidence.includes('PRIVATE'));
   await assert.rejects(reserveDiagnosticAi(db,admin,studyId),/running/);
   const result={cause:'unknown',quote:'',explanation:'Needs verification'};await finishDiagnosticAi(db,reserved.id,reserved.attempt,result);
   assert.deepEqual((await reserveDiagnosticAi(db,admin,studyId)).cached,result);
   assert.equal((await db.query('SELECT attempts FROM research_ai_usage')).rows[0].attempts,2);
   const management=await reserveDiagnosticAi(db,admin,studyId,undefined,'pdca');assert.ok(management.factIds.includes('operations'));assert.match(management.evidence,/PDCA/);
   const config={action:'telemetry-settings',studyId,enabled:['field-record','office-review']};
   await assert.rejects(researchMutation(db,worker,config),/forbidden/);
   await assert.rejects(researchMutation(db,admin,{...config,enabled:['arbitrary']}),/invalid-research-input/);
   assert.equal((await researchMutation(db,admin,config)).version,2);
   assert.equal((await researchMutation(db,admin,config)).version,2);
   assert.equal((await storeRuntime(db,worker,{...event,id:'request-filtered'})).recorded,false);
   assert.equal((await storeRuntime(db,worker,{...event,id:'request-enabled',operation:'save'})).recorded,true);
   const changed=await researchRuntimeExport(db,admin,studyId);
   assert.deepEqual(changed.rows.map(row=>row.collection_version),[1,2]);
   assert.deepEqual(changed.collectionVersions[1].enabled,config.enabled);
   const preset=await researchMutation(db,admin,{action:'create-preset'});
   assert.deepEqual(await researchMutation(db,admin,{action:'create-preset'}),preset);
   await researchMutation(db,admin,{action:'study-status',studyId:preset.id,status:'closed'});
   const nextPreset=await researchMutation(db,admin,{action:'create-preset'});
   assert.notEqual(nextPreset.id,preset.id);
   assert.deepEqual(await researchMutation(db,admin,{action:'create-preset'}),nextPreset);
   assert.ok(!(await reserveDiagnosticAi(db,admin,studyId)).cached);
   await researchMutation(db,admin,{action:'study-status',studyId,status:'closed'});
   assert.equal((await storeRuntime(db,worker,{...event,id:'request-789',operation:'save'})).recorded,false);
   await assert.rejects(reserveDiagnosticAi(db,admin,studyId),/not-collecting/);
 }finally{await db.close();}
});
