import test from 'node:test';
import assert from 'node:assert/strict';
import {migrationHash,matchesMigration} from '../scripts/migration-checksum.mjs';
test('migration verification permits only LF/CRLF differences, never SQL changes',()=>{
 const sql='CREATE TABLE example (id text);\nSELECT 1;\n',hash=migrationHash(sql);
 assert.ok(matchesMigration(sql.replaceAll('\n','\r\n'),hash));
 assert.ok(matchesMigration(sql,migrationHash(sql.replaceAll('\n','\r\n'))));
 assert.equal(matchesMigration(sql.replace('SELECT 1','SELECT 2'),hash),false);
 assert.equal(matchesMigration(sql.trim(),hash),false);
});
