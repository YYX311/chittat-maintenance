import {completeFields,completeItem} from "./complete-fixture.mjs";
import test from 'node:test';
import assert from 'node:assert/strict';
import {validQuantity,validMoney} from '../src/numeric-rules.js';
import {editableCopy,validateWorkerSubmission} from '../lib/case-rules.ts';
const staff={role:'worker',email:'worker@test.invalid'};
const record={...completeFields,id:'test',owner:staff.email,source:'worker',status:'editing',customer:'Client',address:'Site',phone:'12345678',startedAt:'2026-09-20T09:00',notes:'Inspection',items:[],photos:[]};
test('quantities accept zero integers and reject fractional, signed and exponent input on server',()=>{
 for(const qty of [0,1,10000,'2']){
  assert.equal(validQuantity(qty),true);
  const next=editableCopy(record,{items:[{...completeItem,id:'one',preset:0,qty}]},staff);
  assert.doesNotThrow(()=>validateWorkerSubmission(next));
 }
 for(const qty of [-1,1.5,'','-0','1e2','1a',10001]){
  assert.equal(validQuantity(qty),false);
  assert.throws(()=>editableCopy(record,{items:[{...completeItem,id:'one',preset:0,qty}]},staff));
 }
});
test('prices reject coercible characters and excessive precision',()=>{
 for(const price of ['0','12','12.30'])assert.equal(validMoney(price),true);
 for(const price of ['', ' ','1e2','0x10','-1','12.345','Infinity','1,000','$12']) {
  assert.equal(validMoney(price),false);
  if(price!=='')assert.throws(()=>editableCopy({...record,source:'office',status:'draft'},{items:[{...completeItem,id:'one',preset:0,qty:0,price}]},{...staff,role:'office'}));
 }
});
test('deleting a work item clears its orphaned price draft',()=>{
 const office={...staff,role:'office'};
 const next=editableCopy({...record,source:'office',status:'draft',items:[{...completeItem,id:'one',preset:0,qty:0,price:10}],priceDrafts:{one:'12.',gone:'4'}},{items:[]},office);
 assert.deepEqual(next.priceDrafts,{});
});
