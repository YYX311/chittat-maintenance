import {completeFields,completeItem} from "./complete-fixture.mjs";
import assert from "node:assert/strict";
import test from "node:test";
import { clearPriceDraft, confirmedPrice, priceDraftValue, updatePriceDraft } from "../src/pricing-model.js";
import { editableCopy, validateConfirmation } from "../lib/case-rules.ts";

test("office price typing stays local until a complete amount is confirmed", () => {
  const item = { id: "item-1", price: "" };
  let drafts = {};
  for (const value of ["1", "18", "180", "1800"]) drafts = updatePriceDraft(drafts, item.id, value);
  assert.equal(priceDraftValue(item, drafts), "1800");
  assert.equal(confirmedPrice(priceDraftValue(item, drafts)), 1800);
  assert.equal(priceDraftValue({ ...item, price: 1800 }, clearPriceDraft(drafts, item.id)), "1800");
});

test("office price validation accepts two decimals and rejects incomplete values", () => {
  assert.equal(confirmedPrice("0"), 0);
  assert.equal(confirmedPrice("1800.50"), 1800.5);
  assert.equal(confirmedPrice("1800."), null);
  assert.equal(confirmedPrice("-1"), null);
  assert.equal(confirmedPrice("12.345"), null);
});

test("service charge is persisted as a non-negative amount with two decimals", () => {
  const staff = { userId:"office", staffCode:"office", phone:"+85290000000", email:"office@staff.invalid", name:"Office", role:"office" };
  const record = { ...completeFields,id:"case", source:"office", status:"draft", owner:"office@staff.invalid", items:[{...completeItem,id:"item",preset:0,qty:1,price:100}], photos:[], customer:"Customer", address:"Site", date:"2026-09-16", projectId:"project", projectCode:"P-1" };
  assert.equal(editableCopy(record, { chargeAmount:"1800.50" }, staff).chargeAmount, "1800.50");
  assert.throws(() => editableCopy(record, { chargeAmount:"1800.555" }, staff), /invalid-charge-amount/);
  validateConfirmation({ ...record, chargeAmount:"0.00" });
});
