import test from 'node:test';
import assert from 'node:assert/strict';
import {recoverySummary} from '../lib/recovery-analysis.ts';
import {recoveryEvents} from '../lib/recovery-service.ts';
test('recovery preserves missingness, role, period and excludes outcomes beyond end',()=>{
 const start='2026-11-13T00:00:00.000Z',end='2026-11-14T00:00:00.000Z';
 const base={episode:'episode-1',participant:'P-1',role:'worker',variant:'A',active_ms:null,rating:null};
 const rows=[{...base,kind:'shown',at:start},{...base,kind:'resolved',at:'2026-11-13T00:00:10.000Z',active_ms:5000},{...base,kind:'rating',at:'2026-11-13T00:00:11.000Z',rating:3},{...base,kind:'submitted',at:end},{...base,episode:'episode-2',kind:'shown',at:start}];
 const r=recoverySummary(rows,start,end);
 assert.equal(r.total.n,2);assert.equal(r.total.resolved,1);assert.equal(r.total.pending,1);assert.equal(r.total.submitted,0);assert.equal(r.total.medianSeconds,10);assert.equal(r.total.medianActiveSeconds,5);assert.equal(r.total.medianFrustration,3);assert.equal(r.conditions[1].medianSeconds,null);
});
test('recovery payload excludes typed content and rejects invalid rating/time',()=>{
 const now=Date.now(),event={id:'event-1234',episode:'episode-1234',caseId:'case-1234',kind:'rating',at:now,rating:2,phone:'private'};
 assert.equal('phone' in recoveryEvents([event],now)[0],false);
 assert.throws(()=>recoveryEvents([{...event,rating:8}],now));assert.throws(()=>recoveryEvents([{...event,at:now-8*86400000}],now));
});
