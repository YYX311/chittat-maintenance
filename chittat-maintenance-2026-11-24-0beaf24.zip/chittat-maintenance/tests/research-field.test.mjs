import assert from "node:assert/strict";
import test from "node:test";
import { fieldCsv, fieldRange, summarizeBurden, summarizeUsage, trialPeriods } from "../lib/research-field.ts";
import { summarizeTrialTasks } from "../lib/field-study-analysis.ts";

test("field scope applies Hong Kong midnight, inclusive dates, and a bounded window", () => {
  const scope = fieldRange("2026-11-11", "2026-11-12");
  assert.deepEqual(scope.days, ["2026-11-11", "2026-11-12"]);
  assert.equal(scope.start, "2026-11-10T16:00:00.000Z");
  assert.equal(scope.end, "2026-11-12T16:00:00.000Z");
  assert.throws(() => fieldRange("2026-02-29", "2026-03-02"), /invalid-field-range/);
  assert.throws(() => fieldRange("2026-04-01", "2026-08-01"), /invalid-field-range/);
});

test("operation coverage separates successful business events from request errors", () => {
  const sample = { alias: "R-1", participant: "P-1", role: "worker", at: "2026-11-11T16:00:00Z" };
  const result = summarizeUsage([
    { ...sample, action: "submit", source: "handoff", outcome: "ok" },
    { ...sample, action: "submit", source: "request", outcome: "network" },
    { ...sample, action: "confirm", source: "handoff", participant: "P-2", role: "office", outcome: "ok" },
    { ...sample, action: "screen_active", source: "screen", surface:"worker-basic", duration_ms:8000 },
    { ...sample, action: "screen_active", source: "screen", surface:"worker-basic", duration_ms:4000 },
  ], ["2026-11-11", "2026-11-12"]);
  assert.deepEqual(result.daily, [
    { date: "2026-11-11", submitted: 0, confirmed: 0 },
    { date: "2026-11-12", submitted: 1, confirmed: 1 },
  ]);
  assert.equal(result.networkIssues, 1);
  assert.equal(result.participants, 2);
  assert.equal(result.cases, 1);
  assert.deepEqual(result.milestones,{submit:1,confirm:1});
  assert.deepEqual(result.surfaces,[{surface:"worker-basic",duration:12000,segments:2,cases:1}]);
});

test("context and workload comparisons separate scheduled cases from routine observation and missing signals",()=>{
  const task={role:"worker",submitted:1,active_minutes:1,participant:"P-1",phase:"baseline",difficulty:"low",
    after_17:0,net_issues:0,first_return:0,strain:2,ease:5,pulse_before_review:1,friction_score:0,assistant_shown:0};
  const result=summarizeTrialTasks([
    {...task,period:"OBS",after_17:1},
    {...task,period:"A1"},
    {...task,period:"A1",friction_score:null},
    {...task,period:"B1",phase:"improved",net_issues:1,first_return:1},
  ]);
  assert.deepEqual(result.comparisons.map(row=>row.n),[2,1,0,0]);
  assert.equal(result.unknownDemand,1);
  assert.equal(result.usual[0].decided,1);
  assert.equal(result.context[0].decided,0);
  assert.equal(result.context[1].returned,1);
  assert.equal(result.ratings[0].ease,5);
  assert.equal(result.modelCoverage.complete,3);
});

test("burden comparison pairs each case with one current worker report and preserves missingness", () => {
  const rows = [{ alias: "R-1", firstDecision: "return", elapsedMinutes: 5 },
    { alias: "R-2", firstDecision: null, elapsedMinutes: null },
    { alias: "R-3", firstDecision: "confirm", elapsedMinutes: 9 }];
  const worker = { role: "worker", stage: "submit", source: "self_report" };
  const groups = summarizeBurden([
    { ...worker, alias: "R-1", load: 4 },
    { ...worker, alias: "R-1", load: 1 },
    { ...worker, alias: "R-2", load: 3 },
    { ...worker, alias: "R-3", role: "office", load: 2 },
  ], rows);
  assert.deepEqual(groups, [
    { band: "low", n: 1, decided: 0, returned: 0, timed: 0, medianMinutes: null },
    { band: "high", n: 1, decided: 1, returned: 1, timed: 1, medianMinutes: 5 },
  ]);
});

test("four research periods span contiguous dates and CSV protects spreadsheet cells", () => {
  const periods = trialPeriods("2026-11-26", 1);
  assert.deepEqual(periods.map(p => [p.label,p.from,p.to]), [
    ["A1","2026-11-26","2026-12-02"], ["B1","2026-12-03","2026-12-09"],
    ["A2","2026-12-10","2026-12-16"], ["B2","2026-12-17","2026-12-23"],
  ]);
  assert.throws(() => trialPeriods("2026-11-26", 1.5), /invalid-trial-plan/);
  assert.equal(fieldCsv(["alias","value"], [{ alias: "=HYPERLINK(\"test\")", value: -3 }]),
    '\uFEFFalias,value\r\n"\'=HYPERLINK(""test"")","-3"\r\n');
});
