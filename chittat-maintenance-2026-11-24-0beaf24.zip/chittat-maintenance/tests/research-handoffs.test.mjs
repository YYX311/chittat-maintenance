import assert from "node:assert/strict";
import test from "node:test";
import { summarizeHandoffs } from "../lib/research-handoffs.ts";

test("handoffs count committed first decisions and keep pending cases out of the denominator", () => {
  function event(alias, action, minute, reason = null) {
    return { id: alias, alias, phase: "baseline", difficulty: "medium", action, created_at: new Date(minute * 60000), reason };
  }
  const summary = summarizeHandoffs([
    event("early", "return", 0, "photos"), // Submission predates enrollment.
    event("a", "submit", 1), event("b", "submit", 2), event("c", "submit", 3),
    event("a", "return", 4, "equipment"), event("b", "withdraw", 5),
    event("a", "submit", 7), event("d", "submit", 8), event("d", "confirm", 9),
    event("a", "return", 10, "untrusted text"), event("a", "submit", 11), event("a", "confirm", 13),
    event("a", "confirm", 22),
  ]);
  const base = summary.groups.find(group => group.phase === "baseline" && group.difficulty === "all");
  assert.deepEqual(base, {
    phase: "baseline", difficulty: "all", submitted: 4, decided: 2, firstPass: 1, returned: 1,
    confirmed: 2, waitingReview: 1, waitingWorker: 0, withdrawn: 1, medianMinutes: 6.5,
  });
  assert.deepEqual(summary.reasons.map(({ code, count }) => [code, count]), [["equipment", 1], ["unknown", 1]]);
  assert.equal(summary.rows.find(row => row.alias === "a").submissions, 3);
});
