import test from "node:test";
import assert from "node:assert/strict";
import { invokeResearchAi, researchAiAvailable } from "../lib/research-provider.ts";

test("local Qwen requires explicit opt-in and sends scoped evidence through Cloudflare",async t=>{
  const config={RESEARCH_AI_ENABLED:"1",RESEARCH_AI_CLOUDFLARE_ACCOUNT_ID:"a".repeat(32),RESEARCH_AI_CLOUDFLARE_API_TOKEN:"synthetic-only"};
  const original=Object.fromEntries(Object.keys(config).map(key=>[key,process.env[key]]));
  t.after(()=>{for(const [key,value] of Object.entries(original)){if(value===undefined)delete process.env[key];else process.env[key]=value;}});
  Object.assign(process.env,config,{RESEARCH_AI_ENABLED:"0"});
  assert.equal(researchAiAvailable(),false);
  await assert.rejects(invokeResearchAi("summary"),/ai-not-configured/);
  process.env.RESEARCH_AI_ENABLED="1";
  let httpStatus=200;
  const fetchMock=t.mock.method(globalThis,"fetch",async(url,options)=>{
    assert.equal(url,`https://api.cloudflare.com/client/v4/accounts/${config.RESEARCH_AI_CLOUDFLARE_ACCOUNT_ID}/ai/run/@cf/qwen/qwen3.8-27b`);
    assert.equal(options.headers.Authorization,"Bearer synthetic-only");
    const input=JSON.parse(options.body);
    assert.deepEqual(JSON.parse(input.messages[1].content),{evidence:"summary"});
    assert.equal(input.store,false);
    return Response.json({success:true,result:{choices:[{message:{content:"structured report"}}]}},{status:httpStatus});
  });
  assert.equal(await invokeResearchAi("summary"),"structured report");
  httpStatus=429;
  await assert.rejects(invokeResearchAi("summary"),/ai-provider-quota/);
  assert.equal(fetchMock.mock.callCount(),2);
});
