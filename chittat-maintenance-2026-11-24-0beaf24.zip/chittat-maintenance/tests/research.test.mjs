import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile,readdir } from 'node:fs/promises';
import { PGlite } from '@electric-sql/pglite';
import { requireResearchAdmin,researchMutation,researchOverview,researchDetail,researchExport } from '../lib/research-service.ts';
import { reserveResearchAi,finishResearchAi,validateAiResult,dailyLimit,researchResponseText } from '../lib/research-ai.ts';
import { chartGroups,researchComparison } from '../lib/research-chart-data.ts';
import { processEvidence } from '../lib/research-factors.ts';
import {validateContext,summarizeContext} from '../lib/human-factors.ts';
import {contextRows} from '../lib/human-factors-service.ts';
import {managementSnapshot} from '../lib/management-analysis.ts';
import {analyzeMaintenance} from '../lib/maintenance-analysis.ts';
const admin={userId:'owner',role:'office',phone:'+85259849530'},other={userId:'other',role:'manager',phone:'+85211111111'};
process.env.RESEARCH_ADMIN_PHONE=admin.phone;

test('human-factor context never infers fatigue from observers and distinguishes missing burden from low burden',()=>{
  const input={contextPermission:true,role:'worker',stage:'capture',source:'observed',factors:['environment'],load:null,safety:'not_asked'};
  assert.equal(validateContext(input).load,null);
  assert.throws(()=>validateContext({...input,contextPermission:false}),/consent/);
  assert.throws(()=>validateContext({...input,factors:['fatigue']}),/source/);
  assert.throws(()=>validateContext({...input,load:4}),/source/);
  assert.throws(()=>validateContext({...input,factors:['unknown','environment']}),/invalid/);
  assert.throws(()=>validateContext({...input,source:'self_report',load:0}),/invalid/);
  assert.throws(()=>validateContext({...input,source:'self_report',load:3.5}),/invalid/);
  assert.equal(validateContext({...input,source:'self_report',factors:['fatigue'],load:1}).load,1);
  const base={...validateContext(input),id:'a',research_case_id:'r',alias:'R-1',phase:'baseline',difficulty:'low',case_version:1,created_at:'2026-11-01T10:00:00Z'};
  const corrected={...base,id:'b',factors:['unknown'],created_at:'2026-11-01T11:00:00Z'};
  const summary=summarizeContext([corrected,base,{...base,id:'c',role:'office'}]);
  assert.equal(summary.total,2);assert.equal(summary.cases,1);assert.equal(summary.loadMeasured,0);
  assert.equal(summary.counts.find(f=>f.id==='environment').count,1);
  assert.equal(summary.counts.find(f=>f.id==='fatigue').count,0);
  assert.equal(summary.followup,0);
  assert.equal(managementSnapshot(analyzeMaintenance([],[],1),'human_factors').ready,false);
  const snap=managementSnapshot({...analyzeMaintenance([],[],1),context:summary},'human_factors');
  assert.equal(snap.ready,true);assert.match(snap.evidence,/不是因果證明/);
  assert.ok(!snap.evidence.includes('R-1'));assert.ok(!snap.evidence.includes('research_case_id'));
});

test('context review requires separate consent, enrollment, valid source and open study; histories persist without private export fields',async()=>{
  const db=await fixture();try{
    const scope=await setup(db);
    const input={action:'context-review',studyId:scope.studyId,entryNo:'CT-MNA-1000',contextPermission:true,consentReference:'PRIVATE-CONTEXT-CONSENT',role:'worker',stage:'capture',source:'self_report',factors:['fatigue','interruption'],load:4,safety:'reported'};
    await assert.rejects(researchMutation(db,other,input),/forbidden/);
    await assert.rejects(researchMutation(db,admin,{...input,contextPermission:false}),/consent/);
    await assert.rejects(researchMutation(db,admin,{...input,entryNo:'CT-MNA-9999'}),/context-case/);
    await researchMutation(db,admin,input);
    let context=(await researchOverview(db,admin,scope.studyId)).context;
    assert.equal(context.cases,1);assert.equal(context.followup,1);assert.equal(context.loadMeasured,1);
    await researchMutation(db,admin,{...input,factors:['unknown'],load:null,safety:'none_reported'});
    context=(await researchOverview(db,admin,scope.studyId)).context;
    assert.equal(context.total,1);assert.equal(context.followup,0);assert.equal(context.loadMeasured,0);
    const exported=await contextRows(db,scope.studyId);
    assert.equal(exported.rows.length,2);assert.equal(exported.rows[1].load,4);
    assert.ok(!JSON.stringify(exported).includes('PRIVATE'));assert.ok(!JSON.stringify(exported).includes('CT-MNA-1000'));
    const otherStudy=await researchMutation(db,admin,{action:'create-study',title:'Isolated',protocol:'Separate isolated context review.'});
    assert.equal((await contextRows(db,otherStudy.id)).rows.length,0);
    await researchMutation(db,admin,{action:'study-status',studyId:otherStudy.id,status:'collecting'});
    await assert.rejects(researchMutation(db,admin,{...input,studyId:otherStudy.id}),/context-case/);
    await researchMutation(db,admin,{action:'study-status',studyId:scope.studyId,status:'closed'});
    await assert.rejects(researchMutation(db,admin,input),/not-collecting/);
  }finally{await db.close();}
});
test('deployment does not enable research inference without an explicit server setting',async()=>{
  const config=JSON.parse(await readFile(new URL('../wrangler.jsonc',import.meta.url),'utf8'));
  assert.equal(config.vars.RESEARCH_AI_ENABLED,undefined);
  assert.equal(config.ai.binding,'AI');
});
async function fixture(){
  const db=new PGlite();
  const path=new URL('../migrations/',import.meta.url);
  for(const name of (await readdir(path)).filter(n=>n.endsWith('.sql')).sort())await db.exec(await readFile(new URL(name,path),'utf8'));
  for(const id of ['owner','other']){
    await db.query('INSERT INTO "user"(id,name,email) VALUES($1,$1,$2)',[id,`${id}@test.invalid`]);
    await db.query("INSERT INTO employees(user_id,staff_code,role) VALUES($1,$1,'office')",[id]);
  }
  await db.query(`INSERT INTO cases(id,owner_user_id,source,status,entry_no,data) VALUES('case1','other','worker','editing','CT-MNA-1000','{"customer":"PRIVATE NAME"}')`);
  return db;
}
async function setup(db){
  const {id}=await researchMutation(db,admin,{action:'create-study',title:'Test',protocol:'A documented baseline comparison.'});
  await researchMutation(db,admin,{action:'study-status',studyId:id,status:'collecting'});
  const enrolled=await researchMutation(db,admin,{action:'enroll',studyId:id,entryNo:'CT-MNA-1000',phase:'baseline',difficulty:'low',permissionConfirmed:true,consentReference:'C-1'});
  return {studyId:id,id:enrolled.id};
}
test('research denies unconfigured users and manager roles, independent of business access',async()=>{
  assert.throws(()=>requireResearchAdmin(admin,''),/forbidden/);
  assert.throws(()=>requireResearchAdmin(other,admin.phone),/forbidden/);
  requireResearchAdmin(admin,admin.phone);
  const db={query(){throw new Error('must not reach database');}};
  await assert.rejects(researchOverview(db,other,null),/forbidden/);
  await assert.rejects(researchDetail(db,other,'id'),/forbidden/);
  await assert.rejects(researchExport(db,other,'id'),/forbidden/);
  await assert.rejects(researchMutation(db,other,{}),/forbidden/);
  await assert.rejects(reserveResearchAi(db,other,'id',true),/forbidden/);
});

test('diagnostics uses enrolled events and latest observations, isolates studies and never infers causes',async()=>{
  const db=await fixture();try {
    const scope=await setup(db);
    await db.query(`INSERT INTO audit_events(case_id,actor_user_id,action,created_at) VALUES('case1','owner','return',now()-interval '1 day')`);
    let diagnostics=(await researchOverview(db,admin,scope.studyId)).diagnostics;
    assert.equal(diagnostics.total,1);assert.equal(diagnostics.items[0].returns,0);
    assert.match(diagnostics.items[0].rule,/尚無人工觀察/);
    const observation={action:'observe',...scope,workerMinutes:3,officeMinutes:2,qualityErrors:0,outcome:'complete',cause:'unknown',evidence:'Synthetic observed complete case.',method:'observed'};
    await researchMutation(db,admin,observation);
    assert.equal((await researchOverview(db,admin,scope.studyId)).diagnostics.total,0);
    for(let i=0;i<2;i++)await db.query(`INSERT INTO audit_events(case_id,actor_user_id,action) VALUES('case1','owner','return')`);
    diagnostics=(await researchOverview(db,admin,scope.studyId)).diagnostics;
    assert.equal(diagnostics.items[0].returns,2);assert.match(diagnostics.items[0].rule,/重複退回/);
    assert.ok(!('cause' in diagnostics.items[0]));assert.ok(!JSON.stringify(diagnostics).includes('PRIVATE NAME'));
    const otherStudy=await researchMutation(db,admin,{action:'create-study',title:'Empty',protocol:'Other isolated study.'});
    assert.equal((await researchOverview(db,admin,otherStudy.id)).diagnostics.total,0);
    await researchMutation(db,admin,{...observation,outcome:'failed',officeMinutes:null});
    diagnostics=(await researchOverview(db,admin,scope.studyId)).diagnostics;
    assert.match(diagnostics.items[0].rule,/失敗/);assert.match(diagnostics.items[0].rule,/計時不完整/);
    await researchMutation(db,admin,observation);
    diagnostics=(await researchOverview(db,admin,scope.studyId)).diagnostics;
    assert.doesNotMatch(diagnostics.items[0].rule,/失敗|計時不完整/);
  }finally{await db.close();}
});
test('research consent, enrollment isolation, missing values, revisions and closed studies',async()=>{
  const db=await fixture();try{
    assert.equal((await researchOverview(db,admin,null)).total,0);
    const {id:studyId}=await researchMutation(db,admin,{action:'create-study',title:'Test',protocol:'A documented baseline comparison.'});
    const enroll={action:'enroll',studyId,entryNo:'CT-MNA-1000',phase:'baseline',difficulty:'low',permissionConfirmed:true,consentReference:'C-1'};
    await assert.rejects(researchMutation(db,admin,enroll),/not-collecting/);
    await researchMutation(db,admin,{action:'study-status',studyId,status:'collecting'});
    await assert.rejects(researchMutation(db,admin,{...enroll,permissionConfirmed:false}),/consent/);
    const {id}=await researchMutation(db,admin,enroll);
    await assert.rejects(researchMutation(db,admin,enroll),/already-enrolled/);
    const observation={action:'observe',studyId,id,workerMinutes:3,officeMinutes:null,qualityErrors:null,outcome:'incomplete',cause:'unknown',evidence:'There is insufficient evidence.',method:'observed'};
    await researchMutation(db,admin,observation);
    let overview=await researchOverview(db,admin,studyId);
    assert.equal(overview.metrics[0].timed,0);assert.equal(overview.metrics[0].mean_minutes,null);
    await assert.rejects(researchMutation(db,admin,{...observation,workerMinutes:-1}),/invalid/);
    await assert.rejects(researchMutation(db,admin,{...observation,qualityErrors:0.5}),/invalid/);
    await researchMutation(db,admin,{...observation,officeMinutes:2,qualityErrors:0,outcome:'complete'});
    overview=await researchOverview(db,admin,studyId);
    assert.equal(overview.metrics[0].enrolled,1);assert.equal(Number(overview.metrics[0].mean_minutes),5);
    const detail=await researchDetail(db,admin,id);assert.equal(detail.observations.length,2);
    const exported=await researchExport(db,admin,studyId);assert.equal(exported.length,2);
    assert.ok(!JSON.stringify(exported).includes('PRIVATE NAME'));assert.ok(!JSON.stringify(exported).includes('CT-MNA'));
    assert.ok(!('evidence' in exported[0]));
    assert.ok(exported[0].participant.startsWith('P-'));
    assert.ok(!('participant_id' in exported[0]));
    await researchMutation(db,admin,{action:'study-status',studyId,status:'closed'});
    await assert.rejects(researchMutation(db,admin,observation),/not-collecting/);
    await assert.rejects(researchMutation(db,admin,{action:'study-status',studyId,status:'collecting'}),/transition/);
    await db.query("DELETE FROM cases WHERE id='case1'");
    assert.equal((await researchOverview(db,admin,studyId)).total,1);
    assert.equal((await researchDetail(db,admin,id)).record.status,'deleted');
  }finally{await db.close();}
});
test('AI enforces daily budget, reuses immutable results and excludes manual reference label',async()=>{
  const db=await fixture();try{
    const scope=await setup(db);
    const {id}=await researchMutation(db,admin,{action:'observe',...scope,workerMinutes:null,officeMinutes:null,qualityErrors:null,outcome:'incomplete',cause:'changed_requirement',evidence:'The office requested a new field after submission.',method:'observed'});
    await assert.rejects(reserveResearchAi(db,admin,id,false),/consent/);
    const reserved=await reserveResearchAi(db,admin,id,true);
    assert.equal(reserved.evidence,'The office requested a new field after submission.');
    assert.ok(!('cause' in reserved));
    await assert.rejects(reserveResearchAi(db,admin,id,true),/running/);
    const result={cause:'changed_requirement',quote:'requested a new field',explanation:'Evidence indicates a changed requirement.'};
    await finishResearchAi(db,id,reserved.attempt,result);
    assert.deepEqual((await reserveResearchAi(db,admin,id,true)).cached,result);
    assert.equal((await db.query('SELECT attempts FROM research_ai_usage')).rows[0].attempts,1);
    await db.query('UPDATE research_ai_usage SET attempts=$1',[dailyLimit]);
    await db.query("UPDATE research_ai_runs SET status='failed'");
    await assert.rejects(reserveResearchAi(db,admin,id,true),/daily-limit/);
  }finally{await db.close();}
});
test('AI rejects fabricated citations, invalid labels and excessive outputs',()=>{
  assert.deepEqual(validateAiResult('{"cause":"unknown","quote":"","explanation":"Insufficient evidence"}','record'),{cause:'unknown',quote:'',explanation:'Insufficient evidence'});
  assert.throws(()=>validateAiResult('{"cause":"technical_failure","quote":"made up","explanation":"x"}','record'),/invalid/);
  assert.throws(()=>validateAiResult('{"cause":"lazy_worker","quote":"record","explanation":"x"}','record'),/invalid/);
  assert.throws(()=>validateAiResult('x'.repeat(10001),'record'),/invalid/);
});

test('process evidence distinguishes elapsed time, missing endpoints and truncated counts',()=>{
  const events=[{id:'1',action:'submit',created_at:'2026-01-01T09:00:00Z'},{id:'2',action:'return',created_at:'2026-01-01T09:10:00Z'},{id:'3',action:'confirm',created_at:'2026-01-01T10:00:00Z'}];
  assert.equal(processEvidence(events).elapsedMinutes,60);
  assert.deepEqual(processEvidence(events).returnIds,['2']);
  assert.equal(processEvidence(events.slice(1)).elapsedMinutes,null);
  assert.equal(processEvidence(events,true).elapsedMinutes,null);
  const result={factors:[{cause:'missing_information',quote:'missing model',explanation:'Possibly incomplete.'},{cause:'technical_failure',quote:'upload failed',explanation:'Possible network failure.'}],uncertainties:['Was the upload retried?']};
  assert.deepEqual(validateAiResult(JSON.stringify(result),'missing model; upload failed'),result);
  assert.throws(()=>validateAiResult(JSON.stringify(result),'missing model'),/invalid/);
  assert.throws(()=>validateAiResult(JSON.stringify({...result,factors:[result.factors[0],result.factors[0]]}),'missing model'),/invalid/);
});

test('multiple-factor review snapshots, improvement records, stratification and closure survive reload',async()=>{
  const db=await fixture();try{
    const scope=await setup(db);
    const {id}=await researchMutation(db,admin,{action:'observe',...scope,workerMinutes:4,officeMinutes:2,qualityErrors:1,outcome:'complete',cause:'unknown',evidence:'missing model; upload failed',method:'observed'});
    const review={action:'review-ai',studyId:scope.studyId,observationId:id,verdict:'partial',correction:'The network claim needs verification.'};
    await assert.rejects(researchMutation(db,admin,review),/invalid-ai-review/);
    const reserved=await reserveResearchAi(db,admin,id,true);
    const result=validateAiResult(JSON.stringify({factors:[{cause:'missing_information',quote:'missing model',explanation:'Possible missing information.'}],uncertainties:['Why missing?']}),'missing model; upload failed');
    await finishResearchAi(db,id,reserved.attempt,result);
    await assert.rejects(researchMutation(db,admin,{...review,studyId:'missing'}),/not-found/);
    await researchMutation(db,admin,review);
    await researchMutation(db,admin,{...review,verdict:'agree',correction:'Checked against original evidence.'});
    const detail=await researchDetail(db,admin,scope.id);
    assert.equal(detail.reviews.length,2);assert.deepEqual(detail.reviews[0].result_snapshot,result);
    const improvement={action:'improvement',studyId:scope.studyId,changeText:'Add equipment checklist.',rationale:'Observed missing model information.',metric:'errors',appliedOn:'2026-02-01'};
    await assert.rejects(researchMutation(db,admin,{...improvement,appliedOn:'2026-02-31'}),/invalid/);
    await researchMutation(db,admin,improvement);
    const overview=await researchOverview(db,admin,scope.studyId);
    assert.equal(overview.improvements.length,1);assert.equal(overview.improvements[0].applied_on,'2026-02-01');assert.equal(overview.breakdown[0].measurement_method,'observed');assert.equal(Number(overview.breakdown[0].mean_minutes),6);
    const exported=await researchExport(db,admin,scope.studyId);
    assert.deepEqual(exported[0].ai_factors,['missing_information']);assert.equal(exported[0].ai_reviews.length,2);
    assert.ok(!JSON.stringify(exported).includes('network claim'));
    await researchMutation(db,admin,{action:'study-status',studyId:scope.studyId,status:'closed'});
    await assert.rejects(researchMutation(db,admin,review),/not-collecting/);
    await assert.rejects(researchMutation(db,admin,improvement),/not-collecting/);
  }finally{await db.close();}
});

test('research charts weight subgroup means by measured samples and keep zero distinct from missing',()=>{
  const rows=[{phase:'baseline',difficulty:'low',measurement_method:'observed',cases:3,timed:2,mean_minutes:'5',quality_measured:2,mean_errors:'0'},{phase:'baseline',difficulty:'high',measurement_method:'self_report',cases:1,timed:1,mean_minutes:'20',quality_measured:0,mean_errors:null}];
  const groups=chartGroups(rows);
  assert.equal(groups[0].minutes,10);assert.equal(groups[0].errors,0);assert.equal(groups[0].total,4);
  assert.equal(groups[1].minutes,null);assert.equal(groups[1].errors,null);
  assert.equal(chartGroups(rows,'low','observed')[0].minutes,5);
  assert.equal(chartGroups(rows,'high','observed')[0].minutes,null);
});

test('Qwen provider handles structured and chat-completion responses and rejects truncated output',()=>{
 const value={factors:[{cause:'unknown',quote:'',explanation:'Insufficient evidence'}],uncertainties:[]};
 assert.equal(researchResponseText({response:value}),JSON.stringify(value));
 assert.equal(researchResponseText({response:JSON.stringify(value)}),JSON.stringify(value));
 assert.equal(researchResponseText({choices:[{finish_reason:'stop',message:{content:JSON.stringify(value)}}]}),JSON.stringify(value));
 assert.throws(()=>researchResponseText({choices:[{finish_reason:'length',message:{content:'{}'}}],response:value}),/invalid/);
});
test('research comparison suppresses differences for missing, mixed-method and mixed-difficulty samples',()=>{
  const base={phase:'baseline',difficulty:'low',measurement_method:'observed',cases:4,timed:2,mean_minutes:'10',quality_measured:1,mean_errors:'0'};
  const after={...base,phase:'improved',timed:1,mean_minutes:'7',quality_measured:0,mean_errors:null};
  assert.equal(researchComparison([base,after],'all','observed','minutes').delta,-3);
  assert.equal(researchComparison([base,after],'all','observed','errors').status,'missing');
  assert.equal(researchComparison([base,after],'all','all','minutes').status,'method');
  const hard={...after,difficulty:'high',mean_minutes:'3'};
  assert.equal(researchComparison([base,hard],'all','observed','minutes').status,'difficulty');
  assert.equal(researchComparison([base,after,hard],'low','observed','minutes').delta,-3);
  assert.equal(researchComparison([base,{...after,timed:0,mean_minutes:null}],'low','observed','minutes').delta,null);
});
