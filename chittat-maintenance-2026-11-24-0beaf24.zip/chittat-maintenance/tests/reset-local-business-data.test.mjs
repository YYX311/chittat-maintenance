import assert from "node:assert/strict";
import test from "node:test";
import { readFile } from "node:fs/promises";
import { PGlite } from "@electric-sql/pglite";
import { BUSINESS_TABLES, resetBusinessData, snapshotBusinessData } from "../scripts/reset-local-business-data.mjs";

test("local reset removes business records while retaining authorized staff", async () => {
  const database = new PGlite();
  try {
    for (const name of ["000_auth.sql", "001_business.sql", "002_projects.sql", "003_document_format.sql", "004_object_deletions.sql"]) {
      await database.exec(await readFile(new URL(`../migrations/${name}`, import.meta.url), "utf8"));
    }
    await database.query(`INSERT INTO "user"(id,name,email,"phoneNumber") VALUES ('u','User','u@staff.invalid','+15550000001')`);
    await database.query(`INSERT INTO employees(user_id,staff_code,role) VALUES ('u','U','worker')`);
    await database.query(`INSERT INTO projects(id,code,name) VALUES ('p','P','Project')`);
    await database.query(`INSERT INTO cases(id,owner_user_id,source,status,entry_no,project_id,data) VALUES ('c','u','worker','editing','E','p','{}')`);
    await database.query(`INSERT INTO counters(key,value) VALUES ('service',2)`);
    const backup = await snapshotBusinessData(database);
    assert.equal(backup.cases.length, 1);
    await resetBusinessData(database);
    for (const table of BUSINESS_TABLES) assert.equal((await database.query(`SELECT count(*)::int AS count FROM ${table}`)).rows[0].count, 0);
    assert.equal((await database.query(`SELECT count(*)::int AS count FROM employees`)).rows[0].count, 1);
  } finally { await database.close(); }
});
