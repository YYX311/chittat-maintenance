import test from "node:test";
import assert from "node:assert/strict";
import {sessionFetch,setSessionToken} from "../src/session-fetch.js";
test("tab requests use their own signed session and never shared cookies",async()=>{
 const original=globalThis.fetch,storage=globalThis.sessionStorage;
 let value=null,seen;
 globalThis.sessionStorage={getItem:()=>value,setItem:(_,v)=>{value=v},removeItem:()=>{value=null}};
 globalThis.fetch=async(path,options)=>{seen=options;return new Response("{}")};
 try {
  await assert.rejects(sessionFetch("/api/me"),e=>e.status===401);
  setSessionToken("worker.signature");await sessionFetch("/api/me",{credentials:"same-origin"});
  assert.equal(seen.credentials,"omit");assert.equal(seen.headers.get("Authorization"),"Bearer worker.signature");assert.ok(seen.signal);
  setSessionToken(null);await assert.rejects(sessionFetch("/api/me"),e=>e.status===401);
 }finally{globalThis.fetch=original;globalThis.sessionStorage=storage;}
});

test('case diagnostics is nonblocking, content-free and preserves the original response',async()=>{
 const original=globalThis.fetch,storage=globalThis.sessionStorage,calls=[];
 globalThis.sessionStorage={getItem:()=>"worker.signature"};
 globalThis.fetch=async(path,options)=>{calls.push({path,options});if(path==='/api/research/runtime')throw Error('telemetry unavailable');return new Response('{"error":"conflict"}',{status:409});};
 try {
  const response=await sessionFetch('/api/cases/case1/actions',{method:'POST',body:JSON.stringify({action:'submit',customer:'PRIVATE CONTENT'})});
  assert.equal(response.status,409);assert.equal(calls.length,2);
  const captured=JSON.parse(calls[1].options.body);assert.equal(captured.outcome,'conflict');assert.equal(captured.operation,'submit');
  assert.ok(!JSON.stringify(captured).includes('PRIVATE'));assert.equal(calls[1].options.credentials,'omit');
  globalThis.fetch=async(path,options)=>{calls.push({path,options});throw Error('network failed');};
  await assert.rejects(sessionFetch('/api/cases/case1',{method:'PATCH'}),/network failed/);
  assert.equal(JSON.parse(calls.at(-1).options.body).outcome,'network');
 }finally{globalThis.fetch=original;globalThis.sessionStorage=storage;}
});
