import test from "node:test";
import assert from "node:assert/strict";
import { isAutomatedTestCase, archiveCandidates } from "../scripts/test-data-selection.mjs";
test("test archive retains manual records and the three most recently updated test tasks",()=>{
  const row={data:{customer:"E2E-PDF"},created_at:"2026-09-20T09:00:00Z",updated_at:"2026-09-20T09:00:30Z"};
  assert.equal(isAutomatedTestCase(row),true);
  assert.equal(isAutomatedTestCase({...row,data:{customer:"SYNC-123456"}}),true);
  for(const customer of ["Company","123","SYNC-Company",""])
    assert.equal(isAutomatedTestCase({...row,data:{customer}}),false);
  assert.equal(isAutomatedTestCase({...row,created_at:"invalid"}),false);
  const manual={...row,id:"manual",data:{customer:"Company"}};
  const records=Array.from({length:5},(_,id)=>({...row,id,updated_at:`2026-09-20T09:0${id}:30Z`}));
  assert.deepEqual(archiveCandidates([...records,manual]).map(r=>r.id),[1,0]);
});
