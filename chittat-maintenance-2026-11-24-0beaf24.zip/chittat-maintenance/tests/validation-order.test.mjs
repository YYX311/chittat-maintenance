import test from 'node:test';
import assert from 'node:assert/strict';
import {formIssues,firstFormIssue,firstItemIssue,orderedIssues} from '../src/form-validation.js';
import {completeFields,completeItem} from './complete-fixture.mjs';

test('missing and malformed fields follow visual step order rather than rule order',()=>{
 const r={...completeFields,customer:'Client',address:'Site',date:'invalid',tower:'',phone:'abc',notes:'',items:[{...completeItem,id:'a',preset:0,qty:-1}]};
 assert.deepEqual(formIssues(r,true).map(i=>i.field),['date','tower','phone','qty','notes']);
});
test('current page is checked first and earlier steps still block completion',()=>{
 const issues=[{field:'tower',step:0},{field:'phone',step:0},{field:'notes',step:2},{field:'completedAt',step:2}];
 assert.equal(firstFormIssue(issues,2).field,'notes');
 assert.equal(firstFormIssue(issues.filter(i=>i.field!=='notes'),2).field,'completedAt');
 assert.equal(firstFormIssue(issues.slice(0,2),2).field,'tower');
 assert.equal(firstFormIssue(issues,3).field,'tower');
 assert.equal(firstFormIssue([],0),undefined);
});
test('work item rows retain their visual order with the discount after all rows',()=>{
 const items=[{id:'a'},{id:'b'}];
 const issues=[{field:'discountAmount',step:1},{field:'brand',step:1,itemId:'b'},{field:'model',step:1,itemId:'a'},{field:'qty',step:1,itemId:'a'}];
 assert.deepEqual(orderedIssues(issues,items).map(i=>i.field),['qty','model','brand','discountAmount']);
});
test('each item save starts at the first remaining invalid visible control',()=>{
 const item={id:'i',preset:14,brand:'',qty:'',model:'',price:'invalid',description:''};
 for(const [field,value]of [['brand','Daikin'],['qty',1],['model','RX'],['price','12.50'],['description','Repair']]){
  assert.equal(firstItemIssue(item,false).field,field);item[field]=value;
 }
 assert.equal(firstItemIssue(item,false),null);
 assert.equal(firstItemIssue({...item,brand:'',price:''},false,'Default'),null);
 assert.equal(firstItemIssue({...item,price:'invalid'},true),null);
});
