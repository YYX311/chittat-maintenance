import test from "node:test";
import assert from "node:assert/strict";
import {mergeWorkspace} from "../src/workspace-sync.js";
import {requiredIssues} from "../src/required-fields.js";
import {validateWorkerSubmission,validateConfirmation} from "../lib/case-rules.ts";
import {completeFields,completeItem} from "./complete-fixture.mjs";

test("polling never downgrades acknowledged versions or overwrites local typing",()=>{
 const known={id:"a",serverVersion:5,notes:"Saved"};const canonical=new Map([["a",known]]);
 const local={records:[{...known,serverVersion:3,notes:"Typing"}]};
 const merged=mergeWorkspace({records:[{...known,serverVersion:4}]},canonical,local,new Set(["a"]));
 assert.equal(canonical.get("a"),known);
 assert.equal(merged.records[0].notes,"Typing");assert.equal(merged.records[0].serverVersion,5);
 const remote=mergeWorkspace({records:[{...known,serverVersion:6,notes:"Other person"}]},canonical,local,new Set(["a"]));
 assert.equal(canonical.get("a").serverVersion,5,"genuine concurrent edit must still produce a conflict");
 assert.equal(remote.records[0].notes,"Typing");
});
test("a poll started before creation cannot make the acknowledged task disappear",()=>{
 const created={id:"new",serverVersion:0};const map=new Map([["new",created]]);
 assert.deepEqual(mergeWorkspace({records:[]},map,{records:[created]},new Set(),new Map()).records,[created]);
 assert.deepEqual(mergeWorkspace({records:[]},map,{records:[created]},new Set(),new Map([["new",0]])).records,[]);
});

test("compact polls retain hydrated snapshots only for the same server version",()=>{
 const full={id:"a",serverVersion:5,serviceDocuments:[{rev:0,snapshot:{photos:[{id:"p"}]}}]};
 const map=new Map([["a",full]]);
 const compact={...full,serviceDocuments:[{rev:0}]};
 assert.deepEqual(mergeWorkspace({records:[compact]},map,{records:[full]},new Set()).records,[full]);
 const changed={...compact,serverVersion:6};
 assert.deepEqual(mergeWorkspace({records:[changed]},map,{records:[full]},new Set()).records,[changed]);
});
test("every main field is required on both submission and confirmation, supplementary remarks are optional",()=>{
 const complete={...completeFields,id:"a",customer:"Client",address:"Site",projectId:"p",projectCode:"P",feedback:[],photos:[],items:[{...completeItem,id:"i",preset:0,qty:1,price:1}]};
 assert.deepEqual(requiredIssues(complete,true),[]);
 validateWorkerSubmission(complete);validateConfirmation(complete);
 for(const field of ["contact","occupant","tower","floor","flat","notes","completedAt"]){
  const invalid={...complete,[field]:""};
  assert.throws(()=>validateWorkerSubmission(invalid),e=>e.missingFields.includes(field));
  assert.throws(()=>validateConfirmation(invalid),e=>e.missingFields.includes(field));
 }
 assert.ok(requiredIssues({...complete,items:[{...complete.items[0],model:""}]},true).some(e=>e.field==="model"));
});


test("worker times must be explicitly confirmed before continuing",()=>{
 const record={...completeFields,customer:"C",address:"A",photos:[],items:[{...completeItem,preset:0,qty:1}]};
 assert.ok(requiredIssues({...record,timeConfirmed:{startedAt:true,completedAt:false}},true).some(i=>i.field==="completedAt"));
 assert.throws(()=>validateWorkerSubmission({...record,timeConfirmed:{}}),e=>e.missingFields.includes("startedAt"));
});
