import { defineConfig } from "vite";
import vinext from "vinext";
import { cloudflare } from "@cloudflare/vite-plugin";
import path from "node:path";
import { readFileSync } from "node:fs";

export default defineConfig({
  plugins: [
    {
      name: "maintenance-cloudflare-resources",
      enforce: "pre",
      resolveId(source, importer) {
        // PDFKit's Node build resolves ICC profiles from import.meta.url at import time.
        // The browser build embeds them and accepts the same font/image byte buffers.
        if (source === "pdfkit") return path.resolve("node_modules/pdfkit/js/pdfkit.browser.mjs").replaceAll("\\", "/");
        if (!importer || !source.startsWith(".")) return;
        const absolute = path.resolve(path.dirname(importer), source).replace(/\.ts$/, "");
        for (const name of ["db", "pdf-assets", "research-provider", "recovery-document"]) {
          if (absolute === path.resolve("lib", name)) return path.resolve("cloudflare", `${name}.ts`).replaceAll("\\", "/");
        }
      },
      transform(code, id) {
        if (!id.replaceAll("\\", "/").endsWith("/pdfkit/js/pdfkit.browser.mjs")) return;
        // This is an in-memory registry key, not a file read. Workers module URLs
        // are not absolute URLs; keep registration and lookup on a stable key.
        const original = "new URL('./data/sRGB_IEC61966_2_1.icc', import.meta.url).href";
        if (!code.includes(original)) throw new Error("PDFKit ICC adapter requires review after dependency update");
        return { code: code.replace(original, JSON.stringify("pdfkit:srgb-profile")), map: null };
      },
      generateBundle() {
        if (this.environment.name === "client") {
          for (const filename of ["NotoSansHK.ttf", "OFL.txt"]) {
            this.emitFile({ type: "asset", fileName: `pdf-assets/${filename}`, source: readFileSync(`assets/fonts/${filename}`) });
          }
        }
      },
    },
    vinext(),
    cloudflare({
      viteEnvironment: {
        name: "rsc",
        childEnvironments: ["ssr"],
      },
    }),
  ],
});
